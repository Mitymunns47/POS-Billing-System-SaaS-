const { hasPermission } = require('../constants/roles');

function requireRole(allowedRoles) {
  const rolesArray = Array.isArray(allowedRoles) ? allowedRoles : [allowedRoles];

  return (req, res, next) => {
    if (!req.role) {
      return res.status(403).json({
        success: false,
        error: 'Role assignment missing. Access denied.'
      });
    }

    if (!rolesArray.includes(req.role)) {
      return res.status(403).json({
        success: false,
        error: `Access denied. Requires one of roles: ${rolesArray.join(', ')}. Your role is: ${req.role}`,
        code: 'INSUFFICIENT_PERMISSIONS'
      });
    }

    next();
  };
}

function requirePermission(permission) {
  return (req, res, next) => {
    // Owner always has full access
    if (req.role === 'OWNER') {
      return next();
    }

    const perms = req.auth?.permissions || [];
    if (!perms.includes(permission)) {
      return res.status(403).json({
        success: false,
        error: `Access denied. Missing permission: ${permission}`,
        code: 'PERMISSION_DENIED'
      });
    }

    next();
  };
}

module.exports = {
  requireRole,
  requirePermission
};
