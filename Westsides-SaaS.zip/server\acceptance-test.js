/**
 * Westsides Phase 1 Automated End-to-End Acceptance Test
 * Tests the complete flow:
 * 1. Healthcheck & SPA loading
 * 2. Store Creation & Owner Signup (Owner info + Store info)
 * 3. OWNER role assignment & session cookie issuance
 * 4. 4-Step Store Onboarding Wizard progression
 * 5. Current store retrieval (Tenant isolated)
 * 6. Live Cross-Tenant Isolation Security Test (Must block with HTTP 403)
 * 7. Session Logout & session destruction
 * 8. Unauthorized access prevention on protected routes
 * 9. Returning User Login with credential verification
 */

const BASE_URL = 'http://localhost:5000';

async function runAcceptanceTest() {
  console.log('========================================================');
  console.log(' WESTSIDES PHASE 1 - AUTOMATED ACCEPTANCE TEST SUITE');
  console.log('========================================================\n');

  let passedTests = 0;
  let totalTests = 0;

  function assert(condition, message) {
    totalTests++;
    if (condition) {
      console.log(`[PASS] ${message}`);
      passedTests++;
    } else {
      console.error(`[FAIL] ${message}`);
      process.exitCode = 1;
    }
  }

  // 1. Verify Server Health & SPA
  console.log('--- Step 1: Server & SPA Availability ---');
  const healthRes = await fetch(`${BASE_URL}/api/health`);
  const healthData = await healthRes.json();
  assert(healthRes.status === 200 && healthData.status === 'healthy', 'Server is healthy on port 5000');

  const spaRes = await fetch(`${BASE_URL}/`);
  const spaHtml = await spaRes.text();
  assert(spaRes.status === 200 && spaHtml.includes('Westsides'), 'SPA HTML loads with Westsides branding');

  // 2. Signup / Create Your Store
  console.log('\n--- Step 2: Create Your Store (Signup & Tenant Provisioning) ---');
  const uniqueSuffix = Date.now().toString().slice(-5);
  const signupPayload = {
    ownerName: `Vikram Mehta ${uniqueSuffix}`,
    email: `vikram_${uniqueSuffix}@westsides.com`,
    phone: '+91 98201 11222',
    password: 'Password123!',
    confirmPassword: 'Password123!',
    storeName: 'Westsides Flagship',
    storeAddress: '14 Linking Road, Bandra',
    city: 'Mumbai',
    state: 'Maharashtra',
    country: 'India',
    gstNumber: '27AABCV1234F1Z5',
    storePhone: '+91 22 2640 1234'
  };

  const signupRes = await fetch(`${BASE_URL}/api/auth/signup`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(signupPayload)
  });
  const signupData = await signupRes.json();

  assert(signupRes.status === 201, `Signup HTTP status 201 Created (got ${signupRes.status})`);
  assert(signupData.success === true, 'Signup returned success: true');
  assert(signupData.role === 'OWNER', 'Owner role automatically assigned');
  assert(Boolean(signupData.token), 'Authenticated session token generated');
  assert(Boolean(signupData.store.id), `Store created with unique Tenant ID: ${signupData.store?.id}`);
  assert(signupData.store.onboardingCompleted === false, 'Newly created store has onboardingCompleted: false');

  const authToken = signupData.token;
  const storeId = signupData.store.id;
  const authHeaders = {
    'Content-Type': 'application/json',
    'Authorization': `Bearer ${authToken}`
  };

  // 3. Authenticated Session Check (/api/auth/me)
  console.log('\n--- Step 3: Session Validation (/api/auth/me) ---');
  const meRes = await fetch(`${BASE_URL}/api/auth/me`, { headers: authHeaders });
  const meData = await meRes.json();
  assert(meRes.status === 200, 'Authenticated session validated');
  assert(meData.user.email === signupPayload.email, `User email matches (${meData.user.email})`);
  assert(meData.store.id === storeId, `Tenant context matches store ID (${meData.store.id})`);
  assert(meData.role === 'OWNER', 'Role is confirmed as OWNER');
  assert(Array.isArray(meData.permissions) && meData.permissions.length > 5, 'Role permissions matrix attached');

  // 4. Onboarding Wizard Execution (Steps 1 to 4)
  console.log('\n--- Step 4: 4-Step Store Onboarding Wizard ---');
  // Step 1: Store Information
  const obStep1 = await fetch(`${BASE_URL}/api/store/onboarding`, {
    method: 'POST',
    headers: authHeaders,
    body: JSON.stringify({
      step: 2,
      completed: false,
      name: 'Westsides Flagship Store',
      category: 'Apparel & Fashion',
      currency: 'INR'
    })
  });
  assert(obStep1.status === 200, 'Onboarding Step 1 -> Step 2 completed');

  // Step 2: Business & GST Information
  const obStep2 = await fetch(`${BASE_URL}/api/store/onboarding`, {
    method: 'POST',
    headers: authHeaders,
    body: JSON.stringify({
      step: 3,
      completed: false,
      gstNumber: '27AABCV1234F1Z5'
    })
  });
  assert(obStep2.status === 200, 'Onboarding Step 2 -> Step 3 completed');

  // Step 3: Basic Store Configuration
  const obStep3 = await fetch(`${BASE_URL}/api/store/onboarding`, {
    method: 'POST',
    headers: authHeaders,
    body: JSON.stringify({
      step: 4,
      completed: false,
      receiptHeader: 'Westsides - Contemporary Apparel',
      receiptFooter: 'Thank you for shopping! 14-day exchange.'
    })
  });
  assert(obStep3.status === 200, 'Onboarding Step 3 -> Step 4 completed');

  // Step 4: Complete Setup
  const obStep4 = await fetch(`${BASE_URL}/api/store/onboarding`, {
    method: 'POST',
    headers: authHeaders,
    body: JSON.stringify({
      step: 4,
      completed: true
    })
  });
  const obStep4Data = await obStep4.json();
  assert(obStep4.status === 200 && obStep4Data.store.onboardingCompleted === true, 'Onboarding Completed (onboardingCompleted: true)');

  // 5. Verify Store Details & Tenant Boundaries
  console.log('\n--- Step 5: Tenant Isolated Store Details ---');
  const storeRes = await fetch(`${BASE_URL}/api/store/current`, { headers: authHeaders });
  const storeData = await storeRes.json();
  assert(storeRes.status === 200, 'Fetched current store details');
  assert(storeData.store.id === storeId, 'Store ID matches session tenant ID');
  assert(storeData.store.name === 'Westsides Flagship Store', 'Updated store name persisted in SQLite');
  assert(storeData.store.gstNumber === '27AABCV1234F1Z5', 'GST Number persisted');

  // 6. Security Isolation Test: Cross-Tenant Access Block
  console.log('\n--- Step 6: Multi-Tenant Data Isolation Test ---');
  const isolationTestRes = await fetch(`${BASE_URL}/api/store/test-isolation`, {
    method: 'POST',
    headers: authHeaders,
    body: JSON.stringify({ targetStoreId: 'str_foreign_unauthorized_store' })
  });
  const isolationTestData = await isolationTestRes.json();
  assert(
    isolationTestRes.status === 403,
    `Security Boundary: Access to foreign store strictly rejected with HTTP 403 (got ${isolationTestRes.status})`
  );
  assert(
    isolationTestData.isolationEnforced === true,
    'Data isolation enforced flag verified: Store A cannot access Store B'
  );

  // 7. Logout & Session Destruction
  console.log('\n--- Step 7: Logout & Session Destruction ---');
  const logoutRes = await fetch(`${BASE_URL}/api/auth/logout`, {
    method: 'POST',
    headers: authHeaders
  });
  const logoutData = await logoutRes.json();
  assert(logoutRes.status === 200 && logoutData.success === true, 'Logout request succeeded');

  const meAfterLogout = await fetch(`${BASE_URL}/api/auth/me`, { headers: authHeaders });
  assert(
    meAfterLogout.status === 401,
    `Destroyed session rejected with HTTP 401 Unauthorized (got ${meAfterLogout.status})`
  );

  // 8. Returning User Login
  console.log('\n--- Step 8: Returning User Login Flow ---');
  const loginRes = await fetch(`${BASE_URL}/api/auth/login`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      email: signupPayload.email,
      password: signupPayload.password
    })
  });
  const loginData = await loginRes.json();
  assert(loginRes.status === 200 && loginData.success === true, 'Login succeeded for returning user');
  assert(loginData.store.id === storeId, `Identified correct store (${loginData.store.name})`);
  assert(loginData.role === 'OWNER', 'Identified role as OWNER');
  assert(loginData.store.onboardingCompleted === true, 'Directs user to Dashboard (/dashboard)');

  console.log('\n========================================================');
  console.log(` ACCEPTANCE TEST SUMMARY: ${passedTests} / ${totalTests} TESTS PASSED`);
  console.log('========================================================\n');
}

runAcceptanceTest().catch((err) => {
  console.error('Fatal test runner error:', err);
  process.exit(1);
});
