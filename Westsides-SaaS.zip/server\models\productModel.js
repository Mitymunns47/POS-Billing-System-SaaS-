const crypto = require('crypto');
const db = require('../db/database');

const ProductModel = {
  create: ({ storeId, name, sku, categoryId, brandId, description, costPrice, mrp, sellingPrice, barcode, minimumStock }) => {
    // Phase 8: Enforce subscription plan product limit
    try {
      const sub = db.prepare(`
        SELECT sp.maxProducts
        FROM store_subscriptions ss
        JOIN subscription_plans sp ON ss.planId = sp.id
        WHERE ss.storeId = ? AND ss.status IN ('ACTIVE', 'TRIALING')
      `).get(storeId);

      if (sub && sub.maxProducts) {
        const currentProducts = db.prepare('SELECT COUNT(*) as cnt FROM products WHERE storeId = ? AND archived = 0').get(storeId).cnt;
        if (currentProducts >= sub.maxProducts) {
          throw new Error(`Product limit reached for your subscription plan (maximum: ${sub.maxProducts}). Please upgrade your plan.`);
        }
      }
    } catch (err) {
      if (err.message && err.message.includes('Product limit reached')) throw err;
      // If table check fails, do not block creation
    }

    const id = 'prd_' + crypto.randomBytes(8).toString('hex');
    const now = new Date().toISOString();

    db.prepare(`
      INSERT INTO products
        (id, storeId, name, sku, categoryId, brandId, description, costPrice, mrp, sellingPrice, barcode, minimumStock, active, archived, createdAt, updatedAt)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 1, 0, ?, ?)
    `).run(
      id, storeId, name.trim(), sku.trim().toUpperCase(),
      categoryId || null, brandId || null,
      description ? description.trim() : '',
      Number(costPrice) || 0,
      Number(mrp) || 0,
      Number(sellingPrice) || 0,
      barcode ? barcode.trim() : null,
      Number(minimumStock) || 0,
      now, now
    );
    return ProductModel.findById(id, storeId);
  },

  findById: (id, storeId) => {
    const row = db.prepare(`
      SELECT p.*,
        c.name AS categoryName,
        b.name AS brandName
      FROM products p
      LEFT JOIN categories c ON p.categoryId = c.id
      LEFT JOIN brands b ON p.brandId = b.id
      WHERE p.id = ? AND p.storeId = ? AND p.archived = 0
    `).get(id, storeId);
    return row ? { ...row, active: Boolean(row.active) } : null;
  },

  findAll: ({ storeId, search = '', categoryId = '', brandId = '', status = '', page = 1, limit = 20, sortBy = 'createdAt', sortDir = 'DESC' }) => {
    const offset = (page - 1) * limit;
    const conditions = ['p.storeId = ?', 'p.archived = 0'];
    const params = [storeId];

    if (search) {
      conditions.push('(p.name LIKE ? OR p.sku LIKE ? OR p.barcode LIKE ?)');
      const s = `%${search}%`;
      params.push(s, s, s);
    }
    if (categoryId) { conditions.push('p.categoryId = ?'); params.push(categoryId); }
    if (brandId) { conditions.push('p.brandId = ?'); params.push(brandId); }

    const whereClause = conditions.join(' AND ');
    const allowedSorts = ['name', 'sku', 'sellingPrice', 'createdAt', 'updatedAt'];
    const safeSortBy = allowedSorts.includes(sortBy) ? `p.${sortBy}` : 'p.createdAt';
    const safeSortDir = sortDir === 'ASC' ? 'ASC' : 'DESC';

    // Get total count
    const total = db.prepare(`
      SELECT COUNT(*) AS cnt FROM products p WHERE ${whereClause}
    `).get(...params).cnt;

    // Get paginated data with aggregated stock
    const rows = db.prepare(`
      SELECT p.*,
        c.name AS categoryName,
        b.name AS brandName,
        COALESCE(SUM(pv.stock), 0) AS totalStock,
        COUNT(pv.id) AS variantCount
      FROM products p
      LEFT JOIN categories c ON p.categoryId = c.id
      LEFT JOIN brands b ON p.brandId = b.id
      LEFT JOIN product_variants pv ON pv.productId = p.id AND pv.active = 1
      WHERE ${whereClause}
      GROUP BY p.id
      ORDER BY ${safeSortBy} ${safeSortDir}
      LIMIT ? OFFSET ?
    `).all(...params, limit, offset);

    const products = rows.map(r => {
      const totalStock = Number(r.totalStock) || 0;
      const minStock = Number(r.minimumStock) || 0;
      let stockStatus = 'IN_STOCK';
      if (totalStock === 0) stockStatus = 'OUT_OF_STOCK';
      else if (totalStock <= minStock) stockStatus = 'LOW_STOCK';

      return {
        ...r,
        active: Boolean(r.active),
        totalStock,
        variantCount: Number(r.variantCount) || 0,
        stockStatus
      };
    });

    // Filter by status AFTER aggregating
    const filtered = status ? products.filter(p => p.stockStatus === status) : products;

    return {
      products: filtered,
      total,
      page: Number(page),
      limit: Number(limit),
      totalPages: Math.ceil(total / limit)
    };
  },

  update: (id, storeId, fields) => {
    const now = new Date().toISOString();
    if (!ProductModel.findById(id, storeId)) return null;
    const allowed = ['name', 'sku', 'categoryId', 'brandId', 'description', 'costPrice', 'mrp', 'sellingPrice', 'barcode', 'minimumStock', 'active'];
    const sets = [];
    const vals = [];
    for (const key of allowed) {
      if (fields[key] !== undefined) {
        sets.push(`${key} = ?`);
        if (key === 'sku') vals.push(String(fields[key]).trim().toUpperCase());
        else if (key === 'active') vals.push(fields[key] ? 1 : 0);
        else vals.push(fields[key] !== null ? fields[key] : null);
      }
    }
    if (sets.length === 0) return ProductModel.findById(id, storeId);
    sets.push('updatedAt = ?');
    vals.push(now, id, storeId);
    db.prepare(`UPDATE products SET ${sets.join(', ')} WHERE id = ? AND storeId = ?`).run(...vals);
    return ProductModel.findById(id, storeId);
  },

  archive: (id, storeId) => {
    const now = new Date().toISOString();
    const info = db.prepare(
      'UPDATE products SET archived = 1, active = 0, updatedAt = ? WHERE id = ? AND storeId = ?'
    ).run(now, id, storeId);
    return info.changes > 0;
  },

  checkDuplicateSku: (storeId, sku, excludeId = null) => {
    const sql = excludeId
      ? 'SELECT id FROM products WHERE storeId = ? AND sku = ? AND id != ? AND archived = 0'
      : 'SELECT id FROM products WHERE storeId = ? AND sku = ? AND archived = 0';
    const params = excludeId ? [storeId, sku.trim().toUpperCase(), excludeId] : [storeId, sku.trim().toUpperCase()];
    return !!db.prepare(sql).get(...params);
  },

  checkDuplicateBarcode: (storeId, barcode, excludeId = null) => {
    if (!barcode || !barcode.trim()) return false;
    const sql = excludeId
      ? 'SELECT id FROM products WHERE storeId = ? AND barcode = ? AND id != ? AND archived = 0'
      : 'SELECT id FROM products WHERE storeId = ? AND barcode = ? AND archived = 0';
    const params = excludeId ? [storeId, barcode.trim(), excludeId] : [storeId, barcode.trim()];
    return !!db.prepare(sql).get(...params);
  },

  getStats: (storeId) => {
    const total = db.prepare('SELECT COUNT(*) AS c FROM products WHERE storeId = ? AND archived = 0').get(storeId).c;
    const totalUnits = db.prepare(`
      SELECT COALESCE(SUM(pv.stock), 0) AS s
      FROM product_variants pv
      JOIN products p ON pv.productId = p.id
      WHERE p.storeId = ? AND p.archived = 0 AND pv.active = 1
    `).get(storeId).s;

    // Products where total variant stock <= minimumStock and > 0
    const lowStockRows = db.prepare(`
      SELECT p.id, p.minimumStock, COALESCE(SUM(pv.stock),0) as ts
      FROM products p
      LEFT JOIN product_variants pv ON pv.productId = p.id AND pv.active = 1
      WHERE p.storeId = ? AND p.archived = 0
      GROUP BY p.id
    `).all(storeId);

    let lowStock = 0;
    let outOfStock = 0;
    for (const row of lowStockRows) {
      const ts = Number(row.ts);
      const ms = Number(row.minimumStock);
      if (ts === 0) outOfStock++;
      else if (ts <= ms) lowStock++;
    }
    return { total, totalUnits: Number(totalUnits), lowStock, outOfStock };
  }
};

module.exports = ProductModel;
