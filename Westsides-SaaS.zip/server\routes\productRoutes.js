const express = require('express');
const router = express.Router();
const ProductModel = require('../models/productModel');
const VariantModel = require('../models/variantModel');
const InventoryTxModel = require('../models/inventoryTxModel');
const authMiddleware = require('../middleware/auth');
const { requirePermission } = require('../middleware/roles');
const { PERMISSIONS } = require('../constants/roles');

router.use(authMiddleware);

// ── PRODUCTS ──────────────────────────────────────────────────────────────────

// GET /api/products — paginated list with search/filter
router.get('/', requirePermission(PERMISSIONS.PRODUCTS_VIEW), (req, res) => {
  try {
    const { search, categoryId, brandId, status, page = 1, limit = 20, sortBy, sortDir } = req.query;
    const result = ProductModel.findAll({
      storeId: req.storeId,
      search: search || '',
      categoryId: categoryId || '',
      brandId: brandId || '',
      status: status || '',
      page: parseInt(page) || 1,
      limit: Math.min(parseInt(limit) || 20, 100),
      sortBy: sortBy || 'createdAt',
      sortDir: sortDir || 'DESC'
    });
    res.json({ success: true, ...result });
  } catch (err) {
    console.error('List products error:', err);
    res.status(500).json({ success: false, error: 'Could not load products.' });
  }
});

// GET /api/products/stats — dashboard stats
router.get('/stats', requirePermission(PERMISSIONS.PRODUCTS_VIEW), (req, res) => {
  try {
    const stats = ProductModel.getStats(req.storeId);
    res.json({ success: true, stats });
  } catch (err) {
    res.status(500).json({ success: false, error: 'Could not load product stats.' });
  }
});

// GET /api/products/:id — single product with variants
router.get('/:id', requirePermission(PERMISSIONS.PRODUCTS_VIEW), (req, res) => {
  try {
    const product = ProductModel.findById(req.params.id, req.storeId);
    if (!product) return res.status(404).json({ success: false, error: 'Product not found.' });
    const variants = VariantModel.findByProduct(product.id, req.storeId);
    res.json({ success: true, product: { ...product, variants } });
  } catch (err) {
    res.status(500).json({ success: false, error: 'Could not load product.' });
  }
});

// POST /api/products — create product + optional initial variants
router.post('/', requirePermission(PERMISSIONS.PRODUCTS_CREATE), (req, res) => {
  try {
    const {
      name, sku, categoryId, brandId, description,
      costPrice, mrp, sellingPrice, barcode, minimumStock,
      variants = []
    } = req.body;

    // Validation
    if (!name || !name.trim()) return res.status(400).json({ success: false, error: 'Product name is required.' });
    if (!sku || !sku.trim()) return res.status(400).json({ success: false, error: 'SKU is required.' });
    if (sellingPrice === undefined || sellingPrice === null || Number(sellingPrice) < 0) {
      return res.status(400).json({ success: false, error: 'Selling price must be a non-negative number.' });
    }

    // Duplicate SKU check
    if (ProductModel.checkDuplicateSku(req.storeId, sku)) {
      return res.status(400).json({ success: false, error: `SKU "${sku.trim().toUpperCase()}" already exists in this store.` });
    }
    // Duplicate barcode check
    if (barcode && barcode.trim() && ProductModel.checkDuplicateBarcode(req.storeId, barcode)) {
      return res.status(400).json({ success: false, error: `Barcode "${barcode.trim()}" is already assigned to another product.` });
    }

    const product = ProductModel.create({
      storeId: req.storeId,
      name, sku, categoryId, brandId, description,
      costPrice, mrp, sellingPrice, barcode,
      minimumStock: minimumStock || 0
    });

    // Create variants and record initial stock transactions
    const createdVariants = [];
    for (const v of variants) {
      if (v.barcode && v.barcode.trim() && VariantModel.checkDuplicateBarcode(req.storeId, v.barcode)) {
        continue; // Skip duplicate-barcode variants silently (could also reject)
      }
      const variant = VariantModel.create({
        productId: product.id,
        storeId: req.storeId,
        size: v.size,
        color: v.color,
        sku: v.sku,
        barcode: v.barcode,
        price: v.price,
        stock: v.stock || 0,
        minimumStock: v.minimumStock || 0
      });

      if ((v.stock || 0) > 0) {
        InventoryTxModel.record({
          storeId: req.storeId,
          productId: product.id,
          variantId: variant.id,
          action: 'INITIAL_STOCK',
          quantity: variant.stock,
          previousQuantity: 0,
          newQuantity: variant.stock,
          reason: 'Initial stock on product creation',
          performedBy: req.auth.userName,
          note: null
        });
      }
      createdVariants.push(variant);
    }

    res.status(201).json({
      success: true,
      message: 'Product created successfully.',
      product: { ...product, variants: createdVariants }
    });
  } catch (err) {
    console.error('Create product error:', err);
    res.status(500).json({ success: false, error: 'Could not create product.' });
  }
});

// PUT /api/products/:id — update product
router.put('/:id', requirePermission(PERMISSIONS.PRODUCTS_EDIT), (req, res) => {
  try {
    const { name, sku, categoryId, brandId, description, costPrice, mrp, sellingPrice, barcode, minimumStock, active } = req.body;

    if (sku && ProductModel.checkDuplicateSku(req.storeId, sku, req.params.id)) {
      return res.status(400).json({ success: false, error: `SKU "${sku.trim().toUpperCase()}" already exists.` });
    }
    if (barcode && barcode.trim() && ProductModel.checkDuplicateBarcode(req.storeId, barcode, req.params.id)) {
      return res.status(400).json({ success: false, error: `Barcode "${barcode.trim()}" is already assigned to another product.` });
    }

    const updated = ProductModel.update(req.params.id, req.storeId, {
      name, sku, categoryId, brandId, description, costPrice, mrp, sellingPrice, barcode, minimumStock, active
    });

    if (!updated) return res.status(404).json({ success: false, error: 'Product not found.' });
    const variants = VariantModel.findByProduct(updated.id, req.storeId);
    res.json({ success: true, message: 'Product updated.', product: { ...updated, variants } });
  } catch (err) {
    res.status(500).json({ success: false, error: 'Could not update product.' });
  }
});

// DELETE /api/products/:id — soft archive
router.delete('/:id', requirePermission(PERMISSIONS.PRODUCTS_DELETE), (req, res) => {
  try {
    const ok = ProductModel.archive(req.params.id, req.storeId);
    if (!ok) return res.status(404).json({ success: false, error: 'Product not found.' });
    res.json({ success: true, message: 'Product archived. Historical inventory records are preserved.' });
  } catch (err) {
    res.status(500).json({ success: false, error: 'Could not archive product.' });
  }
});

// ── VARIANTS ──────────────────────────────────────────────────────────────────

// GET /api/products/:id/variants
router.get('/:id/variants', requirePermission(PERMISSIONS.PRODUCTS_VIEW), (req, res) => {
  try {
    const product = ProductModel.findById(req.params.id, req.storeId);
    if (!product) return res.status(404).json({ success: false, error: 'Product not found.' });
    const variants = VariantModel.findByProduct(req.params.id, req.storeId);
    res.json({ success: true, variants });
  } catch (err) {
    res.status(500).json({ success: false, error: 'Could not load variants.' });
  }
});

// POST /api/products/:id/variants — add variant
router.post('/:id/variants', requirePermission(PERMISSIONS.PRODUCTS_EDIT), (req, res) => {
  try {
    const product = ProductModel.findById(req.params.id, req.storeId);
    if (!product) return res.status(404).json({ success: false, error: 'Product not found.' });

    const { size, color, sku, barcode, price, stock, minimumStock } = req.body;

    if (barcode && barcode.trim() && VariantModel.checkDuplicateBarcode(req.storeId, barcode)) {
      return res.status(400).json({ success: false, error: `Barcode "${barcode.trim()}" is already in use.` });
    }

    const variant = VariantModel.create({
      productId: product.id,
      storeId: req.storeId,
      size, color, sku, barcode, price,
      stock: stock || 0,
      minimumStock: minimumStock || 0
    });

    if ((stock || 0) > 0) {
      InventoryTxModel.record({
        storeId: req.storeId,
        productId: product.id,
        variantId: variant.id,
        action: 'INITIAL_STOCK',
        quantity: variant.stock,
        previousQuantity: 0,
        newQuantity: variant.stock,
        reason: 'Variant added with initial stock',
        performedBy: req.auth.userName
      });
    }

    res.status(201).json({ success: true, message: 'Variant added.', variant });
  } catch (err) {
    res.status(500).json({ success: false, error: 'Could not add variant.' });
  }
});

// PUT /api/products/:id/variants/:variantId — update variant
router.put('/:id/variants/:variantId', requirePermission(PERMISSIONS.PRODUCTS_EDIT), (req, res) => {
  try {
    const product = ProductModel.findById(req.params.id, req.storeId);
    if (!product) return res.status(404).json({ success: false, error: 'Product not found.' });

    const { barcode } = req.body;
    if (barcode && barcode.trim() && VariantModel.checkDuplicateBarcode(req.storeId, barcode, req.params.variantId)) {
      return res.status(400).json({ success: false, error: `Barcode "${barcode.trim()}" is already in use.` });
    }

    const updated = VariantModel.update(req.params.variantId, req.storeId, req.body);
    if (!updated) return res.status(404).json({ success: false, error: 'Variant not found.' });
    res.json({ success: true, message: 'Variant updated.', variant: updated });
  } catch (err) {
    res.status(500).json({ success: false, error: 'Could not update variant.' });
  }
});

// DELETE /api/products/:id/variants/:variantId
router.delete('/:id/variants/:variantId', requirePermission(PERMISSIONS.PRODUCTS_EDIT), (req, res) => {
  try {
    const product = ProductModel.findById(req.params.id, req.storeId);
    if (!product) return res.status(404).json({ success: false, error: 'Product not found.' });
    const ok = VariantModel.delete(req.params.variantId, req.storeId);
    if (!ok) return res.status(404).json({ success: false, error: 'Variant not found.' });
    res.json({ success: true, message: 'Variant removed.' });
  } catch (err) {
    res.status(500).json({ success: false, error: 'Could not delete variant.' });
  }
});

module.exports = router;
