import React, { useState, useRef, useEffect } from 'react';
import { useAuth } from '../../context/AuthContext';
import { api } from '../../services/api';
import { Badge } from '../ui/Badge';
import {
  Store,
  User,
  Settings,
  LogOut,
  ChevronDown,
  Menu,
  ShieldCheck
} from 'lucide-react';

export function Header({ onToggleSidebar, onNavigate, currentPath, isSidebarCollapsed }) {
  const { user, store, role, logout } = useAuth();
  const [dropdownOpen, setDropdownOpen] = useState(false);
  const dropdownRef = useRef(null);

  // Close dropdown on outside click
  useEffect(() => {
    function handleClickOutside(event) {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target)) {
        setDropdownOpen(false);
      }
    }
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const handleLogout = async () => {
    setDropdownOpen(false);
    await logout();
    if (onNavigate) onNavigate('/login');
  };

  return (
    <header
      style={{
        height: '64px',
        backgroundColor: '#FFFFFF',
        borderBottom: '1px solid var(--border-color)',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'space-between',
        padding: '0 1.5rem',
        position: 'sticky',
        top: 0,
        zIndex: 40
      }}
    >
      {/* Left side: Hamburger (mobile) + Brand/Store context */}
      <div style={{ display: 'flex', alignItems: 'center', gap: '1rem' }}>
        <button
          onClick={onToggleSidebar}
          style={{
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            background: 'none',
            border: 'none',
            cursor: 'pointer',
            padding: '6px 8px',
            color: 'var(--text-main)',
            borderRadius: 'var(--radius-md)',
            transition: 'background-color 0.15s ease'
          }}
          onMouseEnter={(e) => (e.currentTarget.style.backgroundColor = 'var(--bg-page)')}
          onMouseLeave={(e) => (e.currentTarget.style.backgroundColor = 'transparent')}
          title="Toggle navigation sidebar"
          aria-label="Toggle navigation sidebar"
        >
          <Menu size={20} />
        </button>

        <div style={{ display: 'flex', alignItems: 'center', gap: '0.75rem' }}>
          <div
            style={{
              width: '32px',
              height: '32px',
              borderRadius: '8px',
              backgroundColor: '#7EAFD0',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              color: '#FFFFFF',
              fontWeight: '700',
              fontSize: '1rem',
              letterSpacing: '0.5px'
            }}
          >
            W
          </div>
          <div>
            <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
              <span style={{ fontWeight: '700', fontSize: '1rem', color: 'var(--text-main)', letterSpacing: '0.5px' }}>
                WESTSIDES
              </span>
              <span style={{ fontSize: '0.75rem', color: 'var(--text-muted)', display: 'none' }} className="brand-subtitle">
                Clothing Store Management
              </span>
            </div>
          </div>
        </div>

        {/* Current Active Store indicator */}
        <div
          style={{
            marginLeft: '1rem',
            paddingLeft: '1rem',
            borderLeft: '1px solid var(--border-color)',
            display: 'flex',
            alignItems: 'center',
            gap: '8px'
          }}
          className="header-store-badge"
        >
          <Store size={16} color="#7EAFD0" />
          <span style={{ fontSize: '0.8125rem', color: 'var(--text-muted)' }}>Store:</span>
          <span style={{ fontSize: '0.875rem', fontWeight: '600', color: 'var(--text-main)' }}>
            {store?.name || 'Westsides'}
          </span>
        </div>
      </div>

      {/* Right side: User info, Role Badge, Profile dropdown */}
      <div style={{ display: 'flex', alignItems: 'center', gap: '1rem' }}>
        <div style={{ textAlign: 'right', display: 'none' }} className="header-user-text">
          <div style={{ fontSize: '0.875rem', fontWeight: '600', color: 'var(--text-main)' }}>
            {user?.name || 'Store Owner'}
          </div>
          <div style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>
            {user?.email}
          </div>
        </div>

        <Badge variant="primary" size="md">
          {role || 'OWNER'}
        </Badge>


        {/* Profile Dropdown */}
        <div style={{ position: 'relative' }} ref={dropdownRef}>
          <button
            onClick={() => setDropdownOpen(!dropdownOpen)}
            style={{
              display: 'flex',
              alignItems: 'center',
              gap: '6px',
              padding: '6px 10px',
              background: dropdownOpen ? 'var(--bg-page)' : 'transparent',
              border: '1px solid var(--border-color)',
              borderRadius: 'var(--radius-md)',
              cursor: 'pointer',
              color: 'var(--text-main)',
              transition: 'background 0.15s ease'
            }}
            aria-expanded={dropdownOpen}
            aria-haspopup="true"
          >
            <div
              style={{
                width: '26px',
                height: '26px',
                borderRadius: '50%',
                backgroundColor: 'var(--primary-light)',
                color: '#4B7C9E',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                fontSize: '0.75rem',
                fontWeight: '600'
              }}
            >
              {user?.name ? user.name.charAt(0).toUpperCase() : 'U'}
            </div>
            <ChevronDown size={14} color="var(--text-muted)" />
          </button>

          {dropdownOpen && (
            <div
              style={{
                position: 'absolute',
                right: 0,
                top: 'calc(100% + 8px)',
                width: '240px',
                backgroundColor: '#FFFFFF',
                borderRadius: 'var(--radius-md)',
                border: '1px solid var(--border-color)',
                boxShadow: 'var(--shadow-lg)',
                padding: '8px 0',
                zIndex: 50
              }}
              className="animate-fade-in"
            >
              <div
                style={{
                  padding: '10px 16px',
                  borderBottom: '1px solid var(--border-subtle)',
                  marginBottom: '6px'
                }}
              >
                <div style={{ fontWeight: '600', fontSize: '0.875rem', color: 'var(--text-main)' }}>
                  {user?.name}
                </div>
                <div style={{ fontSize: '0.75rem', color: 'var(--text-muted)', overflow: 'hidden', textOverflow: 'ellipsis' }}>
                  {user?.email}
                </div>
                <div style={{ marginTop: '6px', display: 'flex', gap: '6px', alignItems: 'center' }}>
                  <Badge variant="default" size="sm">Store: {store?.name}</Badge>
                </div>
              </div>

              <button
                onClick={() => {
                  setDropdownOpen(false);
                  if (onNavigate) onNavigate('/profile');
                }}
                style={{
                  width: '100%',
                  padding: '8px 16px',
                  display: 'flex',
                  alignItems: 'center',
                  gap: '10px',
                  background: 'none',
                  border: 'none',
                  cursor: 'pointer',
                  textAlign: 'left',
                  fontSize: '0.875rem',
                  color: 'var(--text-main)',
                  transition: 'background 0.15s ease'
                }}
                onMouseEnter={(e) => (e.currentTarget.style.backgroundColor = 'var(--bg-page)')}
                onMouseLeave={(e) => (e.currentTarget.style.backgroundColor = 'transparent')}
              >
                <User size={16} color="var(--text-muted)" />
                <span>Profile</span>
              </button>

              {role === 'OWNER' && (
                <button
                  onClick={() => {
                    setDropdownOpen(false);
                    if (onNavigate) onNavigate('/profile?tab=store');
                  }}
                  style={{
                    width: '100%',
                    padding: '8px 16px',
                    display: 'flex',
                    alignItems: 'center',
                    gap: '10px',
                    background: 'none',
                    border: 'none',
                    cursor: 'pointer',
                    textAlign: 'left',
                    fontSize: '0.875rem',
                    color: 'var(--text-main)',
                    transition: 'background 0.15s ease'
                  }}
                  onMouseEnter={(e) => (e.currentTarget.style.backgroundColor = 'var(--bg-page)')}
                  onMouseLeave={(e) => (e.currentTarget.style.backgroundColor = 'transparent')}
                >
                  <Settings size={16} color="var(--text-muted)" />
                  <span>Store Settings</span>
                </button>
              )}

              <div style={{ height: '1px', backgroundColor: 'var(--border-subtle)', margin: '6px 0' }} />

              <button
                onClick={handleLogout}
                style={{
                  width: '100%',
                  padding: '8px 16px',
                  display: 'flex',
                  alignItems: 'center',
                  gap: '10px',
                  background: 'none',
                  border: 'none',
                  cursor: 'pointer',
                  textAlign: 'left',
                  fontSize: '0.875rem',
                  color: 'var(--danger)',
                  transition: 'background 0.15s ease'
                }}
                onMouseEnter={(e) => (e.currentTarget.style.backgroundColor = 'var(--danger-light)')}
                onMouseLeave={(e) => (e.currentTarget.style.backgroundColor = 'transparent')}
              >
                <LogOut size={16} color="var(--danger)" />
                <span style={{ fontWeight: '500' }}>Logout</span>
              </button>
            </div>
          )}
        </div>
      </div>
    </header>
  );
}
