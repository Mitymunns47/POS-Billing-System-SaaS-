// Phase 3 — Database schema additions
// Appended to existing database.js initialization

const { DatabaseSync } = require('node:sqlite');
const path = require('path');
const fs = require('fs');
const config = require('../config');

// Ensure database directory exists
const dbDir = path.dirname(path.resolve(config.dbPath));
if (!fs.existsSync(dbDir)) {
  fs.mkdirSync(dbDir, { recursive: true });
}

const db = new DatabaseSync(path.resolve(config.dbPath));

// Enable foreign keys
db.exec('PRAGMA foreign_keys = ON;');
db.exec('PRAGMA journal_mode = WAL;');

// Initialize tables
db.exec(`
  CREATE TABLE IF NOT EXISTS stores (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    address TEXT,
    city TEXT,
    state TEXT,
    country TEXT DEFAULT 'India',
    gstNumber TEXT,
    phone TEXT,
    currency TEXT DEFAULT 'INR',
    category TEXT DEFAULT 'Apparel & Fashion',
    receiptHeader TEXT,
    receiptFooter TEXT,
    onboardingStep INTEGER DEFAULT 1,
    onboardingCompleted INTEGER DEFAULT 0,
    createdAt TEXT NOT NULL,
    updatedAt TEXT NOT NULL
  );

  CREATE TABLE IF NOT EXISTS users (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    email TEXT UNIQUE NOT NULL,
    phone TEXT,
    passwordHash TEXT NOT NULL,
    createdAt TEXT NOT NULL,
    updatedAt TEXT NOT NULL
  );

  CREATE TABLE IF NOT EXISTS store_users (
    id TEXT PRIMARY KEY,
    storeId TEXT NOT NULL,
    userId TEXT NOT NULL,
    role TEXT NOT NULL,
    createdAt TEXT NOT NULL,
    FOREIGN KEY (storeId) REFERENCES stores(id) ON DELETE CASCADE,
    FOREIGN KEY (userId) REFERENCES users(id) ON DELETE CASCADE
  );

  CREATE TABLE IF NOT EXISTS sessions (
    id TEXT PRIMARY KEY,
    token TEXT UNIQUE NOT NULL,
    userId TEXT NOT NULL,
    storeId TEXT NOT NULL,
    expiresAt TEXT NOT NULL,
    createdAt TEXT NOT NULL,
    FOREIGN KEY (userId) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (storeId) REFERENCES stores(id) ON DELETE CASCADE
  );

  CREATE INDEX IF NOT EXISTS idx_users_email ON users(email);
  CREATE INDEX IF NOT EXISTS idx_store_users_store ON store_users(storeId);
  CREATE INDEX IF NOT EXISTS idx_store_users_user ON store_users(userId);
  CREATE INDEX IF NOT EXISTS idx_sessions_token ON sessions(token);

  -- Phase 2: Categories (per store/tenant)
  CREATE TABLE IF NOT EXISTS categories (
    id TEXT PRIMARY KEY,
    storeId TEXT NOT NULL,
    name TEXT NOT NULL,
    description TEXT,
    active INTEGER DEFAULT 1,
    createdAt TEXT NOT NULL,
    updatedAt TEXT NOT NULL,
    FOREIGN KEY (storeId) REFERENCES stores(id) ON DELETE CASCADE
  );

  -- Phase 2: Brands (per store/tenant)
  CREATE TABLE IF NOT EXISTS brands (
    id TEXT PRIMARY KEY,
    storeId TEXT NOT NULL,
    name TEXT NOT NULL,
    description TEXT,
    active INTEGER DEFAULT 1,
    createdAt TEXT NOT NULL,
    updatedAt TEXT NOT NULL,
    FOREIGN KEY (storeId) REFERENCES stores(id) ON DELETE CASCADE
  );

  -- Phase 2: Products (per store/tenant)
  CREATE TABLE IF NOT EXISTS products (
    id TEXT PRIMARY KEY,
    storeId TEXT NOT NULL,
    name TEXT NOT NULL,
    sku TEXT NOT NULL,
    categoryId TEXT,
    brandId TEXT,
    description TEXT,
    costPrice REAL DEFAULT 0,
    mrp REAL DEFAULT 0,
    sellingPrice REAL DEFAULT 0,
    barcode TEXT,
    image TEXT,
    minimumStock INTEGER DEFAULT 0,
    active INTEGER DEFAULT 1,
    archived INTEGER DEFAULT 0,
    createdAt TEXT NOT NULL,
    updatedAt TEXT NOT NULL,
    FOREIGN KEY (storeId) REFERENCES stores(id) ON DELETE CASCADE,
    FOREIGN KEY (categoryId) REFERENCES categories(id) ON DELETE SET NULL,
    FOREIGN KEY (brandId) REFERENCES brands(id) ON DELETE SET NULL
  );

  -- Phase 2: Product Variants (sizes, colors etc.)
  CREATE TABLE IF NOT EXISTS product_variants (
    id TEXT PRIMARY KEY,
    productId TEXT NOT NULL,
    storeId TEXT NOT NULL,
    size TEXT,
    color TEXT,
    sku TEXT,
    barcode TEXT,
    price REAL,
    stock INTEGER DEFAULT 0,
    minimumStock INTEGER DEFAULT 0,
    active INTEGER DEFAULT 1,
    createdAt TEXT NOT NULL,
    updatedAt TEXT NOT NULL,
    FOREIGN KEY (productId) REFERENCES products(id) ON DELETE CASCADE,
    FOREIGN KEY (storeId) REFERENCES stores(id) ON DELETE CASCADE
  );

  -- Phase 2: Inventory Transactions (immutable audit trail)
  CREATE TABLE IF NOT EXISTS inventory_transactions (
    id TEXT PRIMARY KEY,
    storeId TEXT NOT NULL,
    productId TEXT NOT NULL,
    variantId TEXT,
    action TEXT NOT NULL,
    quantity INTEGER NOT NULL,
    previousQuantity INTEGER NOT NULL,
    newQuantity INTEGER NOT NULL,
    reason TEXT,
    performedBy TEXT NOT NULL,
    note TEXT,
    createdAt TEXT NOT NULL,
    FOREIGN KEY (storeId) REFERENCES stores(id) ON DELETE CASCADE,
    FOREIGN KEY (productId) REFERENCES products(id) ON DELETE CASCADE,
    FOREIGN KEY (variantId) REFERENCES product_variants(id) ON DELETE SET NULL
  );

  -- Phase 2: Indexes for performance and tenant isolation
  CREATE INDEX IF NOT EXISTS idx_categories_store ON categories(storeId);
  CREATE INDEX IF NOT EXISTS idx_brands_store ON brands(storeId);
  CREATE INDEX IF NOT EXISTS idx_products_store ON products(storeId);
  CREATE INDEX IF NOT EXISTS idx_products_sku ON products(storeId, sku);
  CREATE INDEX IF NOT EXISTS idx_products_barcode ON products(storeId, barcode);
  CREATE INDEX IF NOT EXISTS idx_variants_product ON product_variants(productId);
  CREATE INDEX IF NOT EXISTS idx_variants_store ON product_variants(storeId);
  CREATE INDEX IF NOT EXISTS idx_variants_barcode ON product_variants(storeId, barcode);
  CREATE INDEX IF NOT EXISTS idx_inv_tx_store ON inventory_transactions(storeId);
  CREATE INDEX IF NOT EXISTS idx_inv_tx_product ON inventory_transactions(productId);

  -- Phase 3: Customers (per store/tenant)
  CREATE TABLE IF NOT EXISTS customers (
    id TEXT PRIMARY KEY,
    storeId TEXT NOT NULL,
    name TEXT NOT NULL,
    phone TEXT,
    email TEXT,
    address TEXT,
    totalPurchases INTEGER DEFAULT 0,
    totalSpent REAL DEFAULT 0,
    active INTEGER DEFAULT 1,
    createdAt TEXT NOT NULL,
    updatedAt TEXT NOT NULL,
    FOREIGN KEY (storeId) REFERENCES stores(id) ON DELETE CASCADE
  );

  -- Phase 3: Invoice number counter (per store, ensures sequential & collision-free)
  CREATE TABLE IF NOT EXISTS invoice_counters (
    storeId TEXT PRIMARY KEY,
    lastNumber INTEGER DEFAULT 0,
    prefix TEXT DEFAULT 'WS',
    FOREIGN KEY (storeId) REFERENCES stores(id) ON DELETE CASCADE
  );

  -- Phase 3: Sales transactions
  CREATE TABLE IF NOT EXISTS sales (
    id TEXT PRIMARY KEY,
    storeId TEXT NOT NULL,
    invoiceNumber TEXT NOT NULL,
    customerId TEXT,
    cashierId TEXT NOT NULL,
    cashierName TEXT NOT NULL,
    subtotal REAL NOT NULL,
    discountType TEXT DEFAULT 'none',
    discountValue REAL DEFAULT 0,
    discountAmount REAL DEFAULT 0,
    taxRate REAL DEFAULT 0,
    taxAmount REAL DEFAULT 0,
    totalAmount REAL NOT NULL,
    paymentMethod TEXT NOT NULL,
    paymentAmount REAL NOT NULL,
    changeAmount REAL DEFAULT 0,
    status TEXT DEFAULT 'COMPLETED',
    note TEXT,
    createdAt TEXT NOT NULL,
    updatedAt TEXT NOT NULL,
    FOREIGN KEY (storeId) REFERENCES stores(id) ON DELETE CASCADE,
    FOREIGN KEY (customerId) REFERENCES customers(id) ON DELETE SET NULL
  );

  -- Phase 3: Sale items (with product snapshots for historical accuracy)
  CREATE TABLE IF NOT EXISTS sale_items (
    id TEXT PRIMARY KEY,
    saleId TEXT NOT NULL,
    storeId TEXT NOT NULL,
    productId TEXT NOT NULL,
    variantId TEXT,
    productNameSnapshot TEXT NOT NULL,
    skuSnapshot TEXT,
    sizeSnapshot TEXT,
    colorSnapshot TEXT,
    barcodeSnapshot TEXT,
    unitPrice REAL NOT NULL,
    quantity INTEGER NOT NULL,
    discountAmount REAL DEFAULT 0,
    taxAmount REAL DEFAULT 0,
    lineTotal REAL NOT NULL,
    FOREIGN KEY (saleId) REFERENCES sales(id) ON DELETE CASCADE,
    FOREIGN KEY (storeId) REFERENCES stores(id) ON DELETE CASCADE
  );

  -- Phase 3: Store tax settings
  CREATE TABLE IF NOT EXISTS store_tax_settings (
    storeId TEXT PRIMARY KEY,
    taxEnabled INTEGER DEFAULT 0,
    taxName TEXT DEFAULT 'GST',
    taxRate REAL DEFAULT 18.0,
    taxInclusive INTEGER DEFAULT 0,
    updatedAt TEXT NOT NULL,
    FOREIGN KEY (storeId) REFERENCES stores(id) ON DELETE CASCADE
  );

  -- Phase 3: Indexes
  CREATE INDEX IF NOT EXISTS idx_customers_store ON customers(storeId);
  CREATE INDEX IF NOT EXISTS idx_customers_phone ON customers(storeId, phone);
  CREATE INDEX IF NOT EXISTS idx_sales_store ON sales(storeId);
  CREATE INDEX IF NOT EXISTS idx_sales_invoice ON sales(storeId, invoiceNumber);
  CREATE INDEX IF NOT EXISTS idx_sales_customer ON sales(customerId);
  CREATE INDEX IF NOT EXISTS idx_sales_cashier ON sales(cashierId);
  CREATE INDEX IF NOT EXISTS idx_sales_created ON sales(storeId, createdAt);
  CREATE INDEX IF NOT EXISTS idx_sale_items_sale ON sale_items(saleId);
  CREATE INDEX IF NOT EXISTS idx_sale_items_store ON sale_items(storeId);

  -- Phase 4: User-specific permission overrides (overrides role defaults)
  CREATE TABLE IF NOT EXISTS user_permissions (
    id TEXT PRIMARY KEY,
    storeId TEXT NOT NULL,
    userId TEXT NOT NULL,
    permissionKey TEXT NOT NULL,
    allowed INTEGER NOT NULL DEFAULT 1,
    updatedAt TEXT NOT NULL,
    FOREIGN KEY (storeId) REFERENCES stores(id) ON DELETE CASCADE,
    FOREIGN KEY (userId) REFERENCES users(id) ON DELETE CASCADE,
    UNIQUE(storeId, userId, permissionKey)
  );

  -- Phase 4: Staff activity / audit log
  CREATE TABLE IF NOT EXISTS activity_logs (
    id TEXT PRIMARY KEY,
    storeId TEXT NOT NULL,
    userId TEXT NOT NULL,
    userName TEXT NOT NULL,
    action TEXT NOT NULL,
    module TEXT NOT NULL,
    description TEXT NOT NULL,
    recordId TEXT,
    createdAt TEXT NOT NULL,
    FOREIGN KEY (storeId) REFERENCES stores(id) ON DELETE CASCADE,
    FOREIGN KEY (userId) REFERENCES users(id) ON DELETE CASCADE
  );

  -- Phase 4: Staff attendance
  CREATE TABLE IF NOT EXISTS attendance (
    id TEXT PRIMARY KEY,
    storeId TEXT NOT NULL,
    userId TEXT NOT NULL,
    date TEXT NOT NULL,
    checkIn TEXT,
    checkOut TEXT,
    status TEXT NOT NULL DEFAULT 'PRESENT',
    notes TEXT,
    createdAt TEXT NOT NULL,
    updatedAt TEXT NOT NULL,
    FOREIGN KEY (storeId) REFERENCES stores(id) ON DELETE CASCADE,
    FOREIGN KEY (userId) REFERENCES users(id) ON DELETE CASCADE,
    UNIQUE(storeId, userId, date)
  );

  -- Phase 4: Indexes
  CREATE INDEX IF NOT EXISTS idx_user_perms_store_user ON user_permissions(storeId, userId);
  CREATE INDEX IF NOT EXISTS idx_activity_store ON activity_logs(storeId);
  CREATE INDEX IF NOT EXISTS idx_activity_user ON activity_logs(userId);
  CREATE INDEX IF NOT EXISTS idx_activity_module ON activity_logs(storeId, module);
  CREATE INDEX IF NOT EXISTS idx_activity_created ON activity_logs(storeId, createdAt);
  CREATE INDEX IF NOT EXISTS idx_attendance_store_date ON attendance(storeId, date);
  CREATE INDEX IF NOT EXISTS idx_attendance_user ON attendance(userId);

  -- Phase 5: Expenses table (per store/tenant)
  CREATE TABLE IF NOT EXISTS expenses (
    id TEXT PRIMARY KEY,
    storeId TEXT NOT NULL,
    title TEXT NOT NULL,
    category TEXT NOT NULL,
    amount REAL NOT NULL,
    date TEXT NOT NULL,
    notes TEXT,
    createdBy TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'ACTIVE',
    createdAt TEXT NOT NULL,
    updatedAt TEXT NOT NULL,
    FOREIGN KEY (storeId) REFERENCES stores(id) ON DELETE CASCADE
  );

  -- Phase 5: Reporting and Financial Indexes
  CREATE INDEX IF NOT EXISTS idx_sales_status_date ON sales(storeId, status, createdAt);
  CREATE INDEX IF NOT EXISTS idx_sales_payment ON sales(storeId, paymentMethod);
  CREATE INDEX IF NOT EXISTS idx_sale_items_product ON sale_items(storeId, productId);
  CREATE INDEX IF NOT EXISTS idx_sale_items_variant ON sale_items(storeId, variantId);
  CREATE INDEX IF NOT EXISTS idx_inv_tx_created ON inventory_transactions(storeId, createdAt);
  CREATE INDEX IF NOT EXISTS idx_inv_tx_type ON inventory_transactions(storeId, action);
  CREATE INDEX IF NOT EXISTS idx_expenses_store_date ON expenses(storeId, date);
  CREATE INDEX IF NOT EXISTS idx_expenses_store_category ON expenses(storeId, category);
  CREATE INDEX IF NOT EXISTS idx_expenses_store_status ON expenses(storeId, status);

  -- Phase 6: Sales Returns & Refunds
  CREATE TABLE IF NOT EXISTS returns (
    id TEXT PRIMARY KEY,
    storeId TEXT NOT NULL,
    saleId TEXT NOT NULL,
    invoiceNumber TEXT NOT NULL,
    customerId TEXT,
    staffId TEXT NOT NULL,
    staffName TEXT NOT NULL,
    totalRefundAmount REAL NOT NULL,
    refundMethod TEXT NOT NULL,
    reason TEXT NOT NULL,
    notes TEXT,
    status TEXT NOT NULL DEFAULT 'COMPLETED',
    createdAt TEXT NOT NULL,
    updatedAt TEXT NOT NULL,
    FOREIGN KEY (storeId) REFERENCES stores(id) ON DELETE CASCADE,
    FOREIGN KEY (saleId) REFERENCES sales(id) ON DELETE CASCADE,
    FOREIGN KEY (customerId) REFERENCES customers(id) ON DELETE SET NULL
  );

  CREATE TABLE IF NOT EXISTS return_items (
    id TEXT PRIMARY KEY,
    returnId TEXT NOT NULL,
    saleItemId TEXT NOT NULL,
    productId TEXT NOT NULL,
    variantId TEXT,
    productNameSnapshot TEXT NOT NULL,
    skuSnapshot TEXT,
    sizeSnapshot TEXT,
    colorSnapshot TEXT,
    quantity INTEGER NOT NULL,
    unitPrice REAL NOT NULL,
    discountAmount REAL DEFAULT 0,
    taxAmount REAL DEFAULT 0,
    refundAmount REAL NOT NULL,
    condition TEXT NOT NULL DEFAULT 'RESELLABLE',
    createdAt TEXT NOT NULL,
    FOREIGN KEY (returnId) REFERENCES returns(id) ON DELETE CASCADE,
    FOREIGN KEY (saleItemId) REFERENCES sale_items(id) ON DELETE CASCADE
  );

  -- Phase 6: Store Settings & Operational Controls
  CREATE TABLE IF NOT EXISTS store_settings (
    storeId TEXT PRIMARY KEY,
    storeName TEXT,
    storeLogo TEXT,
    phone TEXT,
    email TEXT,
    address TEXT,
    city TEXT,
    state TEXT,
    postalCode TEXT,
    country TEXT DEFAULT 'India',
    description TEXT,
    gstNumber TEXT,
    legalBusinessName TEXT,
    taxEnabled INTEGER DEFAULT 0,
    taxName TEXT DEFAULT 'GST',
    taxRate REAL DEFAULT 18.0,
    taxInclusive INTEGER DEFAULT 0,
    invoicePrefix TEXT DEFAULT 'WS',
    footerNote TEXT DEFAULT 'Thank you for shopping with Westsides!',
    returnPolicy TEXT DEFAULT 'Items in resellable condition can be returned within 14 days with original receipt.',
    receiptContact TEXT,
    allowNegativeInventory INTEGER DEFAULT 0,
    requireCustomerForSale INTEGER DEFAULT 0,
    allowDiscounts INTEGER DEFAULT 1,
    maxDiscountPercent REAL DEFAULT 50.0,
    requireManagerDiscountApproval INTEGER DEFAULT 0,
    defaultPaymentMethod TEXT DEFAULT 'CASH',
    defaultMinStock INTEGER DEFAULT 5,
    lowStockAlerts INTEGER DEFAULT 1,
    outOfStockAlerts INTEGER DEFAULT 1,
    updatedAt TEXT NOT NULL,
    FOREIGN KEY (storeId) REFERENCES stores(id) ON DELETE CASCADE
  );

  -- Phase 6: Notification & Alert Center
  CREATE TABLE IF NOT EXISTS notifications (
    id TEXT PRIMARY KEY,
    storeId TEXT NOT NULL,
    userId TEXT,
    targetRole TEXT DEFAULT 'ALL',
    type TEXT NOT NULL,
    title TEXT NOT NULL,
    message TEXT NOT NULL,
    recordId TEXT,
    recordType TEXT,
    isRead INTEGER DEFAULT 0,
    createdAt TEXT NOT NULL,
    FOREIGN KEY (storeId) REFERENCES stores(id) ON DELETE CASCADE
  );

  -- Phase 6: Indexes
  CREATE INDEX IF NOT EXISTS idx_returns_store ON returns(storeId);
  CREATE INDEX IF NOT EXISTS idx_returns_sale ON returns(saleId);
  CREATE INDEX IF NOT EXISTS idx_returns_customer ON returns(customerId);
  CREATE INDEX IF NOT EXISTS idx_returns_created ON returns(storeId, createdAt);
  CREATE INDEX IF NOT EXISTS idx_return_items_return ON return_items(returnId);
  CREATE INDEX IF NOT EXISTS idx_return_items_product ON return_items(productId);
  CREATE INDEX IF NOT EXISTS idx_notifications_store ON notifications(storeId);
  CREATE INDEX IF NOT EXISTS idx_notifications_store_read ON notifications(storeId, isRead);
  CREATE INDEX IF NOT EXISTS idx_notifications_type_record ON notifications(storeId, type, recordId);
`);

// ── Phase 4 Safe Column Migrations ─────────────────────────────────────────────
function ensureColumn(tableName, columnName, columnDefinition) {
  try {
    const columns = db.prepare(`PRAGMA table_info(${tableName})`).all();
    const exists = columns.some(col => col.name === columnName);
    if (!exists) {
      db.exec(`ALTER TABLE ${tableName} ADD COLUMN ${columnName} ${columnDefinition}`);
    }
  } catch (err) {
    console.error(`Error ensuring column ${columnName} on ${tableName}:`, err);
  }
}

// Customers table extensions
ensureColumn('customers', 'dateOfBirth', 'TEXT');
ensureColumn('customers', 'gender', 'TEXT');
ensureColumn('customers', 'city', 'TEXT');
ensureColumn('customers', 'state', 'TEXT');
ensureColumn('customers', 'postalCode', 'TEXT');
ensureColumn('customers', 'notes', 'TEXT');
ensureColumn('customers', 'status', "TEXT DEFAULT 'ACTIVE'");

// Backfill status from active for existing customer rows
try {
  db.exec("UPDATE customers SET status = 'ACTIVE' WHERE status IS NULL OR status = ''");
  db.exec("UPDATE customers SET status = 'ARCHIVED' WHERE active = 0 AND status = 'ACTIVE'");
} catch {
  // Ignore if already set
}

// Store users table extensions (staff status and timestamps)
ensureColumn('store_users', 'status', "TEXT DEFAULT 'ACTIVE'");
ensureColumn('store_users', 'updatedAt', 'TEXT');
ensureColumn('store_users', 'lastLoginAt', 'TEXT');

// Backfill store_users status
try {
  db.exec("UPDATE store_users SET status = 'ACTIVE' WHERE status IS NULL OR status = ''");
} catch {
  // Ignore
}

// Phase 6: Expenses paymentMethod
ensureColumn('expenses', 'paymentMethod', "TEXT DEFAULT 'CASH'");

// ─────────────────────────────────────────────────────────────────────────────
// PHASE 7: SaaS Platform Administration, Subscriptions & Tenant Management
// ─────────────────────────────────────────────────────────────────────────────
db.exec(`
  -- Phase 7: Platform Admin Users (separate from store users)
  CREATE TABLE IF NOT EXISTS platform_admins (
    id TEXT PRIMARY KEY,
    userId TEXT NOT NULL UNIQUE,
    platformRole TEXT NOT NULL DEFAULT 'SUPER_ADMIN',
    isActive INTEGER DEFAULT 1,
    createdBy TEXT,
    createdAt TEXT NOT NULL,
    updatedAt TEXT NOT NULL,
    FOREIGN KEY (userId) REFERENCES users(id) ON DELETE CASCADE
  );

  -- Phase 7: Subscription Plans (database-driven, not hardcoded)
  CREATE TABLE IF NOT EXISTS subscription_plans (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL UNIQUE,
    slug TEXT NOT NULL UNIQUE,
    description TEXT,
    price REAL NOT NULL DEFAULT 0,
    billingInterval TEXT NOT NULL DEFAULT 'monthly',
    trialDays INTEGER DEFAULT 14,
    maxUsers INTEGER DEFAULT 5,
    maxProducts INTEGER DEFAULT 100,
    maxCustomers INTEGER DEFAULT 500,
    currency TEXT NOT NULL DEFAULT 'INR',
    isActive INTEGER DEFAULT 1,
    isDefault INTEGER DEFAULT 0,
    sortOrder INTEGER DEFAULT 0,
    createdAt TEXT NOT NULL,
    updatedAt TEXT NOT NULL
  );

  -- Phase 7: Plan Feature Entitlements
  CREATE TABLE IF NOT EXISTS plan_features (
    id TEXT PRIMARY KEY,
    planId TEXT NOT NULL,
    featureKey TEXT NOT NULL,
    enabled INTEGER DEFAULT 1,
    FOREIGN KEY (planId) REFERENCES subscription_plans(id) ON DELETE CASCADE,
    UNIQUE(planId, featureKey)
  );

  -- Phase 7: Store Subscriptions (one per store)
  CREATE TABLE IF NOT EXISTS store_subscriptions (
    id TEXT PRIMARY KEY,
    storeId TEXT NOT NULL UNIQUE,
    planId TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'TRIALING',
    trialStartDate TEXT,
    trialEndDate TEXT,
    currentPeriodStart TEXT,
    currentPeriodEnd TEXT,
    cancelledAt TEXT,
    suspendedAt TEXT,
    suspendedBy TEXT,
    suspensionReason TEXT,
    createdAt TEXT NOT NULL,
    updatedAt TEXT NOT NULL,
    FOREIGN KEY (storeId) REFERENCES stores(id) ON DELETE CASCADE,
    FOREIGN KEY (planId) REFERENCES subscription_plans(id)
  );

  -- Phase 7: Subscription Invoices (SaaS billing, NOT store customer invoices)
  CREATE TABLE IF NOT EXISTS subscription_invoices (
    id TEXT PRIMARY KEY,
    storeId TEXT NOT NULL,
    subscriptionId TEXT NOT NULL,
    planId TEXT NOT NULL,
    planName TEXT NOT NULL,
    amount REAL NOT NULL,
    currency TEXT NOT NULL DEFAULT 'INR',
    billingPeriodStart TEXT NOT NULL,
    billingPeriodEnd TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'PENDING',
    paymentStatus TEXT NOT NULL DEFAULT 'PENDING',
    paidAt TEXT,
    dueDate TEXT,
    notes TEXT,
    createdAt TEXT NOT NULL,
    updatedAt TEXT NOT NULL,
    FOREIGN KEY (storeId) REFERENCES stores(id) ON DELETE CASCADE,
    FOREIGN KEY (subscriptionId) REFERENCES store_subscriptions(id)
  );

  -- Phase 7: Platform Audit Logs (separate from store activity_logs)
  CREATE TABLE IF NOT EXISTS platform_audit_logs (
    id TEXT PRIMARY KEY,
    adminId TEXT NOT NULL,
    adminEmail TEXT NOT NULL,
    action TEXT NOT NULL,
    targetType TEXT,
    targetId TEXT,
    targetName TEXT,
    description TEXT NOT NULL,
    metadata TEXT,
    ipAddress TEXT,
    createdAt TEXT NOT NULL
  );

  -- Phase 7: Platform Settings (key-value configuration store)
  CREATE TABLE IF NOT EXISTS platform_settings (
    key TEXT PRIMARY KEY,
    value TEXT,
    label TEXT,
    description TEXT,
    updatedBy TEXT,
    updatedAt TEXT NOT NULL
  );

  -- Phase 7: Indexes
  CREATE INDEX IF NOT EXISTS idx_platform_admins_user ON platform_admins(userId);
  CREATE INDEX IF NOT EXISTS idx_subscription_plans_active ON subscription_plans(isActive);
  CREATE INDEX IF NOT EXISTS idx_store_subscriptions_store ON store_subscriptions(storeId);
  CREATE INDEX IF NOT EXISTS idx_store_subscriptions_plan ON store_subscriptions(planId);
  CREATE INDEX IF NOT EXISTS idx_store_subscriptions_status ON store_subscriptions(status);
  CREATE INDEX IF NOT EXISTS idx_plan_features_plan ON plan_features(planId);
  CREATE INDEX IF NOT EXISTS idx_sub_invoices_store ON subscription_invoices(storeId);
  CREATE INDEX IF NOT EXISTS idx_sub_invoices_status ON subscription_invoices(status);
  CREATE INDEX IF NOT EXISTS idx_sub_invoices_created ON subscription_invoices(createdAt);
  CREATE INDEX IF NOT EXISTS idx_platform_audit_admin ON platform_audit_logs(adminId);
  CREATE INDEX IF NOT EXISTS idx_platform_audit_created ON platform_audit_logs(createdAt);
  CREATE INDEX IF NOT EXISTS idx_platform_audit_target ON platform_audit_logs(targetType, targetId);
`);

// Phase 7: Safe column migration for stores.status
ensureColumn('stores', 'status', "TEXT DEFAULT 'ACTIVE'");
try { db.exec("UPDATE stores SET status = 'ACTIVE' WHERE status IS NULL OR status = ''"); } catch {}

// Phase 7: Seed Default Subscription Plans if not present
(function seedDefaultPlans() {
  try {
    const planCount = db.prepare('SELECT COUNT(*) as cnt FROM subscription_plans').get().cnt;
    if (planCount > 0) return;

    const now = new Date().toISOString();
    const crypto = require('crypto');

    const plans = [
      {
        id: 'plan_free', name: 'Free', slug: 'free', description: 'For individuals getting started',
        price: 0, billingInterval: 'monthly', trialDays: 0, maxUsers: 2, maxProducts: 50, maxCustomers: 100, isDefault: 1, sortOrder: 1
      },
      {
        id: 'plan_basic', name: 'Basic', slug: 'basic', description: 'For small clothing boutiques',
        price: 999, billingInterval: 'monthly', trialDays: 14, maxUsers: 5, maxProducts: 500, maxCustomers: 1000, isDefault: 0, sortOrder: 2
      },
      {
        id: 'plan_pro', name: 'Pro', slug: 'pro', description: 'For growing retail stores',
        price: 2499, billingInterval: 'monthly', trialDays: 14, maxUsers: 15, maxProducts: 2000, maxCustomers: 10000, isDefault: 0, sortOrder: 3
      },
      {
        id: 'plan_enterprise', name: 'Enterprise', slug: 'enterprise', description: 'For large multi-outlet retailers',
        price: 4999, billingInterval: 'monthly', trialDays: 30, maxUsers: 9999, maxProducts: 9999, maxCustomers: 9999, isDefault: 0, sortOrder: 4
      }
    ];

    const allFeatures = [
      'FEATURE_POS', 'FEATURE_INVENTORY', 'FEATURE_REPORTS', 'FEATURE_EXPENSES',
      'FEATURE_RETURNS', 'FEATURE_ADVANCED_ANALYTICS', 'FEATURE_STAFF_MANAGEMENT',
      'FEATURE_EXPORTS', 'FEATURE_NOTIFICATIONS', 'FEATURE_MULTI_USER'
    ];

    const planFeatureMap = {
      free: ['FEATURE_POS', 'FEATURE_INVENTORY', 'FEATURE_NOTIFICATIONS'],
      basic: ['FEATURE_POS', 'FEATURE_INVENTORY', 'FEATURE_REPORTS', 'FEATURE_EXPENSES', 'FEATURE_RETURNS', 'FEATURE_NOTIFICATIONS', 'FEATURE_MULTI_USER', 'FEATURE_STAFF_MANAGEMENT'],
      pro: allFeatures,
      enterprise: allFeatures
    };

    for (const plan of plans) {
      db.prepare(`
        INSERT OR IGNORE INTO subscription_plans
        (id, name, slug, description, price, billingInterval, trialDays, maxUsers, maxProducts, maxCustomers, currency, isActive, isDefault, sortOrder, createdAt, updatedAt)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'INR', 1, ?, ?, ?, ?)
      `).run(plan.id, plan.name, plan.slug, plan.description, plan.price, plan.billingInterval, plan.trialDays, plan.maxUsers, plan.maxProducts, plan.maxCustomers, plan.isDefault, plan.sortOrder, now, now);

      const features = planFeatureMap[plan.slug] || [];
      for (const feature of features) {
        const fid = 'pf_' + crypto.randomBytes(6).toString('hex');
        db.prepare('INSERT OR IGNORE INTO plan_features (id, planId, featureKey, enabled) VALUES (?, ?, ?, 1)').run(fid, plan.id, feature);
      }
    }

    // Seed default platform settings
    const defaultSettings = [
      { key: 'platform.name', value: 'Westsides SaaS', label: 'Platform Name', description: 'Name of the SaaS platform' },
      { key: 'platform.support_email', value: 'support@westsides.com', label: 'Support Email', description: 'Platform support email address' },
      { key: 'platform.support_phone', value: '+91 98200 99999', label: 'Support Phone', description: 'Platform support phone number' },
      { key: 'platform.currency', value: 'INR', label: 'Default Currency', description: 'Default billing currency' },
      { key: 'platform.default_trial_days', value: '14', label: 'Default Trial Duration', description: 'Default trial period in days for new stores' },
      { key: 'platform.default_plan_id', value: 'plan_free', label: 'Default Plan', description: 'Plan assigned to newly created stores' }
    ];
    for (const s of defaultSettings) {
      db.prepare('INSERT OR IGNORE INTO platform_settings (key, value, label, description, updatedAt) VALUES (?, ?, ?, ?, ?)').run(s.key, s.value, s.label, s.description, now);
    }
  } catch (err) {
    // Tables may already exist or migration already ran — safe to ignore
  }
})();

// Phase 8: Idempotency table for duplicate request prevention
db.exec(`
  CREATE TABLE IF NOT EXISTS idempotency_keys (
    key TEXT PRIMARY KEY,
    storeId TEXT NOT NULL,
    endpoint TEXT NOT NULL,
    responseStatus INTEGER NOT NULL,
    responseBody TEXT NOT NULL,
    createdAt TEXT NOT NULL
  );
  CREATE INDEX IF NOT EXISTS idx_idempotency_store ON idempotency_keys(storeId);
  CREATE INDEX IF NOT EXISTS idx_idempotency_created ON idempotency_keys(createdAt);
`);

module.exports = db;
