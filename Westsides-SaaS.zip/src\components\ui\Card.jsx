import React from 'react';

export function Card({ children, className = '', style = {}, ...props }) {
  return (
    <div
      style={{
        backgroundColor: 'var(--bg-surface)',
        borderRadius: 'var(--radius-lg)',
        border: '1px solid var(--border-color)',
        boxShadow: 'var(--shadow-sm)',
        overflow: 'hidden',
        ...style
      }}
      className={className}
      {...props}
    >
      {children}
    </div>
  );
}

export function CardHeader({ children, className = '', style = {} }) {
  return (
    <div
      style={{
        padding: '1.25rem 1.5rem',
        borderBottom: '1px solid var(--border-subtle)',
        ...style
      }}
      className={className}
    >
      {children}
    </div>
  );
}

export function CardTitle({ children, className = '', style = {} }) {
  return (
    <h3
      style={{
        fontSize: '1.125rem',
        fontWeight: '600',
        color: 'var(--text-main)',
        margin: 0,
        ...style
      }}
      className={className}
    >
      {children}
    </h3>
  );
}

export function CardDescription({ children, className = '', style = {} }) {
  return (
    <p
      style={{
        fontSize: '0.875rem',
        color: 'var(--text-muted)',
        marginTop: '0.25rem',
        marginBottom: 0,
        ...style
      }}
      className={className}
    >
      {children}
    </p>
  );
}

export function CardContent({ children, className = '', style = {} }) {
  return (
    <div
      style={{
        padding: '1.5rem',
        ...style
      }}
      className={className}
    >
      {children}
    </div>
  );
}

export function CardFooter({ children, className = '', style = {} }) {
  return (
    <div
      style={{
        padding: '1rem 1.5rem',
        backgroundColor: 'var(--bg-page)',
        borderTop: '1px solid var(--border-subtle)',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'flex-end',
        gap: '0.75rem',
        ...style
      }}
      className={className}
    >
      {children}
    </div>
  );
}
