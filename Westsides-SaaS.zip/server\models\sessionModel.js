const crypto = require('crypto');
const db = require('../db/database');
const config = require('../config');

const SessionModel = {
  create: ({ userId, storeId }) => {
    const id = 'sess_' + crypto.randomBytes(8).toString('hex');
    const token = crypto.randomBytes(32).toString('hex');
    const now = new Date();
    const expiresAt = new Date(now.getTime() + config.sessionExpiryHours * 60 * 60 * 1000).toISOString();

    const stmt = db.prepare(`
      INSERT INTO sessions (id, token, userId, storeId, expiresAt, createdAt)
      VALUES (?, ?, ?, ?, ?, ?)
    `);

    stmt.run(id, token, userId, storeId, expiresAt, now.toISOString());

    return { id, token, userId, storeId, expiresAt };
  },

  findByToken: (token) => {
    if (!token) return null;
    const now = new Date().toISOString();

    const stmt = db.prepare(`
      SELECT s.*, u.name as userName, u.email as userEmail, u.phone as userPhone,
             st.name as storeName, st.status as storeStatus, st.onboardingCompleted, st.onboardingStep,
             su.role, su.status as staffStatus
      FROM sessions s
      JOIN users u ON s.userId = u.id
      JOIN stores st ON s.storeId = st.id
      JOIN store_users su ON (su.userId = s.userId AND su.storeId = s.storeId)
      WHERE s.token = ? AND s.expiresAt > ?
    `);

    const result = stmt.get(token, now);
    if (!result) return null;

    // Inactive staff members cannot use active sessions
    if (result.staffStatus === 'INACTIVE') {
      return null;
    }

    return {
      ...result,
      onboardingCompleted: Boolean(result.onboardingCompleted)
    };
  },

  delete: (token) => {
    if (!token) return false;
    const stmt = db.prepare('DELETE FROM sessions WHERE token = ?');
    const info = stmt.run(token);
    return info.changes > 0;
  },

  deleteByUser: (userId) => {
    const stmt = db.prepare('DELETE FROM sessions WHERE userId = ?');
    return stmt.run(userId);
  },

  cleanupExpired: () => {
    const now = new Date().toISOString();
    const stmt = db.prepare('DELETE FROM sessions WHERE expiresAt <= ?');
    return stmt.run(now);
  }
};

module.exports = SessionModel;
