const SessionModel = require('../models/sessionModel');
const UserPermissionModel = require('../models/userPermissionModel');
const { ROLE_PERMISSIONS } = require('../constants/roles');

function authMiddleware(req, res, next) {
  // Extract token from Cookie or Authorization header
  let token = null;

  if (req.cookies && req.cookies.westsides_session) {
    token = req.cookies.westsides_session;
  } else if (req.headers.authorization && req.headers.authorization.startsWith('Bearer ')) {
    token = req.headers.authorization.substring(7);
  }

  if (!token) {
    return res.status(401).json({
      success: false,
      error: 'Authentication required. Please log in.'
    });
  }

  const session = SessionModel.findByToken(token);

  if (!session) {
    // Clear cookie if present
    res.clearCookie('westsides_session');
    return res.status(401).json({
      success: false,
      code: 'ACCOUNT_INACTIVE',
      error: 'Session expired, invalid, or account deactivated. Please log in again.'
    });
  }

  // Block access if store has been suspended by platform admin
  if (session.storeStatus === 'SUSPENDED') {
    return res.status(403).json({
      success: false,
      code: 'STORE_SUSPENDED',
      error: 'This store account has been suspended by the platform administrator. Please contact support.'
    });
  }

  // Calculate effective permissions (role defaults + user-specific overrides)
  const permissions = UserPermissionModel.getUserPermissions(session.storeId, session.userId, session.role);

  req.auth = {
    sessionId: session.id,
    token: session.token,
    userId: session.userId,
    userName: session.userName,
    userEmail: session.userEmail,
    userPhone: session.userPhone,
    storeId: session.storeId,
    storeName: session.storeName,
    role: session.role,
    permissions,
    onboardingCompleted: session.onboardingCompleted,
    onboardingStep: session.onboardingStep
  };

  req.userId = session.userId;
  req.storeId = session.storeId;
  req.role = session.role;
  req.user = {
    id: session.userId,
    name: session.userName,
    email: session.userEmail,
    role: session.role
  };

  next();
}

module.exports = authMiddleware;
