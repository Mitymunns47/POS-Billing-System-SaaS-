/**
 * AdminAuditPage.jsx — Phase 7
 * Platform audit log: all Super Admin actions are recorded.
 */
import React, { useEffect, useState, useCallback } from 'react';
import { api } from '../../services/api';

const COLORS = {
  card: '#1E293B', border: 'rgba(126,175,208,0.12)',
  text: '#F1F5F9', muted: '#64748B', accent: '#7EAFD0',
  success: '#10B981', warn: '#F59E0B', danger: '#EF4444'
};

const ACTION_COLORS = {
  STORE_SUSPENDED: '#F59E0B',
  STORE_REACTIVATED: '#10B981',
  STORE_PLAN_CHANGED: '#7EAFD0',
  INVOICE_GENERATED: '#A78BFA',
  INVOICE_MARKED_PAID: '#10B981',
  PLATFORM_SETTINGS_UPDATED: '#64748B',
  PLAN_UPDATED: '#7EAFD0'
};

export function AdminAuditPage() {
  const [logs, setLogs] = useState([]);
  const [total, setTotal] = useState(0);
  const [loading, setLoading] = useState(true);
  const [page, setPage] = useState(1);
  const [actionFilter, setActionFilter] = useState('');
  const [error, setError] = useState('');

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const res = await api.adminGetAuditLog({ page, limit: 50, action: actionFilter || undefined });
      if (res.success) { setLogs(res.logs); setTotal(res.total); }
    } catch (err) { setError(err.message); }
    finally { setLoading(false); }
  }, [page, actionFilter]);

  useEffect(() => { load(); }, [load]);

  const ACTIONS = ['STORE_SUSPENDED', 'STORE_REACTIVATED', 'STORE_PLAN_CHANGED', 'INVOICE_GENERATED', 'INVOICE_MARKED_PAID', 'PLATFORM_SETTINGS_UPDATED', 'PLAN_UPDATED'];

  return (
    <div style={{ padding: '1.75rem', fontFamily: "'Inter', 'Segoe UI', sans-serif" }}>
      <div style={{ marginBottom: '1.5rem' }}>
        <h1 style={{ color: COLORS.text, fontSize: '1.375rem', fontWeight: '700', margin: '0 0 0.25rem' }}>Platform Audit Log</h1>
        <p style={{ color: COLORS.muted, fontSize: '0.875rem', margin: 0 }}>
          Immutable record of all Super Admin actions — {total} total entries
        </p>
      </div>

      {error && <div style={{ background: '#EF444420', border: '1px solid #EF444440', borderRadius: '8px', padding: '0.75rem 1rem', color: '#EF4444', fontSize: '0.875rem', marginBottom: '1rem' }}>{error}</div>}

      {/* Filters */}
      <div style={{ display: 'flex', gap: '0.75rem', marginBottom: '1.25rem' }}>
        <select
          value={actionFilter}
          onChange={e => { setActionFilter(e.target.value); setPage(1); }}
          style={{ padding: '0.625rem 0.875rem', background: COLORS.card, border: `1px solid ${COLORS.border}`, borderRadius: '8px', color: COLORS.text, fontSize: '0.875rem', outline: 'none' }}
        >
          <option value="">All Actions</option>
          {ACTIONS.map(a => <option key={a} value={a}>{a.replace(/_/g, ' ')}</option>)}
        </select>
      </div>

      {/* Log entries */}
      <div style={{ background: COLORS.card, border: `1px solid ${COLORS.border}`, borderRadius: '12px', overflow: 'hidden' }}>
        {loading ? (
          <div style={{ padding: '3rem', textAlign: 'center', color: COLORS.muted }}>Loading audit log...</div>
        ) : logs.length === 0 ? (
          <div style={{ padding: '3rem', textAlign: 'center', color: COLORS.muted }}>No audit log entries yet.</div>
        ) : (
          <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: '0.8125rem' }}>
            <thead>
              <tr style={{ borderBottom: `1px solid ${COLORS.border}` }}>
                {['Timestamp', 'Admin', 'Action', 'Target', 'Description'].map(h => (
                  <th key={h} style={{ color: COLORS.muted, textAlign: 'left', padding: '0.75rem', fontWeight: '500' }}>{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {logs.map(log => {
                const acColor = ACTION_COLORS[log.action] || COLORS.muted;
                return (
                  <tr key={log.id} style={{ borderBottom: `1px solid ${COLORS.border}` }}>
                    <td style={{ color: COLORS.muted, padding: '0.75rem', whiteSpace: 'nowrap', fontSize: '0.75rem' }}>
                      {log.createdAt ? new Date(log.createdAt).toLocaleString('en-IN') : '—'}
                    </td>
                    <td style={{ color: COLORS.text, padding: '0.75rem', fontSize: '0.8125rem' }}>
                      {log.adminEmail}
                    </td>
                    <td style={{ padding: '0.75rem' }}>
                      <span style={{ background: `${acColor}20`, color: acColor, borderRadius: '6px', padding: '2px 8px', fontSize: '0.75rem', fontWeight: '600', whiteSpace: 'nowrap' }}>
                        {log.action.replace(/_/g, ' ')}
                      </span>
                    </td>
                    <td style={{ color: COLORS.text, padding: '0.75rem', fontSize: '0.8125rem' }}>
                      {log.targetName ? (
                        <>
                          <div style={{ fontWeight: '500' }}>{log.targetName}</div>
                          <div style={{ color: COLORS.muted, fontSize: '0.6875rem' }}>{log.targetType}</div>
                        </>
                      ) : (
                        <span style={{ color: COLORS.muted }}>—</span>
                      )}
                    </td>
                    <td style={{ color: COLORS.muted, padding: '0.75rem', fontSize: '0.8125rem' }}>
                      {log.description}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        )}
      </div>

      {/* Pagination */}
      {total > 50 && (
        <div style={{ display: 'flex', justifyContent: 'flex-end', gap: '0.5rem', marginTop: '1rem' }}>
          <button disabled={page === 1} onClick={() => setPage(p => p - 1)} style={{ padding: '0.5rem 1rem', background: COLORS.card, border: `1px solid ${COLORS.border}`, borderRadius: '8px', color: COLORS.text, cursor: page === 1 ? 'not-allowed' : 'pointer' }}>← Prev</button>
          <span style={{ padding: '0.5rem 1rem', color: COLORS.muted, fontSize: '0.875rem' }}>Page {page}</span>
          <button disabled={page * 50 >= total} onClick={() => setPage(p => p + 1)} style={{ padding: '0.5rem 1rem', background: COLORS.card, border: `1px solid ${COLORS.border}`, borderRadius: '8px', color: COLORS.text, cursor: page * 50 >= total ? 'not-allowed' : 'pointer' }}>Next →</button>
        </div>
      )}
    </div>
  );
}
