const PlatformAdminModel = require('../models/platformAdminModel');
const SessionModel = require('../models/sessionModel');

/**
 * requireSuperAdmin middleware
 * Validates the session normally, then additionally checks the platform_admins table.
 * NEVER trusts client-supplied role/admin flag.
 */
function requireSuperAdmin(req, res, next) {
  let token = null;

  if (req.cookies && req.cookies.westsides_session) {
    token = req.cookies.westsides_session;
  } else if (req.headers.authorization && req.headers.authorization.startsWith('Bearer ')) {
    token = req.headers.authorization.substring(7);
  }

  if (!token) {
    return res.status(401).json({ success: false, error: 'Authentication required.' });
  }

  // Get session via the normal session table (validates expiry, joins user+store)
  const db = require('../db/database');
  const now = new Date().toISOString();
  const session = db.prepare(`
    SELECT s.userId, s.storeId, u.name as userName, u.email as userEmail
    FROM sessions s
    JOIN users u ON s.userId = u.id
    WHERE s.token = ? AND s.expiresAt > ?
  `).get(token, now);

  if (!session) {
    res.clearCookie('westsides_session');
    return res.status(401).json({ success: false, error: 'Session expired. Please log in again.' });
  }

  // CRITICAL: verify userId is in platform_admins — never trust client-provided flags
  const isAdmin = PlatformAdminModel.isSuperAdmin(session.userId);
  if (!isAdmin) {
    return res.status(403).json({
      success: false,
      error: 'Access denied. Platform Super Admin privileges required.'
    });
  }

  req.platformAdmin = {
    userId: session.userId,
    userName: session.userName,
    userEmail: session.userEmail,
    storeId: session.storeId
  };

  next();
}

module.exports = requireSuperAdmin;
