const UserModel = require('./models/userModel');
const StoreModel = require('./models/storeModel');
const StoreUserModel = require('./models/storeUserModel');
const SessionModel = require('./models/sessionModel');
const ProductModel = require('./models/productModel');
const VariantModel = require('./models/variantModel');
const InventoryTxModel = require('./models/inventoryTxModel');
const CustomerModel = require('./models/customerModel');
const { SaleModel } = require('./models/saleModel');
const ReturnModel = require('./models/returnModel');
const SettingsModel = require('./models/settingsModel');
const ExpenseModel = require('./models/expenseModel');
const NotificationModel = require('./models/notificationModel');
const ReportModel = require('./models/reportModel');
const { ROLES, PERMISSIONS } = require('./constants/roles');
const UserPermissionModel = require('./models/userPermissionModel');

async function runPhase6Tests() {
  console.log('====================================================');
  console.log('PHASE 6 AUTOMATED INTEGRATION & VERIFICATION SUITE');
  console.log('====================================================\n');

  let passed = 0;
  let failed = 0;

  function assert(condition, message) {
    if (condition) {
      console.log(`✓ [PASS] ${message}`);
      passed++;
    } else {
      console.error(`✗ [FAIL] ${message}`);
      failed++;
    }
  }

  // 1. SETUP STORE A & OWNER
  console.log('--- 1. Setting up Tenant Store A & Store B ---');
  const storeA = StoreModel.create({
    name: 'Westsides Phase6 Flagship',
    city: 'Mumbai',
    state: 'Maharashtra',
    country: 'India',
    phone: '+91 98765 43210'
  });

  const ownerA = UserModel.create({
    name: 'Aarav Mehta',
    email: `aarav_${Date.now()}@westsides.com`,
    password: 'Password123!'
  });

  StoreUserModel.create({
    storeId: storeA.id,
    userId: ownerA.id,
    role: ROLES.OWNER
  });

  const sessionA = SessionModel.create({
    userId: ownerA.id,
    storeId: storeA.id
  });

  // Store B
  const storeB = StoreModel.create({
    name: 'Other Tenant Store B',
    city: 'Delhi',
    country: 'India'
  });

  const ownerB = UserModel.create({
    name: 'Rohan Gupta',
    email: `rohan_${Date.now()}@otherstore.com`,
    password: 'Password123!'
  });

  StoreUserModel.create({
    storeId: storeB.id,
    userId: ownerB.id,
    role: ROLES.OWNER
  });

  assert(storeA.id && storeB.id && storeA.id !== storeB.id, 'Store A and Store B created with isolated IDs');

  // 2. STORE SETTINGS & TAX CONFIGURATION
  console.log('\n--- 2. Testing Store Settings & Tax Configuration ---');
  const initialSettings = SettingsModel.getSettings(storeA.id);
  assert(initialSettings && initialSettings.storeId === storeA.id, 'Store settings initialized automatically for Store A');
  assert(initialSettings.invoicePrefix === 'WS', 'Default invoice prefix is WS');

  // Update Settings: Custom invoice prefix 'WS6-', Tax rate 12%, POS controls
  const updatedSettings = SettingsModel.updateSettings(
    storeA.id,
    {
      taxRate: 12,
      taxName: 'GST',
      taxEnabled: 1,
      invoicePrefix: 'WS6',
      receiptFooter: 'Thank you for shopping at Westsides!',
      returnPolicy: 'Returns accepted within 15 days in original condition.',
      allowDiscounts: 1,
      maxDiscountPercent: 25,
      allowNegativeInventory: 0,
      requireCustomerForSale: 1
    },
    ownerA.id,
    ownerA.name
  );

  assert(updatedSettings.taxRate === 12, 'Tax rate updated to 12% in settings');
  assert(updatedSettings.invoicePrefix === 'WS6', 'Invoice prefix updated to WS6 in settings');
  assert(Boolean(updatedSettings.requireCustomerForSale) === true, 'POS require customer rule set to true');

  // 3. CREATE PRODUCT, VARIANT & INITIAL INVENTORY
  console.log('\n--- 3. Setting up Catalog & Inventory ---');
  const product = ProductModel.create({
    storeId: storeA.id,
    name: 'Slim Fit Cotton Shirt',
    sku: `SFC-${Date.now()}`,
    description: '100% Breathable cotton',
    costPrice: 500,
    mrp: 1200,
    sellingPrice: 1000
  });

  const variantM = VariantModel.create({
    productId: product.id,
    storeId: storeA.id,
    size: 'M',
    color: 'Blue',
    sku: `SFC-M-${Date.now()}`,
    barcode: `89012${Date.now().toString().slice(-7)}`,
    price: 1000,
    stock: 20,
    minimumStock: 5
  });

  const variantL = VariantModel.create({
    productId: product.id,
    storeId: storeA.id,
    size: 'L',
    color: 'Blue',
    sku: `SFC-L-${Date.now()}`,
    barcode: `89013${Date.now().toString().slice(-7)}`,
    price: 1200,
    stock: 10,
    minimumStock: 2
  });

  assert(variantM && variantM.stock === 20, 'Variant M created with initial stock of 20');

  // 4. CUSTOMER SETUP
  const customer = CustomerModel.create({
    storeId: storeA.id,
    name: 'Priya Sharma',
    phone: '9876500001',
    email: 'priya@example.com'
  });
  assert(customer.id, 'Customer created successfully');

  // 5. PROCESS A SALE WITH NEW PREFIX AND TAX
  console.log('\n--- 4. Creating POS Sale ---');
  const sale = SaleModel.create({
    storeId: storeA.id,
    cashierId: ownerA.id,
    customerId: customer.id,
    items: [
      {
        variantId: variantM.id,
        quantity: 3,
        unitPrice: 1000,
        discount: 0
      },
      {
        variantId: variantL.id,
        quantity: 2,
        unitPrice: 1200,
        discount: 0
      }
    ],
    discountType: 'PERCENT',
    discountValue: 10, // 10% discount on cart
    paymentMethod: 'UPI',
    notes: 'In-store purchase'
  });

  assert(sale.invoiceNumber.startsWith('WS6-'), `New invoice follows configured prefix WS6: ${sale.invoiceNumber}`);
  assert(sale.items.length === 2, 'Sale contains 2 item lines');

  // Check inventory deduction
  const variantMAfterSale = VariantModel.findById(variantM.id, storeA.id);
  const variantLAfterSale = VariantModel.findById(variantL.id, storeA.id);
  assert(variantMAfterSale.stock === 17, `Variant M stock deducted from 20 to 17 (actual: ${variantMAfterSale.stock})`);
  assert(variantLAfterSale.stock === 8, `Variant L stock deducted from 10 to 8 (actual: ${variantLAfterSale.stock})`);

  // Check customer spend
  const customerSummary1 = CustomerModel.getPurchaseSummary(customer.id, storeA.id);
  assert(customerSummary1.netSpent > 0, `Customer net spend updated: ₹${customerSummary1.netSpent}`);

  // 6. TEST RETURN OF RESELLABLE ITEM (PARTIAL RETURN)
  console.log('\n--- 5. Testing Partial Resellable Return ---');
  const saleReturnDetails = ReturnModel.getSaleReturnDetails(sale.id, storeA.id);
  assert(saleReturnDetails.items.length === 2, 'Found returnable items for sale');
  const returnableItemM = saleReturnDetails.items.find(i => i.variantId === variantM.id);
  assert(returnableItemM.availableQuantity === 3, 'Variant M has 3 returnable items available');

  const partialReturn = ReturnModel.create({
    storeId: storeA.id,
    saleId: sale.id,
    items: [
      {
        saleItemId: returnableItemM.id,
        quantity: 1,
        condition: 'RESELLABLE'
      }
    ],
    reason: 'Wrong Size',
    notes: 'Exchanging or refunding size M',
    refundMethod: 'UPI',
    staffId: ownerA.id,
    staffName: ownerA.name
  });

  assert(partialReturn.id, `Partial return created with ID: ${partialReturn.id}`);
  assert(partialReturn.totalRefundAmount > 0, `Server calculated pro-rated refund: ₹${partialReturn.totalRefundAmount}`);

  // Verify atomic stock restoration for RESELLABLE
  const variantMAfterReturn = VariantModel.findById(variantM.id, storeA.id);
  assert(variantMAfterReturn.stock === 18, `Variant M stock restored from 17 to 18 (actual: ${variantMAfterReturn.stock})`);

  // Verify inventory transaction created with reason 'RETURN'
  const invTxs = InventoryTxModel.findAll({ storeId: storeA.id, variantId: variantM.id, limit: 5 });
  const returnTx = invTxs.transactions.find(t => t.reason === 'RETURN');
  assert(returnTx && returnTx.quantity === 1, 'Inventory transaction logged with reason=RETURN');

  // Verify customer return history and net spend adjustment
  const customerReturns = CustomerModel.getCustomerReturns(customer.id, storeA.id);
  assert(customerReturns.returns.length === 1, 'Customer return history reflects return');
  assert(customerReturns.totalRefunded === partialReturn.totalRefundAmount, 'Customer totalRefunded matches refund amount');

  const customerSummary2 = CustomerModel.getPurchaseSummary(customer.id, storeA.id);
  assert(customerSummary2.netSpent === customerSummary1.netSpent - partialReturn.totalRefundAmount, 'Customer net spend properly reduced by refund');

  // 7. TEST DAMAGED RETURN (STOCK NOT RESTORED)
  console.log('\n--- 6. Testing Damaged Return ---');
  const returnableItemL = saleReturnDetails.items.find(i => i.variantId === variantL.id);
  const damagedReturn = ReturnModel.create({
    storeId: storeA.id,
    saleId: sale.id,
    items: [
      {
        saleItemId: returnableItemL.id,
        quantity: 1,
        condition: 'DAMAGED'
      }
    ],
    reason: 'Defective Product',
    notes: 'Fabric torn on collar',
    refundMethod: 'CASH',
    staffId: ownerA.id,
    staffName: ownerA.name
  });

  assert(damagedReturn.id, 'Damaged return recorded');
  const variantLAfterDamaged = VariantModel.findById(variantL.id, storeA.id);
  assert(variantLAfterDamaged.stock === 8, `Variant L stock stayed 8 (NOT added back to sellable stock)`);

  const lossTxs = InventoryTxModel.findAll({ storeId: storeA.id, variantId: variantL.id, limit: 5 });
  const lossTx = lossTxs.transactions.find(t => t.reason === 'DAMAGED_RETURN');
  assert(lossTx && lossTx.action === 'INVENTORY_LOSS', 'Inventory loss transaction created for damaged return');

  // 8. TEST VALIDATION: PREVENT EXCESS RETURN QUANTITY
  console.log('\n--- 7. Testing Return Quantity Validation ---');
  let excessReturnError = false;
  try {
    // Already returned 1 of 3 for item M. Remaining available is 2. Attempting to return 3.
    ReturnModel.create({
      storeId: storeA.id,
      saleId: sale.id,
      items: [
        {
          saleItemId: returnableItemM.id,
          quantity: 3,
          condition: 'RESELLABLE'
        }
      ],
      reason: 'Wrong Product',
      refundMethod: 'CASH',
      staffId: ownerA.id,
      staffName: ownerA.name
    });
  } catch (err) {
    excessReturnError = true;
    assert(err.message.includes('maximum returnable') || err.message.includes('already returned'), `Excess return properly rejected: ${err.message}`);
  }
  assert(excessReturnError, 'Backend rejected return exceeding purchased minus already returned quantity');

  // 9. EXPENSE MANAGEMENT WITH PAYMENT METHOD & REPORT
  console.log('\n--- 8. Testing Expense Management & Payment Methods ---');
  const expense = ExpenseModel.create({
    storeId: storeA.id,
    title: 'Monthly Store Rent',
    category: 'Rent',
    amount: 15000,
    expenseDate: new Date().toISOString().split('T')[0],
    paymentMethod: 'BANK_TRANSFER',
    notes: 'Mall store rent',
    createdBy: ownerA.id
  });

  assert(expense.id && expense.paymentMethod === 'BANK_TRANSFER', 'Expense created with paymentMethod=BANK_TRANSFER');

  const expenseTransport = ExpenseModel.create({
    storeId: storeA.id,
    title: 'Fabric Delivery Logistics',
    category: 'Transport',
    amount: 1200,
    expenseDate: new Date().toISOString().split('T')[0],
    paymentMethod: 'UPI',
    notes: 'Courier from warehouse',
    createdBy: ownerA.id
  });
  assert(expenseTransport.id && expenseTransport.category === 'Transport', 'Transport category expense supported');

  // Verify financial report includes net sales (gross - refunds) and expenses
  const finance = ReportModel.getFinanceReport(storeA.id, { range: 'all' });
  assert(finance.grossSales > 0, `Finance report gross sales: ₹${finance.grossSales}`);
  assert(finance.refunds > 0, `Finance report refunds tracked: ₹${finance.refunds}`);
  const expectedNetSales = Math.max(0, Math.round(((finance.grossSales - finance.discounts - finance.refunds) + finance.taxCollected) * 100) / 100);
  assert(finance.netSales === expectedNetSales, `Net sales accurately calculated (gross - disc - ref + tax): ₹${finance.netSales}`);
  assert(finance.expenses >= 16200, `Expenses accurately aggregated: ₹${finance.expenses}`);

  // 10. NOTIFICATION CENTER & LOW STOCK DEDUPLICATION
  console.log('\n--- 9. Testing Notification Deduplication ---');
  // Trigger check on low stock
  NotificationModel.checkLowStockAlerts(storeA.id);
  const notesBefore = NotificationModel.findAll({ storeId: storeA.id });
  const countBefore = notesBefore.total;

  // Trigger check immediately again
  NotificationModel.checkLowStockAlerts(storeA.id);
  const notesAfter = NotificationModel.findAll({ storeId: storeA.id });
  assert(notesAfter.total === countBefore, 'Low stock alerts deduplicated within 24h window (no duplicate floods)');

  // Unread count
  const unreadCount = NotificationModel.getUnreadCount(storeA.id, ownerA.id, ROLES.OWNER);
  assert(unreadCount > 0, `Unread notifications detected: ${unreadCount}`);

  // Mark all read
  NotificationModel.markAllAsRead(storeA.id, ownerA.id, ROLES.OWNER);
  const unreadCountAfter = NotificationModel.getUnreadCount(storeA.id, ownerA.id, ROLES.OWNER);
  assert(unreadCountAfter === 0, 'Mark all as read reduced unread count to 0');

  // 11. MULTI-TENANT ISOLATION
  console.log('\n--- 10. Testing Strict Multi-Tenant Isolation ---');
  // Store B attempts to query Store A returns
  const storeBReturns = ReturnModel.findAll({ storeId: storeB.id });
  assert(storeBReturns.returns.length === 0, 'Store B cannot see Store A returns (0 returns found)');

  // Store B attempts to fetch Store A single return
  const crossTenantReturn = ReturnModel.findById(partialReturn.id, storeB.id);
  assert(crossTenantReturn === null, 'Store B cannot fetch Store A return record by ID (returns null)');

  // Store B attempts to fetch Store A settings
  const storeBSettings = SettingsModel.getSettings(storeB.id);
  assert(storeBSettings.storeId === storeB.id && storeBSettings.invoicePrefix === 'WS', 'Store B settings isolated from Store A settings');

  // Store B attempts to fetch Store A notifications
  const storeBNotes = NotificationModel.findAll({ storeId: storeB.id });
  assert(storeBNotes.total === 0, 'Store B notifications isolated from Store A');

  // 12. ROLE PERMISSION ENFORCEMENT
  console.log('\n--- 11. Testing Role Permission Controls ---');
  const cashierUser = UserModel.create({
    name: 'Rohit Cashier',
    email: `rohit_${Date.now()}@westsides.com`,
    password: 'Password123!'
  });
  StoreUserModel.create({
    storeId: storeA.id,
    userId: cashierUser.id,
    role: ROLES.CASHIER
  });
  const cashierPermissions = UserPermissionModel.getUserPermissions(storeA.id, cashierUser.id, ROLES.CASHIER);
  assert(!cashierPermissions.includes(PERMISSIONS.SETTINGS_EDIT), 'Cashier does NOT have SETTINGS_EDIT permission');
  assert(!cashierPermissions.includes(PERMISSIONS.EXPENSES_ARCHIVE), 'Cashier does NOT have EXPENSES_ARCHIVE permission');
  assert(cashierPermissions.includes(PERMISSIONS.RETURNS_CREATE), 'Cashier has permission to create returns');

  console.log('\n====================================================');
  console.log(`TEST RESULTS: ${passed} PASSED, ${failed} FAILED`);
  console.log('====================================================');

  if (failed > 0) {
    process.exit(1);
  }
}

runPhase6Tests().catch(err => {
  console.error('Test suite failed with unexpected error:', err);
  process.exit(1);
});
