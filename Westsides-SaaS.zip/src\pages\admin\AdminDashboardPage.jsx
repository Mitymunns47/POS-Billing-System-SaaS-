/**
 * AdminDashboardPage.jsx — Phase 7
 * Platform dashboard with KPIs, subscription breakdown, store growth chart.
 */
import React, { useEffect, useState } from 'react';
import { api } from '../../services/api';

const COLORS = {
  bg: '#0F172A', card: '#1E293B', border: 'rgba(126,175,208,0.12)',
  text: '#F1F5F9', muted: '#64748B', accent: '#7EAFD0',
  success: '#10B981', warn: '#F59E0B', danger: '#EF4444'
};

function StatCard({ label, value, sub, color = COLORS.accent, icon }) {
  return (
    <div style={{
      background: COLORS.card, border: `1px solid ${COLORS.border}`,
      borderRadius: '12px', padding: '1.25rem',
    }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
        <div>
          <div style={{ color: COLORS.muted, fontSize: '0.8125rem', marginBottom: '0.5rem' }}>{label}</div>
          <div style={{ color: color, fontSize: '1.75rem', fontWeight: '700', lineHeight: 1 }}>{value}</div>
          {sub && <div style={{ color: COLORS.muted, fontSize: '0.75rem', marginTop: '0.375rem' }}>{sub}</div>}
        </div>
        <span style={{ fontSize: '1.5rem', opacity: 0.6 }}>{icon}</span>
      </div>
    </div>
  );
}

function Section({ title, children }) {
  return (
    <div style={{
      background: COLORS.card, border: `1px solid ${COLORS.border}`,
      borderRadius: '12px', padding: '1.25rem', marginBottom: '1.25rem'
    }}>
      <h3 style={{ color: COLORS.text, fontSize: '0.9375rem', fontWeight: '600', margin: '0 0 1rem' }}>{title}</h3>
      {children}
    </div>
  );
}

const STATUS_COLOR = { ACTIVE: '#10B981', TRIALING: '#7EAFD0', SUSPENDED: '#F59E0B', CANCELLED: '#EF4444' };

export function AdminDashboardPage({ onNavigate }) {
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    api.adminGetDashboard()
      .then(res => { if (res.success) setData(res.dashboard); })
      .catch(err => setError(err.message))
      .finally(() => setLoading(false));
  }, []);

  if (loading) return <div style={{ color: COLORS.muted, padding: '3rem', textAlign: 'center' }}>Loading platform dashboard...</div>;
  if (error) return <div style={{ color: COLORS.danger, padding: '2rem' }}>{error}</div>;
  if (!data) return null;

  const { summary, subscriptions, recentStores, monthlyGrowth } = data;

  const fmtCurrency = (v) => `₹${(v || 0).toLocaleString('en-IN')}`;

  const maxGrowth = Math.max(...monthlyGrowth.map(m => m.count), 1);

  return (
    <div style={{ padding: '1.75rem', fontFamily: "'Inter', 'Segoe UI', sans-serif" }}>
      {/* Page header */}
      <div style={{ marginBottom: '1.5rem' }}>
        <h1 style={{ color: COLORS.text, fontSize: '1.375rem', fontWeight: '700', margin: '0 0 0.25rem' }}>
          Platform Dashboard
        </h1>
        <p style={{ color: COLORS.muted, fontSize: '0.875rem', margin: 0 }}>
          Westsides SaaS — real-time platform overview
        </p>
      </div>

      {/* KPI Grid */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(200px, 1fr))', gap: '1rem', marginBottom: '1.5rem' }}>
        <StatCard label="Total Tenants" value={summary.totalStores} icon="🏪" />
        <StatCard label="Active Stores" value={summary.activeStores} icon="✅" color={COLORS.success} />
        <StatCard label="Suspended Stores" value={summary.suspendedStores} icon="🚫" color={COLORS.danger} />
        <StatCard label="Platform Users" value={summary.totalUsers} icon="👥" />
        <StatCard label="Total Revenue" value={fmtCurrency(summary.totalRevenue)} icon="💰" color={COLORS.success} />
        <StatCard label="Monthly Revenue" value={fmtCurrency(summary.monthlyRevenue)} icon="📈" sub="Current month" color="#10B981" />
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '1.25rem', marginBottom: '1.25rem' }}>
        {/* Subscriptions by status */}
        <Section title="Subscriptions by Status">
          {Object.entries(subscriptions.byStatus).length === 0 ? (
            <p style={{ color: COLORS.muted, fontSize: '0.875rem' }}>No subscriptions yet.</p>
          ) : Object.entries(subscriptions.byStatus).map(([status, cnt]) => (
            <div key={status} style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '0.5rem 0', borderBottom: `1px solid ${COLORS.border}` }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
                <span style={{ width: '8px', height: '8px', borderRadius: '50%', background: STATUS_COLOR[status] || COLORS.muted, flexShrink: 0 }} />
                <span style={{ color: COLORS.text, fontSize: '0.875rem' }}>{status}</span>
              </div>
              <span style={{ color: STATUS_COLOR[status] || COLORS.muted, fontWeight: '600', fontSize: '0.875rem' }}>{cnt}</span>
            </div>
          ))}
        </Section>

        {/* Subscriptions by plan */}
        <Section title="Subscriptions by Plan">
          {subscriptions.byPlan.length === 0 ? (
            <p style={{ color: COLORS.muted, fontSize: '0.875rem' }}>No plan data yet.</p>
          ) : subscriptions.byPlan.map(p => (
            <div key={p.planName} style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '0.5rem 0', borderBottom: `1px solid ${COLORS.border}` }}>
              <span style={{ color: COLORS.text, fontSize: '0.875rem' }}>{p.planName}</span>
              <span style={{ color: COLORS.accent, fontWeight: '600', fontSize: '0.875rem' }}>{p.storeCount} stores</span>
            </div>
          ))}
        </Section>
      </div>

      {/* Store growth bar chart */}
      {monthlyGrowth.length > 0 && (
        <Section title="Monthly Store Registrations">
          <div style={{ display: 'flex', alignItems: 'flex-end', gap: '0.5rem', height: '100px' }}>
            {monthlyGrowth.map(m => (
              <div key={m.month} style={{ flex: 1, display: 'flex', flexDirection: 'column', alignItems: 'center', gap: '0.25rem' }}>
                <div style={{ color: COLORS.muted, fontSize: '0.625rem' }}>{m.count}</div>
                <div style={{
                  width: '100%', background: COLORS.accent, opacity: 0.7, borderRadius: '4px 4px 0 0',
                  height: `${(m.count / maxGrowth) * 70}px`, minHeight: '4px', transition: 'height 0.3s'
                }} />
                <div style={{ color: COLORS.muted, fontSize: '0.625rem', textAlign: 'center' }}>
                  {m.month?.slice(5)}
                </div>
              </div>
            ))}
          </div>
        </Section>
      )}

      {/* Recent Stores */}
      <Section title="Recently Onboarded Stores">
        {recentStores.length === 0 ? (
          <p style={{ color: COLORS.muted, fontSize: '0.875rem' }}>No stores yet.</p>
        ) : (
          <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: '0.8125rem' }}>
            <thead>
              <tr>
                {['Store Name', 'City', 'Plan', 'Sub Status', 'Store Status', 'Created'].map(h => (
                  <th key={h} style={{ color: COLORS.muted, textAlign: 'left', padding: '0.5rem 0.75rem', fontWeight: '500', borderBottom: `1px solid ${COLORS.border}` }}>{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {recentStores.map(s => (
                <tr key={s.id}
                  onClick={() => onNavigate(`/admin/stores/${s.id}`)}
                  style={{ cursor: 'pointer', transition: 'background 0.15s' }}
                  onMouseOver={e => e.currentTarget.style.background = 'rgba(126,175,208,0.04)'}
                  onMouseOut={e => e.currentTarget.style.background = 'transparent'}
                >
                  <td style={{ color: COLORS.accent, padding: '0.6rem 0.75rem', fontWeight: '500' }}>{s.name}</td>
                  <td style={{ color: COLORS.text, padding: '0.6rem 0.75rem' }}>{s.city || '—'}</td>
                  <td style={{ color: COLORS.text, padding: '0.6rem 0.75rem' }}>{s.planName || '—'}</td>
                  <td style={{ padding: '0.6rem 0.75rem' }}>
                    <span style={{ background: STATUS_COLOR[s.subStatus] ? STATUS_COLOR[s.subStatus] + '22' : '#33415522', color: STATUS_COLOR[s.subStatus] || COLORS.muted, borderRadius: '6px', padding: '2px 8px', fontSize: '0.75rem', fontWeight: '600' }}>
                      {s.subStatus || '—'}
                    </span>
                  </td>
                  <td style={{ padding: '0.6rem 0.75rem' }}>
                    <span style={{ background: (s.status === 'ACTIVE' ? '#10B981' : s.status === 'SUSPENDED' ? '#F59E0B' : '#EF4444') + '22', color: s.status === 'ACTIVE' ? '#10B981' : s.status === 'SUSPENDED' ? '#F59E0B' : '#EF4444', borderRadius: '6px', padding: '2px 8px', fontSize: '0.75rem', fontWeight: '600' }}>
                      {s.status || 'ACTIVE'}
                    </span>
                  </td>
                  <td style={{ color: COLORS.muted, padding: '0.6rem 0.75rem' }}>
                    {s.createdAt ? new Date(s.createdAt).toLocaleDateString('en-IN') : '—'}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </Section>
    </div>
  );
}
