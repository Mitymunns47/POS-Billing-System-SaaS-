const express = require('express');
const router = express.Router();
const CustomerModel = require('../models/customerModel');
const ActivityLogModel = require('../models/activityLogModel');
const authMiddleware = require('../middleware/auth');
const { requirePermission } = require('../middleware/roles');
const { PERMISSIONS } = require('../constants/roles');

router.use(authMiddleware);

// Helper for phone validation (Indian/international standard)
const PHONE_REGEX = /^[+]?[\d\s-]{7,15}$/;
const EMAIL_REGEX = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

// GET /api/customers/search?q=...  — Fast search for POS autocomplete
router.get('/search', requirePermission(PERMISSIONS.CUSTOMERS_VIEW), (req, res) => {
  try {
    const { q } = req.query;
    const customers = CustomerModel.search(req.storeId, q || '', 15);
    res.json({ success: true, customers });
  } catch (err) {
    res.status(500).json({ success: false, error: 'Could not search customers.' });
  }
});

// GET /api/customers — List with filtering, sorting, pagination
router.get('/', requirePermission(PERMISSIONS.CUSTOMERS_VIEW), (req, res) => {
  try {
    const { search, status = 'ACTIVE', sortBy = 'name', sortDir = 'ASC', page = 1, limit = 20 } = req.query;

    const result = CustomerModel.findAll({
      storeId: req.storeId,
      search: search || '',
      status: status || 'ACTIVE',
      sortBy: sortBy || 'name',
      sortDir: sortDir || 'ASC',
      page: parseInt(page) || 1,
      limit: Math.min(parseInt(limit) || 20, 100)
    });

    res.json({ success: true, ...result });
  } catch (err) {
    console.error('List customers error:', err);
    res.status(500).json({ success: false, error: 'Could not load customers.' });
  }
});

// GET /api/customers/:id — Customer profile with purchase summary
router.get('/:id', requirePermission(PERMISSIONS.CUSTOMERS_VIEW), (req, res) => {
  try {
    const customer = CustomerModel.findById(req.params.id, req.storeId, true);
    if (!customer) {
      return res.status(404).json({ success: false, error: 'Customer not found.' });
    }

    const purchaseSummary = CustomerModel.getPurchaseSummary(req.params.id, req.storeId);

    res.json({
      success: true,
      customer,
      purchaseSummary,
      summary: purchaseSummary
    });
  } catch (err) {
    console.error('Get customer error:', err);
    res.status(500).json({ success: false, error: 'Could not load customer profile.' });
  }
});

// GET /api/customers/:id/sales — Paginated sales history for this customer
router.get('/:id/sales', requirePermission(PERMISSIONS.CUSTOMERS_VIEW_HISTORY), (req, res) => {
  try {
    const customer = CustomerModel.findById(req.params.id, req.storeId, true);
    if (!customer) {
      return res.status(404).json({ success: false, error: 'Customer not found.' });
    }

    const { page = 1, limit = 15 } = req.query;
    const history = CustomerModel.getCustomerSales(req.params.id, req.storeId, {
      page: parseInt(page) || 1,
      limit: Math.min(parseInt(limit) || 15, 50)
    });

    res.json({ success: true, ...history });
  } catch (err) {
    console.error('Get customer sales error:', err);
    res.status(500).json({ success: false, error: 'Could not load customer sales history.' });
  }
});

// POST /api/customers — Create customer
router.post('/', requirePermission(PERMISSIONS.CUSTOMERS_CREATE), (req, res) => {
  try {
    const { name, phone, email, dateOfBirth, gender, address, city, state, postalCode, notes } = req.body;

    if (!name || !name.trim()) {
      return res.status(400).json({ success: false, error: 'Customer name is required.' });
    }

    if (phone && !PHONE_REGEX.test(phone.trim())) {
      return res.status(400).json({ success: false, error: 'Please enter a valid phone number (7-15 digits).' });
    }

    if (email && !EMAIL_REGEX.test(email.trim())) {
      return res.status(400).json({ success: false, error: 'Please enter a valid email address.' });
    }

    const customer = CustomerModel.create({
      storeId: req.storeId,
      name,
      phone,
      email,
      dateOfBirth,
      gender,
      address,
      city,
      state,
      postalCode,
      notes
    });

    // Activity Log
    ActivityLogModel.log({
      storeId: req.storeId,
      userId: req.auth.userId,
      userName: req.auth.userName,
      action: 'CUSTOMER_CREATED',
      module: 'Customers',
      description: `Created customer profile: ${customer.name}${customer.phone ? ` (${customer.phone})` : ''}`,
      recordId: customer.id
    });

    res.status(201).json({ success: true, message: 'Customer created successfully.', customer });
  } catch (err) {
    console.error('Create customer error:', err);
    res.status(400).json({ success: false, error: err.message || 'Could not create customer.' });
  }
});

// PUT /api/customers/:id — Edit customer
router.put('/:id', requirePermission(PERMISSIONS.CUSTOMERS_EDIT), (req, res) => {
  try {
    const { name, phone, email, dateOfBirth, gender, address, city, state, postalCode, notes } = req.body;

    if (name !== undefined && (!name || !name.trim())) {
      return res.status(400).json({ success: false, error: 'Customer name cannot be empty.' });
    }

    if (phone && !PHONE_REGEX.test(phone.trim())) {
      return res.status(400).json({ success: false, error: 'Please enter a valid phone number.' });
    }

    if (email && !EMAIL_REGEX.test(email.trim())) {
      return res.status(400).json({ success: false, error: 'Please enter a valid email address.' });
    }

    const updated = CustomerModel.update(req.params.id, req.storeId, {
      name,
      phone,
      email,
      dateOfBirth,
      gender,
      address,
      city,
      state,
      postalCode,
      notes
    });

    if (!updated) {
      return res.status(404).json({ success: false, error: 'Customer not found.' });
    }

    // Activity Log
    ActivityLogModel.log({
      storeId: req.storeId,
      userId: req.auth.userId,
      userName: req.auth.userName,
      action: 'CUSTOMER_UPDATED',
      module: 'Customers',
      description: `Updated customer profile: ${updated.name}`,
      recordId: updated.id
    });

    res.json({ success: true, message: 'Customer updated successfully.', customer: updated });
  } catch (err) {
    console.error('Update customer error:', err);
    res.status(400).json({ success: false, error: err.message || 'Could not update customer.' });
  }
});

// PATCH /api/customers/:id/archive — Archive customer
router.patch('/:id/archive', requirePermission(PERMISSIONS.CUSTOMERS_ARCHIVE), (req, res) => {
  try {
    const customer = CustomerModel.findById(req.params.id, req.storeId, true);
    if (!customer) {
      return res.status(404).json({ success: false, error: 'Customer not found.' });
    }

    const archived = CustomerModel.archive(req.params.id, req.storeId);

    // Activity Log
    ActivityLogModel.log({
      storeId: req.storeId,
      userId: req.auth.userId,
      userName: req.auth.userName,
      action: 'CUSTOMER_ARCHIVED',
      module: 'Customers',
      description: `Archived customer: ${customer.name}`,
      recordId: customer.id
    });

    res.json({ success: true, message: `Customer "${customer.name}" archived successfully.`, customer: archived });
  } catch (err) {
    console.error('Archive customer error:', err);
    res.status(500).json({ success: false, error: 'Could not archive customer.' });
  }
});

// PATCH /api/customers/:id/restore — Restore archived customer
router.patch('/:id/restore', requirePermission(PERMISSIONS.CUSTOMERS_ARCHIVE), (req, res) => {
  try {
    const customer = CustomerModel.findById(req.params.id, req.storeId, true);
    if (!customer) {
      return res.status(404).json({ success: false, error: 'Customer not found.' });
    }

    const restored = CustomerModel.restore(req.params.id, req.storeId);

    // Activity Log
    ActivityLogModel.log({
      storeId: req.storeId,
      userId: req.auth.userId,
      userName: req.auth.userName,
      action: 'CUSTOMER_RESTORED',
      module: 'Customers',
      description: `Restored customer: ${customer.name}`,
      recordId: customer.id
    });

    res.json({ success: true, customer: restored });
  } catch (err) {
    console.error('Restore customer error:', err);
    res.status(500).json({ success: false, error: 'Could not restore customer.' });
  }
});

// GET /api/customers/:id/returns — Customer return history
router.get('/:id/returns', requirePermission(PERMISSIONS.CUSTOMERS_VIEW_HISTORY), (req, res) => {
  try {
    const customer = CustomerModel.findById(req.params.id, req.storeId, true);
    if (!customer) {
      return res.status(404).json({ success: false, error: 'Customer not found.' });
    }
    const { page = 1, limit = 15 } = req.query;
    const history = CustomerModel.getCustomerReturns(req.params.id, req.storeId, {
      page: parseInt(page, 10) || 1,
      limit: parseInt(limit, 10) || 15
    });
    res.json({ success: true, ...history });
  } catch (err) {
    console.error('Customer returns history error:', err);
    res.status(500).json({ success: false, error: 'Could not fetch customer return history.' });
  }
});

module.exports = router;
