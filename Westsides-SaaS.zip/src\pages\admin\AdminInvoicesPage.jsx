/**
 * AdminInvoicesPage.jsx — Phase 7
 * Platform subscription billing invoice management.
 */
import React, { useEffect, useState, useCallback } from 'react';
import { api } from '../../services/api';

const COLORS = {
  card: '#1E293B', border: 'rgba(126,175,208,0.12)',
  text: '#F1F5F9', muted: '#64748B', accent: '#7EAFD0',
  success: '#10B981', warn: '#F59E0B', danger: '#EF4444'
};

export function AdminInvoicesPage() {
  const [invoices, setInvoices] = useState([]);
  const [loading, setLoading] = useState(true);
  const [actionLoading, setActionLoading] = useState('');
  const [msg, setMsg] = useState('');
  const [error, setError] = useState('');

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const res = await api.adminListInvoices({ limit: 100 });
      if (res.success) setInvoices(res.invoices);
    } catch (err) { setError(err.message); }
    finally { setLoading(false); }
  }, []);

  useEffect(() => { load(); }, [load]);

  const handleMarkPaid = async (id) => {
    setActionLoading(id);
    try {
      const res = await api.adminMarkInvoicePaid(id);
      if (res.success) { setMsg('Invoice marked as paid.'); load(); }
    } catch (err) { setError(err.message); }
    finally { setActionLoading(''); }
  };

  const totalRevenue = invoices.filter(i => i.paymentStatus === 'PAID').reduce((sum, i) => sum + i.amount, 0);
  const pendingAmount = invoices.filter(i => i.paymentStatus === 'PENDING').reduce((sum, i) => sum + i.amount, 0);

  return (
    <div style={{ padding: '1.75rem', fontFamily: "'Inter', 'Segoe UI', sans-serif" }}>
      <div style={{ marginBottom: '1.5rem' }}>
        <h1 style={{ color: COLORS.text, fontSize: '1.375rem', fontWeight: '700', margin: '0 0 0.25rem' }}>Billing Invoices</h1>
        <p style={{ color: COLORS.muted, fontSize: '0.875rem', margin: 0 }}>Platform subscription invoices for all tenant stores</p>
      </div>

      {msg && <div style={{ background: '#10B98120', border: '1px solid #10B98140', borderRadius: '8px', padding: '0.75rem 1rem', color: '#10B981', fontSize: '0.875rem', marginBottom: '1rem' }}>{msg} <button onClick={() => setMsg('')} style={{ float: 'right', background: 'none', border: 'none', color: '#10B981', cursor: 'pointer' }}>✕</button></div>}
      {error && <div style={{ background: '#EF444420', border: '1px solid #EF444440', borderRadius: '8px', padding: '0.75rem 1rem', color: '#EF4444', fontSize: '0.875rem', marginBottom: '1rem' }}>{error} <button onClick={() => setError('')} style={{ float: 'right', background: 'none', border: 'none', color: '#EF4444', cursor: 'pointer' }}>✕</button></div>}

      {/* Summary */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(200px, 1fr))', gap: '1rem', marginBottom: '1.5rem' }}>
        <div style={{ background: COLORS.card, border: `1px solid ${COLORS.border}`, borderRadius: '12px', padding: '1.25rem' }}>
          <div style={{ color: COLORS.muted, fontSize: '0.8125rem', marginBottom: '0.5rem' }}>Total Invoices</div>
          <div style={{ color: COLORS.text, fontSize: '1.75rem', fontWeight: '700' }}>{invoices.length}</div>
        </div>
        <div style={{ background: COLORS.card, border: `1px solid ${COLORS.border}`, borderRadius: '12px', padding: '1.25rem' }}>
          <div style={{ color: COLORS.muted, fontSize: '0.8125rem', marginBottom: '0.5rem' }}>Collected Revenue</div>
          <div style={{ color: COLORS.success, fontSize: '1.75rem', fontWeight: '700' }}>₹{totalRevenue.toLocaleString('en-IN')}</div>
        </div>
        <div style={{ background: COLORS.card, border: `1px solid ${COLORS.border}`, borderRadius: '12px', padding: '1.25rem' }}>
          <div style={{ color: COLORS.muted, fontSize: '0.8125rem', marginBottom: '0.5rem' }}>Pending Collection</div>
          <div style={{ color: COLORS.warn, fontSize: '1.75rem', fontWeight: '700' }}>₹{pendingAmount.toLocaleString('en-IN')}</div>
        </div>
      </div>

      {/* Table */}
      <div style={{ background: COLORS.card, border: `1px solid ${COLORS.border}`, borderRadius: '12px', overflow: 'hidden' }}>
        {loading ? (
          <div style={{ padding: '3rem', textAlign: 'center', color: COLORS.muted }}>Loading invoices...</div>
        ) : invoices.length === 0 ? (
          <div style={{ padding: '3rem', textAlign: 'center', color: COLORS.muted }}>No invoices generated yet. Use the "Generate Invoice" action from a store's detail page.</div>
        ) : (
          <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: '0.8125rem' }}>
            <thead>
              <tr style={{ borderBottom: `1px solid ${COLORS.border}` }}>
                {['Invoice ID', 'Store', 'Plan', 'Amount', 'Status', 'Period', 'Due Date', 'Paid At', 'Action'].map(h => (
                  <th key={h} style={{ color: COLORS.muted, textAlign: 'left', padding: '0.75rem', fontWeight: '500' }}>{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {invoices.map(inv => (
                <tr key={inv.id} style={{ borderBottom: `1px solid ${COLORS.border}` }}>
                  <td style={{ color: COLORS.muted, padding: '0.75rem', fontSize: '0.7rem' }}>{inv.id}</td>
                  <td style={{ color: COLORS.text, padding: '0.75rem', fontWeight: '500' }}>{inv.storeName}</td>
                  <td style={{ color: COLORS.accent, padding: '0.75rem' }}>{inv.planName}</td>
                  <td style={{ color: COLORS.success, padding: '0.75rem', fontWeight: '600' }}>₹{inv.amount?.toLocaleString('en-IN')}</td>
                  <td style={{ padding: '0.75rem' }}>
                    <span style={{ background: inv.paymentStatus === 'PAID' ? '#10B98120' : '#F59E0B20', color: inv.paymentStatus === 'PAID' ? '#10B981' : '#F59E0B', borderRadius: '6px', padding: '2px 8px', fontSize: '0.75rem', fontWeight: '600' }}>
                      {inv.paymentStatus}
                    </span>
                  </td>
                  <td style={{ color: COLORS.muted, padding: '0.75rem' }}>
                    {inv.billingPeriodStart ? new Date(inv.billingPeriodStart).toLocaleDateString('en-IN') : '—'} → {inv.billingPeriodEnd ? new Date(inv.billingPeriodEnd).toLocaleDateString('en-IN') : '—'}
                  </td>
                  <td style={{ color: COLORS.muted, padding: '0.75rem' }}>{inv.dueDate ? new Date(inv.dueDate).toLocaleDateString('en-IN') : '—'}</td>
                  <td style={{ color: COLORS.muted, padding: '0.75rem' }}>{inv.paidAt ? new Date(inv.paidAt).toLocaleDateString('en-IN') : '—'}</td>
                  <td style={{ padding: '0.75rem' }}>
                    {inv.paymentStatus !== 'PAID' && (
                      <button
                        onClick={() => handleMarkPaid(inv.id)}
                        disabled={actionLoading === inv.id}
                        style={{ padding: '4px 10px', background: 'rgba(16,185,129,0.12)', border: '1px solid rgba(16,185,129,0.3)', borderRadius: '6px', color: '#10B981', fontSize: '0.75rem', cursor: 'pointer', fontWeight: '500' }}
                      >
                        Mark Paid
                      </button>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </div>
  );
}
