const crypto = require('crypto');
const db = require('../db/database');

/**
 * Idempotency middleware for preventing duplicate operations
 * (e.g., duplicate POS sales, refunds, expenses, subscription changes).
 */
function idempotencyMiddleware(options = {}) {
  return function (req, res, next) {
    // Only apply to state-changing methods
    if (!['POST', 'PUT', 'PATCH'].includes(req.method)) {
      return next();
    }

    const headerKey = req.headers['idempotency-key'] || req.headers['x-idempotency-key'] || (req.body && req.body.idempotencyKey);
    const storeId = req.storeId || 'global';

    let key = headerKey;

    // For POS sales without an explicit key, auto-generate a signature from payload to prevent double-clicks within 3 seconds
    if (!key && req.originalUrl && req.originalUrl.includes('/pos/sales') && req.body && req.body.items) {
      try {
        const itemSig = (req.body.items || []).map(i => `${i.variantId}:${i.quantity}:${i.unitPrice}`).join('|');
        const hash = crypto.createHash('sha256')
          .update(`${storeId}:${req.auth?.userId || 'anon'}:${itemSig}:${req.body.paymentAmount}`)
          .digest('hex').slice(0, 24);
        key = `auto_pos_${hash}`;
      } catch {
        // Fallback: proceed normally
      }
    }

    if (!key) {
      return next();
    }

    try {
      const existing = db.prepare('SELECT * FROM idempotency_keys WHERE key = ? AND storeId = ?').get(key, storeId);
      if (existing) {
        // Check age: if created within last 24 hours, return cached response
        const createdMs = new Date(existing.createdAt).getTime();
        const nowMs = Date.now();
        if (nowMs - createdMs < 24 * 60 * 60 * 1000) {
          res.setHeader('X-Idempotent-Replay', 'true');
          const parsed = JSON.parse(existing.responseBody);
          return res.status(existing.responseStatus).json(parsed);
        }
      }
    } catch (err) {
      // If table query fails, don't block the request
    }

    // Intercept res.json to capture response
    const originalJson = res.json.bind(res);
    res.json = function (body) {
      if (res.statusCode >= 200 && res.statusCode < 300) {
        try {
          const now = new Date().toISOString();
          db.prepare(`
            INSERT OR REPLACE INTO idempotency_keys (key, storeId, endpoint, responseStatus, responseBody, createdAt)
            VALUES (?, ?, ?, ?, ?, ?)
          `).run(key, storeId, req.originalUrl || req.url, res.statusCode, JSON.stringify(body), now);
        } catch {
          // Ignore cache write errors
        }
      }
      return originalJson(body);
    };

    next();
  };
}

module.exports = idempotencyMiddleware;
