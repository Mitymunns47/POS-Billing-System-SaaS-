import React from 'react';

export function Button({
  children,
  type = 'button',
  variant = 'primary',
  size = 'md',
  isLoading = false,
  loading = false,
  disabled = false,
  className = '',
  onClick,
  ...props
}) {
  const isBusy = isLoading || loading;
  const baseStyles = {
    display: 'inline-flex',
    alignItems: 'center',
    justifyContent: 'center',
    fontWeight: '500',
    borderRadius: 'var(--radius-md)',
    transition: 'all 0.15s ease-in-out',
    cursor: disabled || isBusy ? 'not-allowed' : 'pointer',
    border: '1px solid transparent',
    outline: 'none',
    textDecoration: 'none',
    opacity: disabled || isBusy ? 0.65 : 1
  };

  const sizeStyles = {
    sm: { padding: '6px 12px', fontSize: '0.8125rem' },
    md: { padding: '9px 18px', fontSize: '0.875rem' },
    lg: { padding: '12px 24px', fontSize: '1rem' }
  };

  const variantStyles = {
    primary: {
      backgroundColor: '#7EAFD0',
      color: '#FFFFFF',
      borderColor: '#7EAFD0',
      boxShadow: '0 1px 2px rgba(126, 175, 208, 0.2)'
    },
    secondary: {
      backgroundColor: '#FFFFFF',
      color: '#172033',
      borderColor: 'var(--border-color)',
      boxShadow: 'var(--shadow-sm)'
    },
    outline: {
      backgroundColor: 'transparent',
      color: '#7EAFD0',
      borderColor: '#7EAFD0'
    },
    ghost: {
      backgroundColor: 'transparent',
      color: '#64748B',
      borderColor: 'transparent'
    },
    danger: {
      backgroundColor: 'var(--danger)',
      color: '#FFFFFF',
      borderColor: 'var(--danger)'
    }
  };

  return (
    <button
      type={type}
      style={{
        ...baseStyles,
        ...sizeStyles[size],
        ...variantStyles[variant]
      }}
      disabled={disabled || isBusy}
      onClick={onClick}
      className={className}
      {...props}
    >
      {isBusy && (
        <svg
          style={{
            animation: 'spin 1s linear infinite',
            marginRight: '8px',
            width: '16px',
            height: '16px'
          }}
          viewBox="0 0 24 24"
          fill="none"
          stroke="currentColor"
          strokeWidth="2"
        >
          <style>{`@keyframes spin { 100% { transform: rotate(360deg); } }`}</style>
          <circle cx="12" cy="12" r="10" strokeOpacity="0.25" />
          <path d="M12 2a10 10 0 0 1 10 10" />
        </svg>
      )}
      {children}
    </button>
  );
}
