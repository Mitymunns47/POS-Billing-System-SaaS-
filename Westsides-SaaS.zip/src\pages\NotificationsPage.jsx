import React, { useState, useEffect } from 'react';
import { api } from '../services/api';
import { Card } from '../components/ui/Card';
import { Badge } from '../components/ui/Badge';
import { Button } from '../components/ui/Button';
import {
  Bell,
  CheckCircle2,
  AlertTriangle,
  RotateCcw,
  Receipt,
  Wallet,
  ShieldAlert,
  Clock,
  CheckCheck,
  Package
} from 'lucide-react';

export function NotificationsPage({ onNavigate }) {
  const [notifications, setNotifications] = useState([]);
  const [loading, setLoading] = useState(true);
  const [filterType, setFilterType] = useState('ALL'); // 'ALL' | 'UNREAD' | 'STOCK' | 'TRANSACTIONS'
  const [unreadCount, setUnreadCount] = useState(0);

  useEffect(() => {
    loadNotifications();
  }, []);

  const loadNotifications = async () => {
    setLoading(true);
    try {
      const [notifsRes, countRes] = await Promise.all([
        api.getNotifications({ limit: 100 }),
        api.getUnreadNotificationCount()
      ]);

      if (notifsRes.success) {
        setNotifications(notifsRes.data.notifications || []);
      }
      if (countRes.success) {
        setUnreadCount(countRes.count || 0);
      }
    } catch (err) {
      console.error('Load notifications error:', err);
    } finally {
      setLoading(false);
    }
  };

  const handleMarkAsRead = async (id) => {
    try {
      await api.markNotificationRead(id);
      setNotifications(prev => prev.map(n => n.id === id ? { ...n, isRead: true } : n));
      setUnreadCount(prev => Math.max(0, prev - 1));
    } catch (err) {
      console.error('Mark read error:', err);
    }
  };

  const handleMarkAllRead = async () => {
    try {
      await api.markAllNotificationsRead();
      setNotifications(prev => prev.map(n => ({ ...n, isRead: true })));
      setUnreadCount(0);
    } catch (err) {
      console.error('Mark all read error:', err);
    }
  };

  const filteredNotifications = notifications.filter(n => {
    if (filterType === 'UNREAD') return !n.isRead;
    if (filterType === 'STOCK') return n.type === 'LOW_STOCK' || n.type === 'OUT_OF_STOCK';
    if (filterType === 'TRANSACTIONS') return n.type === 'SALE_COMPLETED' || n.type === 'RETURN_COMPLETED' || n.type === 'EXPENSE_CREATED';
    return true;
  });

  const getNotificationIcon = (type) => {
    switch (type) {
      case 'OUT_OF_STOCK':
        return <ShieldAlert size={18} color="#DC2626" />;
      case 'LOW_STOCK':
        return <AlertTriangle size={18} color="#D97706" />;
      case 'SALE_COMPLETED':
        return <Receipt size={18} color="#16A34A" />;
      case 'RETURN_COMPLETED':
        return <RotateCcw size={18} color="#0284C7" />;
      case 'EXPENSE_CREATED':
        return <Wallet size={18} color="#7C3AED" />;
      default:
        return <Bell size={18} color="#7EAFD0" />;
    }
  };

  return (
    <div style={{ padding: '1.5rem', maxWidth: '1000px', margin: '0 auto' }}>
      {/* Title */}
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: '1.5rem', flexWrap: 'wrap', gap: '1rem' }}>
        <div>
          <h1 style={{ fontSize: '1.625rem', fontWeight: '700', color: 'var(--text-main)', margin: '0 0 0.25rem 0', letterSpacing: '-0.02em', display: 'flex', alignItems: 'center', gap: '0.625rem' }}>
            <Bell size={26} color="#7EAFD0" />
            Notifications & Operational Alert Center
          </h1>
          <p style={{ margin: 0, fontSize: '0.875rem', color: 'var(--text-muted)' }}>
            Real-time stock warnings, completed sales, customer returns, and store activity alerts.
          </p>
        </div>

        <div style={{ display: 'flex', gap: '0.5rem', alignItems: 'center' }}>
          {unreadCount > 0 && (
            <Button
              variant="outline"
              size="sm"
              onClick={handleMarkAllRead}
              style={{ display: 'flex', alignItems: 'center', gap: '6px' }}
            >
              <CheckCheck size={14} /> Mark All as Read ({unreadCount})
            </Button>
          )}
        </div>
      </div>

      {/* Filter Tabs */}
      <div style={{ display: 'flex', gap: '0.5rem', marginBottom: '1.25rem', flexWrap: 'wrap' }}>
        {[
          { id: 'ALL', label: 'All Alerts' },
          { id: 'UNREAD', label: `Unread (${unreadCount})` },
          { id: 'STOCK', label: 'Inventory & Stock' },
          { id: 'TRANSACTIONS', label: 'Sales & Returns' }
        ].map(f => (
          <button
            key={f.id}
            onClick={() => setFilterType(f.id)}
            style={{
              padding: '6px 14px',
              borderRadius: 'var(--radius-md)',
              border: filterType === f.id ? '1px solid #7EAFD0' : '1px solid var(--border-color)',
              backgroundColor: filterType === f.id ? '#F0F9FF' : '#FFFFFF',
              color: filterType === f.id ? '#0369A1' : 'var(--text-main)',
              fontSize: '0.8125rem',
              fontWeight: filterType === f.id ? '600' : '500',
              cursor: 'pointer',
              transition: 'all 0.15s ease'
            }}
          >
            {f.label}
          </button>
        ))}
      </div>

      {/* Notification List */}
      <Card style={{ padding: '0.5rem' }}>
        {loading ? (
          <div style={{ padding: '3rem', textAlign: 'center', color: 'var(--text-muted)' }}>
            Loading notification updates...
          </div>
        ) : filteredNotifications.length === 0 ? (
          <div style={{ padding: '3rem', textAlign: 'center', color: 'var(--text-muted)' }}>
            <Bell size={36} color="#CBD5E1" style={{ margin: '0 auto 0.75rem', display: 'block' }} />
            <div style={{ fontWeight: '600', color: 'var(--text-main)', marginBottom: '4px' }}>No notifications found</div>
            <div style={{ fontSize: '0.8125rem' }}>You're all caught up with current store operations.</div>
          </div>
        ) : (
          <div style={{ display: 'flex', flexDirection: 'column' }}>
            {filteredNotifications.map(item => (
              <div
                key={item.id}
                style={{
                  display: 'flex',
                  alignItems: 'flex-start',
                  justifyContent: 'space-between',
                  gap: '1rem',
                  padding: '1rem',
                  borderBottom: '1px solid var(--border-subtle)',
                  backgroundColor: !item.isRead ? '#F8FAFC' : '#FFFFFF',
                  borderRadius: 'var(--radius-md)',
                  transition: 'background 0.15s ease'
                }}
              >
                <div style={{ display: 'flex', alignItems: 'flex-start', gap: '0.875rem', flex: 1 }}>
                  <div
                    style={{
                      width: '36px',
                      height: '36px',
                      borderRadius: '50%',
                      backgroundColor: 'var(--bg-page)',
                      border: '1px solid var(--border-color)',
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'center',
                      flexShrink: 0,
                      marginTop: '2px'
                    }}
                  >
                    {getNotificationIcon(item.type)}
                  </div>

                  <div style={{ flex: 1 }}>
                    <div style={{ display: 'flex', alignItems: 'center', gap: '8px', marginBottom: '2px' }}>
                      <span style={{ fontWeight: !item.isRead ? '700' : '600', color: 'var(--text-main)', fontSize: '0.9375rem' }}>
                        {item.title}
                      </span>
                      {!item.isRead && (
                        <span style={{ width: '8px', height: '8px', borderRadius: '50%', backgroundColor: '#0284C7', display: 'inline-block' }} />
                      )}
                    </div>

                    <div style={{ fontSize: '0.8125rem', color: 'var(--text-muted)', marginBottom: '6px' }}>
                      {item.message}
                    </div>

                    <div style={{ fontSize: '0.75rem', color: 'var(--text-muted)', display: 'flex', alignItems: 'center', gap: '4px' }}>
                      <Clock size={12} />
                      {item.createdAt ? item.createdAt.replace('T', ' ').substring(0, 16) : ''}
                    </div>
                  </div>
                </div>

                {!item.isRead && (
                  <button
                    onClick={() => handleMarkAsRead(item.id)}
                    style={{
                      background: 'none',
                      border: 'none',
                      color: '#7EAFD0',
                      fontSize: '0.75rem',
                      fontWeight: '600',
                      cursor: 'pointer',
                      padding: '4px 8px',
                      borderRadius: 'var(--radius-sm)'
                    }}
                  >
                    Mark Read
                  </button>
                )}
              </div>
            ))}
          </div>
        )}
      </Card>
    </div>
  );
}
