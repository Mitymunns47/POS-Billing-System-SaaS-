/**
 * AdminPlansPage.jsx — Phase 7
 * Subscription plan management for the SaaS platform.
 */
import React, { useEffect, useState } from 'react';
import { api } from '../../services/api';

const COLORS = {
  card: '#1E293B', border: 'rgba(126,175,208,0.12)',
  text: '#F1F5F9', muted: '#64748B', accent: '#7EAFD0',
  success: '#10B981', warn: '#F59E0B', danger: '#EF4444'
};

const FEATURE_LABELS = {
  FEATURE_POS: 'POS & Billing',
  FEATURE_INVENTORY: 'Inventory Management',
  FEATURE_REPORTS: 'Reports & Analytics',
  FEATURE_EXPENSES: 'Expense Tracking',
  FEATURE_RETURNS: 'Returns & Refunds',
  FEATURE_ADVANCED_ANALYTICS: 'Advanced Analytics',
  FEATURE_STAFF_MANAGEMENT: 'Staff Management',
  FEATURE_EXPORTS: 'Data Exports',
  FEATURE_NOTIFICATIONS: 'Notifications',
  FEATURE_MULTI_USER: 'Multi-User Access'
};

export function AdminPlansPage() {
  const [plans, setPlans] = useState([]);
  const [loading, setLoading] = useState(true);
  const [editPlan, setEditPlan] = useState(null);
  const [editForm, setEditForm] = useState({});
  const [saving, setSaving] = useState(false);
  const [msg, setMsg] = useState('');
  const [error, setError] = useState('');

  const load = () => {
    api.adminListPlans().then(r => { if (r.success) setPlans(r.plans); }).finally(() => setLoading(false));
  };

  useEffect(load, []);

  const openEdit = (plan) => {
    setEditPlan(plan);
    setEditForm({ name: plan.name, description: plan.description, price: plan.price, trialDays: plan.trialDays, maxUsers: plan.maxUsers, maxProducts: plan.maxProducts, maxCustomers: plan.maxCustomers, isActive: plan.isActive });
    setMsg(''); setError('');
  };

  const handleSave = async () => {
    setSaving(true);
    try {
      const res = await api.adminUpdatePlan(editPlan.id, editForm);
      if (res.success) {
        setMsg('Plan updated successfully.');
        setEditPlan(null);
        load();
      }
    } catch (err) { setError(err.message); }
    finally { setSaving(false); }
  };

  if (loading) return <div style={{ color: COLORS.muted, padding: '3rem', textAlign: 'center' }}>Loading plans...</div>;

  return (
    <div style={{ padding: '1.75rem', fontFamily: "'Inter', 'Segoe UI', sans-serif" }}>
      <div style={{ marginBottom: '1.5rem' }}>
        <h1 style={{ color: COLORS.text, fontSize: '1.375rem', fontWeight: '700', margin: '0 0 0.25rem' }}>Subscription Plans</h1>
        <p style={{ color: COLORS.muted, fontSize: '0.875rem', margin: 0 }}>Manage SaaS pricing plans and feature entitlements</p>
      </div>

      {msg && <div style={{ background: '#10B98120', border: '1px solid #10B98140', borderRadius: '8px', padding: '0.75rem 1rem', color: '#10B981', fontSize: '0.875rem', marginBottom: '1rem' }}>{msg}</div>}
      {error && <div style={{ background: '#EF444420', border: '1px solid #EF444440', borderRadius: '8px', padding: '0.75rem 1rem', color: '#EF4444', fontSize: '0.875rem', marginBottom: '1rem' }}>{error}</div>}

      {/* Edit modal */}
      {editPlan && (
        <div style={{ position: 'fixed', inset: 0, background: 'rgba(0,0,0,0.7)', zIndex: 200, display: 'flex', alignItems: 'center', justifyContent: 'center', padding: '1rem' }}>
          <div style={{ background: '#1E293B', borderRadius: '16px', border: `1px solid ${COLORS.border}`, padding: '2rem', width: '100%', maxWidth: '480px', maxHeight: '90vh', overflowY: 'auto' }}>
            <h2 style={{ color: COLORS.text, fontSize: '1.125rem', fontWeight: '700', margin: '0 0 1.5rem' }}>Edit Plan: {editPlan.name}</h2>
            {[
              { label: 'Name', key: 'name', type: 'text' },
              { label: 'Description', key: 'description', type: 'text' },
              { label: 'Price (₹/month)', key: 'price', type: 'number' },
              { label: 'Trial Days', key: 'trialDays', type: 'number' },
              { label: 'Max Users', key: 'maxUsers', type: 'number' },
              { label: 'Max Products', key: 'maxProducts', type: 'number' },
              { label: 'Max Customers', key: 'maxCustomers', type: 'number' }
            ].map(({ label, key, type }) => (
              <div key={key} style={{ marginBottom: '1rem' }}>
                <label style={{ color: COLORS.muted, fontSize: '0.8125rem', display: 'block', marginBottom: '0.375rem' }}>{label}</label>
                <input
                  type={type}
                  value={editForm[key] ?? ''}
                  onChange={e => setEditForm(f => ({ ...f, [key]: type === 'number' ? Number(e.target.value) : e.target.value }))}
                  style={{ width: '100%', boxSizing: 'border-box', padding: '0.625rem 0.875rem', background: '#263348', border: `1px solid ${COLORS.border}`, borderRadius: '8px', color: COLORS.text, fontSize: '0.875rem', outline: 'none' }}
                />
              </div>
            ))}
            <div style={{ marginBottom: '1rem', display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
              <input type="checkbox" id="planActive" checked={Boolean(editForm.isActive)} onChange={e => setEditForm(f => ({ ...f, isActive: e.target.checked ? 1 : 0 }))} />
              <label htmlFor="planActive" style={{ color: COLORS.muted, fontSize: '0.8125rem' }}>Plan is Active</label>
            </div>
            <div style={{ display: 'flex', gap: '0.75rem', marginTop: '1.5rem' }}>
              <button onClick={handleSave} disabled={saving} style={{ flex: 1, padding: '0.75rem', background: 'linear-gradient(135deg, #7EAFD0, #5B91B8)', border: 'none', borderRadius: '8px', color: '#fff', fontWeight: '600', cursor: 'pointer' }}>
                {saving ? 'Saving...' : 'Save Changes'}
              </button>
              <button onClick={() => setEditPlan(null)} style={{ flex: 1, padding: '0.75rem', background: 'transparent', border: `1px solid ${COLORS.border}`, borderRadius: '8px', color: COLORS.muted, cursor: 'pointer' }}>
                Cancel
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Plan cards */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(280px, 1fr))', gap: '1rem' }}>
        {plans.map(plan => (
          <div key={plan.id} style={{ background: COLORS.card, border: `1px solid ${COLORS.border}`, borderRadius: '12px', padding: '1.25rem' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: '0.75rem' }}>
              <div>
                <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
                  <h3 style={{ color: COLORS.text, fontWeight: '700', fontSize: '1.125rem', margin: 0 }}>{plan.name}</h3>
                  {!plan.isActive && <span style={{ background: '#EF444420', color: '#EF4444', borderRadius: '6px', padding: '1px 6px', fontSize: '0.6875rem', fontWeight: '600' }}>INACTIVE</span>}
                </div>
                <div style={{ color: COLORS.muted, fontSize: '0.8125rem', marginTop: '0.25rem' }}>{plan.description}</div>
              </div>
              <button onClick={() => openEdit(plan)} style={{ padding: '4px 12px', background: 'rgba(126,175,208,0.1)', border: `1px solid ${COLORS.border}`, borderRadius: '6px', color: COLORS.accent, fontSize: '0.75rem', cursor: 'pointer', fontWeight: '500' }}>
                Edit
              </button>
            </div>

            <div style={{ fontSize: '1.75rem', fontWeight: '700', color: COLORS.accent, marginBottom: '0.25rem' }}>
              {plan.price === 0 ? 'Free' : `₹${plan.price.toLocaleString('en-IN')}`}
              {plan.price > 0 && <span style={{ fontSize: '0.875rem', color: COLORS.muted, fontWeight: '400' }}>/month</span>}
            </div>

            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: '0.5rem', margin: '1rem 0', padding: '0.75rem', background: '#263348', borderRadius: '8px' }}>
              {[
                { label: 'Users', value: plan.maxUsers >= 9999 ? '∞' : plan.maxUsers },
                { label: 'Products', value: plan.maxProducts >= 9999 ? '∞' : plan.maxProducts },
                { label: 'Customers', value: plan.maxCustomers >= 9999 ? '∞' : plan.maxCustomers }
              ].map(({ label, value }) => (
                <div key={label} style={{ textAlign: 'center' }}>
                  <div style={{ color: COLORS.text, fontWeight: '700', fontSize: '1rem' }}>{value}</div>
                  <div style={{ color: COLORS.muted, fontSize: '0.6875rem' }}>{label}</div>
                </div>
              ))}
            </div>

            <div style={{ marginTop: '0.75rem' }}>
              {plan.features?.map(f => (
                <div key={f.featureKey} style={{ display: 'flex', alignItems: 'center', gap: '0.375rem', padding: '0.25rem 0', fontSize: '0.8125rem' }}>
                  <span style={{ color: f.enabled ? COLORS.success : COLORS.muted }}>
                    {f.enabled ? '✓' : '✗'}
                  </span>
                  <span style={{ color: f.enabled ? COLORS.text : COLORS.muted }}>
                    {FEATURE_LABELS[f.featureKey] || f.featureKey}
                  </span>
                </div>
              ))}
            </div>

            <div style={{ marginTop: '1rem', paddingTop: '0.75rem', borderTop: `1px solid ${COLORS.border}`, display: 'flex', justifyContent: 'space-between', fontSize: '0.8125rem' }}>
              <span style={{ color: COLORS.muted }}>Trial: {plan.trialDays} days</span>
              <span style={{ color: COLORS.accent, fontWeight: '600' }}>{plan.storeCount} store{plan.storeCount !== 1 ? 's' : ''}</span>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
