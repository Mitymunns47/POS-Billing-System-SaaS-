const crypto = require('crypto');
const db = require('../db/database');

const SubscriptionModel = {
  // ── Plans ──────────────────────────────────────────────────────────────────
  listPlans: () => {
    return db.prepare('SELECT * FROM subscription_plans ORDER BY sortOrder ASC').all();
  },

  findPlanById: (id) => {
    return db.prepare('SELECT * FROM subscription_plans WHERE id = ?').get(id);
  },

  getPlanFeatures: (planId) => {
    return db.prepare('SELECT featureKey, enabled FROM plan_features WHERE planId = ?').all(planId);
  },

  updatePlan: (id, fields) => {
    const now = new Date().toISOString();
    const allowed = ['name', 'description', 'price', 'trialDays', 'maxUsers', 'maxProducts', 'maxCustomers', 'isActive'];
    const updates = [];
    const values = [];
    for (const key of allowed) {
      if (fields[key] !== undefined) {
        updates.push(`${key} = ?`);
        values.push(fields[key]);
      }
    }
    if (updates.length === 0) return SubscriptionModel.findPlanById(id);
    updates.push('updatedAt = ?');
    values.push(now, id);
    db.prepare(`UPDATE subscription_plans SET ${updates.join(', ')} WHERE id = ?`).run(...values);
    return SubscriptionModel.findPlanById(id);
  },

  // ── Store Subscriptions ────────────────────────────────────────────────────
  getStoreSubscription: (storeId) => {
    return db.prepare(`
      SELECT ss.*, sp.name as planName, sp.slug as planSlug, sp.price as planPrice
      FROM store_subscriptions ss
      JOIN subscription_plans sp ON ss.planId = sp.id
      WHERE ss.storeId = ?
    `).get(storeId);
  },

  createSubscription: ({ storeId, planId, status = 'TRIALING', trialDays = 14 }) => {
    const id = 'sub_' + crypto.randomBytes(8).toString('hex');
    const now = new Date().toISOString();
    const trialStart = now;
    const trialEnd = new Date(Date.now() + trialDays * 86400 * 1000).toISOString();
    const periodStart = now;
    const periodEnd = new Date(Date.now() + 30 * 86400 * 1000).toISOString();

    db.prepare(`
      INSERT INTO store_subscriptions
      (id, storeId, planId, status, trialStartDate, trialEndDate, currentPeriodStart, currentPeriodEnd, createdAt, updatedAt)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `).run(id, storeId, planId, status, trialStart, trialEnd, periodStart, periodEnd, now, now);

    return SubscriptionModel.getStoreSubscription(storeId);
  },

  updateSubscriptionStatus: ({ storeId, status, suspendedBy = null, suspensionReason = null }) => {
    const now = new Date().toISOString();
    const updates = { status, updatedAt: now };
    if (status === 'SUSPENDED') {
      updates.suspendedAt = now;
      updates.suspendedBy = suspendedBy;
      updates.suspensionReason = suspensionReason;
    }
    if (status === 'CANCELLED') {
      updates.cancelledAt = now;
    }
    if (status === 'ACTIVE') {
      updates.suspendedAt = null;
      updates.suspendedBy = null;
      updates.suspensionReason = null;
      updates.cancelledAt = null;
    }

    const setClauses = Object.keys(updates).map(k => `${k} = ?`).join(', ');
    db.prepare(`UPDATE store_subscriptions SET ${setClauses} WHERE storeId = ?`).run(...Object.values(updates), storeId);
    return SubscriptionModel.getStoreSubscription(storeId);
  },

  changePlan: ({ storeId, newPlanId }) => {
    const now = new Date().toISOString();
    db.prepare('UPDATE store_subscriptions SET planId = ?, status = ?, updatedAt = ? WHERE storeId = ?')
      .run(newPlanId, 'ACTIVE', now, storeId);
    return SubscriptionModel.getStoreSubscription(storeId);
  },

  // ── Subscription Invoices ──────────────────────────────────────────────────
  listInvoices: ({ storeId = null, limit = 50, offset = 0 } = {}) => {
    if (storeId) {
      return db.prepare(`
        SELECT si.*, s.name as storeName
        FROM subscription_invoices si
        JOIN stores s ON si.storeId = s.id
        WHERE si.storeId = ?
        ORDER BY si.createdAt DESC LIMIT ? OFFSET ?
      `).all(storeId, limit, offset);
    }
    return db.prepare(`
      SELECT si.*, s.name as storeName
      FROM subscription_invoices si
      JOIN stores s ON si.storeId = s.id
      ORDER BY si.createdAt DESC LIMIT ? OFFSET ?
    `).all(limit, offset);
  },

  createInvoice: ({ storeId, subscriptionId, planId, planName, amount, billingPeriodStart, billingPeriodEnd, dueDate }) => {
    const id = 'sinv_' + crypto.randomBytes(8).toString('hex');
    const now = new Date().toISOString();
    db.prepare(`
      INSERT INTO subscription_invoices
      (id, storeId, subscriptionId, planId, planName, amount, currency, billingPeriodStart, billingPeriodEnd, status, paymentStatus, dueDate, createdAt, updatedAt)
      VALUES (?, ?, ?, ?, ?, ?, 'INR', ?, ?, 'PENDING', 'PENDING', ?, ?, ?)
    `).run(id, storeId, subscriptionId, planId, planName, amount, billingPeriodStart, billingPeriodEnd, dueDate, now, now);
    return db.prepare('SELECT * FROM subscription_invoices WHERE id = ?').get(id);
  },

  markInvoicePaid: (invoiceId) => {
    const now = new Date().toISOString();
    db.prepare('UPDATE subscription_invoices SET status = ?, paymentStatus = ?, paidAt = ?, updatedAt = ? WHERE id = ?')
      .run('PAID', 'PAID', now, now, invoiceId);
    return db.prepare('SELECT * FROM subscription_invoices WHERE id = ?').get(invoiceId);
  }
};

module.exports = SubscriptionModel;
