const crypto = require('crypto');
const db = require('../db/database');

const StoreModel = {
  create: ({ name, address, city, state, country, gstNumber, phone, currency, category }) => {
    const id = 'str_' + crypto.randomBytes(8).toString('hex');
    const now = new Date().toISOString();

    const stmt = db.prepare(`
      INSERT INTO stores (
        id, name, address, city, state, country, gstNumber, phone,
        currency, category, onboardingStep, onboardingCompleted, createdAt, updatedAt
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);

    stmt.run(
      id,
      name.trim(),
      address ? address.trim() : '',
      city ? city.trim() : '',
      state ? state.trim() : '',
      country ? country.trim() : 'India',
      gstNumber ? gstNumber.trim().toUpperCase() : '',
      phone ? phone.trim() : '',
      currency || 'INR',
      category || 'Apparel & Fashion',
      1, // Initial onboarding step
      0, // Not completed initially
      now,
      now
    );

    return StoreModel.findById(id);
  },

  findById: (id) => {
    const stmt = db.prepare('SELECT * FROM stores WHERE id = ?');
    const store = stmt.get(id);
    if (!store) return null;
    return {
      ...store,
      onboardingCompleted: Boolean(store.onboardingCompleted)
    };
  },

  update: (id, fields) => {
    const now = new Date().toISOString();
    const current = StoreModel.findById(id);
    if (!current) return null;

    const stmt = db.prepare(`
      UPDATE stores SET
        name = COALESCE(?, name),
        address = COALESCE(?, address),
        city = COALESCE(?, city),
        state = COALESCE(?, state),
        country = COALESCE(?, country),
        gstNumber = COALESCE(?, gstNumber),
        phone = COALESCE(?, phone),
        currency = COALESCE(?, currency),
        category = COALESCE(?, category),
        receiptHeader = COALESCE(?, receiptHeader),
        receiptFooter = COALESCE(?, receiptFooter),
        onboardingStep = COALESCE(?, onboardingStep),
        onboardingCompleted = COALESCE(?, onboardingCompleted),
        updatedAt = ?
      WHERE id = ?
    `);

    stmt.run(
      fields.name !== undefined ? fields.name.trim() : null,
      fields.address !== undefined ? fields.address.trim() : null,
      fields.city !== undefined ? fields.city.trim() : null,
      fields.state !== undefined ? fields.state.trim() : null,
      fields.country !== undefined ? fields.country.trim() : null,
      fields.gstNumber !== undefined ? fields.gstNumber.trim().toUpperCase() : null,
      fields.phone !== undefined ? fields.phone.trim() : null,
      fields.currency !== undefined ? fields.currency : null,
      fields.category !== undefined ? fields.category : null,
      fields.receiptHeader !== undefined ? fields.receiptHeader : null,
      fields.receiptFooter !== undefined ? fields.receiptFooter : null,
      fields.onboardingStep !== undefined ? fields.onboardingStep : null,
      fields.onboardingCompleted !== undefined ? (fields.onboardingCompleted ? 1 : 0) : null,
      now,
      id
    );

    return StoreModel.findById(id);
  }
};

module.exports = StoreModel;
