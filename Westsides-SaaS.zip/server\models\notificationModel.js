const crypto = require('crypto');
const db = require('../db/database');

const NotificationModel = {
  /**
   * Create notification with deduplication protection.
   */
  create: ({ storeId, userId = null, targetRole = 'ALL', type, title, message, recordId = null, recordType = null }) => {
    // Deduplication check: do not create duplicate unread alert for same record within 24 hours
    if (recordId && type) {
      const recent = db.prepare(`
        SELECT id FROM notifications
        WHERE storeId = ? AND type = ? AND recordId = ? AND isRead = 0
        LIMIT 1
      `).get(storeId, type, recordId);
      if (recent) return recent;
    }

    const id = 'not_' + crypto.randomBytes(8).toString('hex');
    const now = new Date().toISOString();

    db.prepare(`
      INSERT INTO notifications (id, storeId, userId, targetRole, type, title, message, recordId, recordType, isRead, createdAt)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 0, ?)
    `).run(id, storeId, userId, targetRole, type, title, message, recordId, recordType, now);

    return db.prepare('SELECT * FROM notifications WHERE id = ?').get(id);
  },

  /**
   * Fetch notifications with role-based visibility and pagination
   */
  findAll: ({ storeId, userId = null, role = 'OWNER', isRead = null, limit = 50, page = 1 }) => {
    const offset = (page - 1) * limit;
    const conditions = ['storeId = ?'];
    const params = [storeId];

    // Role-based visibility
    if (role === 'CASHIER') {
      conditions.push("(targetRole IN ('ALL', 'CASHIER') OR userId = ?)");
      params.push(userId);
    } else if (role === 'STAFF') {
      conditions.push("(targetRole IN ('ALL', 'STAFF') OR userId = ?)");
      params.push(userId);
    }

    if (isRead !== null && isRead !== undefined && isRead !== '') {
      conditions.push('isRead = ?');
      params.push(isRead ? 1 : 0);
    }

    const where = conditions.join(' AND ');
    const total = db.prepare(`SELECT COUNT(*) as count FROM notifications WHERE ${where}`).get(...params).count;

    const rows = db.prepare(`
      SELECT * FROM notifications
      WHERE ${where}
      ORDER BY isRead ASC, createdAt DESC
      LIMIT ? OFFSET ?
    `).all(...params, limit, offset);

    return {
      notifications: rows.map(r => ({ ...r, isRead: Boolean(r.isRead) })),
      total,
      pagination: {
        page,
        limit,
        total,
        totalPages: Math.ceil(total / limit)
      }
    };
  },

  /**
   * Get unread notification count
   */
  getUnreadCount: (storeId, userId = null, role = 'OWNER') => {
    const conditions = ['storeId = ?', 'isRead = 0'];
    const params = [storeId];

    if (role === 'CASHIER') {
      conditions.push("(targetRole IN ('ALL', 'CASHIER') OR userId = ?)");
      params.push(userId);
    } else if (role === 'STAFF') {
      conditions.push("(targetRole IN ('ALL', 'STAFF') OR userId = ?)");
      params.push(userId);
    }

    const row = db.prepare(`
      SELECT COUNT(*) as count FROM notifications
      WHERE ${conditions.join(' AND ')}
    `).get(...params);

    return Number(row?.count) || 0;
  },

  /**
   * Mark single notification as read
   */
  markAsRead: (id, storeId) => {
    db.prepare('UPDATE notifications SET isRead = 1 WHERE id = ? AND storeId = ?').run(id, storeId);
    return true;
  },

  /**
   * Mark all eligible notifications as read
   */
  markAllAsRead: (storeId, userId = null, role = 'OWNER') => {
    const conditions = ['storeId = ?', 'isRead = 0'];
    const params = [storeId];

    if (role === 'CASHIER') {
      conditions.push("(targetRole IN ('ALL', 'CASHIER') OR userId = ?)");
      params.push(userId);
    } else if (role === 'STAFF') {
      conditions.push("(targetRole IN ('ALL', 'STAFF') OR userId = ?)");
      params.push(userId);
    }

    db.prepare(`UPDATE notifications SET isRead = 1 WHERE ${conditions.join(' AND ')}`).run(...params);
    return true;
  },

  /**
   * Run operational scan for inventory low-stock alerts
   */
  checkLowStockAlerts: (storeId) => {
    const variants = db.prepare(`
      SELECT pv.id as variantId, pv.sku, pv.size, pv.color, pv.stock, pv.minimumStock,
             p.id as productId, p.name as productName
      FROM product_variants pv
      JOIN products p ON pv.productId = p.id
      WHERE pv.storeId = ? AND pv.active = 1 AND p.archived = 0 AND p.active = 1
        AND pv.stock <= pv.minimumStock
    `).all(storeId);

    for (const v of variants) {
      const variantDesc = [v.size, v.color].filter(Boolean).join(' / ') || v.sku || 'Default';
      if (v.stock === 0) {
        NotificationModel.create({
          storeId,
          targetRole: 'ALL',
          type: 'OUT_OF_STOCK',
          title: `Out of Stock: ${v.productName} (${variantDesc})`,
          message: `Stock level has hit 0 units. Reorder urgently to avoid missed sales.`,
          recordId: v.variantId,
          recordType: 'variant'
        });
      } else {
        NotificationModel.create({
          storeId,
          targetRole: 'ALL',
          type: 'LOW_STOCK',
          title: `Low Stock: ${v.productName} (${variantDesc})`,
          message: `Only ${v.stock} units remaining (Threshold is ${v.minimumStock}).`,
          recordId: v.variantId,
          recordType: 'variant'
        });
      }
    }
  }
};

module.exports = NotificationModel;
