/**
 * Platform Admin Routes — /api/admin/*
 * ALL routes require SUPER_ADMIN privileges verified server-side.
 * Never trusts client-provided role, storeId, tenantId, or admin flag.
 */
const express = require('express');
const router = express.Router();
const db = require('../db/database');
const requireSuperAdmin = require('../middleware/requireSuperAdmin');
const PlatformAdminModel = require('../models/platformAdminModel');
const SubscriptionModel = require('../models/subscriptionModel');
const PlatformAuditModel = require('../models/platformAuditModel');

// Apply super admin guard to all routes in this file
router.use(requireSuperAdmin);

// ── Helper ─────────────────────────────────────────────────────────────────
const auditLog = (req, action, description, { targetType = null, targetId = null, targetName = null, metadata = null } = {}) => {
  try {
    PlatformAuditModel.log({
      adminId: req.platformAdmin.userId,
      adminEmail: req.platformAdmin.userEmail,
      action,
      targetType,
      targetId,
      targetName,
      description,
      metadata,
      ipAddress: req.ip || req.connection?.remoteAddress || null
    });
  } catch {}
};

// ─────────────────────────────────────────────────────────────────────────────
// PLATFORM DASHBOARD — /api/admin/dashboard
// ─────────────────────────────────────────────────────────────────────────────
router.get('/dashboard', (req, res) => {
  try {
    // Aggregate platform-wide stats
    const totalStores = db.prepare('SELECT COUNT(*) as cnt FROM stores').get().cnt;
    const activeStores = db.prepare("SELECT COUNT(*) as cnt FROM stores WHERE status = 'ACTIVE' OR status IS NULL").get().cnt;
    const suspendedStores = db.prepare("SELECT COUNT(*) as cnt FROM stores WHERE status = 'SUSPENDED'").get().cnt;
    const totalUsers = db.prepare('SELECT COUNT(*) as cnt FROM users').get().cnt;

    // Subscription breakdown
    const subStats = db.prepare(`
      SELECT status, COUNT(*) as cnt FROM store_subscriptions GROUP BY status
    `).all();
    const subByStatus = {};
    for (const row of subStats) subByStatus[row.status] = row.cnt;

    // Revenue from subscription invoices (PAID)
    const revenueRow = db.prepare("SELECT COALESCE(SUM(amount), 0) as total FROM subscription_invoices WHERE paymentStatus = 'PAID'").get();
    const totalRevenue = revenueRow.total;

    // Monthly revenue (current month)
    const monthStart = new Date();
    monthStart.setDate(1);
    monthStart.setHours(0, 0, 0, 0);
    const monthlyRevenue = db.prepare(
      "SELECT COALESCE(SUM(amount), 0) as total FROM subscription_invoices WHERE paymentStatus = 'PAID' AND paidAt >= ?"
    ).get(monthStart.toISOString()).total;

    // Plan distribution
    const planDist = db.prepare(`
      SELECT sp.name as planName, COUNT(ss.id) as storeCount
      FROM store_subscriptions ss
      JOIN subscription_plans sp ON ss.planId = sp.id
      GROUP BY sp.id
    `).all();

    // Recent stores (last 10)
    const recentStores = db.prepare(`
      SELECT s.id, s.name, s.city, s.status, s.createdAt,
             ss.status as subStatus, sp.name as planName
      FROM stores s
      LEFT JOIN store_subscriptions ss ON ss.storeId = s.id
      LEFT JOIN subscription_plans sp ON ss.planId = sp.id
      ORDER BY s.createdAt DESC LIMIT 10
    `).all();

    // Monthly store registrations (last 6 months)
    const monthlyGrowth = db.prepare(`
      SELECT strftime('%Y-%m', createdAt) as month, COUNT(*) as count
      FROM stores
      GROUP BY month
      ORDER BY month DESC LIMIT 6
    `).all().reverse();

    // Platform admin count
    const adminCount = db.prepare('SELECT COUNT(*) as cnt FROM platform_admins WHERE isActive = 1').get().cnt;

    return res.json({
      success: true,
      dashboard: {
        summary: {
          totalStores,
          activeStores,
          suspendedStores,
          totalUsers,
          adminCount,
          totalRevenue,
          monthlyRevenue
        },
        subscriptions: {
          byStatus: subByStatus,
          byPlan: planDist
        },
        recentStores,
        monthlyGrowth
      }
    });
  } catch (err) {
    console.error('Admin dashboard error:', err);
    return res.status(500).json({ success: false, error: 'Failed to load platform dashboard.' });
  }
});

// ─────────────────────────────────────────────────────────────────────────────
// TENANT / STORE MANAGEMENT — /api/admin/stores
// ─────────────────────────────────────────────────────────────────────────────
router.get('/stores', (req, res) => {
  try {
    const { search = '', status = '', plan = '', page = 1, limit = 20 } = req.query;
    const offset = (parseInt(page) - 1) * parseInt(limit);
    const conditions = [];
    const params = [];

    if (search) {
      conditions.push("(s.name LIKE ? OR s.city LIKE ? OR s.gstNumber LIKE ?)");
      params.push(`%${search}%`, `%${search}%`, `%${search}%`);
    }
    if (status) { conditions.push("s.status = ?"); params.push(status); }
    if (plan) { conditions.push("sp.slug = ?"); params.push(plan); }

    const where = conditions.length ? 'WHERE ' + conditions.join(' AND ') : '';

    const countQuery = `
      SELECT COUNT(*) as cnt FROM stores s
      LEFT JOIN store_subscriptions ss ON ss.storeId = s.id
      LEFT JOIN subscription_plans sp ON ss.planId = sp.id
      ${where}
    `;
    const total = db.prepare(countQuery).get(...params).cnt;

    const stores = db.prepare(`
      SELECT
        s.id, s.name, s.city, s.state, s.phone, s.gstNumber, s.status, s.createdAt,
        ss.status as subStatus, ss.trialEndDate, ss.currentPeriodEnd,
        sp.name as planName, sp.slug as planSlug, sp.price as planPrice,
        (SELECT COUNT(*) FROM store_users su WHERE su.storeId = s.id AND su.status = 'ACTIVE') as userCount,
        (SELECT COUNT(*) FROM products p WHERE p.storeId = s.id AND p.active = 1) as productCount,
        (SELECT COUNT(*) FROM sales sa WHERE sa.storeId = s.id) as saleCount
      FROM stores s
      LEFT JOIN store_subscriptions ss ON ss.storeId = s.id
      LEFT JOIN subscription_plans sp ON ss.planId = sp.id
      ${where}
      ORDER BY s.createdAt DESC LIMIT ? OFFSET ?
    `).all(...params, parseInt(limit), offset);

    return res.json({ success: true, stores, total, page: parseInt(page), limit: parseInt(limit) });
  } catch (err) {
    console.error('Admin list stores error:', err);
    return res.status(500).json({ success: false, error: 'Failed to fetch stores.' });
  }
});

router.get('/stores/:storeId', (req, res) => {
  try {
    const { storeId } = req.params;
    const store = db.prepare(`
      SELECT
        s.*,
        ss.id as subId, ss.status as subStatus, ss.trialStartDate, ss.trialEndDate,
        ss.currentPeriodStart, ss.currentPeriodEnd, ss.suspendedAt, ss.suspensionReason, ss.cancelledAt,
        sp.id as planId, sp.name as planName, sp.slug as planSlug, sp.price as planPrice
      FROM stores s
      LEFT JOIN store_subscriptions ss ON ss.storeId = s.id
      LEFT JOIN subscription_plans sp ON ss.planId = sp.id
      WHERE s.id = ?
    `).get(storeId);

    if (!store) {
      return res.status(404).json({ success: false, error: 'Store not found.' });
    }

    // Staff list
    const staff = db.prepare(`
      SELECT su.id, su.role, su.status, su.createdAt, su.lastLoginAt,
             u.name, u.email, u.phone
      FROM store_users su
      JOIN users u ON su.userId = u.id
      WHERE su.storeId = ?
      ORDER BY su.createdAt ASC
    `).all(storeId);

    // Subscription invoices
    const invoices = SubscriptionModel.listInvoices({ storeId, limit: 10 });

    // Store key metrics
    const metrics = {
      totalProducts: db.prepare("SELECT COUNT(*) as cnt FROM products WHERE storeId = ? AND active = 1").get(storeId).cnt,
      totalSales: db.prepare("SELECT COUNT(*) as cnt FROM sales WHERE storeId = ?").get(storeId).cnt,
      totalCustomers: db.prepare("SELECT COUNT(*) as cnt FROM customers WHERE storeId = ?").get(storeId).cnt,
      totalRevenue: db.prepare("SELECT COALESCE(SUM(totalAmount), 0) as total FROM sales WHERE storeId = ? AND status != 'CANCELLED'").get(storeId).total
    };

    return res.json({ success: true, store, staff, invoices, metrics });
  } catch (err) {
    console.error('Admin get store error:', err);
    return res.status(500).json({ success: false, error: 'Failed to fetch store details.' });
  }
});

// Suspend a store
router.post('/stores/:storeId/suspend', (req, res) => {
  try {
    const { storeId } = req.params;
    const { reason = 'Administrative action' } = req.body;

    const store = db.prepare('SELECT id, name, status FROM stores WHERE id = ?').get(storeId);
    if (!store) return res.status(404).json({ success: false, error: 'Store not found.' });

    db.prepare("UPDATE stores SET status = 'SUSPENDED', updatedAt = ? WHERE id = ?")
      .run(new Date().toISOString(), storeId);

    SubscriptionModel.updateSubscriptionStatus({
      storeId,
      status: 'SUSPENDED',
      suspendedBy: req.platformAdmin.userId,
      suspensionReason: reason
    });

    auditLog(req, 'STORE_SUSPENDED', `Suspended store "${store.name}": ${reason}`, {
      targetType: 'STORE', targetId: storeId, targetName: store.name,
      metadata: { reason }
    });

    return res.json({ success: true, message: `Store "${store.name}" has been suspended.` });
  } catch (err) {
    console.error('Suspend store error:', err);
    return res.status(500).json({ success: false, error: 'Failed to suspend store.' });
  }
});

// Reactivate a store
router.post('/stores/:storeId/reactivate', (req, res) => {
  try {
    const { storeId } = req.params;
    const store = db.prepare('SELECT id, name FROM stores WHERE id = ?').get(storeId);
    if (!store) return res.status(404).json({ success: false, error: 'Store not found.' });

    db.prepare("UPDATE stores SET status = 'ACTIVE', updatedAt = ? WHERE id = ?")
      .run(new Date().toISOString(), storeId);

    SubscriptionModel.updateSubscriptionStatus({ storeId, status: 'ACTIVE' });

    auditLog(req, 'STORE_REACTIVATED', `Reactivated store "${store.name}"`, {
      targetType: 'STORE', targetId: storeId, targetName: store.name
    });

    return res.json({ success: true, message: `Store "${store.name}" has been reactivated.` });
  } catch (err) {
    console.error('Reactivate store error:', err);
    return res.status(500).json({ success: false, error: 'Failed to reactivate store.' });
  }
});

// Change store plan
router.post('/stores/:storeId/change-plan', (req, res) => {
  try {
    const { storeId } = req.params;
    const { planId } = req.body;

    if (!planId) return res.status(400).json({ success: false, error: 'planId is required.' });

    const store = db.prepare('SELECT id, name FROM stores WHERE id = ?').get(storeId);
    if (!store) return res.status(404).json({ success: false, error: 'Store not found.' });

    const plan = SubscriptionModel.findPlanById(planId);
    if (!plan) return res.status(404).json({ success: false, error: 'Plan not found.' });

    const sub = SubscriptionModel.getStoreSubscription(storeId);
    if (!sub) {
      SubscriptionModel.createSubscription({ storeId, planId, status: 'ACTIVE', trialDays: 0 });
    } else {
      SubscriptionModel.changePlan({ storeId, newPlanId: planId });
    }

    auditLog(req, 'STORE_PLAN_CHANGED', `Changed plan for "${store.name}" to "${plan.name}"`, {
      targetType: 'STORE', targetId: storeId, targetName: store.name,
      metadata: { newPlanId: planId, newPlanName: plan.name }
    });

    return res.json({ success: true, message: `Plan changed to "${plan.name}" for store "${store.name}".` });
  } catch (err) {
    console.error('Change plan error:', err);
    return res.status(500).json({ success: false, error: 'Failed to change plan.' });
  }
});

// ─────────────────────────────────────────────────────────────────────────────
// SUBSCRIPTION PLANS — /api/admin/plans
// ─────────────────────────────────────────────────────────────────────────────
router.get('/plans', (req, res) => {
  try {
    const plans = SubscriptionModel.listPlans();
    const enriched = plans.map(plan => ({
      ...plan,
      features: SubscriptionModel.getPlanFeatures(plan.id),
      storeCount: db.prepare('SELECT COUNT(*) as cnt FROM store_subscriptions WHERE planId = ?').get(plan.id).cnt
    }));
    return res.json({ success: true, plans: enriched });
  } catch (err) {
    console.error('List plans error:', err);
    return res.status(500).json({ success: false, error: 'Failed to fetch plans.' });
  }
});

router.put('/plans/:planId', (req, res) => {
  try {
    const { planId } = req.params;
    const plan = SubscriptionModel.findPlanById(planId);
    if (!plan) return res.status(404).json({ success: false, error: 'Plan not found.' });

    const updated = SubscriptionModel.updatePlan(planId, req.body);

    auditLog(req, 'PLAN_UPDATED', `Updated plan "${plan.name}"`, {
      targetType: 'PLAN', targetId: planId, targetName: plan.name,
      metadata: req.body
    });

    return res.json({ success: true, plan: updated });
  } catch (err) {
    console.error('Update plan error:', err);
    return res.status(500).json({ success: false, error: 'Failed to update plan.' });
  }
});

// ─────────────────────────────────────────────────────────────────────────────
// SUBSCRIPTION INVOICES — /api/admin/invoices
// ─────────────────────────────────────────────────────────────────────────────
router.get('/invoices', (req, res) => {
  try {
    const { page = 1, limit = 50, storeId } = req.query;
    const offset = (parseInt(page) - 1) * parseInt(limit);
    const invoices = SubscriptionModel.listInvoices({ storeId: storeId || null, limit: parseInt(limit), offset });
    return res.json({ success: true, invoices });
  } catch (err) {
    console.error('List invoices error:', err);
    return res.status(500).json({ success: false, error: 'Failed to fetch invoices.' });
  }
});

router.post('/invoices/:invoiceId/mark-paid', (req, res) => {
  try {
    const { invoiceId } = req.params;
    const invoice = db.prepare('SELECT * FROM subscription_invoices WHERE id = ?').get(invoiceId);
    if (!invoice) return res.status(404).json({ success: false, error: 'Invoice not found.' });
    const updated = SubscriptionModel.markInvoicePaid(invoiceId);
    auditLog(req, 'INVOICE_MARKED_PAID', `Marked invoice ${invoiceId} as paid for store ${invoice.storeId}`, {
      targetType: 'INVOICE', targetId: invoiceId, metadata: { amount: invoice.amount }
    });
    return res.json({ success: true, invoice: updated });
  } catch (err) {
    console.error('Mark invoice paid error:', err);
    return res.status(500).json({ success: false, error: 'Failed to mark invoice paid.' });
  }
});

// Generate a subscription invoice for a store
router.post('/stores/:storeId/generate-invoice', (req, res) => {
  try {
    const { storeId } = req.params;
    const store = db.prepare('SELECT id, name FROM stores WHERE id = ?').get(storeId);
    if (!store) return res.status(404).json({ success: false, error: 'Store not found.' });

    const sub = SubscriptionModel.getStoreSubscription(storeId);
    if (!sub) return res.status(400).json({ success: false, error: 'Store has no active subscription.' });

    const plan = SubscriptionModel.findPlanById(sub.planId);
    const periodStart = new Date().toISOString();
    const periodEnd = new Date(Date.now() + 30 * 86400 * 1000).toISOString();
    const dueDate = new Date(Date.now() + 7 * 86400 * 1000).toISOString();

    const invoice = SubscriptionModel.createInvoice({
      storeId,
      subscriptionId: sub.id,
      planId: sub.planId,
      planName: plan.name,
      amount: plan.price,
      billingPeriodStart: periodStart,
      billingPeriodEnd: periodEnd,
      dueDate
    });

    auditLog(req, 'INVOICE_GENERATED', `Generated invoice for "${store.name}" — ${plan.name} plan ₹${plan.price}`, {
      targetType: 'STORE', targetId: storeId, targetName: store.name,
      metadata: { invoiceId: invoice.id, amount: plan.price }
    });

    return res.status(201).json({ success: true, invoice });
  } catch (err) {
    console.error('Generate invoice error:', err);
    return res.status(500).json({ success: false, error: 'Failed to generate invoice.' });
  }
});

// ─────────────────────────────────────────────────────────────────────────────
// PLATFORM ANALYTICS — /api/admin/analytics
// ─────────────────────────────────────────────────────────────────────────────
router.get('/analytics', (req, res) => {
  try {
    // Store growth by month (last 12)
    const storeGrowth = db.prepare(`
      SELECT strftime('%Y-%m', createdAt) as month, COUNT(*) as count
      FROM stores GROUP BY month ORDER BY month ASC LIMIT 12
    `).all();

    // Revenue by month
    const revenueByMonth = db.prepare(`
      SELECT strftime('%Y-%m', paidAt) as month, SUM(amount) as revenue
      FROM subscription_invoices WHERE paymentStatus = 'PAID'
      GROUP BY month ORDER BY month ASC LIMIT 12
    `).all();

    // Plan distribution
    const planDist = db.prepare(`
      SELECT sp.name, sp.slug, sp.price, COUNT(ss.id) as stores
      FROM subscription_plans sp
      LEFT JOIN store_subscriptions ss ON ss.planId = sp.id
      WHERE sp.isActive = 1
      GROUP BY sp.id ORDER BY sp.sortOrder
    `).all();

    // Store status distribution
    const statusDist = db.prepare(`
      SELECT COALESCE(status, 'ACTIVE') as status, COUNT(*) as count
      FROM stores GROUP BY status
    `).all();

    // Top stores by revenue (store-level sales)
    const topStores = db.prepare(`
      SELECT s.id, s.name, s.city,
             COALESCE(SUM(sa.totalAmount), 0) as storeRevenue,
             COUNT(sa.id) as saleCount
      FROM stores s
      LEFT JOIN sales sa ON sa.storeId = s.id AND sa.status != 'CANCELLED'
      GROUP BY s.id
      ORDER BY storeRevenue DESC LIMIT 10
    `).all();

    // Subscription churn (cancelled this month)
    const churnThisMonth = db.prepare(`
      SELECT COUNT(*) as cnt FROM store_subscriptions
      WHERE status = 'CANCELLED' AND cancelledAt >= date('now', 'start of month')
    `).get().cnt;

    return res.json({
      success: true,
      analytics: {
        storeGrowth,
        revenueByMonth,
        planDistribution: planDist,
        statusDistribution: statusDist,
        topStores,
        churnThisMonth
      }
    });
  } catch (err) {
    console.error('Admin analytics error:', err);
    return res.status(500).json({ success: false, error: 'Failed to load analytics.' });
  }
});

// ─────────────────────────────────────────────────────────────────────────────
// PLATFORM AUDIT LOG — /api/admin/audit
// ─────────────────────────────────────────────────────────────────────────────
router.get('/audit', (req, res) => {
  try {
    const { page = 1, limit = 50, action, targetType } = req.query;
    const offset = (parseInt(page) - 1) * parseInt(limit);
    const logs = PlatformAuditModel.list({ limit: parseInt(limit), offset, action, targetType });
    const total = PlatformAuditModel.countTotal();
    return res.json({ success: true, logs, total });
  } catch (err) {
    console.error('Audit log error:', err);
    return res.status(500).json({ success: false, error: 'Failed to fetch audit logs.' });
  }
});

// ─────────────────────────────────────────────────────────────────────────────
// PLATFORM SETTINGS — /api/admin/settings
// ─────────────────────────────────────────────────────────────────────────────
router.get('/settings', (req, res) => {
  try {
    const settings = db.prepare('SELECT * FROM platform_settings ORDER BY key ASC').all();
    return res.json({ success: true, settings });
  } catch (err) {
    console.error('Platform settings error:', err);
    return res.status(500).json({ success: false, error: 'Failed to fetch platform settings.' });
  }
});

router.put('/settings', (req, res) => {
  try {
    const { settings } = req.body; // array of { key, value }
    if (!Array.isArray(settings)) {
      return res.status(400).json({ success: false, error: 'settings must be an array.' });
    }
    const now = new Date().toISOString();
    for (const { key, value } of settings) {
      if (!key) continue;
      db.prepare('INSERT INTO platform_settings (key, value, updatedBy, updatedAt) VALUES (?, ?, ?, ?) ON CONFLICT(key) DO UPDATE SET value = excluded.value, updatedBy = excluded.updatedBy, updatedAt = excluded.updatedAt')
        .run(key, String(value), req.platformAdmin.userId, now);
    }
    auditLog(req, 'PLATFORM_SETTINGS_UPDATED', 'Updated platform settings', { metadata: settings });
    const updated = db.prepare('SELECT * FROM platform_settings ORDER BY key ASC').all();
    return res.json({ success: true, settings: updated });
  } catch (err) {
    console.error('Update platform settings error:', err);
    return res.status(500).json({ success: false, error: 'Failed to update platform settings.' });
  }
});

// ─────────────────────────────────────────────────────────────────────────────
// SUPER ADMIN IDENTITY CHECK — /api/admin/me
// ─────────────────────────────────────────────────────────────────────────────
router.get('/me', (req, res) => {
  return res.json({
    success: true,
    admin: req.platformAdmin,
    message: 'Super Admin session verified.'
  });
});

module.exports = router;
