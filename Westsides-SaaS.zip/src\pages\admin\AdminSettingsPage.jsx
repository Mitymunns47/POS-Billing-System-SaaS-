/**
 * AdminSettingsPage.jsx — Phase 7
 * Platform-level configuration settings.
 */
import React, { useEffect, useState } from 'react';
import { api } from '../../services/api';

const COLORS = {
  card: '#1E293B', border: 'rgba(126,175,208,0.12)',
  text: '#F1F5F9', muted: '#64748B', accent: '#7EAFD0',
  success: '#10B981', danger: '#EF4444'
};

export function AdminSettingsPage() {
  const [settings, setSettings] = useState([]);
  const [form, setForm] = useState({});
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [msg, setMsg] = useState('');
  const [error, setError] = useState('');

  useEffect(() => {
    api.adminGetSettings().then(res => {
      if (res.success) {
        setSettings(res.settings);
        const f = {};
        for (const s of res.settings) f[s.key] = s.value;
        setForm(f);
      }
    }).finally(() => setLoading(false));
  }, []);

  const handleSave = async () => {
    setSaving(true);
    setMsg(''); setError('');
    const payload = Object.entries(form).map(([key, value]) => ({ key, value }));
    try {
      const res = await api.adminUpdateSettings(payload);
      if (res.success) {
        setSettings(res.settings);
        setMsg('Platform settings saved successfully.');
      }
    } catch (err) { setError(err.message); }
    finally { setSaving(false); }
  };

  if (loading) return <div style={{ color: COLORS.muted, padding: '3rem', textAlign: 'center' }}>Loading platform settings...</div>;

  return (
    <div style={{ padding: '1.75rem', fontFamily: "'Inter', 'Segoe UI', sans-serif" }}>
      <div style={{ marginBottom: '1.5rem' }}>
        <h1 style={{ color: COLORS.text, fontSize: '1.375rem', fontWeight: '700', margin: '0 0 0.25rem' }}>Platform Settings</h1>
        <p style={{ color: COLORS.muted, fontSize: '0.875rem', margin: 0 }}>Configure global Westsides SaaS platform parameters</p>
      </div>

      {msg && <div style={{ background: '#10B98120', border: '1px solid #10B98140', borderRadius: '8px', padding: '0.75rem 1rem', color: '#10B981', fontSize: '0.875rem', marginBottom: '1rem' }}>{msg}</div>}
      {error && <div style={{ background: '#EF444420', border: '1px solid #EF444440', borderRadius: '8px', padding: '0.75rem 1rem', color: '#EF4444', fontSize: '0.875rem', marginBottom: '1rem' }}>{error}</div>}

      <div style={{ background: COLORS.card, border: `1px solid ${COLORS.border}`, borderRadius: '12px', padding: '1.5rem', maxWidth: '640px' }}>
        {settings.map(s => (
          <div key={s.key} style={{ marginBottom: '1.25rem' }}>
            <label style={{ display: 'block', color: COLORS.text, fontSize: '0.875rem', fontWeight: '500', marginBottom: '0.25rem' }}>
              {s.label || s.key}
            </label>
            {s.description && <p style={{ color: COLORS.muted, fontSize: '0.8125rem', margin: '0 0 0.5rem' }}>{s.description}</p>}
            <input
              type="text"
              value={form[s.key] ?? ''}
              onChange={e => setForm(f => ({ ...f, [s.key]: e.target.value }))}
              style={{
                width: '100%', boxSizing: 'border-box',
                padding: '0.625rem 0.875rem',
                background: '#0F172A', border: `1px solid ${COLORS.border}`,
                borderRadius: '8px', color: COLORS.text, fontSize: '0.875rem', outline: 'none'
              }}
            />
            <div style={{ color: '#334155', fontSize: '0.6875rem', marginTop: '0.25rem' }}>Key: {s.key}</div>
          </div>
        ))}

        {settings.length === 0 && (
          <p style={{ color: COLORS.muted, fontSize: '0.875rem' }}>No platform settings found. Restart the server to initialize defaults.</p>
        )}

        <div style={{ marginTop: '1.5rem', borderTop: `1px solid ${COLORS.border}`, paddingTop: '1.25rem' }}>
          <button
            onClick={handleSave}
            disabled={saving}
            style={{
              padding: '0.75rem 2rem',
              background: saving ? 'rgba(126,175,208,0.4)' : 'linear-gradient(135deg, #7EAFD0, #5B91B8)',
              border: 'none', borderRadius: '10px',
              color: '#fff', fontSize: '0.9375rem', fontWeight: '600',
              cursor: saving ? 'not-allowed' : 'pointer',
              boxShadow: saving ? 'none' : '0 4px 14px rgba(126,175,208,0.3)'
            }}
          >
            {saving ? 'Saving...' : 'Save Settings'}
          </button>
        </div>
      </div>

      {/* Security notice */}
      <div style={{ maxWidth: '640px', marginTop: '1.25rem', background: 'rgba(239,68,68,0.05)', border: '1px solid rgba(239,68,68,0.15)', borderRadius: '12px', padding: '1.25rem' }}>
        <h4 style={{ color: '#FCA5A5', fontSize: '0.875rem', fontWeight: '600', margin: '0 0 0.5rem' }}>🔒 Security Notice</h4>
        <ul style={{ color: '#94A3B8', fontSize: '0.8125rem', lineHeight: '1.6', margin: 0, paddingLeft: '1.25rem' }}>
          <li>Never share SUPER_ADMIN credentials with store owners</li>
          <li>All admin actions are recorded in the Platform Audit Log</li>
          <li>Suspending a store immediately blocks all staff from logging in</li>
          <li>Historical store data is preserved even after suspension</li>
          <li>Platform settings changes take effect immediately</li>
        </ul>
      </div>
    </div>
  );
}
