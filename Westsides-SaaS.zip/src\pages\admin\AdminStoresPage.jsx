/**
 * AdminStoresPage.jsx — Phase 7
 * Tenant store management: search, filter, suspend/reactivate, plan change.
 */
import React, { useEffect, useState, useCallback } from 'react';
import { api } from '../../services/api';

const COLORS = {
  bg: '#0F172A', card: '#1E293B', border: 'rgba(126,175,208,0.12)',
  text: '#F1F5F9', muted: '#64748B', accent: '#7EAFD0',
  success: '#10B981', warn: '#F59E0B', danger: '#EF4444'
};

const STATUS_BADGE = {
  ACTIVE: { bg: '#10B98120', color: '#10B981', label: 'Active' },
  SUSPENDED: { bg: '#F59E0B20', color: '#F59E0B', label: 'Suspended' },
  CANCELLED: { bg: '#EF444420', color: '#EF4444', label: 'Cancelled' }
};

const SUB_BADGE = {
  TRIALING: { bg: '#7EAFD020', color: '#7EAFD0', label: 'Trialing' },
  ACTIVE: { bg: '#10B98120', color: '#10B981', label: 'Active' },
  SUSPENDED: { bg: '#F59E0B20', color: '#F59E0B', label: 'Suspended' },
  CANCELLED: { bg: '#EF444420', color: '#EF4444', label: 'Cancelled' }
};

function Badge({ map, value }) {
  const b = map[value] || { bg: '#33415530', color: '#64748B', label: value || '—' };
  return (
    <span style={{ background: b.bg, color: b.color, borderRadius: '6px', padding: '2px 8px', fontSize: '0.75rem', fontWeight: '600' }}>
      {b.label}
    </span>
  );
}

export function AdminStoresPage({ onNavigate }) {
  const [stores, setStores] = useState([]);
  const [total, setTotal] = useState(0);
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState('');
  const [page, setPage] = useState(1);
  const [loading, setLoading] = useState(true);
  const [actionLoading, setActionLoading] = useState('');
  const [error, setError] = useState('');
  const [msg, setMsg] = useState('');

  const load = useCallback(async () => {
    setLoading(true);
    setError('');
    try {
      const res = await api.adminListStores({ search, status: statusFilter, page, limit: 20 });
      if (res.success) { setStores(res.stores); setTotal(res.total); }
    } catch (err) { setError(err.message); }
    finally { setLoading(false); }
  }, [search, statusFilter, page]);

  useEffect(() => { load(); }, [load]);

  const handleSuspend = async (storeId, storeName) => {
    const reason = window.prompt(`Reason for suspending "${storeName}":`, 'Administrative action');
    if (!reason) return;
    setActionLoading(storeId);
    try {
      const res = await api.adminSuspendStore(storeId, reason);
      if (res.success) { setMsg(res.message); load(); }
    } catch (err) { setError(err.message); }
    finally { setActionLoading(''); }
  };

  const handleReactivate = async (storeId) => {
    setActionLoading(storeId);
    try {
      const res = await api.adminReactivateStore(storeId);
      if (res.success) { setMsg(res.message); load(); }
    } catch (err) { setError(err.message); }
    finally { setActionLoading(''); }
  };

  return (
    <div style={{ padding: '1.75rem', fontFamily: "'Inter', 'Segoe UI', sans-serif" }}>
      <div style={{ marginBottom: '1.5rem' }}>
        <h1 style={{ color: COLORS.text, fontSize: '1.375rem', fontWeight: '700', margin: '0 0 0.25rem' }}>Tenant Stores</h1>
        <p style={{ color: COLORS.muted, fontSize: '0.875rem', margin: 0 }}>
          {total} registered tenant{total !== 1 ? 's' : ''}
        </p>
      </div>

      {msg && (
        <div style={{ background: '#10B98120', border: '1px solid #10B98140', borderRadius: '8px', padding: '0.75rem 1rem', color: '#10B981', fontSize: '0.875rem', marginBottom: '1rem' }}>
          {msg} <button onClick={() => setMsg('')} style={{ float: 'right', background: 'none', border: 'none', color: '#10B981', cursor: 'pointer' }}>✕</button>
        </div>
      )}
      {error && (
        <div style={{ background: '#EF444420', border: '1px solid #EF444440', borderRadius: '8px', padding: '0.75rem 1rem', color: '#EF4444', fontSize: '0.875rem', marginBottom: '1rem' }}>
          {error} <button onClick={() => setError('')} style={{ float: 'right', background: 'none', border: 'none', color: '#EF4444', cursor: 'pointer' }}>✕</button>
        </div>
      )}

      {/* Filters */}
      <div style={{ display: 'flex', gap: '0.75rem', marginBottom: '1.25rem', flexWrap: 'wrap' }}>
        <input
          placeholder="Search by name, city, GST..."
          value={search}
          onChange={e => { setSearch(e.target.value); setPage(1); }}
          style={{
            flex: '1', minWidth: '200px', padding: '0.625rem 0.875rem',
            background: COLORS.card, border: `1px solid ${COLORS.border}`,
            borderRadius: '8px', color: COLORS.text, fontSize: '0.875rem', outline: 'none'
          }}
        />
        <select
          value={statusFilter}
          onChange={e => { setStatusFilter(e.target.value); setPage(1); }}
          style={{ padding: '0.625rem 0.875rem', background: COLORS.card, border: `1px solid ${COLORS.border}`, borderRadius: '8px', color: COLORS.text, fontSize: '0.875rem', outline: 'none' }}
        >
          <option value="">All Status</option>
          <option value="ACTIVE">Active</option>
          <option value="SUSPENDED">Suspended</option>
          <option value="CANCELLED">Cancelled</option>
        </select>
      </div>

      {/* Table */}
      <div style={{ background: COLORS.card, border: `1px solid ${COLORS.border}`, borderRadius: '12px', overflow: 'hidden' }}>
        {loading ? (
          <div style={{ padding: '3rem', textAlign: 'center', color: COLORS.muted }}>Loading stores...</div>
        ) : stores.length === 0 ? (
          <div style={{ padding: '3rem', textAlign: 'center', color: COLORS.muted }}>No stores found.</div>
        ) : (
          <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: '0.8125rem' }}>
            <thead>
              <tr style={{ borderBottom: `1px solid ${COLORS.border}` }}>
                {['Store', 'City', 'Plan', 'Sub Status', 'Store Status', 'Users', 'Products', 'Sales', 'Actions'].map(h => (
                  <th key={h} style={{ color: COLORS.muted, textAlign: 'left', padding: '0.75rem', fontWeight: '500' }}>{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {stores.map(s => (
                <tr key={s.id} style={{ borderBottom: `1px solid ${COLORS.border}` }}>
                  <td style={{ padding: '0.75rem' }}>
                    <button
                      onClick={() => onNavigate(`/admin/stores/${s.id}`)}
                      style={{ background: 'none', border: 'none', color: COLORS.accent, cursor: 'pointer', fontWeight: '600', fontSize: '0.8125rem', padding: 0 }}
                    >
                      {s.name}
                    </button>
                    <div style={{ color: COLORS.muted, fontSize: '0.6875rem' }}>{s.id}</div>
                  </td>
                  <td style={{ color: COLORS.text, padding: '0.75rem' }}>{s.city || '—'}</td>
                  <td style={{ color: COLORS.text, padding: '0.75rem' }}>{s.planName || '—'}</td>
                  <td style={{ padding: '0.75rem' }}><Badge map={SUB_BADGE} value={s.subStatus} /></td>
                  <td style={{ padding: '0.75rem' }}><Badge map={STATUS_BADGE} value={s.status || 'ACTIVE'} /></td>
                  <td style={{ color: COLORS.text, padding: '0.75rem', textAlign: 'center' }}>{s.userCount}</td>
                  <td style={{ color: COLORS.text, padding: '0.75rem', textAlign: 'center' }}>{s.productCount}</td>
                  <td style={{ color: COLORS.text, padding: '0.75rem', textAlign: 'center' }}>{s.saleCount}</td>
                  <td style={{ padding: '0.75rem' }}>
                    <div style={{ display: 'flex', gap: '0.375rem' }}>
                      <button
                        onClick={() => onNavigate(`/admin/stores/${s.id}`)}
                        style={{ padding: '4px 10px', background: 'rgba(126,175,208,0.12)', border: '1px solid rgba(126,175,208,0.2)', borderRadius: '6px', color: COLORS.accent, fontSize: '0.75rem', cursor: 'pointer', fontWeight: '500' }}
                      >
                        View
                      </button>
                      {(s.status === 'ACTIVE' || !s.status) ? (
                        <button
                          onClick={() => handleSuspend(s.id, s.name)}
                          disabled={actionLoading === s.id}
                          style={{ padding: '4px 10px', background: 'rgba(245,158,11,0.12)', border: '1px solid rgba(245,158,11,0.2)', borderRadius: '6px', color: '#F59E0B', fontSize: '0.75rem', cursor: 'pointer', fontWeight: '500' }}
                        >
                          Suspend
                        </button>
                      ) : (
                        <button
                          onClick={() => handleReactivate(s.id)}
                          disabled={actionLoading === s.id}
                          style={{ padding: '4px 10px', background: 'rgba(16,185,129,0.12)', border: '1px solid rgba(16,185,129,0.2)', borderRadius: '6px', color: '#10B981', fontSize: '0.75rem', cursor: 'pointer', fontWeight: '500' }}
                        >
                          Reactivate
                        </button>
                      )}
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>

      {/* Pagination */}
      {total > 20 && (
        <div style={{ display: 'flex', justifyContent: 'flex-end', gap: '0.5rem', marginTop: '1rem' }}>
          <button disabled={page === 1} onClick={() => setPage(p => p - 1)} style={{ padding: '0.5rem 1rem', background: COLORS.card, border: `1px solid ${COLORS.border}`, borderRadius: '8px', color: COLORS.text, cursor: page === 1 ? 'not-allowed' : 'pointer' }}>← Prev</button>
          <span style={{ padding: '0.5rem 1rem', color: COLORS.muted, fontSize: '0.875rem' }}>Page {page}</span>
          <button disabled={page * 20 >= total} onClick={() => setPage(p => p + 1)} style={{ padding: '0.5rem 1rem', background: COLORS.card, border: `1px solid ${COLORS.border}`, borderRadius: '8px', color: COLORS.text, cursor: page * 20 >= total ? 'not-allowed' : 'pointer' }}>Next →</button>
        </div>
      )}
    </div>
  );
}
