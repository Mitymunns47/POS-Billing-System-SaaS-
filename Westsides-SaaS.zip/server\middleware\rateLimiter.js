/**
 * Lightweight sliding-window in-memory rate limiter (Phase 8)
 * Protects auth and sensitive platform endpoints against brute-force attacks.
 */

const hitMap = new Map();

// Periodic cleanup every 5 minutes to prevent memory leak
setInterval(() => {
  const now = Date.now();
  for (const [key, record] of hitMap.entries()) {
    if (now - record.resetTime > 0) {
      hitMap.delete(key);
    }
  }
}, 5 * 60 * 1000);

function createRateLimiter({ windowMs = 5 * 60 * 1000, max = 50, message = 'Too many requests. Please try again later.' }) {
  return function rateLimiter(req, res, next) {
    // In test environment, do not throttle
    if (process.env.NODE_ENV === 'test') {
      return next();
    }

    const ip = req.ip || req.connection?.remoteAddress || '127.0.0.1';
    const key = `${req.baseUrl || req.path}:${ip}`;
    const now = Date.now();

    let record = hitMap.get(key);
    if (!record || now > record.resetTime) {
      record = { count: 1, resetTime: now + windowMs };
      hitMap.set(key, record);
    } else {
      record.count++;
    }

    res.setHeader('X-RateLimit-Limit', max);
    res.setHeader('X-RateLimit-Remaining', Math.max(0, max - record.count));
    res.setHeader('X-RateLimit-Reset', Math.ceil(record.resetTime / 1000));

    if (record.count > max) {
      const retryAfterSec = Math.ceil((record.resetTime - now) / 1000);
      res.setHeader('Retry-After', retryAfterSec);
      return res.status(429).json({
        success: false,
        code: 'RATE_LIMIT_EXCEEDED',
        error: message,
        retryAfter: retryAfterSec
      });
    }

    next();
  };
}

const authLimiter = createRateLimiter({
  windowMs: 5 * 60 * 1000, // 5 minutes
  max: 30, // 30 attempts per 5 minutes per IP
  message: 'Too many authentication attempts from this IP address. Please wait a few minutes before trying again.'
});

const generalLimiter = createRateLimiter({
  windowMs: 60 * 1000, // 1 minute
  max: 300, // 300 requests per minute
  message: 'API rate limit exceeded. Please throttle requests.'
});

module.exports = {
  createRateLimiter,
  authLimiter,
  generalLimiter
};
