const crypto = require('crypto');
const db = require('../db/database');
const ActivityLogModel = require('./activityLogModel');
const NotificationModel = require('./notificationModel');

const ReturnModel = {
  /**
   * Process a return atomically with inventory updates and refund calculations.
   */
  create: ({ storeId, saleId, items, reason, notes, refundMethod, staffId, staffName }) => {
    if (!items || !items.length) {
      throw new Error('Please select at least one item to return.');
    }
    if (!reason || !reason.trim()) {
      throw new Error('Return reason is required.');
    }

    db.exec('BEGIN');
    try {
      // 1. Fetch and validate original sale
      const sale = db.prepare(`
        SELECT s.*, c.name as customerName, c.phone as customerPhone
        FROM sales s
        LEFT JOIN customers c ON s.customerId = c.id
        WHERE s.id = ? AND s.storeId = ?
      `).get(saleId, storeId);

      if (!sale) {
        throw new Error('Original sale transaction not found.');
      }
      if (sale.status !== 'COMPLETED') {
        throw new Error(`Cannot return items for a sale with status "${sale.status}".`);
      }

      // 2. Fetch original sale items
      const saleItems = db.prepare('SELECT * FROM sale_items WHERE saleId = ? AND storeId = ?').all(saleId, storeId);
      const saleItemsMap = new Map(saleItems.map(si => [si.id, si]));

      // 3. Fetch all previous returns for this sale to compute already-returned quantities
      const prevReturns = db.prepare(`
        SELECT ri.saleItemId, SUM(ri.quantity) as returnedQty, SUM(ri.refundAmount) as totalRefunded
        FROM return_items ri
        JOIN returns r ON ri.returnId = r.id
        WHERE r.saleId = ? AND r.storeId = ? AND r.status != 'CANCELLED'
        GROUP BY ri.saleItemId
      `).all(saleId, storeId);
      const returnedQtyMap = new Map(prevReturns.map(pr => [pr.saleItemId, Number(pr.returnedQty) || 0]));

      // 4. Validate items and calculate refund server-side
      const validatedItems = [];
      let calculatedTotalRefund = 0;
      const now = new Date().toISOString();

      for (const item of items) {
        const saleItem = saleItemsMap.get(item.saleItemId);
        if (!saleItem) {
          throw new Error(`Invalid line item (${item.saleItemId}) for sale ${sale.invoiceNumber}.`);
        }

        const returnQty = parseInt(item.quantity, 10);
        if (isNaN(returnQty) || returnQty <= 0) {
          throw new Error(`Invalid return quantity for "${saleItem.productNameSnapshot}". Must be greater than 0.`);
        }

        const alreadyReturned = returnedQtyMap.get(saleItem.id) || 0;
        const availableQty = saleItem.quantity - alreadyReturned;

        if (returnQty > availableQty) {
          throw new Error(
            `Cannot return ${returnQty} units of "${saleItem.productNameSnapshot}". Originally purchased: ${saleItem.quantity}, already returned: ${alreadyReturned}, maximum returnable: ${availableQty}.`
          );
        }

        const condition = item.condition === 'DAMAGED' ? 'DAMAGED' : 'RESELLABLE';

        // Precise pro-rated refund calculation:
        // Item ratio of subtotal
        const itemGross = saleItem.unitPrice * returnQty;
        let lineDiscount = 0;
        if (sale.subtotal > 0 && sale.discountAmount > 0) {
          lineDiscount = Math.round(((itemGross / sale.subtotal) * sale.discountAmount) * 100) / 100;
        }
        const lineTaxable = Math.max(0, itemGross - lineDiscount);
        let lineTax = 0;
        if (sale.taxRate > 0) {
          lineTax = Math.round((lineTaxable * (sale.taxRate / 100)) * 100) / 100;
        }
        const lineRefund = Math.round((lineTaxable + lineTax) * 100) / 100;

        calculatedTotalRefund += lineRefund;

        validatedItems.push({
          saleItem,
          quantity: returnQty,
          condition,
          discountAmount: lineDiscount,
          taxAmount: lineTax,
          refundAmount: lineRefund
        });
      }

      calculatedTotalRefund = Math.round(calculatedTotalRefund * 100) / 100;

      // 5. Create return header
      const returnId = 'ret_' + crypto.randomBytes(8).toString('hex');
      const effectiveRefundMethod = refundMethod || sale.paymentMethod || 'CASH';

      db.prepare(`
        INSERT INTO returns (
          id, storeId, saleId, invoiceNumber, customerId,
          staffId, staffName, totalRefundAmount, refundMethod,
          reason, notes, status, createdAt, updatedAt
        ) VALUES (
          ?, ?, ?, ?, ?,
          ?, ?, ?, ?,
          ?, ?, 'COMPLETED', ?, ?
        )
      `).run(
        returnId, storeId, saleId, sale.invoiceNumber, sale.customerId || null,
        staffId, staffName, calculatedTotalRefund, effectiveRefundMethod,
        reason.trim(), notes ? notes.trim() : null, now, now
      );

      // 6. Process return items and atomic inventory restoration
      for (const vi of validatedItems) {
        const returnItemId = 'rit_' + crypto.randomBytes(8).toString('hex');
        const { saleItem, quantity, condition, discountAmount, taxAmount, refundAmount } = vi;

        db.prepare(`
          INSERT INTO return_items (
            id, returnId, saleItemId, productId, variantId,
            productNameSnapshot, skuSnapshot, sizeSnapshot, colorSnapshot,
            quantity, unitPrice, discountAmount, taxAmount, refundAmount, condition, createdAt
          ) VALUES (
            ?, ?, ?, ?, ?,
            ?, ?, ?, ?,
            ?, ?, ?, ?, ?, ?, ?
          )
        `).run(
          returnItemId, returnId, saleItem.id, saleItem.productId, saleItem.variantId,
          saleItem.productNameSnapshot, saleItem.skuSnapshot, saleItem.sizeSnapshot, saleItem.colorSnapshot,
          quantity, saleItem.unitPrice, discountAmount, taxAmount, refundAmount, condition, now
        );

        // Fetch current variant stock for inventory audit
        if (saleItem.variantId) {
          const variant = db.prepare('SELECT stock FROM product_variants WHERE id = ? AND storeId = ?').get(saleItem.variantId, storeId);
          const currentStock = variant ? Number(variant.stock) : 0;

          if (condition === 'RESELLABLE') {
            const newStock = currentStock + quantity;
            // Restore stock
            db.prepare('UPDATE product_variants SET stock = ?, updatedAt = ? WHERE id = ? AND storeId = ?').run(newStock, now, saleItem.variantId, storeId);

            // Audit transaction
            const txId = 'itx_' + crypto.randomBytes(8).toString('hex');
            db.prepare(`
              INSERT INTO inventory_transactions (
                id, storeId, productId, variantId, action, quantity, previousQuantity, newQuantity, reason, performedBy, note, createdAt
              ) VALUES (?, ?, ?, ?, 'ADD_STOCK', ?, ?, ?, 'RETURN', ?, ?, ?)
            `).run(
              txId, storeId, saleItem.productId, saleItem.variantId, quantity,
              currentStock, newStock, staffName,
              `Return for Invoice ${sale.invoiceNumber} (Return ID: ${returnId}) - Restocked`, now
            );
          } else {
            // DAMAGED: Do not add to sellable inventory; record inventory loss
            const txId = 'itx_' + crypto.randomBytes(8).toString('hex');
            db.prepare(`
              INSERT INTO inventory_transactions (
                id, storeId, productId, variantId, action, quantity, previousQuantity, newQuantity, reason, performedBy, note, createdAt
              ) VALUES (?, ?, ?, ?, 'INVENTORY_LOSS', ?, ?, ?, 'DAMAGED_RETURN', ?, ?, ?)
            `).run(
              txId, storeId, saleItem.productId, saleItem.variantId, quantity,
              currentStock, currentStock, staffName,
              `Return for Invoice ${sale.invoiceNumber} (Return ID: ${returnId}) - Damaged/Defective written off`, now
            );
          }
        }
      }

      // 7. Adjust customer lifetime spend if customer linked
      if (sale.customerId) {
        db.prepare(`
          UPDATE customers SET
            totalSpent = MAX(0, totalSpent - ?),
            updatedAt = ?
          WHERE id = ? AND storeId = ?
        `).run(calculatedTotalRefund, now, sale.customerId, storeId);
      }

      // 8. Generate notification
      NotificationModel.create({
        storeId,
        targetRole: 'ALL',
        type: 'RETURN_COMPLETED',
        title: `Return Processed: ${sale.invoiceNumber}`,
        message: `Refund of ₹${calculatedTotalRefund.toFixed(2)} issued via ${effectiveRefundMethod} (${reason}).`,
        recordId: returnId,
        recordType: 'return'
      });

      // 9. Activity Log
      ActivityLogModel.logActivity({
        storeId,
        userId: staffId,
        userName: staffName,
        action: 'PROCESS_RETURN',
        module: 'Returns',
        description: `Processed return on invoice ${sale.invoiceNumber} for ₹${calculatedTotalRefund.toFixed(2)} (${reason})`,
        recordId: returnId
      });

      db.exec('COMMIT');
      return ReturnModel.findById(returnId, storeId);
    } catch (err) {
      db.exec('ROLLBACK');
      throw err;
    }
  },

  /**
   * Find return by ID
   */
  findById: (id, storeId) => {
    const ret = db.prepare(`
      SELECT r.*, c.name as customerName, c.phone as customerPhone, c.email as customerEmail,
             s.totalAmount as originalSaleAmount, s.createdAt as originalSaleDate, s.cashierName as originalCashier
      FROM returns r
      LEFT JOIN customers c ON r.customerId = c.id
      JOIN sales s ON r.saleId = s.id
      WHERE r.id = ? AND r.storeId = ?
    `).get(id, storeId);

    if (!ret) return null;

    const items = db.prepare(`
      SELECT ri.*
      FROM return_items ri
      WHERE ri.returnId = ?
      ORDER BY ri.rowid ASC
    `).all(id);

    return {
      ...ret,
      totalRefundAmount: Number(ret.totalRefundAmount),
      originalSaleAmount: Number(ret.originalSaleAmount),
      items: items.map(item => ({
        ...item,
        unitPrice: Number(item.unitPrice),
        discountAmount: Number(item.discountAmount),
        taxAmount: Number(item.taxAmount),
        refundAmount: Number(item.refundAmount)
      }))
    };
  },

  /**
   * List returns with search, filters and pagination
   */
  findAll: ({ storeId, search, customerId, staffId, refundMethod, status, startDate, endDate, page = 1, limit = 20 }) => {
    const offset = (page - 1) * limit;
    const conditions = ['r.storeId = ?'];
    const params = [storeId];

    if (customerId) {
      conditions.push('r.customerId = ?');
      params.push(customerId);
    }
    if (staffId) {
      conditions.push('r.staffId = ?');
      params.push(staffId);
    }
    if (refundMethod) {
      conditions.push('r.refundMethod = ?');
      params.push(refundMethod);
    }
    if (status) {
      conditions.push('r.status = ?');
      params.push(status);
    }
    if (startDate) {
      conditions.push('r.createdAt >= ?');
      params.push(startDate);
    }
    if (endDate) {
      conditions.push('r.createdAt <= ?');
      params.push(endDate + 'T23:59:59.999Z');
    }
    if (search) {
      conditions.push('(r.invoiceNumber LIKE ? OR c.name LIKE ? OR c.phone LIKE ? OR r.reason LIKE ?)');
      const q = `%${search}%`;
      params.push(q, q, q, q);
    }

    const where = conditions.join(' AND ');
    const total = db.prepare(`
      SELECT COUNT(*) as count
      FROM returns r
      LEFT JOIN customers c ON r.customerId = c.id
      WHERE ${where}
    `).get(...params).count;

    const rows = db.prepare(`
      SELECT r.*, c.name as customerName, c.phone as customerPhone,
             (SELECT COUNT(*) FROM return_items WHERE returnId = r.id) as itemCount,
             (SELECT COALESCE(SUM(quantity), 0) FROM return_items WHERE returnId = r.id) as totalItemsReturned
      FROM returns r
      LEFT JOIN customers c ON r.customerId = c.id
      WHERE ${where}
      ORDER BY r.createdAt DESC
      LIMIT ? OFFSET ?
    `).all(...params, limit, offset);

    return {
      returns: rows.map(r => ({
        ...r,
        totalRefundAmount: Number(r.totalRefundAmount),
        itemCount: Number(r.itemCount),
        totalItemsReturned: Number(r.totalItemsReturned)
      })),
      pagination: {
        page,
        limit,
        total,
        totalPages: Math.ceil(total / limit)
      }
    };
  },

  /**
   * Get return details and item-level returnable status for a sale
   */
  getSaleReturnDetails: (saleId, storeId) => {
    const sale = db.prepare(`
      SELECT s.*, c.name as customerName, c.phone as customerPhone, c.email as customerEmail
      FROM sales s
      LEFT JOIN customers c ON s.customerId = c.id
      WHERE s.id = ? AND s.storeId = ?
    `).get(saleId, storeId);

    if (!sale) return null;

    const saleItems = db.prepare('SELECT * FROM sale_items WHERE saleId = ? AND storeId = ? ORDER BY rowid ASC').all(saleId, storeId);

    // Sum already returned
    const returnedStats = db.prepare(`
      SELECT ri.saleItemId, SUM(ri.quantity) as returnedQty, SUM(ri.refundAmount) as totalRefunded
      FROM return_items ri
      JOIN returns r ON ri.returnId = r.id
      WHERE r.saleId = ? AND r.storeId = ? AND r.status != 'CANCELLED'
      GROUP BY ri.saleItemId
    `).all(saleId, storeId);
    const returnedMap = new Map(returnedStats.map(rs => [rs.saleItemId, Number(rs.returnedQty) || 0]));

    let totalAvailableToReturn = 0;

    const items = saleItems.map(si => {
      const alreadyReturned = returnedMap.get(si.id) || 0;
      const availableQty = Math.max(0, si.quantity - alreadyReturned);
      totalAvailableToReturn += availableQty;

      return {
        ...si,
        unitPrice: Number(si.unitPrice),
        discountAmount: Number(si.discountAmount),
        taxAmount: Number(si.taxAmount),
        lineTotal: Number(si.lineTotal),
        alreadyReturned,
        returnedQuantity: alreadyReturned,
        availableQty,
        availableQuantity: availableQty,
        isFullyReturned: availableQty === 0
      };
    });

    // Past returns on this sale
    const pastReturns = db.prepare(`
      SELECT r.id, r.totalRefundAmount, r.refundMethod, r.reason, r.status, r.createdAt, r.staffName
      FROM returns r
      WHERE r.saleId = ? AND r.storeId = ?
      ORDER BY r.createdAt DESC
    `).all(saleId, storeId).map(pr => ({
      ...pr,
      totalRefundAmount: Number(pr.totalRefundAmount)
    }));

    return {
      sale: {
        ...sale,
        subtotal: Number(sale.subtotal),
        discountAmount: Number(sale.discountAmount),
        taxAmount: Number(sale.taxAmount),
        totalAmount: Number(sale.totalAmount)
      },
      items,
      canReturn: totalAvailableToReturn > 0,
      totalAvailableToReturn,
      pastReturns
    };
  },

  /**
   * Search sales eligible for return (status = 'COMPLETED')
   */
  searchReturnableSales: (storeId, { search = '', page = 1, limit = 20 }) => {
    const offset = (page - 1) * limit;
    const conditions = ['s.storeId = ?', "s.status = 'COMPLETED'"];
    const params = [storeId];

    if (search && search.trim()) {
      const q = `%${search.trim()}%`;
      conditions.push(`(
        s.invoiceNumber LIKE ? OR
        c.name LIKE ? OR
        c.phone LIKE ? OR
        EXISTS (
          SELECT 1 FROM sale_items si
          WHERE si.saleId = s.id AND (si.productNameSnapshot LIKE ? OR si.skuSnapshot LIKE ?)
        )
      )`);
      params.push(q, q, q, q, q);
    }

    const where = conditions.join(' AND ');
    const total = db.prepare(`
      SELECT COUNT(*) as count
      FROM sales s
      LEFT JOIN customers c ON s.customerId = c.id
      WHERE ${where}
    `).get(...params).count;

    const rows = db.prepare(`
      SELECT s.id, s.invoiceNumber, s.customerId, s.cashierName, s.totalAmount, s.paymentMethod, s.status, s.createdAt,
             c.name as customerName, c.phone as customerPhone,
             (SELECT COUNT(*) FROM sale_items WHERE saleId = s.id) as itemCount,
             (SELECT COALESCE(SUM(quantity), 0) FROM sale_items WHERE saleId = s.id) as totalQuantity,
             (
               SELECT COALESCE(SUM(ri.quantity), 0)
               FROM return_items ri
               JOIN returns r ON ri.returnId = r.id
               WHERE r.saleId = s.id AND r.status != 'CANCELLED'
             ) as returnedQuantity
      FROM sales s
      LEFT JOIN customers c ON s.customerId = c.id
      WHERE ${where}
      ORDER BY s.createdAt DESC
      LIMIT ? OFFSET ?
    `).all(...params, limit, offset);

    return {
      sales: rows.map(s => {
        const totalQty = Number(s.totalQuantity) || 0;
        const retQty = Number(s.returnedQuantity) || 0;
        return {
          ...s,
          totalAmount: Number(s.totalAmount),
          itemCount: Number(s.itemCount),
          totalQuantity: totalQty,
          returnedQuantity: retQty,
          isFullyReturned: totalQty > 0 && retQty >= totalQty,
          canReturn: totalQty > retQty
        };
      }),
      pagination: {
        page,
        limit,
        total,
        totalPages: Math.ceil(total / limit)
      }
    };
  }
};

module.exports = ReturnModel;
