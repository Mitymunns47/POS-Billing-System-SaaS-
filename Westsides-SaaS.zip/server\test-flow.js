const UserModel = require('./models/userModel');
const StoreModel = require('./models/storeModel');
const StoreUserModel = require('./models/storeUserModel');
const SessionModel = require('./models/sessionModel');
const { ROLES } = require('./constants/roles');

console.log('--- Testing Backend SaaS Multi-Tenant Foundation ---');

// 1. Create Store A
const storeA = StoreModel.create({
  name: 'Westsides',
  address: '100 Fashion Blvd',
  city: 'Mumbai',
  state: 'Maharashtra',
  country: 'India',
  gstNumber: '27AABCS1429B1Z2',
  phone: '+91 98200 12345'
});
console.log('✓ Store A Created:', storeA.id, storeA.name);

// 2. Create User A
const userA = UserModel.create({
  name: 'Rajesh Sharma',
  email: `rajesh_${Date.now()}@westsides.com`,
  phone: '+91 98200 12345',
  password: 'SecurePassword123!'
});
console.log('✓ User A Created:', userA.id, userA.email);

// 3. Verify Password
const passCheck = UserModel.verifyPassword('SecurePassword123!', userA.passwordHash || UserModel.findByEmail(userA.email).passwordHash);
console.log('✓ Password Hashing & Verification:', passCheck === true ? 'PASSED' : 'FAILED');

// 4. Assign OWNER role
const storeUserA = StoreUserModel.create({
  storeId: storeA.id,
  userId: userA.id,
  role: ROLES.OWNER
});
console.log('✓ StoreUser A Assigned Role:', storeUserA.role);

// 5. Create Session
const sessionA = SessionModel.create({
  userId: userA.id,
  storeId: storeA.id
});
console.log('✓ Session Created with Token:', sessionA.token.substring(0, 10) + '...');

// 6. Validate Session
const validated = SessionModel.findByToken(sessionA.token);
console.log('✓ Session Validated. User:', validated.userName, '| Store:', validated.storeName, '| Role:', validated.role);

// 7. Test Tenant Isolation
// Create Store B
const storeB = StoreModel.create({
  name: 'Eastside Boutique',
  address: '25 Park Street',
  city: 'Kolkata',
  state: 'West Bengal',
  country: 'India',
  gstNumber: '19AABCE9999K1Z1',
  phone: '+91 98300 54321'
});
console.log('✓ Store B Created for Cross-Tenant test:', storeB.id);

// Check if User A belongs to Store B
const crossTenantCheck = StoreUserModel.findByUserAndStore(userA.id, storeB.id);
console.log('✓ Cross-Tenant Check (User A in Store B):', crossTenantCheck === null ? 'BLOCKED / ISOLATED (PASS)' : 'LEAK DETECTED (FAIL)');

// 8. Test Logout / Session Invalidation
SessionModel.delete(sessionA.token);
const sessionAfterLogout = SessionModel.findByToken(sessionA.token);
console.log('✓ Logout Session Destruction:', sessionAfterLogout === null ? 'SESSION DESTROYED (PASS)' : 'FAILED');

console.log('--- All Backend Multi-Tenant Tests Passed Successfully! ---');
