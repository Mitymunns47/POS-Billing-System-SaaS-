import React, { useState, useEffect, useCallback } from 'react';
import { api } from '../services/api';
import { useAuth } from '../context/AuthContext';
import { Button } from '../components/ui/Button';
import { Input } from '../components/ui/Input';
import { Alert } from '../components/ui/Alert';
import { Badge } from '../components/ui/Badge';
import { Modal } from '../components/ui/Modal';
import {
  Users,
  UserPlus,
  ShieldCheck,
  Search,
  RotateCcw,
  Edit2,
  KeyRound,
  Lock,
  Unlock,
  ChevronLeft,
  ChevronRight,
  Activity,
  CalendarCheck,
  CheckCircle2,
  XCircle,
  Clock,
  Briefcase,
  Sliders,
  Calendar,
  Filter,
  AlertTriangle,
  UserCheck,
  Trash2
} from 'lucide-react';

const fmt = (n) => Number(n || 0).toFixed(2);
const EMAIL_REGEX = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

export function StaffPage({ initialTab = 'directory', onNavigate }) {
  const { user: currentUser, role: currentRole, hasPermission } = useAuth();

  const [activeTab, setActiveTab] = useState(initialTab); // 'directory', 'activity', 'attendance'

  // ── Staff Directory State ───────────────────────────────────────────────────
  const [staffList, setStaffList] = useState([]);
  const [staffPagination, setStaffPagination] = useState({ page: 1, limit: 15, total: 0, pages: 1 });
  const [staffLoading, setStaffLoading] = useState(true);
  const [staffSearch, setStaffSearch] = useState('');
  const [roleFilter, setRoleFilter] = useState('');
  const [statusFilter, setStatusFilter] = useState('');

  // ── Activity Log State ──────────────────────────────────────────────────────
  const [activities, setActivities] = useState([]);
  const [activityPagination, setActivityPagination] = useState({ page: 1, limit: 25, total: 0, pages: 1 });
  const [activityLoading, setActivityLoading] = useState(false);
  const [activitySearch, setActivitySearch] = useState('');
  const [activityModule, setActivityModule] = useState('');

  // ── Attendance State ────────────────────────────────────────────────────────
  const [attendanceRecords, setAttendanceRecords] = useState([]);
  const [attendanceLoading, setAttendanceLoading] = useState(false);
  const [attendanceDate, setAttendanceDate] = useState(() => new Date().toISOString().split('T')[0]);

  // Notifications
  const [error, setError] = useState(null);
  const [successMsg, setSuccessMsg] = useState(null);

  // Modals
  const [isAddStaffOpen, setIsAddStaffOpen] = useState(false);
  const [addStaffForm, setAddStaffForm] = useState({ name: '', email: '', phone: '', role: 'CASHIER', password: '' });
  const [addStaffErrors, setAddStaffErrors] = useState({});
  const [addingStaff, setAddingStaff] = useState(false);

  const [editStaffTarget, setEditStaffTarget] = useState(null);
  const [editStaffForm, setEditStaffForm] = useState({ name: '', phone: '' });
  const [savingEdit, setSavingEdit] = useState(false);

  const [roleChangeTarget, setRoleChangeTarget] = useState(null);
  const [newRoleVal, setNewRoleVal] = useState('');
  const [savingRole, setSavingRole] = useState(false);

  const [statusToggleTarget, setStatusToggleTarget] = useState(null);
  const [savingStatus, setSavingStatus] = useState(false);

  const [passwordResetTarget, setPasswordResetTarget] = useState(null);
  const [newPassVal, setNewPassVal] = useState('');
  const [savingPass, setSavingPass] = useState(false);

  const [isAttendanceModalOpen, setIsAttendanceModalOpen] = useState(false);
  const [attendanceForm, setAttendanceForm] = useState({ userId: '', status: 'PRESENT', checkIn: '09:30', checkOut: '19:30', notes: '' });
  const [savingAttendance, setSavingAttendance] = useState(false);

  const [deleteTarget, setDeleteTarget] = useState(null);
  const [savingDelete, setSavingDelete] = useState(false);

  // ── Load Staff Directory ────────────────────────────────────────────────────
  const loadStaff = useCallback(async (page = 1) => {
    setStaffLoading(true);
    setError(null);
    try {
      const res = await api.getStaffList({
        page,
        limit: staffPagination.limit,
        search: staffSearch.trim() || undefined,
        role: roleFilter || undefined,
        status: statusFilter || undefined
      });
      if (res.success) {
        setStaffList(res.staff || []);
        setStaffPagination({
          page: res.page || 1,
          limit: res.limit || 15,
          total: res.total || 0,
          pages: res.totalPages || 1
        });
      }
    } catch (err) {
      setError(err.message || 'Failed to load staff list.');
    } finally {
      setStaffLoading(false);
    }
  }, [staffSearch, roleFilter, statusFilter, staffPagination.limit]);

  // ── Load Activity Logs ──────────────────────────────────────────────────────
  const loadActivity = useCallback(async (page = 1) => {
    setActivityLoading(true);
    try {
      const res = await api.getStaffActivity({
        page,
        limit: activityPagination.limit,
        search: activitySearch.trim() || undefined,
        module: activityModule || undefined
      });
      if (res.success) {
        setActivities(res.activities || []);
        setActivityPagination({
          page: res.page || 1,
          limit: res.limit || 25,
          total: res.total || 0,
          pages: res.totalPages || 1
        });
      }
    } catch (err) {
      console.error('Failed to load activity logs:', err);
    } finally {
      setActivityLoading(false);
    }
  }, [activitySearch, activityModule, activityPagination.limit]);

  // ── Load Attendance ─────────────────────────────────────────────────────────
  const loadAttendance = useCallback(async () => {
    setAttendanceLoading(true);
    try {
      const res = await api.getAttendance({ date: attendanceDate });
      if (res.success) {
        setAttendanceRecords(res.attendance || []);
      }
    } catch (err) {
      console.error('Failed to load attendance:', err);
    } finally {
      setAttendanceLoading(false);
    }
  }, [attendanceDate]);

  useEffect(() => {
    if (activeTab === 'directory') loadStaff(1);
    else if (activeTab === 'activity') loadActivity(1);
    else if (activeTab === 'attendance') loadAttendance();
  }, [activeTab, loadStaff, loadActivity, loadAttendance]);

  // Add Staff Submit
  const handleAddStaffSubmit = async (e) => {
    e.preventDefault();
    const errs = {};
    if (!addStaffForm.name.trim()) errs.name = 'Name is required.';
    if (!addStaffForm.email || !EMAIL_REGEX.test(addStaffForm.email.trim())) errs.email = 'Valid email is required.';
    if (!addStaffForm.password || addStaffForm.password.length < 6) errs.password = 'Password must be at least 6 characters.';

    if (Object.keys(errs).length > 0) {
      setAddStaffErrors(errs);
      return;
    }

    setAddingStaff(true);
    setAddStaffErrors({});
    try {
      const res = await api.createStaff(addStaffForm);
      if (res.success) {
        setIsAddStaffOpen(false);
        setSuccessMsg(`Staff account for ${res.staff.name} created successfully.`);
        setAddStaffForm({ name: '', email: '', phone: '', role: 'CASHIER', password: '' });
        loadStaff(1);
      }
    } catch (err) {
      setAddStaffErrors({ submit: err.message || 'Failed to create staff member.' });
    } finally {
      setAddingStaff(false);
    }
  };

  // Edit Staff Profile Submit
  const handleEditStaffSubmit = async (e) => {
    e.preventDefault();
    if (!editStaffTarget) return;
    setSavingEdit(true);
    try {
      const res = await api.updateStaff(editStaffTarget.id, editStaffForm);
      if (res.success) {
        setEditStaffTarget(null);
        setSuccessMsg(`Profile updated for ${res.staff.name}.`);
        loadStaff(staffPagination.page);
      }
    } catch (err) {
      setError(err.message || 'Failed to update profile.');
    } finally {
      setSavingEdit(false);
    }
  };

  // Change Role Submit
  const handleRoleChangeSubmit = async () => {
    if (!roleChangeTarget || !newRoleVal) return;
    setSavingRole(true);
    try {
      const res = await api.updateStaffRole(roleChangeTarget.id, newRoleVal);
      if (res.success) {
        setRoleChangeTarget(null);
        setSuccessMsg(`Role updated to ${newRoleVal} for ${roleChangeTarget.name}.`);
        loadStaff(staffPagination.page);
      }
    } catch (err) {
      setError(err.message || 'Failed to change staff role.');
    } finally {
      setSavingRole(false);
    }
  };

  // Toggle Status Submit (Activate / Deactivate)
  const handleStatusToggleSubmit = async () => {
    if (!statusToggleTarget) return;
    const targetStatus = statusToggleTarget.status === 'ACTIVE' ? 'INACTIVE' : 'ACTIVE';
    setSavingStatus(true);
    try {
      const res = await api.updateStaffStatus(statusToggleTarget.id, targetStatus);
      if (res.success) {
        setStatusToggleTarget(null);
        setSuccessMsg(`Staff member ${statusToggleTarget.name} has been ${targetStatus === 'ACTIVE' ? 'activated' : 'deactivated'}.`);
        loadStaff(staffPagination.page);
      }
    } catch (err) {
      setError(err.message || 'Failed to change staff status.');
    } finally {
      setSavingStatus(false);
    }
  };

  // Reset Password Submit
  const handlePasswordResetSubmit = async (e) => {
    e.preventDefault();
    if (!passwordResetTarget || !newPassVal || newPassVal.length < 6) return;
    setSavingPass(true);
    try {
      const res = await api.resetStaffPassword(passwordResetTarget.id, newPassVal);
      if (res.success) {
        setPasswordResetTarget(null);
        setNewPassVal('');
        setSuccessMsg(`Password reset successfully for ${passwordResetTarget.name}.`);
      }
    } catch (err) {
      setError(err.message || 'Failed to reset password.');
    } finally {
      setSavingPass(false);
    }
  };

  // Record Attendance Submit
  const handleAttendanceSubmit = async (e) => {
    e.preventDefault();
    if (!attendanceForm.userId) return;
    setSavingAttendance(true);
    try {
      const res = await api.recordAttendance({
        ...attendanceForm,
        date: attendanceDate
      });
      if (res.success) {
        setIsAttendanceModalOpen(false);
        setSuccessMsg('Attendance record logged successfully.');
        loadAttendance();
      }
    } catch (err) {
      setError(err.message || 'Failed to record attendance.');
    } finally {
      setSavingAttendance(false);
    }
  };

  // Delete Staff Submit
  const handleDeleteStaffSubmit = async () => {
    if (!deleteTarget) return;
    setSavingDelete(true);
    try {
      const res = await api.deleteStaff(deleteTarget.id);
      if (res.success) {
        setSuccessMsg(`Staff member "${deleteTarget.name}" removed successfully.`);
        setDeleteTarget(null);
        loadStaff(staffPagination.page);
      }
    } catch (err) {
      setError(err.message || 'Failed to remove staff member.');
    } finally {
      setSavingDelete(false);
    }
  };

  return (
    <div style={{ maxWidth: '1400px', margin: '0 auto', display: 'flex', flexDirection: 'column', gap: '1.5rem' }}>
      {/* Top Header */}
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: '1rem' }}>
        <div>
          <h1 style={{ fontSize: '1.5rem', fontWeight: '700', color: 'var(--text-main)', margin: '0 0 4px 0', letterSpacing: '-0.02em' }}>
            Staff & Permissions
          </h1>
          <p style={{ margin: 0, color: 'var(--text-muted)', fontSize: '0.875rem' }}>
            Manage store employees, role hierarchy, custom permission overrides, and activity logs.
          </p>
        </div>

        <div style={{ display: 'flex', gap: '0.75rem' }}>
          <Button
            variant="outline"
            onClick={() => {
              if (activeTab === 'directory') loadStaff(staffPagination.page);
              else if (activeTab === 'activity') loadActivity(activityPagination.page);
              else loadAttendance();
            }}
            style={{ display: 'flex', alignItems: 'center', gap: '6px' }}
          >
            <RotateCcw size={15} />
            Refresh
          </Button>

          <Button
            variant="primary"
            onClick={() => {
              setActiveTab('directory');
              setAddStaffForm({ name: '', email: '', phone: '', role: 'CASHIER', password: '' });
              setAddStaffErrors({});
              setIsAddStaffOpen(true);
            }}
            style={{ display: 'flex', alignItems: 'center', gap: '6px' }}
          >
            <UserPlus size={16} />
            Add Staff Member
          </Button>

          {activeTab === 'attendance' && (
            <Button
              variant="primary"
              onClick={() => {
                setAttendanceForm({
                  userId: staffList[0]?.id || '',
                  status: 'PRESENT',
                  checkIn: '09:30',
                  checkOut: '19:30',
                  notes: ''
                });
                setIsAttendanceModalOpen(true);
              }}
              style={{ display: 'flex', alignItems: 'center', gap: '6px' }}
            >
              <CalendarCheck size={16} />
              Log Attendance
            </Button>
          )}
        </div>
      </div>

      {successMsg && (
        <Alert variant="success" onClose={() => setSuccessMsg(null)}>
          {successMsg}
        </Alert>
      )}

      {error && (
        <Alert variant="danger" onClose={() => setError(null)}>
          {error}
        </Alert>
      )}

      {/* Tabs Bar */}
      <div style={{ backgroundColor: '#FFFFFF', borderRadius: 'var(--radius-lg)', border: '1px solid var(--border-color)', padding: '0.75rem 1.25rem', boxShadow: 'var(--shadow-sm)', display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: '1rem' }}>
        <div style={{ display: 'flex', backgroundColor: 'var(--bg-page)', borderRadius: 'var(--radius-md)', padding: '3px' }}>
          <button
            onClick={() => setActiveTab('directory')}
            style={{
              border: 'none',
              padding: '6px 16px',
              borderRadius: 'var(--radius-sm)',
              fontSize: '0.8125rem',
              fontWeight: '600',
              cursor: 'pointer',
              backgroundColor: activeTab === 'directory' ? '#FFFFFF' : 'transparent',
              color: activeTab === 'directory' ? 'var(--text-main)' : 'var(--text-muted)',
              boxShadow: activeTab === 'directory' ? 'var(--shadow-sm)' : 'none',
              display: 'flex',
              alignItems: 'center',
              gap: '6px'
            }}
          >
            <Users size={14} />
            Staff Directory
          </button>
          <button
            onClick={() => setActiveTab('activity')}
            style={{
              border: 'none',
              padding: '6px 16px',
              borderRadius: 'var(--radius-sm)',
              fontSize: '0.8125rem',
              fontWeight: '600',
              cursor: 'pointer',
              backgroundColor: activeTab === 'activity' ? '#FFFFFF' : 'transparent',
              color: activeTab === 'activity' ? 'var(--text-main)' : 'var(--text-muted)',
              boxShadow: activeTab === 'activity' ? 'var(--shadow-sm)' : 'none',
              display: 'flex',
              alignItems: 'center',
              gap: '6px'
            }}
          >
            <Activity size={14} />
            Activity Audit Log
          </button>
          <button
            onClick={() => setActiveTab('attendance')}
            style={{
              border: 'none',
              padding: '6px 16px',
              borderRadius: 'var(--radius-sm)',
              fontSize: '0.8125rem',
              fontWeight: '600',
              cursor: 'pointer',
              backgroundColor: activeTab === 'attendance' ? '#FFFFFF' : 'transparent',
              color: activeTab === 'attendance' ? 'var(--text-main)' : 'var(--text-muted)',
              boxShadow: activeTab === 'attendance' ? 'var(--shadow-sm)' : 'none',
              display: 'flex',
              alignItems: 'center',
              gap: '6px'
            }}
          >
            <CalendarCheck size={14} />
            Daily Attendance
          </button>
        </div>

        {/* Tab specific mini-controls */}
        {activeTab === 'directory' && (
          <div style={{ display: 'flex', gap: '0.75rem', flexWrap: 'wrap', alignItems: 'center' }}>
            <div style={{ position: 'relative', width: '220px' }}>
              <Search size={14} style={{ position: 'absolute', left: '10px', top: '50%', transform: 'translateY(-50%)', color: 'var(--text-muted)' }} />
              <input
                type="text"
                placeholder="Search staff name/email..."
                value={staffSearch}
                onChange={(e) => setStaffSearch(e.target.value)}
                style={{
                  width: '100%',
                  padding: '0.4rem 0.75rem 0.4rem 2rem',
                  border: '1px solid var(--border-color)',
                  borderRadius: 'var(--radius-md)',
                  fontSize: '0.8125rem',
                  backgroundColor: 'var(--bg-page)',
                  outline: 'none'
                }}
              />
            </div>
            <select
              value={roleFilter}
              onChange={(e) => setRoleFilter(e.target.value)}
              style={{
                padding: '0.4rem 0.75rem',
                border: '1px solid var(--border-color)',
                borderRadius: 'var(--radius-md)',
                fontSize: '0.8125rem',
                backgroundColor: 'var(--bg-page)',
                outline: 'none'
              }}
            >
              <option value="">All Roles</option>
              <option value="OWNER">Owner</option>
              <option value="MANAGER">Manager</option>
              <option value="CASHIER">Cashier</option>
              <option value="STAFF">Staff</option>
            </select>
            <select
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value)}
              style={{
                padding: '0.4rem 0.75rem',
                border: '1px solid var(--border-color)',
                borderRadius: 'var(--radius-md)',
                fontSize: '0.8125rem',
                backgroundColor: 'var(--bg-page)',
                outline: 'none'
              }}
            >
              <option value="">All Statuses</option>
              <option value="ACTIVE">Active</option>
              <option value="INACTIVE">Inactive</option>
            </select>
          </div>
        )}

        {activeTab === 'activity' && (
          <div style={{ display: 'flex', gap: '0.75rem', flexWrap: 'wrap', alignItems: 'center' }}>
            <div style={{ position: 'relative', width: '220px' }}>
              <Search size={14} style={{ position: 'absolute', left: '10px', top: '50%', transform: 'translateY(-50%)', color: 'var(--text-muted)' }} />
              <input
                type="text"
                placeholder="Search audit trail..."
                value={activitySearch}
                onChange={(e) => setActivitySearch(e.target.value)}
                style={{
                  width: '100%',
                  padding: '0.4rem 0.75rem 0.4rem 2rem',
                  border: '1px solid var(--border-color)',
                  borderRadius: 'var(--radius-md)',
                  fontSize: '0.8125rem',
                  backgroundColor: 'var(--bg-page)',
                  outline: 'none'
                }}
              />
            </div>
            <select
              value={activityModule}
              onChange={(e) => setActivityModule(e.target.value)}
              style={{
                padding: '0.4rem 0.75rem',
                border: '1px solid var(--border-color)',
                borderRadius: 'var(--radius-md)',
                fontSize: '0.8125rem',
                backgroundColor: 'var(--bg-page)',
                outline: 'none'
              }}
            >
              <option value="">All Modules</option>
              <option value="Customers">Customers</option>
              <option value="Staff">Staff</option>
              <option value="Attendance">Attendance</option>
              <option value="POS">POS & Billing</option>
              <option value="Inventory">Inventory</option>
            </select>
          </div>
        )}

        {activeTab === 'attendance' && (
          <div style={{ display: 'flex', gap: '0.75rem', alignItems: 'center' }}>
            <label style={{ fontSize: '0.8125rem', color: 'var(--text-muted)', fontWeight: '600' }}>Date:</label>
            <input
              type="date"
              value={attendanceDate}
              onChange={(e) => setAttendanceDate(e.target.value)}
              style={{
                padding: '0.4rem 0.75rem',
                border: '1px solid var(--border-color)',
                borderRadius: 'var(--radius-md)',
                fontSize: '0.8125rem',
                backgroundColor: 'var(--bg-page)',
                outline: 'none'
              }}
            />
          </div>
        )}
      </div>

      {/* ── TAB 1: STAFF DIRECTORY ────────────────────────────────────────────── */}
      {activeTab === 'directory' && (
        <div style={{ backgroundColor: '#FFFFFF', borderRadius: 'var(--radius-lg)', border: '1px solid var(--border-color)', boxShadow: 'var(--shadow-sm)', overflow: 'hidden' }}>
          <div style={{ overflowX: 'auto' }}>
            <table style={{ width: '100%', borderCollapse: 'collapse', textAlign: 'left', fontSize: '0.875rem' }}>
              <thead>
                <tr style={{ backgroundColor: 'var(--bg-page)', borderBottom: '1px solid var(--border-color)' }}>
                  <th style={{ padding: '0.875rem 1rem', fontWeight: '600', color: 'var(--text-muted)', fontSize: '0.75rem', textTransform: 'uppercase', letterSpacing: '0.04em' }}>Staff Member</th>
                  <th style={{ padding: '0.875rem 1rem', fontWeight: '600', color: 'var(--text-muted)', fontSize: '0.75rem', textTransform: 'uppercase', letterSpacing: '0.04em' }}>Role</th>
                  <th style={{ padding: '0.875rem 1rem', fontWeight: '600', color: 'var(--text-muted)', fontSize: '0.75rem', textTransform: 'uppercase', letterSpacing: '0.04em' }}>Status</th>
                  <th style={{ padding: '0.875rem 1rem', fontWeight: '600', color: 'var(--text-muted)', fontSize: '0.75rem', textTransform: 'uppercase', letterSpacing: '0.04em', textAlign: 'center' }}>Sales Made</th>
                  <th style={{ padding: '0.875rem 1rem', fontWeight: '600', color: 'var(--text-muted)', fontSize: '0.75rem', textTransform: 'uppercase', letterSpacing: '0.04em', textAlign: 'right' }}>Revenue</th>
                  <th style={{ padding: '0.875rem 1rem', fontWeight: '600', color: 'var(--text-muted)', fontSize: '0.75rem', textTransform: 'uppercase', letterSpacing: '0.04em' }}>Joined</th>
                  <th style={{ padding: '0.875rem 1rem', fontWeight: '600', color: 'var(--text-muted)', fontSize: '0.75rem', textTransform: 'uppercase', letterSpacing: '0.04em', textAlign: 'right' }}>Actions</th>
                </tr>
              </thead>
              <tbody>
                {staffLoading ? (
                  <tr>
                    <td colSpan="7" style={{ padding: '3rem 1rem', textAlign: 'center', color: 'var(--text-muted)' }}>
                      <div style={{ display: 'inline-block', width: '20px', height: '20px', border: '2px solid #7EAFD0', borderTopColor: 'transparent', borderRadius: '50%', animation: 'spin 0.8s linear infinite', marginBottom: '8px' }} />
                      <div>Loading staff directory...</div>
                    </td>
                  </tr>
                ) : staffList.length === 0 ? (
                  <tr>
                    <td colSpan="7" style={{ padding: '3.5rem 1rem', textAlign: 'center' }}>
                      <div style={{ width: '48px', height: '48px', borderRadius: '50%', backgroundColor: 'var(--bg-page)', display: 'inline-flex', alignItems: 'center', justifyContent: 'center', color: 'var(--text-muted)', marginBottom: '12px' }}>
                        <Users size={24} />
                      </div>
                      <div style={{ fontWeight: '600', color: 'var(--text-main)', marginBottom: '4px' }}>No staff members found</div>
                      <div style={{ color: 'var(--text-muted)', fontSize: '0.8125rem' }}>
                        {staffSearch || roleFilter || statusFilter ? 'Try clearing your filters.' : 'Add your first employee to the store.'}
                      </div>
                    </td>
                  </tr>
                ) : (
                  staffList.map((s) => {
                    const isOwner = s.role === 'OWNER';
                    const isSelf = s.id === currentUser?.id;
                    const isActive = s.status === 'ACTIVE';

                    return (
                      <tr key={s.id} style={{ borderBottom: '1px solid var(--border-subtle)' }}>
                        {/* Name & Contact */}
                        <td style={{ padding: '0.875rem 1rem', fontWeight: '600', color: '#172033' }}>
                          <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
                            <div style={{ width: '32px', height: '32px', borderRadius: '50%', backgroundColor: isOwner ? 'rgba(126, 175, 208, 0.2)' : 'var(--bg-page)', color: isOwner ? '#4B7C9E' : 'var(--text-muted)', display: 'flex', alignItems: 'center', justifyContent: 'center', fontWeight: '700', fontSize: '0.8125rem' }}>
                              {s.name.charAt(0).toUpperCase()}
                            </div>
                            <div>
                              <div style={{ display: 'flex', alignItems: 'center', gap: '6px' }}>
                                <span>{s.name}</span>
                                {isSelf && <span style={{ fontSize: '0.6875rem', backgroundColor: '#E2E8F0', padding: '1px 5px', borderRadius: '4px', color: 'var(--text-muted)' }}>You</span>}
                              </div>
                              <div style={{ fontSize: '0.75rem', color: 'var(--text-muted)', fontWeight: '400' }}>{s.email}</div>
                              {s.phone && <div style={{ fontSize: '0.75rem', color: 'var(--text-muted)', fontWeight: '400' }}>{s.phone}</div>}
                            </div>
                          </div>
                        </td>

                        {/* Role */}
                        <td style={{ padding: '0.875rem 1rem' }}>
                          <span style={{
                            display: 'inline-flex',
                            alignItems: 'center',
                            gap: '4px',
                            padding: '3px 8px',
                            borderRadius: 'var(--radius-sm)',
                            fontSize: '0.75rem',
                            fontWeight: '700',
                            backgroundColor: s.role === 'OWNER' ? 'rgba(126, 175, 208, 0.15)' : s.role === 'MANAGER' ? '#EFF6FF' : s.role === 'CASHIER' ? '#ECFDF5' : '#F1F5F9',
                            color: s.role === 'OWNER' ? '#4B7C9E' : s.role === 'MANAGER' ? '#1E40AF' : s.role === 'CASHIER' ? '#065F46' : 'var(--text-muted)'
                          }}>
                            {s.role}
                          </span>
                        </td>

                        {/* Status */}
                        <td style={{ padding: '0.875rem 1rem' }}>
                          <Badge variant={isActive ? 'success' : 'danger'} size="sm">
                            {isActive ? 'Active' : 'Inactive'}
                          </Badge>
                        </td>

                        {/* Sales Made */}
                        <td style={{ padding: '0.875rem 1rem', textAlign: 'center', fontWeight: '600', color: 'var(--text-main)' }}>
                          {s.salesCount || 0}
                        </td>

                        {/* Revenue */}
                        <td style={{ padding: '0.875rem 1rem', textAlign: 'right', fontWeight: '700', color: '#172033' }}>
                          ₹{fmt(s.totalRevenue)}
                        </td>

                        {/* Joined Date */}
                        <td style={{ padding: '0.875rem 1rem', color: 'var(--text-muted)', fontSize: '0.8125rem' }}>
                          {new Date(s.joinedAt).toLocaleDateString('en-IN', { day: '2-digit', month: 'short', year: 'numeric' })}
                        </td>

                        {/* Actions */}
                        <td style={{ padding: '0.875rem 1rem', textAlign: 'right' }}>
                          <div style={{ display: 'inline-flex', gap: '4px' }}>
                            {/* Permissions */}
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => onNavigate(`/staff/${s.id}/permissions`)}
                              title="Configure Granular Permissions"
                              style={{ padding: '4px 6px' }}
                            >
                              <Sliders size={14} />
                            </Button>

                            {/* Edit Profile */}
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => {
                                setEditStaffTarget(s);
                                setEditStaffForm({ name: s.name, phone: s.phone || '' });
                              }}
                              title="Edit Profile"
                              style={{ padding: '4px 6px' }}
                            >
                              <Edit2 size={14} />
                            </Button>

                            {/* Change Role (Only if not Owner) */}
                            {!isOwner && (
                              <Button
                                variant="ghost"
                                size="sm"
                                onClick={() => {
                                  setRoleChangeTarget(s);
                                  setNewRoleVal(s.role);
                                }}
                                title="Change Role"
                                style={{ padding: '4px 6px' }}
                              >
                                <Briefcase size={14} />
                              </Button>
                            )}

                            {/* Reset Password */}
                            {(!isOwner || currentRole === 'OWNER') && (
                              <Button
                                variant="ghost"
                                size="sm"
                                onClick={() => {
                                  setPasswordResetTarget(s);
                                  setNewPassVal('');
                                }}
                                title="Reset Password"
                                style={{ padding: '4px 6px' }}
                              >
                                <KeyRound size={14} />
                              </Button>
                            )}

                            {/* Activate / Deactivate (Owner cannot be deactivated) */}
                            {!isOwner && (
                              <Button
                                variant="ghost"
                                size="sm"
                                onClick={() => setStatusToggleTarget(s)}
                                title={isActive ? 'Deactivate Staff Account' : 'Activate Staff Account'}
                                style={{ padding: '4px 6px', color: isActive ? '#EF4444' : '#10B981' }}
                              >
                                {isActive ? <Lock size={14} /> : <Unlock size={14} />}
                              </Button>
                            )}

                            {/* Delete Staff Member (Cannot delete owner or self) */}
                            {!isOwner && !isSelf && (
                              <Button
                                variant="ghost"
                                size="sm"
                                onClick={() => setDeleteTarget(s)}
                                title="Remove Staff Member"
                                style={{ padding: '4px 6px', color: '#DC2626' }}
                              >
                                <Trash2 size={14} />
                              </Button>
                            )}
                          </div>
                        </td>
                      </tr>
                    );
                  })
                )}
              </tbody>
            </table>
          </div>

          {/* Pagination */}
          {staffPagination.pages > 1 && (
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '0.875rem 1.25rem', borderTop: '1px solid var(--border-color)', backgroundColor: 'var(--bg-page)', fontSize: '0.8125rem', color: 'var(--text-muted)' }}>
              <div>
                Showing {((staffPagination.page - 1) * staffPagination.limit) + 1} to {Math.min(staffPagination.page * staffPagination.limit, staffPagination.total)} of {staffPagination.total} staff members
              </div>
              <div style={{ display: 'flex', gap: '6px' }}>
                <Button
                  variant="outline"
                  size="sm"
                  disabled={staffPagination.page <= 1}
                  onClick={() => loadStaff(staffPagination.page - 1)}
                >
                  <ChevronLeft size={14} /> Previous
                </Button>
                <div style={{ display: 'flex', alignItems: 'center', padding: '0 8px', fontWeight: '600', color: 'var(--text-main)' }}>
                  {staffPagination.page} / {staffPagination.pages}
                </div>
                <Button
                  variant="outline"
                  size="sm"
                  disabled={staffPagination.page >= staffPagination.pages}
                  onClick={() => loadStaff(staffPagination.page + 1)}
                >
                  Next <ChevronRight size={14} />
                </Button>
              </div>
            </div>
          )}
        </div>
      )}

      {/* ── TAB 2: ACTIVITY AUDIT LOG ─────────────────────────────────────────── */}
      {activeTab === 'activity' && (
        <div style={{ backgroundColor: '#FFFFFF', borderRadius: 'var(--radius-lg)', border: '1px solid var(--border-color)', boxShadow: 'var(--shadow-sm)', overflow: 'hidden' }}>
          <div style={{ overflowX: 'auto' }}>
            <table style={{ width: '100%', borderCollapse: 'collapse', textAlign: 'left', fontSize: '0.875rem' }}>
              <thead>
                <tr style={{ backgroundColor: 'var(--bg-page)', borderBottom: '1px solid var(--border-color)' }}>
                  <th style={{ padding: '0.875rem 1rem', fontWeight: '600', color: 'var(--text-muted)', fontSize: '0.75rem', textTransform: 'uppercase', letterSpacing: '0.04em' }}>Timestamp</th>
                  <th style={{ padding: '0.875rem 1rem', fontWeight: '600', color: 'var(--text-muted)', fontSize: '0.75rem', textTransform: 'uppercase', letterSpacing: '0.04em' }}>Staff Member</th>
                  <th style={{ padding: '0.875rem 1rem', fontWeight: '600', color: 'var(--text-muted)', fontSize: '0.75rem', textTransform: 'uppercase', letterSpacing: '0.04em' }}>Module</th>
                  <th style={{ padding: '0.875rem 1rem', fontWeight: '600', color: 'var(--text-muted)', fontSize: '0.75rem', textTransform: 'uppercase', letterSpacing: '0.04em' }}>Action</th>
                  <th style={{ padding: '0.875rem 1rem', fontWeight: '600', color: 'var(--text-muted)', fontSize: '0.75rem', textTransform: 'uppercase', letterSpacing: '0.04em' }}>Description</th>
                </tr>
              </thead>
              <tbody>
                {activityLoading ? (
                  <tr>
                    <td colSpan="5" style={{ padding: '3rem 1rem', textAlign: 'center', color: 'var(--text-muted)' }}>
                      <div style={{ display: 'inline-block', width: '20px', height: '20px', border: '2px solid #7EAFD0', borderTopColor: 'transparent', borderRadius: '50%', animation: 'spin 0.8s linear infinite', marginBottom: '8px' }} />
                      <div>Loading activity trail...</div>
                    </td>
                  </tr>
                ) : activities.length === 0 ? (
                  <tr>
                    <td colSpan="5" style={{ padding: '3rem 1rem', textAlign: 'center', color: 'var(--text-muted)' }}>
                      <Activity size={24} style={{ marginBottom: '8px', opacity: 0.5 }} />
                      <div style={{ fontWeight: '600', color: 'var(--text-main)', marginBottom: '4px' }}>No audit actions recorded</div>
                      <div style={{ fontSize: '0.8125rem' }}>Staff actions like customer creation, role changes, and attendance will appear here.</div>
                    </td>
                  </tr>
                ) : (
                  activities.map((a) => {
                    const date = new Date(a.createdAt);
                    return (
                      <tr key={a.id} style={{ borderBottom: '1px solid var(--border-subtle)' }}>
                        <td style={{ padding: '0.875rem 1rem', color: 'var(--text-muted)', whiteSpace: 'nowrap', fontSize: '0.8125rem' }}>
                          <div>{date.toLocaleDateString('en-IN', { day: '2-digit', month: 'short', year: 'numeric' })}</div>
                          <div>{date.toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit' })}</div>
                        </td>

                        <td style={{ padding: '0.875rem 1rem', fontWeight: '600', color: 'var(--text-main)' }}>
                          {a.userName}
                        </td>

                        <td style={{ padding: '0.875rem 1rem' }}>
                          <span style={{
                            padding: '2px 8px',
                            borderRadius: 'var(--radius-sm)',
                            fontSize: '0.75rem',
                            fontWeight: '600',
                            backgroundColor: 'var(--bg-page)',
                            border: '1px solid var(--border-subtle)'
                          }}>
                            {a.module}
                          </span>
                        </td>

                        <td style={{ padding: '0.875rem 1rem', fontFamily: 'monospace', fontSize: '0.75rem', color: 'var(--text-muted)' }}>
                          {a.action}
                        </td>

                        <td style={{ padding: '0.875rem 1rem', color: 'var(--text-main)', fontSize: '0.8125rem' }}>
                          {a.description}
                        </td>
                      </tr>
                    );
                  })
                )}
              </tbody>
            </table>
          </div>

          {/* Activity Pagination */}
          {activityPagination.pages > 1 && (
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '0.875rem 1.25rem', borderTop: '1px solid var(--border-color)', backgroundColor: 'var(--bg-page)', fontSize: '0.8125rem', color: 'var(--text-muted)' }}>
              <div>
                Showing {((activityPagination.page - 1) * activityPagination.limit) + 1} to {Math.min(activityPagination.page * activityPagination.limit, activityPagination.total)} of {activityPagination.total} audit logs
              </div>
              <div style={{ display: 'flex', gap: '6px' }}>
                <Button
                  variant="outline"
                  size="sm"
                  disabled={activityPagination.page <= 1}
                  onClick={() => loadActivity(activityPagination.page - 1)}
                >
                  <ChevronLeft size={14} /> Previous
                </Button>
                <div style={{ display: 'flex', alignItems: 'center', padding: '0 8px', fontWeight: '600', color: 'var(--text-main)' }}>
                  {activityPagination.page} / {activityPagination.pages}
                </div>
                <Button
                  variant="outline"
                  size="sm"
                  disabled={activityPagination.page >= activityPagination.pages}
                  onClick={() => loadActivity(activityPagination.page + 1)}
                >
                  Next <ChevronRight size={14} />
                </Button>
              </div>
            </div>
          )}
        </div>
      )}

      {/* ── TAB 3: DAILY ATTENDANCE ───────────────────────────────────────────── */}
      {activeTab === 'attendance' && (
        <div style={{ backgroundColor: '#FFFFFF', borderRadius: 'var(--radius-lg)', border: '1px solid var(--border-color)', boxShadow: 'var(--shadow-sm)', overflow: 'hidden' }}>
          <div style={{ overflowX: 'auto' }}>
            <table style={{ width: '100%', borderCollapse: 'collapse', textAlign: 'left', fontSize: '0.875rem' }}>
              <thead>
                <tr style={{ backgroundColor: 'var(--bg-page)', borderBottom: '1px solid var(--border-color)' }}>
                  <th style={{ padding: '0.875rem 1rem', fontWeight: '600', color: 'var(--text-muted)', fontSize: '0.75rem', textTransform: 'uppercase', letterSpacing: '0.04em' }}>Staff Member</th>
                  <th style={{ padding: '0.875rem 1rem', fontWeight: '600', color: 'var(--text-muted)', fontSize: '0.75rem', textTransform: 'uppercase', letterSpacing: '0.04em' }}>Role</th>
                  <th style={{ padding: '0.875rem 1rem', fontWeight: '600', color: 'var(--text-muted)', fontSize: '0.75rem', textTransform: 'uppercase', letterSpacing: '0.04em' }}>Status</th>
                  <th style={{ padding: '0.875rem 1rem', fontWeight: '600', color: 'var(--text-muted)', fontSize: '0.75rem', textTransform: 'uppercase', letterSpacing: '0.04em' }}>Check-In</th>
                  <th style={{ padding: '0.875rem 1rem', fontWeight: '600', color: 'var(--text-muted)', fontSize: '0.75rem', textTransform: 'uppercase', letterSpacing: '0.04em' }}>Check-Out</th>
                  <th style={{ padding: '0.875rem 1rem', fontWeight: '600', color: 'var(--text-muted)', fontSize: '0.75rem', textTransform: 'uppercase', letterSpacing: '0.04em' }}>Notes</th>
                </tr>
              </thead>
              <tbody>
                {attendanceLoading ? (
                  <tr>
                    <td colSpan="6" style={{ padding: '3rem 1rem', textAlign: 'center', color: 'var(--text-muted)' }}>
                      <div style={{ display: 'inline-block', width: '20px', height: '20px', border: '2px solid #7EAFD0', borderTopColor: 'transparent', borderRadius: '50%', animation: 'spin 0.8s linear infinite', marginBottom: '8px' }} />
                      <div>Loading attendance records...</div>
                    </td>
                  </tr>
                ) : attendanceRecords.length === 0 ? (
                  <tr>
                    <td colSpan="6" style={{ padding: '3rem 1rem', textAlign: 'center', color: 'var(--text-muted)' }}>
                      <CalendarCheck size={24} style={{ marginBottom: '8px', opacity: 0.5 }} />
                      <div style={{ fontWeight: '600', color: 'var(--text-main)', marginBottom: '4px' }}>No attendance logged for {attendanceDate}</div>
                      <div style={{ fontSize: '0.8125rem', marginBottom: '1rem' }}>Click below to log attendance for team members.</div>
                      <Button
                        variant="primary"
                        size="sm"
                        onClick={() => {
                          setAttendanceForm({
                            userId: staffList[0]?.id || '',
                            status: 'PRESENT',
                            checkIn: '09:30',
                            checkOut: '19:30',
                            notes: ''
                          });
                          setIsAttendanceModalOpen(true);
                        }}
                      >
                        Log Attendance
                      </Button>
                    </td>
                  </tr>
                ) : (
                  attendanceRecords.map((att) => (
                    <tr key={att.id} style={{ borderBottom: '1px solid var(--border-subtle)' }}>
                      <td style={{ padding: '0.875rem 1rem', fontWeight: '600', color: 'var(--text-main)' }}>
                        {att.staffName}
                      </td>
                      <td style={{ padding: '0.875rem 1rem', fontSize: '0.8125rem', color: 'var(--text-muted)' }}>
                        {att.staffRole}
                      </td>
                      <td style={{ padding: '0.875rem 1rem' }}>
                        <span style={{
                          padding: '3px 8px',
                          borderRadius: 'var(--radius-sm)',
                          fontSize: '0.75rem',
                          fontWeight: '700',
                          backgroundColor: att.status === 'PRESENT' ? '#ECFDF5' : att.status === 'LATE' ? '#FFFBEB' : '#FEF2F2',
                          color: att.status === 'PRESENT' ? '#065F46' : att.status === 'LATE' ? '#92400E' : '#B91C1C'
                        }}>
                          {att.status}
                        </span>
                      </td>
                      <td style={{ padding: '0.875rem 1rem', fontSize: '0.8125rem', color: 'var(--text-main)' }}>
                        {att.checkIn || '—'}
                      </td>
                      <td style={{ padding: '0.875rem 1rem', fontSize: '0.8125rem', color: 'var(--text-main)' }}>
                        {att.checkOut || '—'}
                      </td>
                      <td style={{ padding: '0.875rem 1rem', fontSize: '0.8125rem', color: 'var(--text-muted)' }}>
                        {att.notes || '—'}
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* ── MODALS ───────────────────────────────────────────────────────────── */}

      {/* Add Staff Modal */}
      <Modal
        isOpen={isAddStaffOpen}
        onClose={() => setIsAddStaffOpen(false)}
        title="Add Store Staff Member"
        width="500px"
      >
        <form onSubmit={handleAddStaffSubmit} style={{ display: 'flex', flexDirection: 'column', gap: '1rem' }}>
          {addStaffErrors.submit && (
            <Alert variant="danger">
              {addStaffErrors.submit}
            </Alert>
          )}

          <Input
            label="Full Name *"
            placeholder="e.g. Priya Nair"
            value={addStaffForm.name}
            onChange={(e) => setAddStaffForm({ ...addStaffForm, name: e.target.value })}
            error={addStaffErrors.name}
            required
          />

          <Input
            label="Email Address (Login Username) *"
            type="email"
            placeholder="e.g. priya@westsides.com"
            value={addStaffForm.email}
            onChange={(e) => setAddStaffForm({ ...addStaffForm, email: e.target.value })}
            error={addStaffErrors.email}
            required
          />

          <Input
            label="Phone Number"
            placeholder="e.g. +91 98200 11223"
            value={addStaffForm.phone}
            onChange={(e) => setAddStaffForm({ ...addStaffForm, phone: e.target.value })}
          />

          <div>
            <label style={{ display: 'block', fontSize: '0.8125rem', fontWeight: '600', color: 'var(--text-main)', marginBottom: '4px' }}>
              Staff Role *
            </label>
            <select
              value={addStaffForm.role}
              onChange={(e) => setAddStaffForm({ ...addStaffForm, role: e.target.value })}
              style={{
                width: '100%',
                padding: '0.625rem 0.875rem',
                border: '1px solid var(--border-color)',
                borderRadius: 'var(--radius-md)',
                fontSize: '0.875rem',
                color: 'var(--text-main)',
                backgroundColor: 'var(--bg-page)',
                outline: 'none'
              }}
            >
              <option value="CASHIER">CASHIER (POS checkout, billing & customer search)</option>
              <option value="STAFF">STAFF (Catalog view & inventory assistant)</option>
              <option value="MANAGER">MANAGER (Store supervisor & inventory adjustments)</option>
              {currentRole === 'OWNER' && <option value="OWNER">OWNER (Full administrative access)</option>}
            </select>
          </div>

          <Input
            label="Initial Password *"
            type="password"
            placeholder="Min 6 characters"
            value={addStaffForm.password}
            onChange={(e) => setAddStaffForm({ ...addStaffForm, password: e.target.value })}
            error={addStaffErrors.password}
            required
          />

          <div style={{ display: 'flex', justifyContent: 'flex-end', gap: '0.75rem', marginTop: '0.5rem' }}>
            <Button type="button" variant="outline" onClick={() => setIsAddStaffOpen(false)} disabled={addingStaff}>
              Cancel
            </Button>
            <Button type="submit" variant="primary" loading={addingStaff}>
              Create Staff Account
            </Button>
          </div>
        </form>
      </Modal>

      {/* Edit Staff Profile Modal */}
      {editStaffTarget && (
        <Modal
          isOpen={Boolean(editStaffTarget)}
          onClose={() => setEditStaffTarget(null)}
          title={`Edit Profile: ${editStaffTarget.name}`}
          width="460px"
        >
          <form onSubmit={handleEditStaffSubmit} style={{ display: 'flex', flexDirection: 'column', gap: '1rem' }}>
            <Input
              label="Full Name *"
              value={editStaffForm.name}
              onChange={(e) => setEditStaffForm({ ...editStaffForm, name: e.target.value })}
              required
            />
            <Input
              label="Phone Number"
              value={editStaffForm.phone}
              onChange={(e) => setEditStaffForm({ ...editStaffForm, phone: e.target.value })}
            />
            <div style={{ display: 'flex', justifyContent: 'flex-end', gap: '0.75rem', marginTop: '0.5rem' }}>
              <Button type="button" variant="outline" onClick={() => setEditStaffTarget(null)} disabled={savingEdit}>
                Cancel
              </Button>
              <Button type="submit" variant="primary" loading={savingEdit}>
                Save Changes
              </Button>
            </div>
          </form>
        </Modal>
      )}

      {/* Change Role Modal */}
      {roleChangeTarget && (
        <Modal
          isOpen={Boolean(roleChangeTarget)}
          onClose={() => setRoleChangeTarget(null)}
          title={`Change Role: ${roleChangeTarget.name}`}
          width="460px"
        >
          <div style={{ display: 'flex', flexDirection: 'column', gap: '1rem' }}>
            <p style={{ margin: 0, fontSize: '0.875rem', color: 'var(--text-muted)' }}>
              Current role: <strong>{roleChangeTarget.role}</strong>. Changing the role updates default module permissions.
            </p>

            <div>
              <label style={{ display: 'block', fontSize: '0.8125rem', fontWeight: '600', color: 'var(--text-main)', marginBottom: '4px' }}>
                Select New Role
              </label>
              <select
                value={newRoleVal}
                onChange={(e) => setNewRoleVal(e.target.value)}
                style={{
                  width: '100%',
                  padding: '0.625rem 0.875rem',
                  border: '1px solid var(--border-color)',
                  borderRadius: 'var(--radius-md)',
                  fontSize: '0.875rem',
                  backgroundColor: 'var(--bg-page)',
                  outline: 'none'
                }}
              >
                <option value="CASHIER">CASHIER</option>
                <option value="STAFF">STAFF</option>
                <option value="MANAGER">MANAGER</option>
                {currentRole === 'OWNER' && <option value="OWNER">OWNER</option>}
              </select>
            </div>

            <div style={{ display: 'flex', justifyContent: 'flex-end', gap: '0.75rem', marginTop: '0.5rem' }}>
              <Button variant="outline" disabled={savingRole} onClick={() => setRoleChangeTarget(null)}>
                Cancel
              </Button>
              <Button variant="primary" loading={savingRole} onClick={handleRoleChangeSubmit}>
                Confirm Role Change
              </Button>
            </div>
          </div>
        </Modal>
      )}

      {/* Activate / Deactivate Modal */}
      {statusToggleTarget && (
        <Modal
          isOpen={Boolean(statusToggleTarget)}
          onClose={() => setStatusToggleTarget(null)}
          title={statusToggleTarget.status === 'ACTIVE' ? 'Deactivate Staff Account' : 'Activate Staff Account'}
          width="440px"
        >
          <div style={{ display: 'flex', flexDirection: 'column', gap: '1rem' }}>
            <p style={{ margin: 0, fontSize: '0.875rem', color: 'var(--text-muted)', lineHeight: '1.5' }}>
              {statusToggleTarget.status === 'ACTIVE'
                ? `Deactivating ${statusToggleTarget.name} prevents them from logging into this store. Historical sales and audit logs are fully preserved.`
                : `Activating ${statusToggleTarget.name} restores login access to this store with their assigned permissions.`}
            </p>

            <div style={{ display: 'flex', justifyContent: 'flex-end', gap: '0.75rem', marginTop: '0.5rem' }}>
              <Button variant="outline" disabled={savingStatus} onClick={() => setStatusToggleTarget(null)}>
                Cancel
              </Button>
              <Button
                variant={statusToggleTarget.status === 'ACTIVE' ? 'danger' : 'primary'}
                loading={savingStatus}
                onClick={handleStatusToggleSubmit}
              >
                {statusToggleTarget.status === 'ACTIVE' ? 'Deactivate Account' : 'Activate Account'}
              </Button>
            </div>
          </div>
        </Modal>
      )}

      {/* Reset Password Modal */}
      {passwordResetTarget && (
        <Modal
          isOpen={Boolean(passwordResetTarget)}
          onClose={() => setPasswordResetTarget(null)}
          title={`Reset Password for ${passwordResetTarget.name}`}
          width="440px"
        >
          <form onSubmit={handlePasswordResetSubmit} style={{ display: 'flex', flexDirection: 'column', gap: '1rem' }}>
            <Input
              label="New Password (min 6 characters) *"
              type="password"
              placeholder="Enter new password"
              value={newPassVal}
              onChange={(e) => setNewPassVal(e.target.value)}
              required
            />
            <div style={{ display: 'flex', justifyContent: 'flex-end', gap: '0.75rem', marginTop: '0.5rem' }}>
              <Button type="button" variant="outline" disabled={savingPass} onClick={() => setPasswordResetTarget(null)}>
                Cancel
              </Button>
              <Button type="submit" variant="primary" loading={savingPass}>
                Update Password
              </Button>
            </div>
          </form>
        </Modal>
      )}

      {/* Log Attendance Modal */}
      <Modal
        isOpen={isAttendanceModalOpen}
        onClose={() => setIsAttendanceModalOpen(false)}
        title={`Log Attendance for ${attendanceDate}`}
        width="460px"
      >
        <form onSubmit={handleAttendanceSubmit} style={{ display: 'flex', flexDirection: 'column', gap: '1rem' }}>
          <div>
            <label style={{ display: 'block', fontSize: '0.8125rem', fontWeight: '600', color: 'var(--text-main)', marginBottom: '4px' }}>
              Staff Member *
            </label>
            <select
              value={attendanceForm.userId}
              onChange={(e) => setAttendanceForm({ ...attendanceForm, userId: e.target.value })}
              style={{
                width: '100%',
                padding: '0.625rem 0.875rem',
                border: '1px solid var(--border-color)',
                borderRadius: 'var(--radius-md)',
                fontSize: '0.875rem',
                backgroundColor: 'var(--bg-page)',
                outline: 'none'
              }}
              required
            >
              {staffList.map((s) => (
                <option key={s.id} value={s.id}>
                  {s.name} ({s.role})
                </option>
              ))}
            </select>
          </div>

          <div>
            <label style={{ display: 'block', fontSize: '0.8125rem', fontWeight: '600', color: 'var(--text-main)', marginBottom: '4px' }}>
              Status *
            </label>
            <select
              value={attendanceForm.status}
              onChange={(e) => setAttendanceForm({ ...attendanceForm, status: e.target.value })}
              style={{
                width: '100%',
                padding: '0.625rem 0.875rem',
                border: '1px solid var(--border-color)',
                borderRadius: 'var(--radius-md)',
                fontSize: '0.875rem',
                backgroundColor: 'var(--bg-page)',
                outline: 'none'
              }}
            >
              <option value="PRESENT">PRESENT</option>
              <option value="LATE">LATE</option>
              <option value="ABSENT">ABSENT</option>
              <option value="LEAVE">LEAVE</option>
            </select>
          </div>

          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '1rem' }}>
            <Input
              label="Check-In Time"
              type="time"
              value={attendanceForm.checkIn}
              onChange={(e) => setAttendanceForm({ ...attendanceForm, checkIn: e.target.value })}
            />
            <Input
              label="Check-Out Time"
              type="time"
              value={attendanceForm.checkOut}
              onChange={(e) => setAttendanceForm({ ...attendanceForm, checkOut: e.target.value })}
            />
          </div>

          <div>
            <label style={{ display: 'block', fontSize: '0.8125rem', fontWeight: '600', color: 'var(--text-main)', marginBottom: '4px' }}>
              Notes
            </label>
            <input
              type="text"
              placeholder="e.g. Morning shift, 15m late traffic"
              value={attendanceForm.notes}
              onChange={(e) => setAttendanceForm({ ...attendanceForm, notes: e.target.value })}
              style={{
                width: '100%',
                padding: '0.625rem 0.875rem',
                border: '1px solid var(--border-color)',
                borderRadius: 'var(--radius-md)',
                fontSize: '0.875rem',
                backgroundColor: 'var(--bg-page)',
                outline: 'none'
              }}
            />
          </div>

          <div style={{ display: 'flex', justifyContent: 'flex-end', gap: '0.75rem', marginTop: '0.5rem' }}>
            <Button type="button" variant="outline" disabled={savingAttendance} onClick={() => setIsAttendanceModalOpen(false)}>
              Cancel
            </Button>
            <Button type="submit" variant="primary" loading={savingAttendance}>
              Save Attendance
            </Button>
          </div>
        </form>
      </Modal>

      {/* Delete Staff Confirmation Modal */}
      {deleteTarget && (
        <Modal
          isOpen={Boolean(deleteTarget)}
          onClose={() => setDeleteTarget(null)}
          title={`Remove Staff Member: ${deleteTarget.name}`}
          width="460px"
        >
          <div style={{ display: 'flex', flexDirection: 'column', gap: '1rem' }}>
            <div style={{ display: 'flex', alignItems: 'flex-start', gap: '12px', padding: '12px', backgroundColor: '#FEF2F2', borderRadius: 'var(--radius-md)', border: '1px solid #FCA5A5' }}>
              <AlertTriangle size={24} style={{ color: '#DC2626', flexShrink: 0, marginTop: '2px' }} />
              <div style={{ fontSize: '0.875rem', color: '#991B1B', lineHeight: '1.4' }}>
                Are you sure you want to remove <strong>{deleteTarget.name}</strong> ({deleteTarget.role})? This will revoke their store access and remove them from your active team.
              </div>
            </div>
            <div style={{ display: 'flex', justifyContent: 'flex-end', gap: '0.75rem', marginTop: '0.5rem' }}>
              <Button type="button" variant="outline" onClick={() => setDeleteTarget(null)} disabled={savingDelete}>
                Cancel
              </Button>
              <Button
                type="button"
                variant="danger"
                loading={savingDelete}
                onClick={handleDeleteStaffSubmit}
                style={{ backgroundColor: '#DC2626', borderColor: '#DC2626', color: '#FFFFFF' }}
              >
                Yes, Remove Staff
              </Button>
            </div>
          </div>
        </Modal>
      )}
    </div>
  );
}
