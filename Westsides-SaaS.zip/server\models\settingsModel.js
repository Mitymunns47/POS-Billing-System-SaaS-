const db = require('../db/database');
const ActivityLogModel = require('./activityLogModel');

const SettingsModel = {
  /**
   * Get store settings. Creates default settings row if none exists.
   */
  getSettings: (storeId) => {
    let settings = db.prepare('SELECT * FROM store_settings WHERE storeId = ?').get(storeId);

    if (!settings) {
      const store = db.prepare('SELECT * FROM stores WHERE id = ?').get(storeId);
      const now = new Date().toISOString();
      const defaultName = store ? store.name : 'Westsides Store';

      db.prepare(`
        INSERT INTO store_settings (
          storeId, storeName, storeLogo, phone, email, address, city, state, postalCode, country,
          description, gstNumber, legalBusinessName,
          taxEnabled, taxName, taxRate, taxInclusive,
          invoicePrefix, footerNote, returnPolicy, receiptContact,
          allowNegativeInventory, requireCustomerForSale, allowDiscounts, maxDiscountPercent, requireManagerDiscountApproval, defaultPaymentMethod,
          defaultMinStock, lowStockAlerts, outOfStockAlerts,
          updatedAt
        ) VALUES (
          ?, ?, null, null, null, null, null, null, null, 'India',
          null, null, null,
          0, 'GST', 18.0, 0,
          'WS', 'Thank you for shopping with Westsides!', 'Items in resellable condition can be returned within 14 days with original receipt.', null,
          0, 0, 1, 50.0, 0, 'CASH',
          5, 1, 1,
          ?
        )
      `).run(storeId, defaultName, now);

      settings = db.prepare('SELECT * FROM store_settings WHERE storeId = ?').get(storeId);
    }

    return {
      ...settings,
      taxEnabled: Boolean(settings.taxEnabled),
      taxInclusive: Boolean(settings.taxInclusive),
      allowNegativeInventory: Boolean(settings.allowNegativeInventory),
      requireCustomerForSale: Boolean(settings.requireCustomerForSale),
      allowDiscounts: Boolean(settings.allowDiscounts),
      requireManagerDiscountApproval: Boolean(settings.requireManagerDiscountApproval),
      lowStockAlerts: Boolean(settings.lowStockAlerts),
      outOfStockAlerts: Boolean(settings.outOfStockAlerts),
      taxRate: Number(settings.taxRate) || 0,
      maxDiscountPercent: Number(settings.maxDiscountPercent) || 50,
      defaultMinStock: Number(settings.defaultMinStock) || 5
    };
  },

  /**
   * Update store settings
   */
  updateSettings: (storeId, data, userId = null, userName = 'Admin') => {
    const existing = SettingsModel.getSettings(storeId);
    const now = new Date().toISOString();

    const updated = {
      storeName: data.storeName !== undefined ? data.storeName.trim() : existing.storeName,
      storeLogo: data.storeLogo !== undefined ? data.storeLogo : existing.storeLogo,
      phone: data.phone !== undefined ? (data.phone ? data.phone.trim() : null) : existing.phone,
      email: data.email !== undefined ? (data.email ? data.email.trim().toLowerCase() : null) : existing.email,
      address: data.address !== undefined ? data.address : existing.address,
      city: data.city !== undefined ? data.city : existing.city,
      state: data.state !== undefined ? data.state : existing.state,
      postalCode: data.postalCode !== undefined ? data.postalCode : existing.postalCode,
      country: data.country !== undefined ? data.country : (existing.country || 'India'),
      description: data.description !== undefined ? data.description : existing.description,
      gstNumber: data.gstNumber !== undefined ? (data.gstNumber ? data.gstNumber.trim().toUpperCase() : null) : existing.gstNumber,
      legalBusinessName: data.legalBusinessName !== undefined ? data.legalBusinessName : existing.legalBusinessName,
      // Tax
      taxEnabled: data.taxEnabled !== undefined ? (data.taxEnabled ? 1 : 0) : (existing.taxEnabled ? 1 : 0),
      taxName: data.taxName !== undefined ? data.taxName.trim() : existing.taxName,
      taxRate: data.taxRate !== undefined ? Math.max(0, Number(data.taxRate) || 0) : existing.taxRate,
      taxInclusive: data.taxInclusive !== undefined ? (data.taxInclusive ? 1 : 0) : (existing.taxInclusive ? 1 : 0),
      // Invoice & Receipt
      invoicePrefix: data.invoicePrefix !== undefined ? (data.invoicePrefix.trim().toUpperCase().replace(/[^A-Z0-9-]/g, '') || 'WS') : existing.invoicePrefix,
      footerNote: data.footerNote !== undefined ? data.footerNote : existing.footerNote,
      returnPolicy: data.returnPolicy !== undefined ? data.returnPolicy : existing.returnPolicy,
      receiptContact: data.receiptContact !== undefined ? data.receiptContact : existing.receiptContact,
      // POS Controls
      allowNegativeInventory: data.allowNegativeInventory !== undefined ? (data.allowNegativeInventory ? 1 : 0) : (existing.allowNegativeInventory ? 1 : 0),
      requireCustomerForSale: data.requireCustomerForSale !== undefined ? (data.requireCustomerForSale ? 1 : 0) : (existing.requireCustomerForSale ? 1 : 0),
      allowDiscounts: data.allowDiscounts !== undefined ? (data.allowDiscounts ? 1 : 0) : (existing.allowDiscounts ? 1 : 0),
      maxDiscountPercent: data.maxDiscountPercent !== undefined ? Math.min(100, Math.max(0, Number(data.maxDiscountPercent) || 0)) : existing.maxDiscountPercent,
      requireManagerDiscountApproval: data.requireManagerDiscountApproval !== undefined ? (data.requireManagerDiscountApproval ? 1 : 0) : (existing.requireManagerDiscountApproval ? 1 : 0),
      defaultPaymentMethod: data.defaultPaymentMethod !== undefined ? data.defaultPaymentMethod : existing.defaultPaymentMethod,
      // Inventory Controls
      defaultMinStock: data.defaultMinStock !== undefined ? Math.max(0, parseInt(data.defaultMinStock) || 0) : existing.defaultMinStock,
      lowStockAlerts: data.lowStockAlerts !== undefined ? (data.lowStockAlerts ? 1 : 0) : (existing.lowStockAlerts ? 1 : 0),
      outOfStockAlerts: data.outOfStockAlerts !== undefined ? (data.outOfStockAlerts ? 1 : 0) : (existing.outOfStockAlerts ? 1 : 0)
    };

    db.prepare(`
      UPDATE store_settings SET
        storeName = ?, storeLogo = ?, phone = ?, email = ?, address = ?, city = ?, state = ?, postalCode = ?, country = ?,
        description = ?, gstNumber = ?, legalBusinessName = ?,
        taxEnabled = ?, taxName = ?, taxRate = ?, taxInclusive = ?,
        invoicePrefix = ?, footerNote = ?, returnPolicy = ?, receiptContact = ?,
        allowNegativeInventory = ?, requireCustomerForSale = ?, allowDiscounts = ?, maxDiscountPercent = ?, requireManagerDiscountApproval = ?, defaultPaymentMethod = ?,
        defaultMinStock = ?, lowStockAlerts = ?, outOfStockAlerts = ?,
        updatedAt = ?
      WHERE storeId = ?
    `).run(
      updated.storeName, updated.storeLogo, updated.phone, updated.email, updated.address, updated.city, updated.state, updated.postalCode, updated.country,
      updated.description, updated.gstNumber, updated.legalBusinessName,
      updated.taxEnabled, updated.taxName, updated.taxRate, updated.taxInclusive,
      updated.invoicePrefix, updated.footerNote, updated.returnPolicy, updated.receiptContact,
      updated.allowNegativeInventory, updated.requireCustomerForSale, updated.allowDiscounts, updated.maxDiscountPercent, updated.requireManagerDiscountApproval, updated.defaultPaymentMethod,
      updated.defaultMinStock, updated.lowStockAlerts, updated.outOfStockAlerts,
      now, storeId
    );

    // Sync legacy/Phase 3 store_tax_settings for seamless backward compatibility
    db.prepare(`
      INSERT OR REPLACE INTO store_tax_settings (storeId, taxEnabled, taxName, taxRate, taxInclusive, updatedAt)
      VALUES (?, ?, ?, ?, ?, ?)
    `).run(storeId, updated.taxEnabled, updated.taxName, updated.taxRate, updated.taxInclusive, now);

    // Sync invoice prefix to invoice_counters if changed
    db.prepare(`
      INSERT INTO invoice_counters (storeId, lastNumber, prefix)
      VALUES (?, 0, ?)
      ON CONFLICT(storeId) DO UPDATE SET prefix = excluded.prefix
    `).run(storeId, updated.invoicePrefix);

    // Audit log
    if (userId) {
      ActivityLogModel.logActivity({
        storeId,
        userId,
        userName,
        action: 'UPDATE_SETTINGS',
        module: 'Settings',
        description: `Updated store configuration and operational rules (Tax: ${updated.taxEnabled ? updated.taxRate + '%' : 'Disabled'}, Prefix: ${updated.invoicePrefix})`,
        recordId: storeId
      });
    }

    return SettingsModel.getSettings(storeId);
  }
};

module.exports = SettingsModel;
