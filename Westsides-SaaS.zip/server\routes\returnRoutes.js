const express = require('express');
const router = express.Router();
const authMiddleware = require('../middleware/auth');
const { requirePermission } = require('../middleware/roles');
const { PERMISSIONS } = require('../constants/roles');
const ReturnModel = require('../models/returnModel');

router.use(authMiddleware);

/**
 * GET /api/returns — List returns with filters & pagination
 */
router.get('/', requirePermission(PERMISSIONS.RETURNS_VIEW), (req, res) => {
  try {
    const {
      search = '',
      customerId = '',
      staffId = '',
      refundMethod = '',
      status = '',
      startDate = '',
      endDate = '',
      page = 1,
      limit = 20
    } = req.query;

    const result = ReturnModel.findAll({
      storeId: req.storeId,
      search,
      customerId,
      staffId,
      refundMethod,
      status,
      startDate,
      endDate,
      page: parseInt(page, 10) || 1,
      limit: parseInt(limit, 10) || 20
    });

    res.json({ success: true, data: result });
  } catch (err) {
    console.error('List returns error:', err);
    res.status(500).json({ success: false, error: 'Failed to retrieve returns.' });
  }
});

/**
 * GET /api/returns/sales — Search completed sales eligible for return
 */
router.get('/sales', requirePermission(PERMISSIONS.RETURNS_VIEW), (req, res) => {
  try {
    const { search = '', page = 1, limit = 20 } = req.query;
    const result = ReturnModel.searchReturnableSales(req.storeId, {
      search,
      page: parseInt(page, 10) || 1,
      limit: parseInt(limit, 10) || 20
    });
    res.json({ success: true, data: result });
  } catch (err) {
    console.error('Search returnable sales error:', err);
    res.status(500).json({ success: false, error: 'Failed to search returnable sales.' });
  }
});

/**
 * GET /api/returns/sale/:saleId — Get returnable details & remaining quantities for a specific sale
 */
router.get('/sale/:saleId', requirePermission(PERMISSIONS.RETURNS_VIEW), (req, res) => {
  try {
    const result = ReturnModel.getSaleReturnDetails(req.params.saleId, req.storeId);
    if (!result) {
      return res.status(404).json({ success: false, error: 'Sale record not found.' });
    }
    res.json({ success: true, data: result });
  } catch (err) {
    console.error('Get sale return details error:', err);
    res.status(500).json({ success: false, error: 'Failed to get sale return details.' });
  }
});

/**
 * GET /api/returns/:id — Get details of a single return
 */
router.get('/:id', requirePermission(PERMISSIONS.RETURNS_VIEW), (req, res) => {
  try {
    const returnRecord = ReturnModel.findById(req.params.id, req.storeId);
    if (!returnRecord) {
      return res.status(404).json({ success: false, error: 'Return record not found.' });
    }
    res.json({ success: true, data: returnRecord });
  } catch (err) {
    console.error('Get return error:', err);
    res.status(500).json({ success: false, error: 'Failed to fetch return details.' });
  }
});

/**
 * POST /api/returns — Process a full or partial return
 */
router.post('/', requirePermission(PERMISSIONS.RETURNS_CREATE), (req, res) => {
  try {
    const { saleId, items, reason, notes, refundMethod } = req.body;

    if (!saleId) {
      return res.status(400).json({ success: false, error: 'Sale ID is required.' });
    }
    if (!items || !Array.isArray(items) || items.length === 0) {
      return res.status(400).json({ success: false, error: 'At least one return item is required.' });
    }
    if (!reason || !reason.trim()) {
      return res.status(400).json({ success: false, error: 'Return reason is required.' });
    }

    const createdReturn = ReturnModel.create({
      storeId: req.storeId,
      saleId,
      items,
      reason,
      notes,
      refundMethod,
      staffId: req.user.id,
      staffName: req.user.name || 'Cashier'
    });

    res.status(201).json({
      success: true,
      message: 'Return processed and inventory updated successfully.',
      data: createdReturn
    });
  } catch (err) {
    console.error('Process return error:', err);
    res.status(400).json({ success: false, error: err.message || 'Failed to process return.' });
  }
});

module.exports = router;
