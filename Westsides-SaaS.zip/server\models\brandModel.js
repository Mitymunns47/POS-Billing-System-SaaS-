const crypto = require('crypto');
const db = require('../db/database');

const BrandModel = {
  create: ({ storeId, name, description = '' }) => {
    const id = 'brd_' + crypto.randomBytes(8).toString('hex');
    const now = new Date().toISOString();
    db.prepare(`
      INSERT INTO brands (id, storeId, name, description, active, createdAt, updatedAt)
      VALUES (?, ?, ?, ?, 1, ?, ?)
    `).run(id, storeId, name.trim(), description.trim(), now, now);
    return BrandModel.findById(id, storeId);
  },

  findById: (id, storeId) => {
    const row = db.prepare('SELECT * FROM brands WHERE id = ? AND storeId = ?').get(id, storeId);
    return row ? { ...row, active: Boolean(row.active) } : null;
  },

  findAll: (storeId, includeInactive = false) => {
    const sql = includeInactive
      ? 'SELECT * FROM brands WHERE storeId = ? ORDER BY name ASC'
      : 'SELECT * FROM brands WHERE storeId = ? AND active = 1 ORDER BY name ASC';
    return db.prepare(sql).all(storeId).map(r => ({ ...r, active: Boolean(r.active) }));
  },

  update: (id, storeId, { name, description, active }) => {
    const now = new Date().toISOString();
    if (!BrandModel.findById(id, storeId)) return null;
    db.prepare(`
      UPDATE brands
      SET name = COALESCE(?, name),
          description = COALESCE(?, description),
          active = COALESCE(?, active),
          updatedAt = ?
      WHERE id = ? AND storeId = ?
    `).run(
      name !== undefined ? name.trim() : null,
      description !== undefined ? description.trim() : null,
      active !== undefined ? (active ? 1 : 0) : null,
      now, id, storeId
    );
    return BrandModel.findById(id, storeId);
  },

  delete: (id, storeId) => {
    const now = new Date().toISOString();
    const info = db.prepare(
      'UPDATE brands SET active = 0, updatedAt = ? WHERE id = ? AND storeId = ?'
    ).run(now, id, storeId);
    return info.changes > 0;
  },

  checkDuplicate: (storeId, name, excludeId = null) => {
    const sql = excludeId
      ? 'SELECT id FROM brands WHERE storeId = ? AND name = ? AND id != ? COLLATE NOCASE'
      : 'SELECT id FROM brands WHERE storeId = ? AND name = ? COLLATE NOCASE';
    const params = excludeId ? [storeId, name.trim(), excludeId] : [storeId, name.trim()];
    return !!db.prepare(sql).get(...params);
  }
};

module.exports = BrandModel;
