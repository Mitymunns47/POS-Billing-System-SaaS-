const express = require('express');
const router = express.Router();
const ReportModel = require('../models/reportModel');
const ExpenseModel = require('../models/expenseModel');
const authMiddleware = require('../middleware/auth');
const { requirePermission } = require('../middleware/roles');
const { PERMISSIONS } = require('../constants/roles');

router.use(authMiddleware);

// All report endpoints require reports.view permission
router.use(requirePermission(PERMISSIONS.REPORTS_VIEW));

// GET /api/reports/dashboard — Executive overview KPIs & widgets
router.get('/dashboard', (req, res) => {
  try {
    const { range, startDate, endDate } = req.query;
    const overview = ReportModel.getDashboardOverview(req.storeId, { range, startDate, endDate });
    res.json({ success: true, ...overview });
  } catch (err) {
    console.error('Dashboard report error:', err);
    res.status(500).json({ success: false, error: 'Could not generate dashboard report.' });
  }
});

// GET /api/reports/sales — Sales overview, timeline, payment distribution
router.get('/sales', (req, res) => {
  try {
    const { range, startDate, endDate, groupBy } = req.query;
    const report = ReportModel.getSalesReport(req.storeId, { range, startDate, endDate, groupBy });
    res.json({ success: true, ...report });
  } catch (err) {
    console.error('Sales report error:', err);
    res.status(500).json({ success: false, error: 'Could not generate sales report.' });
  }
});

// GET /api/reports/products — Top selling products & category breakdown
router.get('/products', (req, res) => {
  try {
    const { range, startDate, endDate, categoryId, sortBy, sortDir } = req.query;
    const report = ReportModel.getProductReport(req.storeId, { range, startDate, endDate, categoryId, sortBy, sortDir });
    res.json({ success: true, ...report });
  } catch (err) {
    console.error('Product report error:', err);
    res.status(500).json({ success: false, error: 'Could not generate product report.' });
  }
});

// GET /api/reports/inventory — Stock valuations & low stock report
router.get('/inventory', (req, res) => {
  try {
    const { statusFilter, limit } = req.query;
    const report = ReportModel.getInventoryReport(req.storeId, {
      statusFilter,
      limit: parseInt(limit) || 100
    });
    res.json({ success: true, ...report });
  } catch (err) {
    console.error('Inventory report error:', err);
    res.status(500).json({ success: false, error: 'Could not generate inventory report.' });
  }
});

// GET /api/reports/customers — Customer acquisition, retention & top customers
router.get('/customers', (req, res) => {
  try {
    const { range, startDate, endDate } = req.query;
    const report = ReportModel.getCustomerReport(req.storeId, { range, startDate, endDate });
    res.json({ success: true, ...report });
  } catch (err) {
    console.error('Customer report error:', err);
    res.status(500).json({ success: false, error: 'Could not generate customer report.' });
  }
});

// GET /api/reports/staff — Staff objective transaction performance
router.get('/staff', (req, res) => {
  try {
    const { range, startDate, endDate } = req.query;
    const report = ReportModel.getStaffReport(req.storeId, { range, startDate, endDate });
    res.json({ success: true, ...report });
  } catch (err) {
    console.error('Staff report error:', err);
    res.status(500).json({ success: false, error: 'Could not generate staff report.' });
  }
});

// GET /api/reports/finance — Financial summary, margins, and expenses
router.get('/finance', (req, res) => {
  try {
    const { range, startDate, endDate } = req.query;
    const report = ReportModel.getFinanceReport(req.storeId, { range, startDate, endDate });
    res.json({ success: true, ...report });
  } catch (err) {
    console.error('Finance report error:', err);
    res.status(500).json({ success: false, error: 'Could not generate financial report.' });
  }
});

// Helper: Escape CSV string values safely
function toCSV(headers, rows) {
  const headerLine = headers.map(h => `"${h.replace(/"/g, '""')}"`).join(',');
  const lines = rows.map(row => {
    return headers.map(h => {
      const val = row[h] !== undefined && row[h] !== null ? String(row[h]) : '';
      return `"${val.replace(/"/g, '""')}"`;
    }).join(',');
  });
  return [headerLine, ...lines].join('\n');
}

// GET /api/reports/export/:type — CSV Export foundation
router.get('/export/:type', (req, res) => {
  try {
    const { type } = req.params;
    const { range = 'last30days', startDate = '', endDate = '', statusFilter = 'ALL' } = req.query;

    let csvContent = '';
    let filename = `westsides-${type}-${new Date().toISOString().split('T')[0]}.csv`;

    switch (type) {
      case 'sales': {
        const data = ReportModel.getSalesReport(req.storeId, { range, startDate, endDate });
        const rows = data.sales.map(s => ({
          'Invoice Number': s.invoiceNumber,
          'Date': s.createdAt ? s.createdAt.replace('T', ' ').substring(0, 19) : '',
          'Customer': s.customerName || 'Walk-in',
          'Cashier': s.cashierName || '',
          'Subtotal (INR)': s.subtotal.toFixed(2),
          'Discount (INR)': s.discountAmount.toFixed(2),
          'Tax (INR)': s.taxAmount.toFixed(2),
          'Total Amount (INR)': s.totalAmount.toFixed(2),
          'Payment Method': s.paymentMethod,
          'Status': s.status
        }));
        const headers = ['Invoice Number', 'Date', 'Customer', 'Cashier', 'Subtotal (INR)', 'Discount (INR)', 'Tax (INR)', 'Total Amount (INR)', 'Payment Method', 'Status'];
        csvContent = toCSV(headers, rows);
        break;
      }

      case 'products': {
        const data = ReportModel.getProductReport(req.storeId, { range, startDate, endDate });
        const rows = data.products.map(p => ({
          'Product': p.productName,
          'SKU': p.sku || '',
          'Category': p.categoryName || 'Uncategorized',
          'Units Sold': p.unitsSold,
          'Revenue (INR)': p.revenue.toFixed(2),
          'Avg Selling Price (INR)': p.avgSellingPrice.toFixed(2)
        }));
        const headers = ['Product', 'SKU', 'Category', 'Units Sold', 'Revenue (INR)', 'Avg Selling Price (INR)'];
        csvContent = toCSV(headers, rows);
        break;
      }

      case 'inventory': {
        const data = ReportModel.getInventoryReport(req.storeId, { statusFilter, limit: 1000 });
        const rows = data.lowStockItems.map(item => ({
          'Product': item.productName,
          'SKU': item.sku || '',
          'Size': item.size || '',
          'Color': item.color || '',
          'Current Stock': item.currentStock,
          'Minimum Stock': item.minimumStock,
          'Cost Price (INR)': item.costPrice.toFixed(2),
          'Selling Price (INR)': item.sellingPrice.toFixed(2),
          'Status': item.status
        }));
        const headers = ['Product', 'SKU', 'Size', 'Color', 'Current Stock', 'Minimum Stock', 'Cost Price (INR)', 'Selling Price (INR)', 'Status'];
        csvContent = toCSV(headers, rows);
        break;
      }

      case 'customers': {
        const data = ReportModel.getCustomerReport(req.storeId, { range, startDate, endDate });
        const rows = data.topCustomers.map(c => ({
          'Customer Name': c.customerName,
          'Phone': c.customerPhone || '',
          'Email': c.customerEmail || '',
          'Orders Completed': c.orders,
          'Total Spent (INR)': c.totalSpent.toFixed(2),
          'Last Purchase': c.lastPurchaseDate ? c.lastPurchaseDate.replace('T', ' ').substring(0, 19) : ''
        }));
        const headers = ['Customer Name', 'Phone', 'Email', 'Orders Completed', 'Total Spent (INR)', 'Last Purchase'];
        csvContent = toCSV(headers, rows);
        break;
      }

      case 'staff': {
        const data = ReportModel.getStaffReport(req.storeId, { range, startDate, endDate });
        const rows = data.staff.map(s => ({
          'Staff Member': s.staffName,
          'Email': s.staffEmail,
          'Role': s.staffRole,
          'Status': s.staffStatus,
          'Orders Completed': s.ordersCompleted,
          'Items Sold': s.itemsSold,
          'Total Sales (INR)': s.salesAmount.toFixed(2),
          'Average Order Value (INR)': s.averageOrderValue.toFixed(2),
          'Last Sale': s.lastSaleDate ? s.lastSaleDate.replace('T', ' ').substring(0, 19) : 'None'
        }));
        const headers = ['Staff Member', 'Email', 'Role', 'Status', 'Orders Completed', 'Items Sold', 'Total Sales (INR)', 'Average Order Value (INR)', 'Last Sale'];
        csvContent = toCSV(headers, rows);
        break;
      }

      case 'expenses': {
        const data = ExpenseModel.findAll({ storeId: req.storeId, limit: 1000, startDate, endDate });
        const rows = data.expenses.map(e => ({
          'Title': e.title,
          'Category': e.category,
          'Amount (INR)': Number(e.amount).toFixed(2),
          'Date': e.date,
          'Notes': e.notes || '',
          'Created By': e.createdBy || '',
          'Status': e.status
        }));
        const headers = ['Title', 'Category', 'Amount (INR)', 'Date', 'Notes', 'Created By', 'Status'];
        csvContent = toCSV(headers, rows);
        break;
      }

      default:
        return res.status(400).json({ success: false, error: `Invalid export type: ${type}` });
    }

    res.setHeader('Content-Type', 'text/csv');
    res.setHeader('Content-Disposition', `attachment; filename="${filename}"`);
    return res.status(200).send(csvContent);
  } catch (err) {
    console.error('Export error:', err);
    res.status(500).json({ success: false, error: 'Could not generate report export.' });
  }
});

module.exports = router;
