import React, { useState } from 'react';
import { useAuth } from '../context/AuthContext';
import { Button } from '../components/ui/Button';
import { Input } from '../components/ui/Input';
import { Card, CardContent } from '../components/ui/Card';
import { Alert } from '../components/ui/Alert';
import { Eye, EyeOff, Lock, Mail, Store, Shield } from 'lucide-react';

export function LoginPage({ onNavigate }) {
  const { login } = useAuth();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [rememberMe, setRememberMe] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState(null);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError(null);

    if (!email.trim()) {
      setError('Please enter your email or username.');
      return;
    }

    if (!password) {
      setError('Please enter your password.');
      return;
    }

    setIsLoading(true);

    try {
      const result = await login({ email, password, rememberMe });
      if (result.success) {
        // Check if onboarding completed
        if (!result.store?.onboardingCompleted) {
          onNavigate('/onboarding');
        } else {
          onNavigate('/dashboard');
        }
      }
    } catch (err) {
      setError(err.message || 'Invalid credentials or account not found.');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div
      style={{
        minHeight: '100vh',
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center',
        justifyContent: 'center',
        backgroundColor: 'var(--bg-page)',
        padding: '1.5rem'
      }}
    >
      <div style={{ width: '100%', maxWidth: '420px' }} className="animate-fade-in">
        {/* Brand Header */}
        <div style={{ textAlign: 'center', marginBottom: '2rem' }}>
          <div
            style={{
              width: '48px',
              height: '48px',
              borderRadius: '12px',
              backgroundColor: '#7EAFD0',
              display: 'inline-flex',
              alignItems: 'center',
              justifyContent: 'center',
              color: '#FFFFFF',
              fontWeight: '700',
              fontSize: '1.5rem',
              boxShadow: '0 4px 10px rgba(126, 175, 208, 0.3)',
              marginBottom: '1rem'
            }}
          >
            W
          </div>
          <h1
            style={{
              fontSize: '1.625rem',
              fontWeight: '700',
              color: 'var(--text-main)',
              letterSpacing: '0.5px',
              margin: '0 0 4px 0'
            }}
          >
            WESTSIDES
          </h1>
          <p
            style={{
              fontSize: '0.875rem',
              color: 'var(--text-muted)',
              fontWeight: '500',
              marginBottom: '4px'
            }}
          >
            Clothing Store Management
          </p>
          <p style={{ fontSize: '0.8125rem', color: 'var(--text-light)' }}>
            Welcome back. Please sign in to your store account.
          </p>
        </div>

        {/* Login Card */}
        <Card style={{ padding: '0.5rem' }}>
          <CardContent>
            {error && (
              <Alert
                variant="danger"
                style={{ marginBottom: '1.25rem' }}
                onDismiss={() => setError(null)}
              >
                {error}
              </Alert>
            )}

            <form onSubmit={handleSubmit} style={{ display: 'flex', flexDirection: 'column', gap: '1.25rem' }}>
              <Input
                label="Email / Username"
                id="login-email"
                type="email"
                placeholder="admin@westsides.com"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                required
                startIcon={<Mail size={16} />}
                autoComplete="email"
              />

              <Input
                label="Password"
                id="login-password"
                type={showPassword ? 'text' : 'password'}
                placeholder="••••••••"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                required
                startIcon={<Lock size={16} />}
                autoComplete="current-password"
                endIcon={
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    style={{
                      background: 'none',
                      border: 'none',
                      cursor: 'pointer',
                      color: 'var(--text-muted)',
                      display: 'flex',
                      alignItems: 'center',
                      padding: 0
                    }}
                    title={showPassword ? 'Hide password' : 'Show password'}
                  >
                    {showPassword ? <EyeOff size={16} /> : <Eye size={16} />}
                  </button>
                }
              />

              <div
                style={{
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'space-between',
                  fontSize: '0.8125rem'
                }}
              >
                <label style={{ display: 'flex', alignItems: 'center', gap: '8px', cursor: 'pointer', color: 'var(--text-muted)' }}>
                  <input
                    type="checkbox"
                    checked={rememberMe}
                    onChange={(e) => setRememberMe(e.target.checked)}
                    style={{ accentColor: '#7EAFD0', width: '15px', height: '15px', cursor: 'pointer' }}
                  />
                  Remember Me
                </label>

                <button
                  type="button"
                  onClick={() => onNavigate('/forgot-password')}
                  style={{
                    background: 'none',
                    border: 'none',
                    padding: 0,
                    color: '#7EAFD0',
                    fontSize: '0.8125rem',
                    cursor: 'pointer',
                    fontWeight: '500'
                  }}
                >
                  Forgot Password?
                </button>
              </div>

              <Button
                type="submit"
                variant="primary"
                size="lg"
                isLoading={isLoading}
                style={{ width: '100%', marginTop: '0.5rem' }}
              >
                Sign In
              </Button>
            </form>
          </CardContent>
        </Card>

        {/* Create Store Prompt */}
        <div
          style={{
            marginTop: '1.5rem',
            textAlign: 'center',
            fontSize: '0.875rem',
            color: 'var(--text-muted)'
          }}
        >
          New clothing store?{' '}
          <button
            type="button"
            onClick={() => onNavigate('/signup')}
            style={{
              background: 'none',
              border: 'none',
              padding: 0,
              color: '#7EAFD0',
              fontWeight: '600',
              cursor: 'pointer'
            }}
          >
            Create Your Store
          </button>
        </div>

        {/* Security Assurance Footer */}
        <div
          style={{
            marginTop: '2.5rem',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            gap: '6px',
            fontSize: '0.75rem',
            color: 'var(--text-light)'
          }}
        >
          <Shield size={14} color="#7EAFD0" />
          <span>Multi-Tenant Architecture • End-to-End Data Isolation</span>
        </div>

        <div style={{ marginTop: '1rem', textAlign: 'center' }}>
          <a
            href="/admin"
            style={{
              fontSize: '0.75rem',
              color: 'var(--text-light)',
              textDecoration: 'none',
              display: 'inline-flex',
              alignItems: 'center',
              gap: '4px',
              opacity: 0.8,
              transition: 'opacity 0.2s'
            }}
            onMouseEnter={(e) => { e.currentTarget.style.opacity = '1'; e.currentTarget.style.color = '#7EAFD0'; }}
            onMouseLeave={(e) => { e.currentTarget.style.opacity = '0.8'; e.currentTarget.style.color = 'var(--text-light)'; }}
          >
            SaaS Platform Admin Portal →
          </a>
        </div>
      </div>
    </div>
  );
}
