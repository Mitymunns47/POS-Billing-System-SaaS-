import React, { useState, useEffect } from 'react';
import { api } from '../services/api';
import { useAuth } from '../context/AuthContext';
import { Card } from '../components/ui/Card';
import { Button } from '../components/ui/Button';
import { Badge } from '../components/ui/Badge';
import {
  Settings,
  Store,
  Receipt,
  Percent,
  Sliders,
  Bell,
  Boxes,
  CheckCircle2,
  AlertTriangle,
  Save,
  HelpCircle,
  FileText
} from 'lucide-react';

export function SettingsPage() {
  const { user, role, store } = useAuth();
  const [activeTab, setActiveTab] = useState('general');
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [saveSuccess, setSaveSuccess] = useState('');
  const [saveError, setSaveError] = useState('');

  // Settings Form State
  const [formData, setFormData] = useState({
    storeName: '',
    storeLogo: '',
    phone: '',
    email: '',
    address: '',
    city: '',
    state: '',
    postalCode: '',
    country: 'India',
    description: '',
    gstNumber: '',
    legalBusinessName: '',
    // Tax
    taxEnabled: false,
    taxName: 'GST',
    taxRate: 18.0,
    taxInclusive: false,
    // Invoice
    invoicePrefix: 'WS',
    footerNote: 'Thank you for shopping with Westsides!',
    returnPolicy: 'Items in resellable condition can be returned within 14 days with original receipt.',
    receiptContact: '',
    // POS
    allowNegativeInventory: false,
    requireCustomerForSale: false,
    allowDiscounts: true,
    maxDiscountPercent: 50.0,
    requireManagerDiscountApproval: false,
    defaultPaymentMethod: 'CASH',
    // Inventory
    defaultMinStock: 5,
    lowStockAlerts: true,
    outOfStockAlerts: true
  });

  useEffect(() => {
    loadSettings();
  }, []);

  const loadSettings = async () => {
    setLoading(true);
    setSaveError('');
    try {
      const res = await api.getSettings();
      if (res.success && res.data) {
        setFormData({
          ...res.data,
          taxEnabled: Boolean(res.data.taxEnabled),
          taxInclusive: Boolean(res.data.taxInclusive),
          allowNegativeInventory: Boolean(res.data.allowNegativeInventory),
          requireCustomerForSale: Boolean(res.data.requireCustomerForSale),
          allowDiscounts: Boolean(res.data.allowDiscounts),
          requireManagerDiscountApproval: Boolean(res.data.requireManagerDiscountApproval),
          lowStockAlerts: Boolean(res.data.lowStockAlerts),
          outOfStockAlerts: Boolean(res.data.outOfStockAlerts),
          taxRate: Number(res.data.taxRate) || 0,
          maxDiscountPercent: Number(res.data.maxDiscountPercent) || 50,
          defaultMinStock: Number(res.data.defaultMinStock) || 5
        });
      }
    } catch (err) {
      setSaveError(err.message || 'Failed to load store settings.');
    } finally {
      setLoading(false);
    }
  };

  const handleChange = (field, value) => {
    setFormData(prev => ({
      ...prev,
      [field]: value
    }));
  };

  const handleSave = async (e) => {
    if (e) e.preventDefault();
    setSaving(true);
    setSaveSuccess('');
    setSaveError('');

    try {
      const res = await api.updateSettings(formData);
      if (res.success) {
        setSaveSuccess('Store configurations and business rules updated successfully.');
        setTimeout(() => setSaveSuccess(''), 4000);
      }
    } catch (err) {
      setSaveError(err.message || 'Failed to update store settings.');
    } finally {
      setSaving(false);
    }
  };

  const tabs = [
    { id: 'general', label: 'Store Profile', icon: Store },
    { id: 'tax', label: 'Tax & GST', icon: Percent },
    { id: 'invoice', label: 'Invoicing & Receipts', icon: Receipt },
    { id: 'pos', label: 'POS & Checkout', icon: Sliders },
    { id: 'inventory', label: 'Inventory Rules', icon: Boxes }
  ];

  return (
    <div style={{ padding: '1.5rem', maxWidth: '1200px', margin: '0 auto' }}>
      {/* Title */}
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: '1.5rem', flexWrap: 'wrap', gap: '1rem' }}>
        <div>
          <h1 style={{ fontSize: '1.625rem', fontWeight: '700', color: 'var(--text-main)', margin: '0 0 0.25rem 0', letterSpacing: '-0.02em', display: 'flex', alignItems: 'center', gap: '0.625rem' }}>
            <Settings size={26} color="#7EAFD0" />
            Store Settings & Operational Rules
          </h1>
          <p style={{ margin: 0, fontSize: '0.875rem', color: 'var(--text-muted)' }}>
            Configure store metadata, tax rates, receipt formatting, checkout safeguards, and inventory controls.
          </p>
        </div>

        <Button
          variant="primary"
          onClick={handleSave}
          disabled={saving || loading}
          style={{ display: 'flex', alignItems: 'center', gap: '6px' }}
        >
          <Save size={16} />
          {saving ? 'Saving Changes...' : 'Save Settings'}
        </Button>
      </div>

      {saveSuccess && (
        <div style={{ padding: '0.75rem 1rem', backgroundColor: '#F0FDF4', border: '1px solid #86EFAC', borderRadius: 'var(--radius-md)', color: '#166534', marginBottom: '1.25rem', fontSize: '0.875rem', display: 'flex', alignItems: 'center', gap: '8px' }}>
          <CheckCircle2 size={16} /> {saveSuccess}
        </div>
      )}

      {saveError && (
        <div style={{ padding: '0.75rem 1rem', backgroundColor: '#FEF2F2', border: '1px solid #FCA5A5', borderRadius: 'var(--radius-md)', color: '#991B1B', marginBottom: '1.25rem', fontSize: '0.875rem', display: 'flex', alignItems: 'center', gap: '8px' }}>
          <AlertTriangle size={16} /> {saveError}
        </div>
      )}

      {/* Main Settings Grid */}
      <div style={{ display: 'grid', gridTemplateColumns: '240px 1fr', gap: '1.5rem', alignItems: 'start' }}>
        {/* Navigation Sidebar */}
        <Card style={{ padding: '0.5rem' }}>
          <nav style={{ display: 'flex', flexDirection: 'column', gap: '4px' }}>
            {tabs.map(tab => {
              const Icon = tab.icon;
              const isActive = activeTab === tab.id;
              return (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id)}
                  style={{
                    display: 'flex',
                    alignItems: 'center',
                    gap: '10px',
                    width: '100%',
                    padding: '10px 12px',
                    borderRadius: 'var(--radius-md)',
                    border: 'none',
                    background: isActive ? '#F0F9FF' : 'transparent',
                    color: isActive ? '#0369A1' : 'var(--text-main)',
                    fontWeight: isActive ? '600' : '500',
                    fontSize: '0.875rem',
                    cursor: 'pointer',
                    textAlign: 'left',
                    transition: 'all 0.15s ease'
                  }}
                >
                  <Icon size={18} color={isActive ? '#0284C7' : 'var(--text-muted)'} />
                  {tab.label}
                </button>
              );
            })}
          </nav>
        </Card>

        {/* Content Area */}
        <Card style={{ padding: '1.5rem' }}>
          {loading ? (
            <div style={{ padding: '3rem', textAlign: 'center', color: 'var(--text-muted)' }}>
              Loading store configurations...
            </div>
          ) : (
            <form onSubmit={handleSave}>
              {/* ── SECTION 1: GENERAL STORE PROFILE ────────────────────────── */}
              {activeTab === 'general' && (
                <div>
                  <h3 style={{ fontSize: '1.125rem', fontWeight: '600', color: 'var(--text-main)', margin: '0 0 1.25rem 0', borderBottom: '1px solid var(--border-color)', paddingBottom: '0.75rem' }}>
                    General Store Profile
                  </h3>

                  <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '1rem', marginBottom: '1rem' }}>
                    <div>
                      <label style={{ display: 'block', fontSize: '0.8125rem', fontWeight: '600', color: 'var(--text-main)', marginBottom: '4px' }}>
                        Store Trade Name *
                      </label>
                      <input
                        type="text"
                        value={formData.storeName}
                        onChange={(e) => handleChange('storeName', e.target.value)}
                        style={{ width: '100%', padding: '8px 12px', borderRadius: 'var(--radius-md)', border: '1px solid var(--border-color)', fontSize: '0.875rem' }}
                        required
                      />
                    </div>
                    <div>
                      <label style={{ display: 'block', fontSize: '0.8125rem', fontWeight: '600', color: 'var(--text-main)', marginBottom: '4px' }}>
                        Legal Business Name
                      </label>
                      <input
                        type="text"
                        placeholder="e.g. Westsides Apparel Retail LLP"
                        value={formData.legalBusinessName || ''}
                        onChange={(e) => handleChange('legalBusinessName', e.target.value)}
                        style={{ width: '100%', padding: '8px 12px', borderRadius: 'var(--radius-md)', border: '1px solid var(--border-color)', fontSize: '0.875rem' }}
                      />
                    </div>
                  </div>

                  <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '1rem', marginBottom: '1rem' }}>
                    <div>
                      <label style={{ display: 'block', fontSize: '0.8125rem', fontWeight: '600', color: 'var(--text-main)', marginBottom: '4px' }}>
                        Contact Phone
                      </label>
                      <input
                        type="tel"
                        placeholder="+91 98765 43210"
                        value={formData.phone || ''}
                        onChange={(e) => handleChange('phone', e.target.value)}
                        style={{ width: '100%', padding: '8px 12px', borderRadius: 'var(--radius-md)', border: '1px solid var(--border-color)', fontSize: '0.875rem' }}
                      />
                    </div>
                    <div>
                      <label style={{ display: 'block', fontSize: '0.8125rem', fontWeight: '600', color: 'var(--text-main)', marginBottom: '4px' }}>
                        Support Email
                      </label>
                      <input
                        type="email"
                        placeholder="store@westsides.com"
                        value={formData.email || ''}
                        onChange={(e) => handleChange('email', e.target.value)}
                        style={{ width: '100%', padding: '8px 12px', borderRadius: 'var(--radius-md)', border: '1px solid var(--border-color)', fontSize: '0.875rem' }}
                      />
                    </div>
                  </div>

                  <div style={{ marginBottom: '1rem' }}>
                    <label style={{ display: 'block', fontSize: '0.8125rem', fontWeight: '600', color: 'var(--text-main)', marginBottom: '4px' }}>
                      Storefront Address
                    </label>
                    <input
                      type="text"
                      placeholder="Shop #12, Fashion Boulevard, Commercial Street"
                      value={formData.address || ''}
                      onChange={(e) => handleChange('address', e.target.value)}
                      style={{ width: '100%', padding: '8px 12px', borderRadius: 'var(--radius-md)', border: '1px solid var(--border-color)', fontSize: '0.875rem' }}
                    />
                  </div>

                  <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: '1rem', marginBottom: '1rem' }}>
                    <div>
                      <label style={{ display: 'block', fontSize: '0.8125rem', fontWeight: '600', color: 'var(--text-main)', marginBottom: '4px' }}>
                        City
                      </label>
                      <input
                        type="text"
                        value={formData.city || ''}
                        onChange={(e) => handleChange('city', e.target.value)}
                        style={{ width: '100%', padding: '8px 12px', borderRadius: 'var(--radius-md)', border: '1px solid var(--border-color)', fontSize: '0.875rem' }}
                      />
                    </div>
                    <div>
                      <label style={{ display: 'block', fontSize: '0.8125rem', fontWeight: '600', color: 'var(--text-main)', marginBottom: '4px' }}>
                        State
                      </label>
                      <input
                        type="text"
                        value={formData.state || ''}
                        onChange={(e) => handleChange('state', e.target.value)}
                        style={{ width: '100%', padding: '8px 12px', borderRadius: 'var(--radius-md)', border: '1px solid var(--border-color)', fontSize: '0.875rem' }}
                      />
                    </div>
                    <div>
                      <label style={{ display: 'block', fontSize: '0.8125rem', fontWeight: '600', color: 'var(--text-main)', marginBottom: '4px' }}>
                        Postal Code
                      </label>
                      <input
                        type="text"
                        value={formData.postalCode || ''}
                        onChange={(e) => handleChange('postalCode', e.target.value)}
                        style={{ width: '100%', padding: '8px 12px', borderRadius: 'var(--radius-md)', border: '1px solid var(--border-color)', fontSize: '0.875rem' }}
                      />
                    </div>
                  </div>

                  <div style={{ marginBottom: '1rem' }}>
                    <label style={{ display: 'block', fontSize: '0.8125rem', fontWeight: '600', color: 'var(--text-main)', marginBottom: '4px' }}>
                      Business Description
                    </label>
                    <textarea
                      rows="2"
                      placeholder="Premium men's & women's urban lifestyle clothing and apparel store."
                      value={formData.description || ''}
                      onChange={(e) => handleChange('description', e.target.value)}
                      style={{ width: '100%', padding: '8px 12px', borderRadius: 'var(--radius-md)', border: '1px solid var(--border-color)', fontSize: '0.875rem', fontFamily: 'inherit' }}
                    />
                  </div>
                </div>
              )}

              {/* ── SECTION 2: TAX & GST ─────────────────────────────────────── */}
              {activeTab === 'tax' && (
                <div>
                  <h3 style={{ fontSize: '1.125rem', fontWeight: '600', color: 'var(--text-main)', margin: '0 0 1.25rem 0', borderBottom: '1px solid var(--border-color)', paddingBottom: '0.75rem' }}>
                    Tax & GST Configuration
                  </h3>

                  <div style={{ marginBottom: '1.5rem', backgroundColor: 'var(--bg-page)', padding: '1rem', borderRadius: 'var(--radius-md)', border: '1px solid var(--border-color)' }}>
                    <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
                      <div>
                        <div style={{ fontWeight: '600', color: 'var(--text-main)', fontSize: '0.9375rem' }}>Enable Tax Collection</div>
                        <div style={{ fontSize: '0.8125rem', color: 'var(--text-muted)' }}>Apply tax percentage automatically during POS checkout</div>
                      </div>
                      <input
                        type="checkbox"
                        checked={formData.taxEnabled}
                        onChange={(e) => handleChange('taxEnabled', e.target.checked)}
                        style={{ width: '20px', height: '20px', cursor: 'pointer' }}
                      />
                    </div>
                  </div>

                  <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '1rem', marginBottom: '1rem' }}>
                    <div>
                      <label style={{ display: 'block', fontSize: '0.8125rem', fontWeight: '600', color: 'var(--text-main)', marginBottom: '4px' }}>
                        Tax Name Label
                      </label>
                      <input
                        type="text"
                        placeholder="GST / VAT"
                        value={formData.taxName}
                        onChange={(e) => handleChange('taxName', e.target.value)}
                        style={{ width: '100%', padding: '8px 12px', borderRadius: 'var(--radius-md)', border: '1px solid var(--border-color)', fontSize: '0.875rem' }}
                      />
                    </div>
                    <div>
                      <label style={{ display: 'block', fontSize: '0.8125rem', fontWeight: '600', color: 'var(--text-main)', marginBottom: '4px' }}>
                        Default Tax Rate (%)
                      </label>
                      <input
                        type="number"
                        step="0.01"
                        min="0"
                        max="100"
                        value={formData.taxRate}
                        onChange={(e) => handleChange('taxRate', e.target.value)}
                        style={{ width: '100%', padding: '8px 12px', borderRadius: 'var(--radius-md)', border: '1px solid var(--border-color)', fontSize: '0.875rem' }}
                      />
                    </div>
                  </div>

                  <div style={{ marginBottom: '1rem' }}>
                    <label style={{ display: 'block', fontSize: '0.8125rem', fontWeight: '600', color: 'var(--text-main)', marginBottom: '4px' }}>
                      Business GST Identification Number (GSTIN)
                    </label>
                    <input
                      type="text"
                      placeholder="29AAAAA0000A1Z5"
                      value={formData.gstNumber || ''}
                      onChange={(e) => handleChange('gstNumber', e.target.value)}
                      style={{ width: '100%', padding: '8px 12px', borderRadius: 'var(--radius-md)', border: '1px solid var(--border-color)', fontSize: '0.875rem', textTransform: 'uppercase' }}
                    />
                    <span style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>
                      Printed on customer tax invoices. Changes will apply to future sales without rewriting historical records.
                    </span>
                  </div>
                </div>
              )}

              {/* ── SECTION 3: INVOICE & RECEIPTS ────────────────────────────── */}
              {activeTab === 'invoice' && (
                <div>
                  <h3 style={{ fontSize: '1.125rem', fontWeight: '600', color: 'var(--text-main)', margin: '0 0 1.25rem 0', borderBottom: '1px solid var(--border-color)', paddingBottom: '0.75rem' }}>
                    Invoicing & Customer Receipt Customization
                  </h3>

                  <div style={{ marginBottom: '1.25rem' }}>
                    <label style={{ display: 'block', fontSize: '0.8125rem', fontWeight: '600', color: 'var(--text-main)', marginBottom: '4px' }}>
                      Invoice Series Prefix *
                    </label>
                    <div style={{ display: 'flex', alignItems: 'center', gap: '0.75rem' }}>
                      <input
                        type="text"
                        maxLength="6"
                        value={formData.invoicePrefix}
                        onChange={(e) => handleChange('invoicePrefix', e.target.value.toUpperCase())}
                        style={{ width: '120px', padding: '8px 12px', borderRadius: 'var(--radius-md)', border: '1px solid var(--border-color)', fontSize: '0.875rem', fontWeight: '700', textTransform: 'uppercase' }}
                        required
                      />
                      <span style={{ fontSize: '0.8125rem', color: 'var(--text-muted)' }}>
                        Preview: <strong style={{ color: 'var(--text-main)' }}>{formData.invoicePrefix}-000001</strong>
                      </span>
                    </div>
                  </div>

                  <div style={{ marginBottom: '1.25rem' }}>
                    <label style={{ display: 'block', fontSize: '0.8125rem', fontWeight: '600', color: 'var(--text-main)', marginBottom: '4px' }}>
                      Receipt Return Policy Text
                    </label>
                    <textarea
                      rows="2"
                      value={formData.returnPolicy}
                      onChange={(e) => handleChange('returnPolicy', e.target.value)}
                      style={{ width: '100%', padding: '8px 12px', borderRadius: 'var(--radius-md)', border: '1px solid var(--border-color)', fontSize: '0.875rem', fontFamily: 'inherit' }}
                    />
                    <span style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>Printed in the receipt footer for customer notice.</span>
                  </div>

                  <div style={{ marginBottom: '1.25rem' }}>
                    <label style={{ display: 'block', fontSize: '0.8125rem', fontWeight: '600', color: 'var(--text-main)', marginBottom: '4px' }}>
                      Receipt Footer Note / Greeting
                    </label>
                    <input
                      type="text"
                      value={formData.footerNote}
                      onChange={(e) => handleChange('footerNote', e.target.value)}
                      style={{ width: '100%', padding: '8px 12px', borderRadius: 'var(--radius-md)', border: '1px solid var(--border-color)', fontSize: '0.875rem' }}
                    />
                  </div>
                </div>
              )}

              {/* ── SECTION 4: POS & CHECKOUT SAFEGUARDS ──────────────────────── */}
              {activeTab === 'pos' && (
                <div>
                  <h3 style={{ fontSize: '1.125rem', fontWeight: '600', color: 'var(--text-main)', margin: '0 0 1.25rem 0', borderBottom: '1px solid var(--border-color)', paddingBottom: '0.75rem' }}>
                    POS Checkout Safeguards & Business Rules
                  </h3>

                  <div style={{ display: 'flex', flexDirection: 'column', gap: '1rem', marginBottom: '1.5rem' }}>
                    {/* Allow Negative Stock */}
                    <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '1rem', backgroundColor: 'var(--bg-page)', borderRadius: 'var(--radius-md)', border: '1px solid var(--border-color)' }}>
                      <div>
                        <div style={{ fontWeight: '600', color: 'var(--text-main)', fontSize: '0.9375rem' }}>Allow Negative Stock Checkout</div>
                        <div style={{ fontSize: '0.8125rem', color: 'var(--text-muted)' }}>If disabled, cashiers cannot bill items with 0 available stock</div>
                      </div>
                      <input
                        type="checkbox"
                        checked={formData.allowNegativeInventory}
                        onChange={(e) => handleChange('allowNegativeInventory', e.target.checked)}
                        style={{ width: '18px', height: '18px', cursor: 'pointer' }}
                      />
                    </div>

                    {/* Require Customer for Sale */}
                    <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '1rem', backgroundColor: 'var(--bg-page)', borderRadius: 'var(--radius-md)', border: '1px solid var(--border-color)' }}>
                      <div>
                        <div style={{ fontWeight: '600', color: 'var(--text-main)', fontSize: '0.9375rem' }}>Mandatory Customer Selection</div>
                        <div style={{ fontSize: '0.8125rem', color: 'var(--text-muted)' }}>Require associating a customer before checkout can proceed</div>
                      </div>
                      <input
                        type="checkbox"
                        checked={formData.requireCustomerForSale}
                        onChange={(e) => handleChange('requireCustomerForSale', e.target.checked)}
                        style={{ width: '18px', height: '18px', cursor: 'pointer' }}
                      />
                    </div>

                    {/* Allow Discounts */}
                    <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '1rem', backgroundColor: 'var(--bg-page)', borderRadius: 'var(--radius-md)', border: '1px solid var(--border-color)' }}>
                      <div>
                        <div style={{ fontWeight: '600', color: 'var(--text-main)', fontSize: '0.9375rem' }}>Allow Cashier Discounts</div>
                        <div style={{ fontSize: '0.8125rem', color: 'var(--text-muted)' }}>Enable promotional discount inputs on the POS register</div>
                      </div>
                      <input
                        type="checkbox"
                        checked={formData.allowDiscounts}
                        onChange={(e) => handleChange('allowDiscounts', e.target.checked)}
                        style={{ width: '18px', height: '18px', cursor: 'pointer' }}
                      />
                    </div>
                  </div>

                  <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '1rem', marginBottom: '1rem' }}>
                    <div>
                      <label style={{ display: 'block', fontSize: '0.8125rem', fontWeight: '600', color: 'var(--text-main)', marginBottom: '4px' }}>
                        Maximum Discount Percentage (%)
                      </label>
                      <input
                        type="number"
                        min="0"
                        max="100"
                        value={formData.maxDiscountPercent}
                        onChange={(e) => handleChange('maxDiscountPercent', e.target.value)}
                        style={{ width: '100%', padding: '8px 12px', borderRadius: 'var(--radius-md)', border: '1px solid var(--border-color)', fontSize: '0.875rem' }}
                      />
                      <span style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>Backend validates and blocks discounts above this ceiling.</span>
                    </div>

                    <div>
                      <label style={{ display: 'block', fontSize: '0.8125rem', fontWeight: '600', color: 'var(--text-main)', marginBottom: '4px' }}>
                        Default Payment Method
                      </label>
                      <select
                        value={formData.defaultPaymentMethod}
                        onChange={(e) => handleChange('defaultPaymentMethod', e.target.value)}
                        style={{ width: '100%', padding: '8px 12px', borderRadius: 'var(--radius-md)', border: '1px solid var(--border-color)', fontSize: '0.875rem', backgroundColor: '#FFFFFF' }}
                      >
                        <option value="CASH">Cash</option>
                        <option value="UPI">UPI</option>
                        <option value="CARD">Card</option>
                      </select>
                    </div>
                  </div>
                </div>
              )}

              {/* ── SECTION 5: INVENTORY RULES ───────────────────────────────── */}
              {activeTab === 'inventory' && (
                <div>
                  <h3 style={{ fontSize: '1.125rem', fontWeight: '600', color: 'var(--text-main)', margin: '0 0 1.25rem 0', borderBottom: '1px solid var(--border-color)', paddingBottom: '0.75rem' }}>
                    Inventory Operational Thresholds & Alerts
                  </h3>

                  <div style={{ marginBottom: '1.5rem' }}>
                    <label style={{ display: 'block', fontSize: '0.8125rem', fontWeight: '600', color: 'var(--text-main)', marginBottom: '4px' }}>
                      Default Variant Minimum Stock Alert Threshold
                    </label>
                    <input
                      type="number"
                      min="0"
                      value={formData.defaultMinStock}
                      onChange={(e) => handleChange('defaultMinStock', e.target.value)}
                      style={{ width: '140px', padding: '8px 12px', borderRadius: 'var(--radius-md)', border: '1px solid var(--border-color)', fontSize: '0.875rem' }}
                    />
                    <span style={{ display: 'block', marginTop: '4px', fontSize: '0.75rem', color: 'var(--text-muted)' }}>
                      Default threshold assigned to new garment variants unless overridden individually.
                    </span>
                  </div>

                  <div style={{ display: 'flex', flexDirection: 'column', gap: '1rem' }}>
                    <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '1rem', backgroundColor: 'var(--bg-page)', borderRadius: 'var(--radius-md)', border: '1px solid var(--border-color)' }}>
                      <div>
                        <div style={{ fontWeight: '600', color: 'var(--text-main)', fontSize: '0.9375rem' }}>Generate Low-Stock Alerts</div>
                        <div style={{ fontSize: '0.8125rem', color: 'var(--text-muted)' }}>Notify store managers when stock level drops below minimum threshold</div>
                      </div>
                      <input
                        type="checkbox"
                        checked={formData.lowStockAlerts}
                        onChange={(e) => handleChange('lowStockAlerts', e.target.checked)}
                        style={{ width: '18px', height: '18px', cursor: 'pointer' }}
                      />
                    </div>

                    <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '1rem', backgroundColor: 'var(--bg-page)', borderRadius: 'var(--radius-md)', border: '1px solid var(--border-color)' }}>
                      <div>
                        <div style={{ fontWeight: '600', color: 'var(--text-main)', fontSize: '0.9375rem' }}>Generate Out-of-Stock Urgent Notices</div>
                        <div style={{ fontSize: '0.8125rem', color: 'var(--text-muted)' }}>Trigger critical notification when variant stock hits 0 units</div>
                      </div>
                      <input
                        type="checkbox"
                        checked={formData.outOfStockAlerts}
                        onChange={(e) => handleChange('outOfStockAlerts', e.target.checked)}
                        style={{ width: '18px', height: '18px', cursor: 'pointer' }}
                      />
                    </div>
                  </div>
                </div>
              )}

              {/* Submit footer */}
              <div style={{ marginTop: '2rem', paddingTop: '1.25rem', borderTop: '1px solid var(--border-color)', display: 'flex', justifyContent: 'flex-end', gap: '0.75rem' }}>
                <Button variant="outline" type="button" onClick={loadSettings} disabled={saving}>
                  Reset
                </Button>
                <Button variant="primary" type="submit" disabled={saving}>
                  {saving ? 'Saving...' : 'Save Settings'}
                </Button>
              </div>
            </form>
          )}
        </Card>
      </div>
    </div>
  );
}
