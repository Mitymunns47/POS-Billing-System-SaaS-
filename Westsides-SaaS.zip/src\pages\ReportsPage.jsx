import React, { useState, useEffect } from 'react';
import { api } from '../services/api';
import { Card, CardHeader, CardTitle, CardDescription, CardContent } from '../components/ui/Card';
import { Badge } from '../components/ui/Badge';
import { Button } from '../components/ui/Button';
import { Alert } from '../components/ui/Alert';
import { DateRangePicker } from '../components/reports/DateRangePicker';
import { SalesChart } from '../components/reports/Chart';
import { ExportButton } from '../components/reports/ExportButton';
import {
  TrendingUp,
  Receipt,
  Boxes,
  Users,
  ShieldCheck,
  IndianRupee,
  Wallet,
  AlertTriangle,
  ArrowRight,
  Shirt,
  Percent,
  Layers,
  Calendar,
  Info
} from 'lucide-react';

const fmt = (n) => Number(n || 0).toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 });

export function ReportsPage({ initialTab = 'sales', onNavigate }) {
  const [activeTab, setActiveTab] = useState(initialTab);
  const [dateFilter, setDateFilter] = useState({ range: 'last30days', startDate: '', endDate: '' });
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  // Tab specific data
  const [salesData, setSalesData] = useState(null);
  const [productData, setProductData] = useState(null);
  const [inventoryData, setInventoryData] = useState(null);
  const [customerData, setCustomerData] = useState(null);
  const [staffData, setStaffData] = useState(null);
  const [financeData, setFinanceData] = useState(null);

  // Sorting & sub-filters
  const [productSortBy, setProductSortBy] = useState('revenue');
  const [inventoryFilter, setInventoryFilter] = useState('ALL');

  useEffect(() => {
    setActiveTab(initialTab);
  }, [initialTab]);

  useEffect(() => {
    fetchReportData();
  }, [activeTab, dateFilter, productSortBy, inventoryFilter]);

  const fetchReportData = async () => {
    try {
      setLoading(true);
      setError(null);

      const params = {
        range: dateFilter.range,
        startDate: dateFilter.startDate,
        endDate: dateFilter.endDate
      };

      if (activeTab === 'sales') {
        const res = await api.getSalesReport(params);
        if (res.success) setSalesData(res);
      } else if (activeTab === 'products') {
        const res = await api.getProductsReport({ ...params, sortBy: productSortBy });
        if (res.success) setProductData(res);
      } else if (activeTab === 'inventory') {
        const res = await api.getInventoryReport({ statusFilter: inventoryFilter });
        if (res.success) setInventoryData(res);
      } else if (activeTab === 'customers') {
        const res = await api.getCustomersReport(params);
        if (res.success) setCustomerData(res);
      } else if (activeTab === 'staff') {
        const res = await api.getStaffPerformanceReport(params);
        if (res.success) setStaffData(res);
      } else if (activeTab === 'finance') {
        const res = await api.getFinanceReport(params);
        if (res.success) setFinanceData(res);
      }
    } catch (err) {
      console.error('Failed to load report:', err);
      setError(err.message || 'Could not load report data.');
    } finally {
      setLoading(false);
    }
  };

  const tabs = [
    { id: 'sales', label: 'Sales Analytics', icon: TrendingUp },
    { id: 'products', label: 'Products & Categories', icon: Shirt },
    { id: 'inventory', label: 'Inventory & Valuation', icon: Boxes },
    { id: 'customers', label: 'Customer Analytics', icon: Users },
    { id: 'staff', label: 'Staff Performance', icon: ShieldCheck },
    { id: 'finance', label: 'Financial Summary', icon: IndianRupee }
  ];

  return (
    <div style={{ maxWidth: '1200px', margin: '0 auto', display: 'flex', flexDirection: 'column', gap: '1.5rem' }} className="animate-fade-in">
      {/* Header */}
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', flexWrap: 'wrap', gap: '1rem' }}>
        <div>
          <h1 style={{ fontSize: '1.75rem', fontWeight: '700', color: 'var(--text-main)', margin: 0 }}>
            Business Intelligence & Reports
          </h1>
          <p style={{ fontSize: '0.9375rem', color: 'var(--text-muted)', marginTop: '4px', margin: 0 }}>
            Real-time analytics, revenue trends, inventory valuations, and financial summaries from store sales.
          </p>
        </div>

        <div style={{ display: 'flex', alignItems: 'center', gap: '10px', flexWrap: 'wrap' }}>
          <ExportButton
            type={activeTab === 'finance' ? 'sales' : activeTab}
            params={{
              range: dateFilter.range,
              startDate: dateFilter.startDate,
              endDate: dateFilter.endDate,
              statusFilter: inventoryFilter
            }}
            filename={`westsides-${activeTab}-report.csv`}
            label={`Export ${tabs.find(t => t.id === activeTab)?.label.split(' ')[0]} CSV`}
          />
        </div>
      </div>

      {/* Tabs Row */}
      <div
        style={{
          display: 'flex',
          gap: '8px',
          borderBottom: '1px solid var(--border-color)',
          overflowX: 'auto',
          paddingBottom: '4px'
        }}
      >
        {tabs.map((tab) => {
          const Icon = tab.icon;
          const isActive = activeTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => {
                setActiveTab(tab.id);
                if (onNavigate) onNavigate(`/reports/${tab.id}`);
              }}
              style={{
                display: 'flex',
                alignItems: 'center',
                gap: '8px',
                padding: '10px 16px',
                border: 'none',
                background: 'none',
                cursor: 'pointer',
                fontSize: '0.875rem',
                fontWeight: isActive ? '600' : '500',
                color: isActive ? '#4B7C9E' : 'var(--text-muted)',
                borderBottom: isActive ? '2px solid #7EAFD0' : '2px solid transparent',
                marginBottom: '-5px',
                whiteSpace: 'nowrap',
                transition: 'all 0.15s ease'
              }}
            >
              <Icon size={16} />
              {tab.label}
            </button>
          );
        })}
      </div>

      {/* Date Filter Bar (applicable to all tabs except inventory which is real-time current stock) */}
      {activeTab !== 'inventory' && (
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: '1rem', backgroundColor: '#FFFFFF', padding: '12px 16px', borderRadius: 'var(--radius-md)', border: '1px solid var(--border-color)' }}>
          <DateRangePicker
            range={dateFilter.range}
            startDate={dateFilter.startDate}
            endDate={dateFilter.endDate}
            onChange={(newFilter) => setDateFilter(newFilter)}
          />

          <div style={{ fontSize: '0.8125rem', color: 'var(--text-muted)' }}>
            Showing data for: <strong style={{ color: 'var(--text-main)' }}>{dateFilter.startDate ? `${dateFilter.startDate} to ${dateFilter.endDate}` : dateFilter.range.toUpperCase()}</strong>
          </div>
        </div>
      )}

      {error && (
        <Alert variant="danger" title="Reporting Error">
          {error}
        </Alert>
      )}

      {/* ────────────────────────────────────────────────────────────────────────── */}
      {/* 1. SALES ANALYTICS TAB */}
      {/* ────────────────────────────────────────────────────────────────────────── */}
      {activeTab === 'sales' && salesData && (
        <div style={{ display: 'flex', flexDirection: 'column', gap: '1.5rem' }}>
          {/* Top KPI row */}
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))', gap: '1rem' }}>
            <Card style={{ padding: '1.25rem' }}>
              <div style={{ fontSize: '0.8125rem', color: 'var(--text-muted)', fontWeight: '600' }}>Gross Sales</div>
              <div style={{ fontSize: '1.5rem', fontWeight: '800', color: 'var(--text-main)', marginTop: '4px' }}>
                ₹{fmt(salesData.summary?.grossSales)}
              </div>
              <div style={{ fontSize: '0.75rem', color: 'var(--text-muted)', marginTop: '4px' }}>
                Before discounts & taxes
              </div>
            </Card>

            <Card style={{ padding: '1.25rem' }}>
              <div style={{ fontSize: '0.8125rem', color: 'var(--text-muted)', fontWeight: '600' }}>Discounts Applied</div>
              <div style={{ fontSize: '1.5rem', fontWeight: '800', color: '#DC2626', marginTop: '4px' }}>
                -₹{fmt(salesData.summary?.discounts)}
              </div>
              <div style={{ fontSize: '0.75rem', color: 'var(--text-muted)', marginTop: '4px' }}>
                Promotional & bill discounts
              </div>
            </Card>

            <Card style={{ padding: '1.25rem' }}>
              <div style={{ fontSize: '0.8125rem', color: 'var(--text-muted)', fontWeight: '600' }}>Tax / GST Collected</div>
              <div style={{ fontSize: '1.5rem', fontWeight: '800', color: '#2563EB', marginTop: '4px' }}>
                ₹{fmt(salesData.summary?.tax)}
              </div>
              <div style={{ fontSize: '0.75rem', color: 'var(--text-muted)', marginTop: '4px' }}>
                Store tax liability
              </div>
            </Card>

            <Card style={{ padding: '1.25rem', borderLeft: '4px solid #7EAFD0' }}>
              <div style={{ fontSize: '0.8125rem', color: 'var(--text-muted)', fontWeight: '600' }}>Net Sales Revenue</div>
              <div style={{ fontSize: '1.5rem', fontWeight: '800', color: 'var(--text-main)', marginTop: '4px' }}>
                ₹{fmt(salesData.summary?.netSales)}
              </div>
              <div style={{ fontSize: '0.75rem', color: '#16A34A', fontWeight: '600', marginTop: '4px' }}>
                Total collected revenue
              </div>
            </Card>

            <Card style={{ padding: '1.25rem' }}>
              <div style={{ fontSize: '0.8125rem', color: 'var(--text-muted)', fontWeight: '600' }}>Completed Orders</div>
              <div style={{ fontSize: '1.5rem', fontWeight: '800', color: 'var(--text-main)', marginTop: '4px' }}>
                {salesData.summary?.orderCount}
              </div>
              <div style={{ fontSize: '0.75rem', color: 'var(--text-muted)', marginTop: '4px' }}>
                AOV: ₹{fmt(salesData.summary?.averageOrderValue)}
              </div>
            </Card>

            <Card style={{ padding: '1.25rem' }}>
              <div style={{ fontSize: '0.8125rem', color: 'var(--text-muted)', fontWeight: '600' }}>Items Sold</div>
              <div style={{ fontSize: '1.5rem', fontWeight: '800', color: 'var(--text-main)', marginTop: '4px' }}>
                {salesData.summary?.itemsSold}
              </div>
              <div style={{ fontSize: '0.75rem', color: 'var(--text-muted)', marginTop: '4px' }}>
                Pieces checked out
              </div>
            </Card>
          </div>

          {/* Sales Chart Section */}
          <Card>
            <CardHeader>
              <CardTitle style={{ fontSize: '1.0625rem' }}>Sales Revenue Over Time</CardTitle>
              <CardDescription>Daily revenue trends and completed bills across the selected period</CardDescription>
            </CardHeader>
            <CardContent>
              <SalesChart data={salesData.timeline} loading={loading} height={260} />
            </CardContent>
          </Card>

          {/* Payment Methods Breakdown */}
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(300px, 1fr))', gap: '1.25rem' }}>
            <Card>
              <CardHeader>
                <CardTitle style={{ fontSize: '1rem' }}>Payment Distribution</CardTitle>
                <CardDescription>Breakdown by tender type</CardDescription>
              </CardHeader>
              <CardContent>
                <div style={{ display: 'flex', flexDirection: 'column', gap: '1rem' }}>
                  {salesData.payments?.map((pm) => (
                    <div key={pm.method}>
                      <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '0.875rem', marginBottom: '4px' }}>
                        <span style={{ fontWeight: '600', color: 'var(--text-main)' }}>{pm.method}</span>
                        <span style={{ color: 'var(--text-muted)' }}>
                          ₹{fmt(pm.amount)} ({pm.percentage}%) • {pm.count} txns
                        </span>
                      </div>
                      <div style={{ width: '100%', height: '8px', backgroundColor: '#F1F5F9', borderRadius: '4px', overflow: 'hidden' }}>
                        <div
                          style={{
                            width: `${pm.percentage}%`,
                            height: '100%',
                            backgroundColor: pm.method === 'UPI' ? '#10B981' : pm.method === 'CARD' ? '#3B82F6' : '#7EAFD0',
                            borderRadius: '4px'
                          }}
                        />
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Formula Reference Card */}
            <Card style={{ backgroundColor: '#F8FAFC' }}>
              <CardHeader>
                <div style={{ display: 'flex', alignItems: 'center', gap: '6px' }}>
                  <Info size={16} color="#7EAFD0" />
                  <CardTitle style={{ fontSize: '0.9375rem' }}>Standard Accounting Definitions</CardTitle>
                </div>
              </CardHeader>
              <CardContent>
                <div style={{ display: 'flex', flexDirection: 'column', gap: '8px', fontSize: '0.8125rem', color: 'var(--text-muted)' }}>
                  <div><strong>Gross Sales:</strong> Sum of item line totals before discounts and tax.</div>
                  <div><strong>Net Sales:</strong> Gross Sales - Discounts + GST/Tax collected.</div>
                  <div><strong>Average Order Value (AOV):</strong> Net Sales ÷ Completed Orders.</div>
                  <div><strong>Valid Transactions:</strong> Only COMPLETED sales are counted. Cancelled sales are excluded.</div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      )}

      {/* ────────────────────────────────────────────────────────────────────────── */}
      {/* 2. PRODUCTS & CATEGORY PERFORMANCE TAB */}
      {/* ────────────────────────────────────────────────────────────────────────── */}
      {activeTab === 'products' && productData && (
        <div style={{ display: 'flex', flexDirection: 'column', gap: '1.5rem' }}>
          {/* Top Selling Products */}
          <Card>
            <CardHeader style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: '1rem' }}>
              <div>
                <CardTitle style={{ fontSize: '1.0625rem' }}>Top-Selling Products</CardTitle>
                <CardDescription>Product volume and revenue based on actual line item records</CardDescription>
              </div>

              <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                <span style={{ fontSize: '0.8125rem', color: 'var(--text-muted)' }}>Sort by:</span>
                <select
                  value={productSortBy}
                  onChange={(e) => setProductSortBy(e.target.value)}
                  style={{
                    padding: '4px 8px',
                    borderRadius: '6px',
                    border: '1px solid var(--border-color)',
                    fontSize: '0.8125rem',
                    color: 'var(--text-main)'
                  }}
                >
                  <option value="revenue">Highest Revenue</option>
                  <option value="units">Most Units Sold</option>
                </select>
              </div>
            </CardHeader>

            <CardContent style={{ padding: 0 }}>
              {productData.products?.length === 0 ? (
                <div style={{ padding: '2rem', textAlign: 'center', color: 'var(--text-muted)', fontSize: '0.875rem' }}>
                  No product sales in this period.
                </div>
              ) : (
                <div style={{ overflowX: 'auto' }}>
                  <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: '0.875rem' }}>
                    <thead>
                      <tr style={{ backgroundColor: '#F8FAFC', borderBottom: '1px solid var(--border-color)', textAlign: 'left' }}>
                        <th style={{ padding: '10px 16px', color: 'var(--text-muted)', fontWeight: '600' }}>Product</th>
                        <th style={{ padding: '10px 16px', color: 'var(--text-muted)', fontWeight: '600' }}>SKU</th>
                        <th style={{ padding: '10px 16px', color: 'var(--text-muted)', fontWeight: '600' }}>Category</th>
                        <th style={{ padding: '10px 16px', color: 'var(--text-muted)', fontWeight: '600', textAlign: 'right' }}>Units Sold</th>
                        <th style={{ padding: '10px 16px', color: 'var(--text-muted)', fontWeight: '600', textAlign: 'right' }}>Revenue</th>
                        <th style={{ padding: '10px 16px', color: 'var(--text-muted)', fontWeight: '600', textAlign: 'right' }}>Avg Price</th>
                      </tr>
                    </thead>
                    <tbody>
                      {productData.products?.map((p, idx) => (
                        <tr key={idx} style={{ borderBottom: '1px solid var(--border-color)' }}>
                          <td style={{ padding: '12px 16px', fontWeight: '600', color: 'var(--text-main)' }}>{p.productName}</td>
                          <td style={{ padding: '12px 16px', fontFamily: 'monospace', color: 'var(--text-muted)' }}>{p.sku || '—'}</td>
                          <td style={{ padding: '12px 16px', color: 'var(--text-muted)' }}>{p.categoryName || 'Uncategorized'}</td>
                          <td style={{ padding: '12px 16px', textAlign: 'right', fontWeight: '600' }}>{p.unitsSold}</td>
                          <td style={{ padding: '12px 16px', textAlign: 'right', fontWeight: '700', color: 'var(--text-main)' }}>₹{fmt(p.revenue)}</td>
                          <td style={{ padding: '12px 16px', textAlign: 'right', color: 'var(--text-muted)' }}>₹{fmt(p.avgSellingPrice)}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
            </CardContent>
          </Card>

          {/* Category Performance */}
          <Card>
            <CardHeader>
              <CardTitle style={{ fontSize: '1.0625rem' }}>Category Performance</CardTitle>
              <CardDescription>Sales distribution across apparel categories</CardDescription>
            </CardHeader>
            <CardContent style={{ padding: 0 }}>
              {productData.categories?.length === 0 ? (
                <div style={{ padding: '2rem', textAlign: 'center', color: 'var(--text-muted)', fontSize: '0.875rem' }}>
                  No category sales in this period.
                </div>
              ) : (
                <div style={{ overflowX: 'auto' }}>
                  <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: '0.875rem' }}>
                    <thead>
                      <tr style={{ backgroundColor: '#F8FAFC', borderBottom: '1px solid var(--border-color)', textAlign: 'left' }}>
                        <th style={{ padding: '10px 16px', color: 'var(--text-muted)', fontWeight: '600' }}>Category</th>
                        <th style={{ padding: '10px 16px', color: 'var(--text-muted)', fontWeight: '600', textAlign: 'right' }}>Units Sold</th>
                        <th style={{ padding: '10px 16px', color: 'var(--text-muted)', fontWeight: '600', textAlign: 'right' }}>Revenue</th>
                        <th style={{ padding: '10px 16px', color: 'var(--text-muted)', fontWeight: '600', width: '220px' }}>% of Total Sales</th>
                      </tr>
                    </thead>
                    <tbody>
                      {productData.categories?.map((c, idx) => (
                        <tr key={idx} style={{ borderBottom: '1px solid var(--border-color)' }}>
                          <td style={{ padding: '12px 16px', fontWeight: '600', color: 'var(--text-main)' }}>{c.categoryName}</td>
                          <td style={{ padding: '12px 16px', textAlign: 'right', fontWeight: '600' }}>{c.unitsSold}</td>
                          <td style={{ padding: '12px 16px', textAlign: 'right', fontWeight: '700', color: 'var(--text-main)' }}>₹{fmt(c.revenue)}</td>
                          <td style={{ padding: '12px 16px' }}>
                            <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                              <div style={{ flex: 1, height: '6px', backgroundColor: '#F1F5F9', borderRadius: '3px', overflow: 'hidden' }}>
                                <div style={{ width: `${c.percentage}%`, height: '100%', backgroundColor: '#7EAFD0' }} />
                              </div>
                              <span style={{ fontSize: '0.75rem', fontWeight: '600', width: '38px', textAlign: 'right' }}>{c.percentage}%</span>
                            </div>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      )}

      {/* ────────────────────────────────────────────────────────────────────────── */}
      {/* 3. INVENTORY ANALYTICS & VALUATION TAB */}
      {/* ────────────────────────────────────────────────────────────────────────── */}
      {activeTab === 'inventory' && inventoryData && (
        <div style={{ display: 'flex', flexDirection: 'column', gap: '1.5rem' }}>
          {/* Inventory KPIs */}
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))', gap: '1rem' }}>
            <Card style={{ padding: '1.25rem' }}>
              <div style={{ fontSize: '0.8125rem', color: 'var(--text-muted)', fontWeight: '600' }}>Catalog Items</div>
              <div style={{ fontSize: '1.5rem', fontWeight: '800', color: 'var(--text-main)', marginTop: '4px' }}>
                {inventoryData.summary?.totalProducts}
              </div>
              <div style={{ fontSize: '0.75rem', color: 'var(--text-muted)', marginTop: '4px' }}>
                Active product styles
              </div>
            </Card>

            <Card style={{ padding: '1.25rem' }}>
              <div style={{ fontSize: '0.8125rem', color: 'var(--text-muted)', fontWeight: '600' }}>Total Stock Units</div>
              <div style={{ fontSize: '1.5rem', fontWeight: '800', color: 'var(--text-main)', marginTop: '4px' }}>
                {inventoryData.summary?.totalStockUnits}
              </div>
              <div style={{ fontSize: '0.75rem', color: 'var(--text-muted)', marginTop: '4px' }}>
                Garment pieces in store
              </div>
            </Card>

            <Card style={{ padding: '1.25rem' }}>
              <div style={{ fontSize: '0.8125rem', color: 'var(--text-muted)', fontWeight: '600' }}>Low Stock Items</div>
              <div style={{ fontSize: '1.5rem', fontWeight: '800', color: (inventoryData.summary?.lowStockProducts > 0) ? '#D97706' : 'var(--text-main)', marginTop: '4px' }}>
                {inventoryData.summary?.lowStockProducts}
              </div>
              <div style={{ fontSize: '0.75rem', color: 'var(--text-muted)', marginTop: '4px' }}>
                Variants at/below threshold
              </div>
            </Card>

            <Card style={{ padding: '1.25rem' }}>
              <div style={{ fontSize: '0.8125rem', color: 'var(--text-muted)', fontWeight: '600' }}>Out of Stock</div>
              <div style={{ fontSize: '1.5rem', fontWeight: '800', color: (inventoryData.summary?.outOfStockProducts > 0) ? '#DC2626' : 'var(--text-main)', marginTop: '4px' }}>
                {inventoryData.summary?.outOfStockProducts}
              </div>
              <div style={{ fontSize: '0.75rem', color: 'var(--text-muted)', marginTop: '4px' }}>
                Zero inventory variants
              </div>
            </Card>

            <Card style={{ padding: '1.25rem', borderLeft: '4px solid #3B82F6' }}>
              <div style={{ fontSize: '0.8125rem', color: 'var(--text-muted)', fontWeight: '600' }}>Inventory Cost Valuation</div>
              <div style={{ fontSize: '1.5rem', fontWeight: '800', color: 'var(--text-main)', marginTop: '4px' }}>
                ₹{fmt(inventoryData.summary?.inventoryCostValue)}
              </div>
              <div style={{ fontSize: '0.75rem', color: 'var(--text-muted)', marginTop: '4px' }}>
                Current stock × cost price
              </div>
            </Card>

            <Card style={{ padding: '1.25rem', borderLeft: '4px solid #10B981' }}>
              <div style={{ fontSize: '0.8125rem', color: 'var(--text-muted)', fontWeight: '600' }}>Potential Retail Value</div>
              <div style={{ fontSize: '1.5rem', fontWeight: '800', color: 'var(--text-main)', marginTop: '4px' }}>
                ₹{fmt(inventoryData.summary?.potentialRetailValue)}
              </div>
              <div style={{ fontSize: '0.75rem', color: '#16A34A', fontWeight: '600', marginTop: '4px' }}>
                Current stock × retail price
              </div>
            </Card>
          </div>

          {/* Low Stock & Out-of-Stock Report */}
          <Card>
            <CardHeader style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: '1rem' }}>
              <div>
                <CardTitle style={{ fontSize: '1.0625rem' }}>Low Stock & Reorder Report</CardTitle>
                <CardDescription>Variants requiring replenishment based on minimum stock threshold</CardDescription>
              </div>

              <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                <span style={{ fontSize: '0.8125rem', color: 'var(--text-muted)' }}>Filter status:</span>
                <select
                  value={inventoryFilter}
                  onChange={(e) => setInventoryFilter(e.target.value)}
                  style={{
                    padding: '4px 8px',
                    borderRadius: '6px',
                    border: '1px solid var(--border-color)',
                    fontSize: '0.8125rem',
                    color: 'var(--text-main)'
                  }}
                >
                  <option value="ALL">All Items</option>
                  <option value="ALL_ALERTS">All Alerts (Low + Out)</option>
                  <option value="LOW_STOCK">Low Stock Only</option>
                  <option value="OUT_OF_STOCK">Out of Stock Only</option>
                </select>
              </div>
            </CardHeader>

            <CardContent style={{ padding: 0 }}>
              {inventoryData.lowStockItems?.length === 0 ? (
                <div style={{ padding: '2rem', textAlign: 'center', color: 'var(--text-muted)', fontSize: '0.875rem' }}>
                  All catalog inventory is currently healthy and above minimum thresholds.
                </div>
              ) : (
                <div style={{ overflowX: 'auto' }}>
                  <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: '0.875rem' }}>
                    <thead>
                      <tr style={{ backgroundColor: '#F8FAFC', borderBottom: '1px solid var(--border-color)', textAlign: 'left' }}>
                        <th style={{ padding: '10px 16px', color: 'var(--text-muted)', fontWeight: '600' }}>Product</th>
                        <th style={{ padding: '10px 16px', color: 'var(--text-muted)', fontWeight: '600' }}>SKU</th>
                        <th style={{ padding: '10px 16px', color: 'var(--text-muted)', fontWeight: '600' }}>Size / Color</th>
                        <th style={{ padding: '10px 16px', color: 'var(--text-muted)', fontWeight: '600', textAlign: 'right' }}>Current Stock</th>
                        <th style={{ padding: '10px 16px', color: 'var(--text-muted)', fontWeight: '600', textAlign: 'right' }}>Min Threshold</th>
                        <th style={{ padding: '10px 16px', color: 'var(--text-muted)', fontWeight: '600', textAlign: 'right' }}>Cost Price</th>
                        <th style={{ padding: '10px 16px', color: 'var(--text-muted)', fontWeight: '600' }}>Status</th>
                      </tr>
                    </thead>
                    <tbody>
                      {inventoryData.lowStockItems?.map((item, idx) => (
                        <tr key={idx} style={{ borderBottom: '1px solid var(--border-color)' }}>
                          <td style={{ padding: '12px 16px', fontWeight: '600', color: 'var(--text-main)' }}>{item.productName}</td>
                          <td style={{ padding: '12px 16px', fontFamily: 'monospace', color: 'var(--text-muted)' }}>{item.sku}</td>
                          <td style={{ padding: '12px 16px', color: 'var(--text-muted)' }}>{item.size || '—'} {item.color ? `• ${item.color}` : ''}</td>
                          <td style={{ padding: '12px 16px', textAlign: 'right', fontWeight: '700', color: item.currentStock === 0 ? '#DC2626' : item.currentStock <= item.minimumStock ? '#D97706' : 'var(--text-main)' }}>
                            {item.currentStock}
                          </td>
                          <td style={{ padding: '12px 16px', textAlign: 'right', color: 'var(--text-muted)' }}>{item.minimumStock}</td>
                          <td style={{ padding: '12px 16px', textAlign: 'right', color: 'var(--text-muted)' }}>₹{fmt(item.costPrice)}</td>
                          <td style={{ padding: '12px 16px' }}>
                            <Badge variant={item.status === 'OUT OF STOCK' ? 'danger' : item.status === 'LOW STOCK' ? 'warning' : 'success'} size="sm">
                              {item.status}
                            </Badge>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      )}

      {/* ────────────────────────────────────────────────────────────────────────── */}
      {/* 4. CUSTOMER ANALYTICS TAB */}
      {/* ────────────────────────────────────────────────────────────────────────── */}
      {activeTab === 'customers' && customerData && (
        <div style={{ display: 'flex', flexDirection: 'column', gap: '1.5rem' }}>
          {/* Top Customer Metrics */}
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))', gap: '1rem' }}>
            <Card style={{ padding: '1.25rem' }}>
              <div style={{ fontSize: '0.8125rem', color: 'var(--text-muted)', fontWeight: '600' }}>Total Customers</div>
              <div style={{ fontSize: '1.5rem', fontWeight: '800', color: 'var(--text-main)', marginTop: '4px' }}>
                {customerData.metrics?.totalCustomers}
              </div>
              <div style={{ fontSize: '0.75rem', color: 'var(--text-muted)', marginTop: '4px' }}>
                Active directory accounts
              </div>
            </Card>

            <Card style={{ padding: '1.25rem' }}>
              <div style={{ fontSize: '0.8125rem', color: 'var(--text-muted)', fontWeight: '600' }}>New Customers</div>
              <div style={{ fontSize: '1.5rem', fontWeight: '800', color: '#10B981', marginTop: '4px' }}>
                {customerData.metrics?.newCustomers}
              </div>
              <div style={{ fontSize: '0.75rem', color: 'var(--text-muted)', marginTop: '4px' }}>
                Registered in selected period
              </div>
            </Card>

            <Card style={{ padding: '1.25rem' }}>
              <div style={{ fontSize: '0.8125rem', color: 'var(--text-muted)', fontWeight: '600' }}>Returning Customers</div>
              <div style={{ fontSize: '1.5rem', fontWeight: '800', color: '#3B82F6', marginTop: '4px' }}>
                {customerData.metrics?.returningCustomers}
              </div>
              <div style={{ fontSize: '0.75rem', color: 'var(--text-muted)', marginTop: '4px' }}>
                Customers with &gt; 1 completed sale
              </div>
            </Card>

            <Card style={{ padding: '1.25rem' }}>
              <div style={{ fontSize: '0.8125rem', color: 'var(--text-muted)', fontWeight: '600' }}>Active Purchasers</div>
              <div style={{ fontSize: '1.5rem', fontWeight: '800', color: 'var(--text-main)', marginTop: '4px' }}>
                {customerData.metrics?.customersWithPurchases}
              </div>
              <div style={{ fontSize: '0.75rem', color: 'var(--text-muted)', marginTop: '4px' }}>
                Shopped in this period
              </div>
            </Card>

            <Card style={{ padding: '1.25rem' }}>
              <div style={{ fontSize: '0.8125rem', color: 'var(--text-muted)', fontWeight: '600' }}>Average Customer Spend</div>
              <div style={{ fontSize: '1.5rem', fontWeight: '800', color: 'var(--text-main)', marginTop: '4px' }}>
                ₹{fmt(customerData.metrics?.averageCustomerSpend)}
              </div>
              <div style={{ fontSize: '0.75rem', color: 'var(--text-muted)', marginTop: '4px' }}>
                Spend per active purchaser
              </div>
            </Card>
          </div>

          {/* Top Customers Table */}
          <Card>
            <CardHeader>
              <CardTitle style={{ fontSize: '1.0625rem' }}>Top Customers by Spend</CardTitle>
              <CardDescription>Customer purchase frequency and lifetime value in selected period</CardDescription>
            </CardHeader>
            <CardContent style={{ padding: 0 }}>
              {customerData.topCustomers?.length === 0 ? (
                <div style={{ padding: '2rem', textAlign: 'center', color: 'var(--text-muted)', fontSize: '0.875rem' }}>
                  No customer purchases recorded in this date range.
                </div>
              ) : (
                <div style={{ overflowX: 'auto' }}>
                  <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: '0.875rem' }}>
                    <thead>
                      <tr style={{ backgroundColor: '#F8FAFC', borderBottom: '1px solid var(--border-color)', textAlign: 'left' }}>
                        <th style={{ padding: '10px 16px', color: 'var(--text-muted)', fontWeight: '600' }}>Customer</th>
                        <th style={{ padding: '10px 16px', color: 'var(--text-muted)', fontWeight: '600' }}>Phone</th>
                        <th style={{ padding: '10px 16px', color: 'var(--text-muted)', fontWeight: '600' }}>Email</th>
                        <th style={{ padding: '10px 16px', color: 'var(--text-muted)', fontWeight: '600', textAlign: 'right' }}>Orders</th>
                        <th style={{ padding: '10px 16px', color: 'var(--text-muted)', fontWeight: '600', textAlign: 'right' }}>Total Spent</th>
                        <th style={{ padding: '10px 16px', color: 'var(--text-muted)', fontWeight: '600' }}>Last Purchase</th>
                        <th style={{ padding: '10px 16px', color: 'var(--text-muted)', textAlign: 'center' }}>Action</th>
                      </tr>
                    </thead>
                    <tbody>
                      {customerData.topCustomers?.map((c, idx) => (
                        <tr key={idx} style={{ borderBottom: '1px solid var(--border-color)' }}>
                          <td style={{ padding: '12px 16px', fontWeight: '600', color: 'var(--text-main)' }}>{c.customerName}</td>
                          <td style={{ padding: '12px 16px', color: 'var(--text-muted)' }}>{c.customerPhone || '—'}</td>
                          <td style={{ padding: '12px 16px', color: 'var(--text-muted)' }}>{c.customerEmail || '—'}</td>
                          <td style={{ padding: '12px 16px', textAlign: 'right', fontWeight: '600' }}>{c.orders}</td>
                          <td style={{ padding: '12px 16px', textAlign: 'right', fontWeight: '700', color: 'var(--text-main)' }}>₹{fmt(c.totalSpent)}</td>
                          <td style={{ padding: '12px 16px', color: 'var(--text-muted)', fontSize: '0.8125rem' }}>
                            {c.lastPurchaseDate ? new Date(c.lastPurchaseDate).toLocaleDateString() : '—'}
                          </td>
                          <td style={{ padding: '12px 16px', textAlign: 'center' }}>
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={() => onNavigate(`/customers/${c.customerId}`)}
                              style={{ display: 'inline-flex', alignItems: 'center', gap: '4px' }}
                            >
                              <span>View Profile</span>
                              <ArrowRight size={13} />
                            </Button>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      )}

      {/* ────────────────────────────────────────────────────────────────────────── */}
      {/* 5. STAFF PERFORMANCE TAB */}
      {/* ────────────────────────────────────────────────────────────────────────── */}
      {activeTab === 'staff' && staffData && (
        <div style={{ display: 'flex', flexDirection: 'column', gap: '1.5rem' }}>
          <Card>
            <CardHeader>
              <CardTitle style={{ fontSize: '1.0625rem' }}>Staff Transaction Performance</CardTitle>
              <CardDescription>Objective sales volume and completed bills processed per cashier</CardDescription>
            </CardHeader>
            <CardContent style={{ padding: 0 }}>
              {staffData.staff?.length === 0 ? (
                <div style={{ padding: '2rem', textAlign: 'center', color: 'var(--text-muted)', fontSize: '0.875rem' }}>
                  No staff members found for this store.
                </div>
              ) : (
                <div style={{ overflowX: 'auto' }}>
                  <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: '0.875rem' }}>
                    <thead>
                      <tr style={{ backgroundColor: '#F8FAFC', borderBottom: '1px solid var(--border-color)', textAlign: 'left' }}>
                        <th style={{ padding: '10px 16px', color: 'var(--text-muted)', fontWeight: '600' }}>Staff Member</th>
                        <th style={{ padding: '10px 16px', color: 'var(--text-muted)', fontWeight: '600' }}>Role</th>
                        <th style={{ padding: '10px 16px', color: 'var(--text-muted)', fontWeight: '600', textAlign: 'right' }}>Orders Completed</th>
                        <th style={{ padding: '10px 16px', color: 'var(--text-muted)', fontWeight: '600', textAlign: 'right' }}>Items Sold</th>
                        <th style={{ padding: '10px 16px', color: 'var(--text-muted)', fontWeight: '600', textAlign: 'right' }}>Sales Revenue</th>
                        <th style={{ padding: '10px 16px', color: 'var(--text-muted)', fontWeight: '600', textAlign: 'right' }}>Average Bill</th>
                        <th style={{ padding: '10px 16px', color: 'var(--text-muted)' }}>Last Sale</th>
                      </tr>
                    </thead>
                    <tbody>
                      {staffData.staff?.map((s, idx) => (
                        <tr key={idx} style={{ borderBottom: '1px solid var(--border-color)' }}>
                          <td style={{ padding: '12px 16px' }}>
                            <div style={{ fontWeight: '600', color: 'var(--text-main)' }}>{s.staffName}</div>
                            <div style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>{s.staffEmail}</div>
                          </td>
                          <td style={{ padding: '12px 16px' }}>
                            <Badge variant={s.staffRole === 'OWNER' ? 'primary' : s.staffRole === 'MANAGER' ? 'info' : 'neutral'} size="sm">
                              {s.staffRole}
                            </Badge>
                          </td>
                          <td style={{ padding: '12px 16px', textAlign: 'right', fontWeight: '600' }}>{s.ordersCompleted}</td>
                          <td style={{ padding: '12px 16px', textAlign: 'right', color: 'var(--text-muted)' }}>{s.itemsSold}</td>
                          <td style={{ padding: '12px 16px', textAlign: 'right', fontWeight: '700', color: 'var(--text-main)' }}>₹{fmt(s.salesAmount)}</td>
                          <td style={{ padding: '12px 16px', textAlign: 'right', color: 'var(--text-muted)' }}>₹{fmt(s.averageOrderValue)}</td>
                          <td style={{ padding: '12px 16px', color: 'var(--text-muted)', fontSize: '0.8125rem' }}>
                            {s.lastSaleDate ? new Date(s.lastSaleDate).toLocaleString() : 'No sales yet'}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      )}

      {/* ────────────────────────────────────────────────────────────────────────── */}
      {/* 6. FINANCIAL SUMMARY & MARGINS TAB */}
      {/* ────────────────────────────────────────────────────────────────────────── */}
      {activeTab === 'finance' && financeData && (
        <div style={{ display: 'flex', flexDirection: 'column', gap: '1.5rem' }}>
          {/* Financial Breakdown Grid */}
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(240px, 1fr))', gap: '1rem' }}>
            <Card style={{ padding: '1.25rem' }}>
              <div style={{ fontSize: '0.8125rem', color: 'var(--text-muted)', fontWeight: '600' }}>Net Product Sales</div>
              <div style={{ fontSize: '1.5rem', fontWeight: '800', color: 'var(--text-main)', marginTop: '4px' }}>
                ₹{fmt(financeData.metrics?.netProductSales)}
              </div>
              <div style={{ fontSize: '0.75rem', color: 'var(--text-muted)', marginTop: '4px' }}>
                Gross sales minus discounts (excl. tax)
              </div>
            </Card>

            <Card style={{ padding: '1.25rem' }}>
              <div style={{ fontSize: '0.8125rem', color: 'var(--text-muted)', fontWeight: '600' }}>Estimated Cost of Goods (COGS)</div>
              <div style={{ fontSize: '1.5rem', fontWeight: '800', color: '#D97706', marginTop: '4px' }}>
                ₹{fmt(financeData.metrics?.estimatedCOGS)}
              </div>
              <div style={{ fontSize: '0.75rem', color: 'var(--text-muted)', marginTop: '4px' }}>
                Sum of items sold × product cost price
              </div>
            </Card>

            <Card style={{ padding: '1.25rem', borderLeft: '4px solid #10B981' }}>
              <div style={{ fontSize: '0.8125rem', color: 'var(--text-muted)', fontWeight: '600' }}>Estimated Gross Profit</div>
              <div style={{ fontSize: '1.5rem', fontWeight: '800', color: '#16A34A', marginTop: '4px' }}>
                ₹{fmt(financeData.metrics?.estimatedGrossProfit)}
              </div>
              <div style={{ fontSize: '0.75rem', color: '#16A34A', fontWeight: '600', marginTop: '4px' }}>
                Net Product Sales - COGS
              </div>
            </Card>

            <Card style={{ padding: '1.25rem' }}>
              <div style={{ fontSize: '0.8125rem', color: 'var(--text-muted)', fontWeight: '600' }}>Gross Margin %</div>
              <div style={{ fontSize: '1.5rem', fontWeight: '800', color: 'var(--text-main)', marginTop: '4px' }}>
                {financeData.metrics?.grossMarginPercent}%
              </div>
              <div style={{ fontSize: '0.75rem', color: 'var(--text-muted)', marginTop: '4px' }}>
                (Estimated Gross Profit ÷ Net Sales)
              </div>
            </Card>

            <Card style={{ padding: '1.25rem' }}>
              <div style={{ fontSize: '0.8125rem', color: 'var(--text-muted)', fontWeight: '600' }}>Operating Expenses</div>
              <div style={{ fontSize: '1.5rem', fontWeight: '800', color: '#DC2626', marginTop: '4px' }}>
                ₹{fmt(financeData.metrics?.operatingExpenses)}
              </div>
              <div style={{ fontSize: '0.75rem', color: 'var(--text-muted)', marginTop: '4px' }}>
                Store expenses in this period
              </div>
            </Card>

            <Card style={{ padding: '1.25rem', borderLeft: '4px solid #7EAFD0' }}>
              <div style={{ fontSize: '0.8125rem', color: 'var(--text-muted)', fontWeight: '600' }}>Estimated Operating Result</div>
              <div style={{ fontSize: '1.5rem', fontWeight: '800', color: financeData.metrics?.estimatedOperatingResult >= 0 ? '#16A34A' : '#DC2626', marginTop: '4px' }}>
                ₹{fmt(financeData.metrics?.estimatedOperatingResult)}
              </div>
              <div style={{ fontSize: '0.75rem', color: 'var(--text-muted)', marginTop: '4px' }}>
                Gross Profit - Operating Expenses
              </div>
            </Card>
          </div>

          {financeData.metrics?.hasIncompleteCostData && (
            <Alert variant="warning" title="Incomplete Product Cost Data">
              {financeData.metrics.missingCostItems} sold line item(s) in this period have no recorded product cost price (cost = ₹0.00). The Cost of Goods Sold and Gross Profit calculations are labeled as estimates based on available cost data.
            </Alert>
          )}

          {/* Quick link to manage expenses */}
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', backgroundColor: '#FFFFFF', padding: '1rem 1.25rem', borderRadius: 'var(--radius-md)', border: '1px solid var(--border-color)' }}>
            <div>
              <div style={{ fontWeight: '600', color: 'var(--text-main)', fontSize: '0.9375rem' }}>Record Store Operating Expenses</div>
              <div style={{ fontSize: '0.8125rem', color: 'var(--text-muted)', marginTop: '2px' }}>
                Track rent, utilities, staff salaries, marketing, and store supplies to compute accurate net operating performance.
              </div>
            </div>
            <Button variant="primary" size="sm" onClick={() => onNavigate('/expenses')}>
              <Wallet size={15} style={{ marginRight: '6px' }} />
              Manage Expenses
            </Button>
          </div>
        </div>
      )}
    </div>
  );
}
