import React, { useState, useEffect } from 'react';
import { api } from '../services/api';
import { Card, CardHeader, CardTitle, CardDescription, CardContent } from '../components/ui/Card';
import { Badge } from '../components/ui/Badge';
import { Button } from '../components/ui/Button';
import { Alert } from '../components/ui/Alert';
import { ExportButton } from '../components/reports/ExportButton';
import {
  Wallet,
  Plus,
  Search,
  Filter,
  Calendar,
  IndianRupee,
  Archive,
  RefreshCw,
  Edit2,
  Trash2,
  Tag,
  CheckCircle2,
  X
} from 'lucide-react';

const fmt = (n) => Number(n || 0).toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 });

const CATEGORIES = [
  'Rent',
  'Utilities',
  'Salaries',
  'Marketing',
  'Maintenance',
  'Supplies',
  'Transport',
  'Other'
];

export function ExpensesPage() {
  const [expenses, setExpenses] = useState([]);
  const [totalAmount, setTotalAmount] = useState(0);
  const [pagination, setPagination] = useState({ total: 0, page: 1, limit: 20, totalPages: 1 });
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [successMsg, setSuccessMsg] = useState('');

  // Filters
  const [search, setSearch] = useState('');
  const [categoryFilter, setCategoryFilter] = useState('');
  const [statusFilter, setStatusFilter] = useState('ACTIVE');
  const [page, setPage] = useState(1);

  // Modal State
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingExpense, setEditingExpense] = useState(null);
  const [formData, setFormData] = useState({
    title: '',
    category: 'Rent',
    amount: '',
    date: new Date().toISOString().split('T')[0],
    paymentMethod: 'CASH',
    notes: ''
  });
  const [submitting, setSubmitting] = useState(false);

  useEffect(() => {
    fetchExpenses();
  }, [search, categoryFilter, statusFilter, page]);

  const fetchExpenses = async () => {
    try {
      setLoading(true);
      setError(null);

      const res = await api.getExpenses({
        search,
        category: categoryFilter,
        status: statusFilter,
        page,
        limit: 20
      });

      if (res.success) {
        setExpenses(res.expenses || []);
        setTotalAmount(res.totalAmount || 0);
        setPagination(res.pagination || { total: 0, page: 1, limit: 20, totalPages: 1 });
      }
    } catch (err) {
      console.error('Failed to load expenses:', err);
      setError(err.message || 'Could not load expenses.');
    } finally {
      setLoading(false);
    }
  };

  const handleOpenAddModal = () => {
    setEditingExpense(null);
    setFormData({
      title: '',
      category: 'Rent',
      amount: '',
      date: new Date().toISOString().split('T')[0],
      paymentMethod: 'CASH',
      notes: ''
    });
    setIsModalOpen(true);
  };

  const handleOpenEditModal = (exp) => {
    setEditingExpense(exp);
    setFormData({
      title: exp.title,
      category: exp.category,
      amount: exp.amount,
      date: exp.date,
      paymentMethod: exp.paymentMethod || 'CASH',
      notes: exp.notes || ''
    });
    setIsModalOpen(true);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!formData.title.trim()) {
      alert('Expense title is required.');
      return;
    }
    const num = Number(formData.amount);
    if (isNaN(num) || num <= 0) {
      alert('Please enter a valid positive amount.');
      return;
    }

    try {
      setSubmitting(true);
      if (editingExpense) {
        await api.updateExpense(editingExpense.id, formData);
        setSuccessMsg(`Expense "${formData.title}" updated successfully.`);
      } else {
        await api.createExpense(formData);
        setSuccessMsg(`Expense "${formData.title}" recorded successfully.`);
      }
      setIsModalOpen(false);
      fetchExpenses();
      setTimeout(() => setSuccessMsg(''), 4000);
    } catch (err) {
      alert(err.message || 'Operation failed.');
    } finally {
      setSubmitting(false);
    }
  };

  const handleArchive = async (id, title) => {
    if (!window.confirm(`Are you sure you want to archive expense "${title}"?`)) return;
    try {
      await api.archiveExpense(id);
      setSuccessMsg(`Expense "${title}" archived.`);
      fetchExpenses();
      setTimeout(() => setSuccessMsg(''), 3000);
    } catch (err) {
      alert(err.message || 'Could not archive expense.');
    }
  };

  const handleRestore = async (id, title) => {
    try {
      await api.restoreExpense(id);
      setSuccessMsg(`Expense "${title}" restored to active status.`);
      fetchExpenses();
      setTimeout(() => setSuccessMsg(''), 3000);
    } catch (err) {
      alert(err.message || 'Could not restore expense.');
    }
  };

  return (
    <div style={{ maxWidth: '1200px', margin: '0 auto', display: 'flex', flexDirection: 'column', gap: '1.5rem' }} className="animate-fade-in">
      {/* Header */}
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: '1rem' }}>
        <div>
          <h1 style={{ fontSize: '1.75rem', fontWeight: '700', color: 'var(--text-main)', margin: 0 }}>
            Operating Expenses
          </h1>
          <p style={{ fontSize: '0.9375rem', color: 'var(--text-muted)', marginTop: '4px', margin: 0 }}>
            Record store expenditures, rent, utilities, maintenance, and supplies.
          </p>
        </div>

        <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
          <ExportButton
            type="expenses"
            filename="westsides-expenses.csv"
            label="Export Expenses CSV"
          />
          <Button variant="primary" onClick={handleOpenAddModal} style={{ display: 'flex', alignItems: 'center', gap: '6px' }}>
            <Plus size={16} />
            <span>Record Expense</span>
          </Button>
        </div>
      </div>

      {successMsg && (
        <Alert variant="success" title="Success">
          {successMsg}
        </Alert>
      )}

      {error && (
        <Alert variant="danger" title="Error">
          {error}
        </Alert>
      )}

      {/* Top Total Amount Card */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(240px, 1fr))', gap: '1rem' }}>
        <Card style={{ padding: '1.25rem', borderLeft: '4px solid #7EAFD0' }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
            <span style={{ fontSize: '0.8125rem', fontWeight: '600', color: 'var(--text-muted)' }}>Total {statusFilter === 'ARCHIVED' ? 'Archived' : 'Active'} Expenses</span>
            <div style={{ padding: '6px', borderRadius: '6px', backgroundColor: '#F1F5F9', color: '#64748B' }}>
              <Wallet size={18} />
            </div>
          </div>
          <div style={{ fontSize: '1.75rem', fontWeight: '800', color: 'var(--text-main)', marginTop: '4px' }}>
            ₹{fmt(totalAmount)}
          </div>
          <div style={{ fontSize: '0.75rem', color: 'var(--text-muted)', marginTop: '4px' }}>
            Across {pagination.total} recorded expense item{pagination.total === 1 ? '' : 's'}
          </div>
        </Card>
      </div>

      {/* Filter and Tab Controls */}
      <Card style={{ padding: '1rem' }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: '1rem' }}>
          {/* Status Tabs */}
          <div style={{ display: 'flex', gap: '4px', backgroundColor: '#F1F5F9', padding: '4px', borderRadius: 'var(--radius-md)' }}>
            <button
              onClick={() => { setStatusFilter('ACTIVE'); setPage(1); }}
              style={{
                padding: '6px 14px',
                borderRadius: '6px',
                fontSize: '0.8125rem',
                fontWeight: statusFilter === 'ACTIVE' ? '600' : '500',
                border: 'none',
                cursor: 'pointer',
                backgroundColor: statusFilter === 'ACTIVE' ? '#FFFFFF' : 'transparent',
                color: statusFilter === 'ACTIVE' ? 'var(--text-main)' : 'var(--text-muted)',
                boxShadow: statusFilter === 'ACTIVE' ? 'var(--shadow-sm)' : 'none'
              }}
            >
              Active Expenses
            </button>
            <button
              onClick={() => { setStatusFilter('ARCHIVED'); setPage(1); }}
              style={{
                padding: '6px 14px',
                borderRadius: '6px',
                fontSize: '0.8125rem',
                fontWeight: statusFilter === 'ARCHIVED' ? '600' : '500',
                border: 'none',
                cursor: 'pointer',
                backgroundColor: statusFilter === 'ARCHIVED' ? '#FFFFFF' : 'transparent',
                color: statusFilter === 'ARCHIVED' ? 'var(--text-main)' : 'var(--text-muted)',
                boxShadow: statusFilter === 'ARCHIVED' ? 'var(--shadow-sm)' : 'none'
              }}
            >
              Archived
            </button>
          </div>

          {/* Search & Category Filter */}
          <div style={{ display: 'flex', alignItems: 'center', gap: '8px', flexWrap: 'wrap' }}>
            <div style={{ position: 'relative' }}>
              <Search size={15} style={{ position: 'absolute', left: '10px', top: '50%', transform: 'translateY(-50%)', color: 'var(--text-muted)' }} />
              <input
                type="text"
                placeholder="Search expense title, notes..."
                value={search}
                onChange={(e) => { setSearch(e.target.value); setPage(1); }}
                style={{
                  padding: '6px 10px 6px 32px',
                  borderRadius: '6px',
                  border: '1px solid var(--border-color)',
                  fontSize: '0.8125rem',
                  width: '220px'
                }}
              />
            </div>

            <select
              value={categoryFilter}
              onChange={(e) => { setCategoryFilter(e.target.value); setPage(1); }}
              style={{
                padding: '6px 10px',
                borderRadius: '6px',
                border: '1px solid var(--border-color)',
                fontSize: '0.8125rem',
                color: 'var(--text-main)'
              }}
            >
              <option value="">All Categories</option>
              {CATEGORIES.map(c => (
                <option key={c} value={c}>{c}</option>
              ))}
            </select>
          </div>
        </div>
      </Card>

      {/* Expenses Table */}
      <Card>
        <CardContent style={{ padding: 0 }}>
          {loading ? (
            <div style={{ padding: '3rem', textAlign: 'center', color: 'var(--text-muted)' }}>
              Loading expenses...
            </div>
          ) : expenses.length === 0 ? (
            <div style={{ padding: '3rem', textAlign: 'center', color: 'var(--text-muted)' }}>
              <Wallet size={36} color="#CBD5E1" style={{ marginBottom: '8px' }} />
              <div style={{ fontWeight: '600', color: 'var(--text-main)' }}>No expenses found</div>
              <div style={{ fontSize: '0.8125rem', marginTop: '2px' }}>
                {search || categoryFilter ? 'Try clearing your active filters.' : 'Record your first store expense using the button above.'}
              </div>
            </div>
          ) : (
            <div style={{ overflowX: 'auto' }}>
              <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: '0.875rem' }}>
                <thead>
                  <tr style={{ backgroundColor: '#F8FAFC', borderBottom: '1px solid var(--border-color)', textAlign: 'left' }}>
                    <th style={{ padding: '10px 16px', color: 'var(--text-muted)', fontWeight: '600' }}>Date</th>
                    <th style={{ padding: '10px 16px', color: 'var(--text-muted)', fontWeight: '600' }}>Expense Title</th>
                    <th style={{ padding: '10px 16px', color: 'var(--text-muted)', fontWeight: '600' }}>Category</th>
                    <th style={{ padding: '10px 16px', color: 'var(--text-muted)', fontWeight: '600', textAlign: 'right' }}>Amount</th>
                    <th style={{ padding: '10px 16px', color: 'var(--text-muted)', fontWeight: '600' }}>Payment</th>
                    <th style={{ padding: '10px 16px', color: 'var(--text-muted)', fontWeight: '600' }}>Recorded By</th>
                    <th style={{ padding: '10px 16px', color: 'var(--text-muted)', fontWeight: '600' }}>Notes</th>
                    <th style={{ padding: '10px 16px', color: 'var(--text-muted)', fontWeight: '600', textAlign: 'right' }}>Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {expenses.map((exp) => (
                    <tr key={exp.id} style={{ borderBottom: '1px solid var(--border-color)' }}>
                      <td style={{ padding: '12px 16px', whiteSpace: 'nowrap', color: 'var(--text-muted)' }}>{exp.date}</td>
                      <td style={{ padding: '12px 16px', fontWeight: '600', color: 'var(--text-main)' }}>{exp.title}</td>
                      <td style={{ padding: '12px 16px' }}>
                        <Badge variant="neutral" size="sm">{exp.category}</Badge>
                      </td>
                      <td style={{ padding: '12px 16px', textAlign: 'right', fontWeight: '700', color: 'var(--text-main)' }}>
                        ₹{fmt(exp.amount)}
                      </td>
                      <td style={{ padding: '12px 16px' }}>
                        <Badge variant="outline" size="sm">{exp.paymentMethod || 'CASH'}</Badge>
                      </td>
                      <td style={{ padding: '12px 16px', color: 'var(--text-muted)', fontSize: '0.8125rem' }}>{exp.createdBy}</td>
                      <td style={{ padding: '12px 16px', color: 'var(--text-muted)', fontSize: '0.8125rem', maxWidth: '200px', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                        {exp.notes || '—'}
                      </td>
                      <td style={{ padding: '12px 16px', textAlign: 'right' }}>
                        <div style={{ display: 'inline-flex', alignItems: 'center', gap: '6px' }}>
                          {statusFilter === 'ACTIVE' ? (
                            <>
                              <button
                                onClick={() => handleOpenEditModal(exp)}
                                title="Edit Expense"
                                style={{ padding: '4px', background: 'none', border: 'none', cursor: 'pointer', color: 'var(--text-muted)' }}
                              >
                                <Edit2 size={15} />
                              </button>
                              <button
                                onClick={() => handleArchive(exp.id, exp.title)}
                                title="Archive Expense"
                                style={{ padding: '4px', background: 'none', border: 'none', cursor: 'pointer', color: '#DC2626' }}
                              >
                                <Archive size={15} />
                              </button>
                            </>
                          ) : (
                            <button
                              onClick={() => handleRestore(exp.id, exp.title)}
                              title="Restore Expense"
                              style={{ padding: '4px 8px', borderRadius: '4px', border: '1px solid #7EAFD0', backgroundColor: '#F0F9FF', color: '#4B7C9E', cursor: 'pointer', fontSize: '0.75rem', fontWeight: '600' }}
                            >
                              Restore
                            </button>
                          )}
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Pagination Controls */}
      {pagination.totalPages > 1 && (
        <div style={{ display: 'flex', justifyContent: 'center', alignItems: 'center', gap: '8px' }}>
          <Button
            variant="outline"
            size="sm"
            onClick={() => setPage(p => Math.max(p - 1, 1))}
            disabled={page <= 1}
          >
            Previous
          </Button>
          <span style={{ fontSize: '0.8125rem', color: 'var(--text-muted)' }}>
            Page {pagination.page} of {pagination.totalPages}
          </span>
          <Button
            variant="outline"
            size="sm"
            onClick={() => setPage(p => Math.min(p + 1, pagination.totalPages))}
            disabled={page >= pagination.totalPages}
          >
            Next
          </Button>
        </div>
      )}

      {/* Add / Edit Expense Modal */}
      {isModalOpen && (
        <div
          style={{
            position: 'fixed',
            inset: 0,
            backgroundColor: 'rgba(23, 32, 51, 0.45)',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            zIndex: 1000,
            padding: '1rem'
          }}
        >
          <div
            style={{
              backgroundColor: '#FFFFFF',
              borderRadius: 'var(--radius-lg)',
              maxWidth: '480px',
              width: '100%',
              padding: '1.5rem',
              boxShadow: 'var(--shadow-lg)'
            }}
          >
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '1.25rem' }}>
              <h3 style={{ fontSize: '1.125rem', fontWeight: '700', color: 'var(--text-main)', margin: 0 }}>
                {editingExpense ? 'Edit Expense' : 'Record New Expense'}
              </h3>
              <button
                onClick={() => setIsModalOpen(false)}
                style={{ background: 'none', border: 'none', cursor: 'pointer', color: 'var(--text-muted)' }}
              >
                <X size={18} />
              </button>
            </div>

            <form onSubmit={handleSubmit} style={{ display: 'flex', flexDirection: 'column', gap: '1rem' }}>
              <div>
                <label style={{ display: 'block', fontSize: '0.8125rem', fontWeight: '600', color: 'var(--text-main)', marginBottom: '4px' }}>
                  Expense Title *
                </label>
                <input
                  type="text"
                  placeholder="e.g. October Store Rent, Electric Bill"
                  value={formData.title}
                  onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                  style={{
                    width: '100%',
                    padding: '8px 12px',
                    borderRadius: '6px',
                    border: '1px solid var(--border-color)',
                    fontSize: '0.875rem'
                  }}
                  required
                />
              </div>

              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '1rem' }}>
                <div>
                  <label style={{ display: 'block', fontSize: '0.8125rem', fontWeight: '600', color: 'var(--text-main)', marginBottom: '4px' }}>
                    Category *
                  </label>
                  <select
                    value={formData.category}
                    onChange={(e) => setFormData({ ...formData, category: e.target.value })}
                    style={{
                      width: '100%',
                      padding: '8px 12px',
                      borderRadius: '6px',
                      border: '1px solid var(--border-color)',
                      fontSize: '0.875rem',
                      color: 'var(--text-main)'
                    }}
                  >
                    {CATEGORIES.map(c => (
                      <option key={c} value={c}>{c}</option>
                    ))}
                  </select>
                </div>

                <div>
                  <label style={{ display: 'block', fontSize: '0.8125rem', fontWeight: '600', color: 'var(--text-main)', marginBottom: '4px' }}>
                    Amount (₹) *
                  </label>
                  <input
                    type="number"
                    step="0.01"
                    min="0"
                    placeholder="0.00"
                    value={formData.amount}
                    onChange={(e) => setFormData({ ...formData, amount: e.target.value })}
                    style={{
                      width: '100%',
                      padding: '8px 12px',
                      borderRadius: '6px',
                      border: '1px solid var(--border-color)',
                      fontSize: '0.875rem'
                    }}
                    required
                  />
                </div>
              </div>

              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '1rem' }}>
                <div>
                  <label style={{ display: 'block', fontSize: '0.8125rem', fontWeight: '600', color: 'var(--text-main)', marginBottom: '4px' }}>
                    Date *
                  </label>
                  <input
                    type="date"
                    value={formData.date}
                    onChange={(e) => setFormData({ ...formData, date: e.target.value })}
                    style={{
                      width: '100%',
                      padding: '8px 12px',
                      borderRadius: '6px',
                      border: '1px solid var(--border-color)',
                      fontSize: '0.875rem'
                    }}
                    required
                  />
                </div>

                <div>
                  <label style={{ display: 'block', fontSize: '0.8125rem', fontWeight: '600', color: 'var(--text-main)', marginBottom: '4px' }}>
                    Payment Method *
                  </label>
                  <select
                    value={formData.paymentMethod}
                    onChange={(e) => setFormData({ ...formData, paymentMethod: e.target.value })}
                    style={{
                      width: '100%',
                      padding: '8px 12px',
                      borderRadius: '6px',
                      border: '1px solid var(--border-color)',
                      fontSize: '0.875rem',
                      backgroundColor: '#FFFFFF'
                    }}
                  >
                    <option value="CASH">Cash</option>
                    <option value="UPI">UPI</option>
                    <option value="CARD">Card</option>
                    <option value="BANK_TRANSFER">Bank Transfer</option>
                    <option value="OTHER">Other</option>
                  </select>
                </div>
              </div>

              <div>
                <label style={{ display: 'block', fontSize: '0.8125rem', fontWeight: '600', color: 'var(--text-main)', marginBottom: '4px' }}>
                  Notes / Reference
                </label>
                <textarea
                  placeholder="Optional details, invoice #, payee details..."
                  rows={2}
                  value={formData.notes}
                  onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
                  style={{
                    width: '100%',
                    padding: '8px 12px',
                    borderRadius: '6px',
                    border: '1px solid var(--border-color)',
                    fontSize: '0.875rem',
                    resize: 'vertical'
                  }}
                />
              </div>

              <div style={{ display: 'flex', justifyContent: 'flex-end', gap: '8px', marginTop: '0.5rem' }}>
                <Button type="button" variant="outline" onClick={() => setIsModalOpen(false)}>
                  Cancel
                </Button>
                <Button type="submit" variant="primary" isLoading={submitting}>
                  {editingExpense ? 'Save Changes' : 'Record Expense'}
                </Button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
