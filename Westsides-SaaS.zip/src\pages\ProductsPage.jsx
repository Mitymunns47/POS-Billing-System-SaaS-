import React, { useState, useEffect, useCallback } from 'react';
import { api } from '../services/api';
import { Button } from '../components/ui/Button';
import { Input } from '../components/ui/Input';
import { Select } from '../components/ui/Select';
import { Badge } from '../components/ui/Badge';
import { Alert } from '../components/ui/Alert';
import { Modal } from '../components/ui/Modal';
import {
  Plus, Search, RefreshCw, Edit2, Trash2, ChevronLeft, ChevronRight,
  Package, X, Tag, Layers, AlertTriangle
} from 'lucide-react';

// ── Stock status badge ────────────────────────────────────────────────────────
function StockBadge({ status }) {
  const map = {
    IN_STOCK: { variant: 'success', label: 'In Stock' },
    LOW_STOCK: { variant: 'warning', label: 'Low Stock' },
    OUT_OF_STOCK: { variant: 'danger', label: 'Out of Stock' }
  };
  const { variant, label } = map[status] || { variant: 'neutral', label: 'Unknown' };
  return <Badge variant={variant} size="sm">{label}</Badge>;
}

// ── Variant row editor ────────────────────────────────────────────────────────
const DEFAULT_VARIANT = { size: '', color: '', sku: '', barcode: '', price: '', stock: 0, minimumStock: 0 };
const SIZES = ['XS', 'S', 'M', 'L', 'XL', 'XXL', 'XXXL', 'Free Size', 'Custom'];
const COLORS = ['Black', 'White', 'Red', 'Blue', 'Green', 'Navy', 'Grey', 'Brown', 'Yellow', 'Pink', 'Orange', 'Custom'];

function VariantEditor({ variants, onChange }) {
  const add = () => onChange([...variants, { ...DEFAULT_VARIANT, id: `tmp_${Date.now()}` }]);
  const remove = (idx) => onChange(variants.filter((_, i) => i !== idx));
  const update = (idx, field, val) => onChange(variants.map((v, i) => i === idx ? { ...v, [field]: val } : v));

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '12px' }}>
      {variants.map((v, idx) => (
        <div key={v.id || idx} style={{
          border: '1px solid var(--border-color)', borderRadius: 'var(--radius-md)',
          padding: '1rem', backgroundColor: 'var(--bg-page)', position: 'relative'
        }}>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(140px, 1fr))', gap: '10px' }}>
            <div style={{ display: 'flex', flexDirection: 'column', gap: '5px' }}>
              <label style={{ fontSize: '0.75rem', fontWeight: '500', color: 'var(--text-muted)' }}>Size</label>
              <select value={v.size} onChange={e => update(idx, 'size', e.target.value)} style={selectSx}>
                <option value="">—</option>
                {SIZES.map(s => <option key={s} value={s}>{s}</option>)}
              </select>
            </div>
            <div style={{ display: 'flex', flexDirection: 'column', gap: '5px' }}>
              <label style={{ fontSize: '0.75rem', fontWeight: '500', color: 'var(--text-muted)' }}>Color</label>
              <select value={v.color} onChange={e => update(idx, 'color', e.target.value)} style={selectSx}>
                <option value="">—</option>
                {COLORS.map(c => <option key={c} value={c}>{c}</option>)}
              </select>
            </div>
            <div style={{ display: 'flex', flexDirection: 'column', gap: '5px' }}>
              <label style={{ fontSize: '0.75rem', fontWeight: '500', color: 'var(--text-muted)' }}>SKU</label>
              <input style={inputSx} value={v.sku} onChange={e => update(idx, 'sku', e.target.value)} placeholder="Optional" />
            </div>
            <div style={{ display: 'flex', flexDirection: 'column', gap: '5px' }}>
              <label style={{ fontSize: '0.75rem', fontWeight: '500', color: 'var(--text-muted)' }}>Barcode</label>
              <input style={inputSx} value={v.barcode} onChange={e => update(idx, 'barcode', e.target.value)} placeholder="Optional" />
            </div>
            <div style={{ display: 'flex', flexDirection: 'column', gap: '5px' }}>
              <label style={{ fontSize: '0.75rem', fontWeight: '500', color: 'var(--text-muted)' }}>Price (₹)</label>
              <input style={inputSx} type="number" min="0" value={v.price} onChange={e => update(idx, 'price', e.target.value)} placeholder="Override" />
            </div>
            <div style={{ display: 'flex', flexDirection: 'column', gap: '5px' }}>
              <label style={{ fontSize: '0.75rem', fontWeight: '500', color: 'var(--text-muted)' }}>Stock Qty</label>
              <input style={inputSx} type="number" min="0" value={v.stock} onChange={e => update(idx, 'stock', parseInt(e.target.value) || 0)} />
            </div>
            <div style={{ display: 'flex', flexDirection: 'column', gap: '5px' }}>
              <label style={{ fontSize: '0.75rem', fontWeight: '500', color: 'var(--text-muted)' }}>Min Stock</label>
              <input style={inputSx} type="number" min="0" value={v.minimumStock} onChange={e => update(idx, 'minimumStock', parseInt(e.target.value) || 0)} />
            </div>
          </div>
          <button
            type="button" onClick={() => remove(idx)}
            style={{ position: 'absolute', top: '8px', right: '8px', background: 'none', border: 'none', cursor: 'pointer', color: 'var(--danger)', padding: '2px' }}
          ><X size={14} /></button>
        </div>
      ))}
      <Button type="button" variant="secondary" size="sm" onClick={add}>
        <Plus size={14} style={{ marginRight: '4px' }} /> Add Variant
      </Button>
    </div>
  );
}

const selectSx = {
  padding: '7px 10px', borderRadius: '6px', border: '1px solid var(--border-color)',
  fontSize: '0.8125rem', color: 'var(--text-main)', backgroundColor: '#fff', width: '100%', outline: 'none'
};
const inputSx = {
  padding: '7px 10px', borderRadius: '6px', border: '1px solid var(--border-color)',
  fontSize: '0.8125rem', color: 'var(--text-main)', backgroundColor: '#fff', width: '100%', outline: 'none', fontFamily: 'inherit'
};

// ── Product Form ──────────────────────────────────────────────────────────────
function ProductForm({ initial, categories, brands, onSave, onCancel, isLoading }) {
  const empty = {
    name: '', sku: '', categoryId: '', brandId: '', description: '',
    costPrice: '', mrp: '', sellingPrice: '', barcode: '', minimumStock: 0,
    variants: []
  };

  const [form, setForm] = useState(initial ? {
    name: initial.name || '',
    sku: initial.sku || '',
    categoryId: initial.categoryId || '',
    brandId: initial.brandId || '',
    description: initial.description || '',
    costPrice: initial.costPrice || '',
    mrp: initial.mrp || '',
    sellingPrice: initial.sellingPrice || '',
    barcode: initial.barcode || '',
    minimumStock: initial.minimumStock || 0,
    variants: initial.variants || []
  } : empty);

  const set = (field) => (e) => setForm(prev => ({ ...prev, [field]: e.target.value }));

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '1.5rem' }}>
      {/* Basic Information */}
      <section>
        <div style={{ fontSize: '0.75rem', fontWeight: '700', color: 'var(--text-muted)', textTransform: 'uppercase', letterSpacing: '0.05em', marginBottom: '0.875rem' }}>
          Basic Information
        </div>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(220px, 1fr))', gap: '1rem' }}>
          <Input label="Product Name" id="pf-name" value={form.name} onChange={set('name')} required placeholder="e.g. Classic Oversized T-Shirt" />
          <Input label="SKU" id="pf-sku" value={form.sku} onChange={set('sku')} required placeholder="e.g. TSH-BLK-001" helperText="Unique identifier within your store." />
          <Select label="Category" id="pf-category" value={form.categoryId} onChange={set('categoryId')}>
            <option value="">— No Category —</option>
            {categories.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
          </Select>
          <Select label="Brand" id="pf-brand" value={form.brandId} onChange={set('brandId')}>
            <option value="">— No Brand —</option>
            {brands.map(b => <option key={b.id} value={b.id}>{b.name}</option>)}
          </Select>
          <div style={{ gridColumn: '1 / -1' }}>
            <div style={{ display: 'flex', flexDirection: 'column', gap: '6px' }}>
              <label style={{ fontSize: '0.875rem', fontWeight: '500', color: 'var(--text-main)' }}>Description</label>
              <textarea
                value={form.description}
                onChange={set('description')}
                rows={2}
                placeholder="Brief product description (optional)"
                style={{ ...inputSx, resize: 'vertical' }}
              />
            </div>
          </div>
        </div>
      </section>

      {/* Pricing */}
      <section>
        <div style={{ fontSize: '0.75rem', fontWeight: '700', color: 'var(--text-muted)', textTransform: 'uppercase', letterSpacing: '0.05em', marginBottom: '0.875rem' }}>
          Pricing
        </div>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(160px, 1fr))', gap: '1rem' }}>
          <Input label="Cost Price (₹)" id="pf-cost" type="number" min="0" value={form.costPrice} onChange={set('costPrice')} placeholder="0.00" />
          <Input label="MRP (₹)" id="pf-mrp" type="number" min="0" value={form.mrp} onChange={set('mrp')} placeholder="0.00" />
          <Input label="Selling Price (₹)" id="pf-price" type="number" min="0" value={form.sellingPrice} onChange={set('sellingPrice')} required placeholder="0.00" />
        </div>
      </section>

      {/* Inventory */}
      <section>
        <div style={{ fontSize: '0.75rem', fontWeight: '700', color: 'var(--text-muted)', textTransform: 'uppercase', letterSpacing: '0.05em', marginBottom: '0.875rem' }}>
          Inventory & Barcode
        </div>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(180px, 1fr))', gap: '1rem' }}>
          <Input label="Product Barcode" id="pf-barcode" value={form.barcode} onChange={set('barcode')} placeholder="Optional EAN/UPC barcode" />
          <Input label="Minimum Stock Level" id="pf-minstock" type="number" min="0" value={form.minimumStock} onChange={set('minimumStock')} helperText="Alert threshold for low stock." />
        </div>
      </section>

      {/* Variants */}
      <section>
        <div style={{ fontSize: '0.75rem', fontWeight: '700', color: 'var(--text-muted)', textTransform: 'uppercase', letterSpacing: '0.05em', marginBottom: '0.875rem' }}>
          Product Variants (Sizes & Colors)
        </div>
        <VariantEditor variants={form.variants} onChange={(v) => setForm(prev => ({ ...prev, variants: v }))} />
      </section>

      {/* Actions */}
      <div style={{ display: 'flex', justifyContent: 'flex-end', gap: '0.75rem', paddingTop: '0.5rem', borderTop: '1px solid var(--border-subtle)' }}>
        <Button type="button" variant="secondary" size="md" onClick={onCancel} disabled={isLoading}>Cancel</Button>
        <Button type="button" variant="primary" size="md" isLoading={isLoading}
          onClick={() => onSave(form)}>
          {initial ? 'Save Changes' : 'Save Product'}
        </Button>
      </div>
    </div>
  );
}

// ── Delete Confirm Modal ──────────────────────────────────────────────────────
function DeleteConfirmModal({ product, onConfirm, onCancel, isLoading }) {
  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '1rem' }}>
      <div style={{ display: 'flex', gap: '12px', alignItems: 'flex-start' }}>
        <div style={{ padding: '10px', borderRadius: '8px', backgroundColor: 'var(--danger-light)', color: 'var(--danger)', flexShrink: 0 }}>
          <AlertTriangle size={20} />
        </div>
        <div>
          <p style={{ fontSize: '0.9375rem', color: 'var(--text-main)', marginBottom: '6px' }}>
            Are you sure you want to archive <strong>"{product?.name}"</strong>?
          </p>
          <p style={{ fontSize: '0.8125rem', color: 'var(--text-muted)', lineHeight: '1.5' }}>
            The product will be archived (soft deleted). Historical inventory and transaction records will be preserved for reporting in future phases.
          </p>
        </div>
      </div>
      <div style={{ display: 'flex', justifyContent: 'flex-end', gap: '0.75rem' }}>
        <Button variant="secondary" size="md" onClick={onCancel} disabled={isLoading}>Cancel</Button>
        <Button variant="danger" size="md" isLoading={isLoading} onClick={onConfirm}>Archive Product</Button>
      </div>
    </div>
  );
}

// ── Main Products Page ────────────────────────────────────────────────────────
export function ProductsPage({ onNavigate }) {
  const [products, setProducts] = useState([]);
  const [categories, setCategories] = useState([]);
  const [brands, setBrands] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [alert, setAlert] = useState(null);

  // Filters
  const [search, setSearch] = useState('');
  const [filterCategory, setFilterCategory] = useState('');
  const [filterBrand, setFilterBrand] = useState('');
  const [filterStatus, setFilterStatus] = useState('');
  const [page, setPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);
  const [total, setTotal] = useState(0);

  // Modals
  const [showForm, setShowForm] = useState(false);
  const [editProduct, setEditProduct] = useState(null);
  const [deleteProduct, setDeleteProduct] = useState(null);
  const [savingProduct, setSavingProduct] = useState(false);
  const [deletingProduct, setDeletingProduct] = useState(false);

  const loadData = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const [catRes, brandRes, prodRes] = await Promise.all([
        api.getCategories(),
        api.getBrands(),
        api.getProducts({ search, categoryId: filterCategory, brandId: filterBrand, status: filterStatus, page, limit: 20 })
      ]);
      if (catRes.success) setCategories(catRes.categories || []);
      if (brandRes.success) setBrands(brandRes.brands || []);
      if (prodRes.success) {
        setProducts(prodRes.products || []);
        setTotalPages(prodRes.totalPages || 1);
        setTotal(prodRes.total || 0);
      }
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  }, [search, filterCategory, filterBrand, filterStatus, page]);

  useEffect(() => { loadData(); }, [loadData]);

  const handleSaveProduct = async (form) => {
    setSavingProduct(true);
    setAlert(null);
    try {
      if (!form.name?.trim()) throw new Error('Product name is required.');
      if (!form.sku?.trim()) throw new Error('SKU is required.');
      if (form.sellingPrice === '' || form.sellingPrice === undefined) throw new Error('Selling price is required.');

      let res;
      if (editProduct) {
        res = await api.updateProduct(editProduct.id, form);
      } else {
        res = await api.createProduct(form);
      }
      if (res.success) {
        setAlert({ variant: 'success', message: res.message });
        setShowForm(false);
        setEditProduct(null);
        loadData();
      }
    } catch (err) {
      setAlert({ variant: 'danger', message: err.message });
    } finally {
      setSavingProduct(false);
    }
  };

  const handleDelete = async () => {
    if (!deleteProduct) return;
    setDeletingProduct(true);
    try {
      const res = await api.deleteProduct(deleteProduct.id);
      if (res.success) {
        setAlert({ variant: 'success', message: res.message });
        setDeleteProduct(null);
        loadData();
      }
    } catch (err) {
      setAlert({ variant: 'danger', message: err.message });
    } finally {
      setDeletingProduct(false);
    }
  };

  return (
    <div style={{ maxWidth: '1200px', margin: '0 auto' }} className="animate-fade-in">
      {/* Header */}
      <div style={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', marginBottom: '1.5rem', flexWrap: 'wrap', gap: '1rem' }}>
        <div>
          <h1 style={{ fontSize: '1.5rem', fontWeight: '700', color: 'var(--text-main)', margin: '0 0 4px 0' }}>Products</h1>
          <p style={{ fontSize: '0.875rem', color: 'var(--text-muted)', margin: 0 }}>Manage your clothing catalog and product information.</p>
        </div>
        <div style={{ display: 'flex', gap: '0.75rem', flexWrap: 'wrap' }}>
          <Button variant="secondary" size="md" onClick={() => onNavigate('/products/categories')}>
            <Tag size={16} style={{ marginRight: '6px' }} /> Categories & Brands
          </Button>
          <Button variant="primary" size="md" onClick={() => { setEditProduct(null); setShowForm(true); }}>
            <Plus size={16} style={{ marginRight: '6px' }} /> Add Product
          </Button>
        </div>
      </div>

      {alert && (
        <Alert variant={alert.variant} style={{ marginBottom: '1.25rem' }} onDismiss={() => setAlert(null)}>
          {alert.message}
        </Alert>
      )}

      {/* Filters */}
      <div style={{
        backgroundColor: '#FFFFFF', borderRadius: 'var(--radius-lg)', border: '1px solid var(--border-color)',
        padding: '1rem 1.25rem', marginBottom: '1.25rem', boxShadow: 'var(--shadow-sm)',
        display: 'flex', flexWrap: 'wrap', gap: '0.75rem', alignItems: 'flex-end'
      }}>
        <div style={{ flex: '1 1 220px', minWidth: '180px' }}>
          <Input
            id="prod-search" placeholder="Search name, SKU, barcode…" value={search}
            onChange={e => { setSearch(e.target.value); setPage(1); }}
            startIcon={<Search size={16} />}
          />
        </div>
        <div style={{ flex: '0 1 160px' }}>
          <select value={filterCategory} onChange={e => { setFilterCategory(e.target.value); setPage(1); }} style={{ ...selectSx, width: '100%' }}>
            <option value="">All Categories</option>
            {categories.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
          </select>
        </div>
        <div style={{ flex: '0 1 140px' }}>
          <select value={filterBrand} onChange={e => { setFilterBrand(e.target.value); setPage(1); }} style={{ ...selectSx, width: '100%' }}>
            <option value="">All Brands</option>
            {brands.map(b => <option key={b.id} value={b.id}>{b.name}</option>)}
          </select>
        </div>
        <div style={{ flex: '0 1 140px' }}>
          <select value={filterStatus} onChange={e => { setFilterStatus(e.target.value); setPage(1); }} style={{ ...selectSx, width: '100%' }}>
            <option value="">All Stock Status</option>
            <option value="IN_STOCK">In Stock</option>
            <option value="LOW_STOCK">Low Stock</option>
            <option value="OUT_OF_STOCK">Out of Stock</option>
          </select>
        </div>
        <Button variant="ghost" size="md" onClick={() => { setSearch(''); setFilterCategory(''); setFilterBrand(''); setFilterStatus(''); setPage(1); }}>
          Clear
        </Button>
      </div>

      {/* Table */}
      <div style={{ backgroundColor: '#FFFFFF', borderRadius: 'var(--radius-lg)', border: '1px solid var(--border-color)', boxShadow: 'var(--shadow-sm)', overflow: 'hidden' }}>
        {/* Table header */}
        <div style={{ padding: '1rem 1.25rem', borderBottom: '1px solid var(--border-subtle)', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
          <span style={{ fontSize: '0.8125rem', color: 'var(--text-muted)' }}>
            {loading ? 'Loading…' : `${total} product${total !== 1 ? 's' : ''}`}
          </span>
          <button onClick={loadData} style={{ background: 'none', border: 'none', cursor: 'pointer', color: 'var(--text-muted)', display: 'flex', alignItems: 'center', gap: '4px', fontSize: '0.8125rem' }}>
            <RefreshCw size={13} /> Refresh
          </button>
        </div>

        {error ? (
          <div style={{ padding: '2rem', textAlign: 'center', color: 'var(--danger)', fontSize: '0.875rem' }}>{error}</div>
        ) : loading ? (
          <div style={{ padding: '3rem', textAlign: 'center', color: 'var(--text-muted)', fontSize: '0.875rem' }}>Loading products…</div>
        ) : products.length === 0 ? (
          <div style={{ padding: '3rem', textAlign: 'center' }}>
            <Package size={40} color="#CBD5E1" style={{ marginBottom: '0.75rem' }} />
            <p style={{ color: 'var(--text-muted)', fontSize: '0.9375rem', fontWeight: '500' }}>No products found</p>
            <p style={{ color: 'var(--text-light)', fontSize: '0.875rem', marginTop: '4px' }}>
              {search || filterCategory || filterBrand || filterStatus ? 'Try adjusting your filters.' : 'Click "Add Product" to create your first clothing product.'}
            </p>
          </div>
        ) : (
          <div style={{ overflowX: 'auto' }}>
            <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: '0.875rem' }}>
              <thead>
                <tr style={{ backgroundColor: 'var(--bg-page)', borderBottom: '1px solid var(--border-color)' }}>
                  {['Product', 'SKU', 'Category', 'Brand', 'Variants', 'Selling Price', 'Current Stock', 'Status', 'Actions'].map(h => (
                    <th key={h} style={{ padding: '10px 14px', textAlign: 'left', fontWeight: '600', color: 'var(--text-main)', whiteSpace: 'nowrap', fontSize: '0.8125rem' }}>{h}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {products.map((p, idx) => (
                  <tr key={p.id} style={{ borderBottom: idx < products.length - 1 ? '1px solid var(--border-subtle)' : 'none' }}>
                    <td style={{ padding: '11px 14px' }}>
                      <div style={{ fontWeight: '600', color: 'var(--text-main)' }}>{p.name}</div>
                      {p.barcode && <div style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>{p.barcode}</div>}
                    </td>
                    <td style={{ padding: '11px 14px', color: 'var(--text-muted)', fontFamily: 'monospace', fontSize: '0.8125rem' }}>{p.sku}</td>
                    <td style={{ padding: '11px 14px', color: 'var(--text-muted)' }}>{p.categoryName || '—'}</td>
                    <td style={{ padding: '11px 14px', color: 'var(--text-muted)' }}>{p.brandName || '—'}</td>
                    <td style={{ padding: '11px 14px', color: 'var(--text-muted)', textAlign: 'center' }}>{p.variantCount || 0}</td>
                    <td style={{ padding: '11px 14px', color: 'var(--text-main)', fontWeight: '500' }}>₹{Number(p.sellingPrice).toFixed(2)}</td>
                    <td style={{ padding: '11px 14px', color: 'var(--text-main)', textAlign: 'center' }}>{p.totalStock}</td>
                    <td style={{ padding: '11px 14px' }}><StockBadge status={p.stockStatus} /></td>
                    <td style={{ padding: '11px 14px' }}>
                      <div style={{ display: 'flex', gap: '4px' }}>
                        <button
                          title="Edit" onClick={() => { setEditProduct(p); setShowForm(true); }}
                          style={actionBtnSx}><Edit2 size={14} /></button>
                        <button
                          title="Archive / Delete" onClick={() => setDeleteProduct(p)}
                          style={{ ...actionBtnSx, color: 'var(--danger)' }}><Trash2 size={14} /></button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}

        {/* Pagination */}
        {totalPages > 1 && (
          <div style={{ padding: '1rem 1.25rem', borderTop: '1px solid var(--border-subtle)', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
            <span style={{ fontSize: '0.8125rem', color: 'var(--text-muted)' }}>Page {page} of {totalPages}</span>
            <div style={{ display: 'flex', gap: '0.5rem' }}>
              <Button variant="secondary" size="sm" onClick={() => setPage(p => Math.max(1, p - 1))} disabled={page <= 1}>
                <ChevronLeft size={14} />
              </Button>
              <Button variant="secondary" size="sm" onClick={() => setPage(p => Math.min(totalPages, p + 1))} disabled={page >= totalPages}>
                <ChevronRight size={14} />
              </Button>
            </div>
          </div>
        )}
      </div>

      {/* Add / Edit Product Modal */}
      <Modal isOpen={showForm} onClose={() => { setShowForm(false); setEditProduct(null); }} title={editProduct ? `Edit Product — ${editProduct.name}` : 'Add New Product'} width="760px">
        {alert && alert.variant === 'danger' && (
          <Alert variant="danger" style={{ marginBottom: '1rem' }} onDismiss={() => setAlert(null)}>{alert.message}</Alert>
        )}
        <ProductForm
          initial={editProduct}
          categories={categories}
          brands={brands}
          onSave={handleSaveProduct}
          onCancel={() => { setShowForm(false); setEditProduct(null); }}
          isLoading={savingProduct}
        />
      </Modal>

      {/* Delete Confirmation Modal */}
      <Modal isOpen={Boolean(deleteProduct)} onClose={() => setDeleteProduct(null)} title="Archive Product" width="480px">
        <DeleteConfirmModal
          product={deleteProduct}
          onConfirm={handleDelete}
          onCancel={() => setDeleteProduct(null)}
          isLoading={deletingProduct}
        />
      </Modal>
    </div>
  );
}

const actionBtnSx = {
  background: 'none', border: 'none', cursor: 'pointer',
  color: 'var(--text-muted)', padding: '5px', borderRadius: '5px',
  display: 'flex', alignItems: 'center', transition: 'background 0.12s'
};
