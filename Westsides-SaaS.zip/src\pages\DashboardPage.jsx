import React, { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext';
import { api } from '../services/api';
import { Card, CardHeader, CardTitle, CardDescription, CardContent, CardFooter } from '../components/ui/Card';
import { Badge } from '../components/ui/Badge';
import { Button } from '../components/ui/Button';
import { Alert } from '../components/ui/Alert';
import { SalesChart } from '../components/reports/Chart';
import {
  Store,
  Shirt,
  Boxes,
  Receipt,
  Users,
  BarChart3,
  ShieldCheck,
  CheckCircle2,
  Clock,
  ArrowRight,
  TrendingUp,
  TrendingDown,
  Layers,
  Info,
  Building,
  KeyRound,
  IndianRupee,
  AlertTriangle,
  FileText,
  Wallet,
  Calendar
} from 'lucide-react';

const fmt = (n) => Number(n || 0).toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 });

export function DashboardPage({ onNavigate }) {
  const { user, store, role } = useAuth();
  const [storeData, setStoreData] = useState(null);
  const [dashboardData, setDashboardData] = useState(null);
  const [range, setRange] = useState('last30days');
  const [loading, setLoading] = useState(true);
  const [testResult, setTestResult] = useState(null);
  const [testingIsolation, setTestingIsolation] = useState(false);

  useEffect(() => {
    fetchDashboard();
  }, [range]);

  const fetchDashboard = async () => {
    try {
      setLoading(true);
      const [storeRes, dashRes] = await Promise.allSettled([
        api.getCurrentStore(),
        api.getDashboardReport({ range })
      ]);

      if (storeRes.status === 'fulfilled' && storeRes.value?.success) {
        setStoreData(storeRes.value.store);
      }
      if (dashRes.status === 'fulfilled' && dashRes.value?.success) {
        setDashboardData(dashRes.value);
      }
    } catch (err) {
      console.error('Failed to load dashboard:', err);
    } finally {
      setLoading(false);
    }
  };

  const runTenantIsolationTest = async () => {
    setTestingIsolation(true);
    setTestResult(null);

    try {
      await api.testTenantIsolation('store_demo_b_isolated');
      setTestResult({
        success: false,
        message: 'Security warning: Cross-tenant access was not blocked!'
      });
    } catch (err) {
      if (err.status === 403) {
        setTestResult({
          success: true,
          status: 403,
          code: 'TENANT_ISOLATION_VERIFIED',
          message: 'Passed: Server strictly blocked access to foreign tenant store data (HTTP 403 Forbidden). Data isolation is fully active.'
        });
      } else {
        setTestResult({
          success: false,
          message: err.message || 'Error executing test.'
        });
      }
    } finally {
      setTestingIsolation(false);
    }
  };

  const currentStore = storeData || store;
  const kpis = dashboardData?.kpis || {};

  return (
    <div style={{ maxWidth: '1200px', margin: '0 auto', display: 'flex', flexDirection: 'column', gap: '1.75rem' }} className="animate-fade-in">
      {/* Welcome Banner & Quick Action Header */}
      <div
        style={{
          backgroundColor: '#FFFFFF',
          borderRadius: 'var(--radius-lg)',
          border: '1px solid var(--border-color)',
          padding: '1.75rem 2rem',
          boxShadow: 'var(--shadow-sm)',
          display: 'flex',
          flexDirection: 'column',
          gap: '0.75rem'
        }}
      >
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', flexWrap: 'wrap', gap: '1rem' }}>
          <div>
            <div style={{ display: 'flex', alignItems: 'center', gap: '8px', marginBottom: '4px' }}>
              <span style={{ fontSize: '0.8125rem', fontWeight: '600', color: '#4B7C9E', textTransform: 'uppercase', letterSpacing: '0.05em' }}>
                Store Operations Engine • Business Intelligence & Reports Active
              </span>
            </div>
            <h1 style={{ fontSize: '1.75rem', fontWeight: '700', color: 'var(--text-main)', margin: 0 }}>
              {currentStore?.name || 'Westsides'} Overview
            </h1>
            <p style={{ fontSize: '0.9375rem', color: 'var(--text-muted)', marginTop: '4px', margin: 0 }}>
              Live retail performance, inventory alerts, and transaction intelligence.
            </p>
          </div>

          <div style={{ display: 'flex', alignItems: 'center', gap: '0.75rem', flexWrap: 'wrap' }}>
            <Button variant="primary" onClick={() => onNavigate('/pos')} style={{ display: 'flex', alignItems: 'center', gap: '6px' }}>
              <Receipt size={16} />
              Open POS Register
            </Button>
            <Button variant="outline" onClick={() => onNavigate('/reports')} style={{ display: 'flex', alignItems: 'center', gap: '6px' }}>
              <BarChart3 size={16} />
              View Full Reports
            </Button>
            <Badge variant="primary" size="md">
              ROLE: {role || 'OWNER'}
            </Badge>
          </div>
        </div>
      </div>

      {/* Date Range Selector for Dashboard Overview */}
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: '1rem', backgroundColor: '#FFFFFF', padding: '10px 16px', borderRadius: 'var(--radius-md)', border: '1px solid var(--border-color)' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
          <Calendar size={16} color="#7EAFD0" />
          <span style={{ fontSize: '0.875rem', fontWeight: '600', color: 'var(--text-main)' }}>Overview Period:</span>
        </div>

        <div style={{ display: 'flex', gap: '6px', flexWrap: 'wrap' }}>
          {[
            { id: 'today', label: 'Today' },
            { id: 'last7days', label: 'Last 7 Days' },
            { id: 'last30days', label: 'Last 30 Days' },
            { id: 'thismonth', label: 'This Month' }
          ].map(p => (
            <button
              key={p.id}
              onClick={() => setRange(p.id)}
              style={{
                padding: '5px 12px',
                borderRadius: '6px',
                border: 'none',
                cursor: 'pointer',
                fontSize: '0.8125rem',
                fontWeight: range === p.id ? '600' : '500',
                backgroundColor: range === p.id ? '#7EAFD0' : '#F1F5F9',
                color: range === p.id ? '#FFFFFF' : 'var(--text-main)',
                transition: 'all 0.15s ease'
              }}
            >
              {p.label}
            </button>
          ))}
        </div>
      </div>

      {/* Primary KPI Row */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(210px, 1fr))', gap: '1rem' }}>
        {/* Today's Sales with Comparison */}
        <Card style={{ padding: '1.25rem', borderLeft: '4px solid #7EAFD0' }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
            <span style={{ fontSize: '0.8125rem', fontWeight: '600', color: 'var(--text-muted)' }}>Today's Sales</span>
            <div style={{ padding: '6px', borderRadius: '6px', backgroundColor: 'rgba(126, 175, 208, 0.15)', color: '#4B7C9E' }}>
              <IndianRupee size={18} />
            </div>
          </div>
          <div style={{ fontSize: '1.625rem', fontWeight: '800', color: 'var(--text-main)', marginTop: '4px' }}>
            ₹{fmt(kpis.todaySales)}
          </div>
          <div style={{ display: 'flex', alignItems: 'center', gap: '6px', fontSize: '0.75rem', marginTop: '6px' }}>
            {kpis.todayVsYesterdayRevPercent !== null ? (
              <span style={{ color: kpis.todayVsYesterdayRevPercent >= 0 ? '#16A34A' : '#DC2626', fontWeight: '600', display: 'flex', alignItems: 'center', gap: '2px' }}>
                {kpis.todayVsYesterdayRevPercent >= 0 ? <TrendingUp size={13} /> : <TrendingDown size={13} />}
                {kpis.todayVsYesterdayRevPercent > 0 ? `+${kpis.todayVsYesterdayRevPercent}%` : `${kpis.todayVsYesterdayRevPercent}%`}
              </span>
            ) : (
              <span style={{ color: 'var(--text-muted)' }}>First day recorded</span>
            )}
            <span style={{ color: 'var(--text-muted)' }}>vs yesterday (₹{fmt(kpis.yesterdaySales)})</span>
          </div>
        </Card>

        {/* Selected Period Sales */}
        <Card style={{ padding: '1.25rem' }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
            <span style={{ fontSize: '0.8125rem', fontWeight: '600', color: 'var(--text-muted)' }}>Period Revenue</span>
            <div style={{ padding: '6px', borderRadius: '6px', backgroundColor: '#EFF6FF', color: '#1E40AF' }}>
              <TrendingUp size={18} />
            </div>
          </div>
          <div style={{ fontSize: '1.625rem', fontWeight: '800', color: 'var(--text-main)', marginTop: '4px' }}>
            ₹{fmt(kpis.periodRevenue)}
          </div>
          <div style={{ fontSize: '0.75rem', color: 'var(--text-muted)', marginTop: '4px' }}>
            {kpis.periodOrders} order{kpis.periodOrders === 1 ? '' : 's'} • AOV: ₹{fmt(kpis.periodAverageOrderValue)}
          </div>
        </Card>

        {/* Catalog Products */}
        <Card style={{ padding: '1.25rem' }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
            <span style={{ fontSize: '0.8125rem', fontWeight: '600', color: 'var(--text-muted)' }}>Catalog Items</span>
            <div style={{ padding: '6px', borderRadius: '6px', backgroundColor: '#ECFDF5', color: '#065F46' }}>
              <Shirt size={18} />
            </div>
          </div>
          <div style={{ fontSize: '1.625rem', fontWeight: '800', color: 'var(--text-main)', marginTop: '4px' }}>
            {kpis.totalProducts}
          </div>
          <div style={{ fontSize: '0.75rem', color: 'var(--text-muted)', marginTop: '4px' }}>
            {kpis.totalStockUnits} total stock units
          </div>
        </Card>

        {/* Registered Customers */}
        <Card style={{ padding: '1.25rem' }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
            <span style={{ fontSize: '0.8125rem', fontWeight: '600', color: 'var(--text-muted)' }}>Total Customers</span>
            <div style={{ padding: '6px', borderRadius: '6px', backgroundColor: '#F5F3FF', color: '#7C3AED' }}>
              <Users size={18} />
            </div>
          </div>
          <div style={{ fontSize: '1.625rem', fontWeight: '800', color: 'var(--text-main)', marginTop: '4px' }}>
            {kpis.totalCustomers}
          </div>
          <div style={{ fontSize: '0.75rem', color: 'var(--text-muted)', marginTop: '4px' }}>
            Registered store clients
          </div>
        </Card>

        {/* Low Stock Alerts */}
        <Card style={{ padding: '1.25rem' }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
            <span style={{ fontSize: '0.8125rem', fontWeight: '600', color: 'var(--text-muted)' }}>Low Stock Items</span>
            <div style={{ padding: '6px', borderRadius: '6px', backgroundColor: kpis.lowStockCount > 0 ? '#FEF2F2' : '#F0FDF4', color: kpis.lowStockCount > 0 ? '#EF4444' : '#10B981' }}>
              <AlertTriangle size={18} />
            </div>
          </div>
          <div style={{ fontSize: '1.625rem', fontWeight: '800', color: kpis.lowStockCount > 0 ? '#DC2626' : 'var(--text-main)', marginTop: '4px' }}>
            {kpis.lowStockCount}
          </div>
          <div style={{ fontSize: '0.75rem', color: 'var(--text-muted)', marginTop: '4px' }}>
            {kpis.outOfStockCount > 0 ? `${kpis.outOfStockCount} out of stock` : 'Healthy stock levels'}
          </div>
        </Card>
      </div>

      {/* Sales Trend Chart */}
      <Card>
        <CardHeader style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
          <div>
            <CardTitle style={{ fontSize: '1.0625rem' }}>Sales Revenue Timeline</CardTitle>
            <CardDescription>Daily revenue trends and completed bills across {range.replace('last', 'last ').toUpperCase()}</CardDescription>
          </div>
          <Button variant="outline" size="sm" onClick={() => onNavigate('/reports/sales')}>
            <span>Detailed Analytics</span>
            <ArrowRight size={14} style={{ marginLeft: '4px' }} />
          </Button>
        </CardHeader>
        <CardContent>
          <SalesChart data={dashboardData?.timeline} loading={loading} height={240} />
        </CardContent>
      </Card>

      {/* Secondary Row: Top Products & Payment Breakdown */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(320px, 1fr))', gap: '1.25rem' }}>
        {/* Top Selling Products */}
        <Card>
          <CardHeader style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
            <div>
              <CardTitle style={{ fontSize: '1rem' }}>Top Selling Garments</CardTitle>
              <CardDescription>By units sold in this period</CardDescription>
            </div>
            <Button variant="outline" size="sm" onClick={() => onNavigate('/reports/products')}>
              All Products
            </Button>
          </CardHeader>
          <CardContent style={{ padding: 0 }}>
            {dashboardData?.topProducts?.length === 0 ? (
              <div style={{ padding: '2rem', textAlign: 'center', color: 'var(--text-muted)', fontSize: '0.875rem' }}>
                No product sales recorded in this period.
              </div>
            ) : (
              <div style={{ display: 'flex', flexDirection: 'column' }}>
                {dashboardData?.topProducts?.map((p, idx) => (
                  <div
                    key={idx}
                    style={{
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'space-between',
                      padding: '12px 16px',
                      borderBottom: idx !== dashboardData.topProducts.length - 1 ? '1px solid var(--border-color)' : 'none'
                    }}
                  >
                    <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
                      <span style={{ width: '22px', height: '22px', borderRadius: '50%', backgroundColor: '#F1F5F9', color: '#64748B', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: '0.75rem', fontWeight: '700' }}>
                        {idx + 1}
                      </span>
                      <div>
                        <div style={{ fontWeight: '600', color: 'var(--text-main)', fontSize: '0.875rem' }}>{p.productName}</div>
                        <div style={{ fontSize: '0.75rem', color: 'var(--text-muted)', fontFamily: 'monospace' }}>{p.sku || '—'}</div>
                      </div>
                    </div>

                    <div style={{ textAlign: 'right' }}>
                      <div style={{ fontWeight: '700', color: 'var(--text-main)', fontSize: '0.875rem' }}>₹{fmt(p.revenue)}</div>
                      <div style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>{p.unitsSold} units</div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>

        {/* Payment Breakdown */}
        <Card>
          <CardHeader>
            <CardTitle style={{ fontSize: '1rem' }}>Payment Distribution</CardTitle>
            <CardDescription>Tender breakdown across completed sales</CardDescription>
          </CardHeader>
          <CardContent>
            <div style={{ display: 'flex', flexDirection: 'column', gap: '1.25rem' }}>
              {dashboardData?.payments?.map((pm) => (
                <div key={pm.method}>
                  <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '0.875rem', marginBottom: '6px' }}>
                    <span style={{ fontWeight: '600', color: 'var(--text-main)' }}>{pm.method}</span>
                    <span style={{ color: 'var(--text-muted)' }}>
                      ₹{fmt(pm.amount)} ({pm.percentage}%) • {pm.count} bills
                    </span>
                  </div>
                  <div style={{ width: '100%', height: '8px', backgroundColor: '#F1F5F9', borderRadius: '4px', overflow: 'hidden' }}>
                    <div
                      style={{
                        width: `${pm.percentage}%`,
                        height: '100%',
                        backgroundColor: pm.method === 'UPI' ? '#10B981' : pm.method === 'CARD' ? '#3B82F6' : '#7EAFD0',
                        borderRadius: '4px'
                      }}
                    />
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Lower Row: Recent Sales & Staff Activity */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(320px, 1fr))', gap: '1.25rem' }}>
        {/* Recent Sales */}
        <Card>
          <CardHeader style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
            <div>
              <CardTitle style={{ fontSize: '1rem' }}>Recent Sales</CardTitle>
              <CardDescription>Latest completed store transactions</CardDescription>
            </div>
            <Button variant="outline" size="sm" onClick={() => onNavigate('/sales')}>
              All Sales
            </Button>
          </CardHeader>
          <CardContent style={{ padding: 0 }}>
            {dashboardData?.recentSales?.length === 0 ? (
              <div style={{ padding: '2rem', textAlign: 'center', color: 'var(--text-muted)', fontSize: '0.875rem' }}>
                No completed sales in this store yet.
              </div>
            ) : (
              <div style={{ display: 'flex', flexDirection: 'column' }}>
                {dashboardData?.recentSales?.map((s, idx) => (
                  <div
                    key={s.id}
                    style={{
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'space-between',
                      padding: '10px 16px',
                      borderBottom: idx !== dashboardData.recentSales.length - 1 ? '1px solid var(--border-color)' : 'none'
                    }}
                  >
                    <div>
                      <div style={{ fontWeight: '600', color: 'var(--text-main)', fontSize: '0.875rem', fontFamily: 'monospace' }}>
                        {s.invoiceNumber}
                      </div>
                      <div style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>
                        {s.customerName || 'Walk-in'} • {new Date(s.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                      </div>
                    </div>

                    <div style={{ textAlign: 'right' }}>
                      <div style={{ fontWeight: '700', color: 'var(--text-main)', fontSize: '0.875rem' }}>
                        ₹{fmt(s.totalAmount)}
                      </div>
                      <Badge variant="success" size="sm">
                        {s.paymentMethod}
                      </Badge>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>

        {/* Recent Activity (Admin only) */}
        {role === 'OWNER' && (
          <Card>
            <CardHeader style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
              <div>
                <CardTitle style={{ fontSize: '1rem' }}>Staff Activity Audit Trail</CardTitle>
                <CardDescription>Recent actions logged by store personnel</CardDescription>
              </div>
              <Button variant="outline" size="sm" onClick={() => onNavigate('/staff/activity')}>
                Full Log
              </Button>
            </CardHeader>
            <CardContent style={{ padding: 0 }}>
              {dashboardData?.recentActivity?.length === 0 ? (
                <div style={{ padding: '2rem', textAlign: 'center', color: 'var(--text-muted)', fontSize: '0.875rem' }}>
                  No staff activity logged yet.
                </div>
              ) : (
                <div style={{ display: 'flex', flexDirection: 'column' }}>
                  {dashboardData?.recentActivity?.map((a, idx) => (
                    <div
                      key={a.id}
                      style={{
                        display: 'flex',
                        flexDirection: 'column',
                        padding: '10px 16px',
                        borderBottom: idx !== dashboardData.recentActivity.length - 1 ? '1px solid var(--border-color)' : 'none'
                      }}
                    >
                      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                        <span style={{ fontSize: '0.8125rem', fontWeight: '600', color: 'var(--text-main)' }}>
                          {a.userName}
                        </span>
                        <span style={{ fontSize: '0.7rem', color: 'var(--text-muted)' }}>
                          {new Date(a.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                        </span>
                      </div>
                      <div style={{ fontSize: '0.75rem', color: 'var(--text-muted)', marginTop: '2px' }}>
                        {a.description}
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        )}
      </div>

      {/* Tenant Isolation Security Verification Card */}
      <Card style={{ border: '1px solid #D4E6F1', backgroundColor: '#FFFFFF' }}>
        <CardHeader>
          <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
            <ShieldCheck size={20} color="#7EAFD0" />
            <CardTitle style={{ fontSize: '1.0625rem' }}>Multi-Tenant Isolation Security Test</CardTitle>
          </div>
          <CardDescription>
            Live verification of tenant boundary enforcement. Tests that your authenticated user session cannot read, write, or access any foreign store's data.
          </CardDescription>
        </CardHeader>

        <CardContent>
          <div style={{ display: 'flex', flexDirection: 'column', gap: '1rem' }}>
            <div
              style={{
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'space-between',
                flexWrap: 'wrap',
                gap: '1rem',
                padding: '1rem',
                backgroundColor: 'var(--bg-page)',
                borderRadius: 'var(--radius-md)',
                fontSize: '0.875rem'
              }}
            >
              <div>
                <div style={{ fontWeight: '600', color: 'var(--text-main)' }}>Current Tenant Context</div>
                <div style={{ color: 'var(--text-muted)', fontSize: '0.8125rem', marginTop: '2px' }}>
                  Authenticated as <strong>{user?.email}</strong> for Store ID: <code style={{ backgroundColor: '#E2E8F0', padding: '2px 6px', borderRadius: '4px' }}>{currentStore?.id}</code>
                </div>
              </div>

              <Button
                variant="primary"
                size="md"
                onClick={runTenantIsolationTest}
                isLoading={testingIsolation}
              >
                <span>Run Isolation Test</span>
              </Button>
            </div>

            {testResult && (
              <Alert
                variant={testResult.success ? 'success' : 'danger'}
                title={testResult.success ? 'Tenant Isolation Active (HTTP 403 Forbidden on Foreign Access)' : 'Test Alert'}
              >
                {testResult.message}
              </Alert>
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
