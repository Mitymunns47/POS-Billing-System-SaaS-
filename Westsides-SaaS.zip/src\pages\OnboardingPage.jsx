import React, { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext';
import { api } from '../services/api';
import { Button } from '../components/ui/Button';
import { Input } from '../components/ui/Input';
import { Card, CardHeader, CardTitle, CardDescription, CardContent, CardFooter } from '../components/ui/Card';
import { Alert } from '../components/ui/Alert';
import {
  Store,
  FileCheck2,
  Sliders,
  CheckCircle2,
  ArrowRight,
  ArrowLeft,
  Building,
  MapPin,
  Tag,
  ShieldCheck,
  Receipt,
  Sparkles
} from 'lucide-react';

export function OnboardingPage({ onNavigate }) {
  const { store, user, role, updateStoreState } = useAuth();

  const [currentStep, setCurrentStep] = useState(1);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState(null);
  const [storeDetails, setStoreDetails] = useState({
    name: 'Westsides',
    phone: '',
    address: '',
    city: '',
    state: '',
    country: 'India',
    currency: 'INR',
    category: 'Apparel & Fashion',
    gstNumber: '',
    legalName: 'Westsides Retail Pvt Ltd',
    receiptHeader: 'Westsides - Contemporary Clothing & Apparel',
    receiptFooter: 'Thank you for shopping with us! Exchange within 14 days with original receipt.',
    barcodeMode: 'enabled',
    defaultUnit: 'Pieces (Pcs)'
  });

  // Load existing store details if present
  useEffect(() => {
    async function loadStore() {
      try {
        const res = await api.getCurrentStore();
        if (res.success && res.store) {
          setStoreDetails((prev) => ({
            ...prev,
            name: res.store.name || prev.name,
            phone: res.store.phone || prev.phone,
            address: res.store.address || prev.address,
            city: res.store.city || prev.city,
            state: res.store.state || prev.state,
            country: res.store.country || prev.country,
            gstNumber: res.store.gstNumber || prev.gstNumber,
            receiptHeader: res.store.receiptHeader || prev.receiptHeader,
            receiptFooter: res.store.receiptFooter || prev.receiptFooter
          }));
          if (res.store.onboardingStep && res.store.onboardingStep > 1 && res.store.onboardingStep <= 4) {
            setCurrentStep(res.store.onboardingStep);
          }
        }
      } catch (e) {
        // Fallback to auth context
      }
    }
    loadStore();
  }, []);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setStoreDetails((prev) => ({ ...prev, [name]: value }));
  };

  const handleNext = async () => {
    setError(null);
    setIsLoading(true);

    try {
      if (currentStep < 4) {
        const nextStep = currentStep + 1;
        await api.updateOnboarding({
          step: nextStep,
          completed: false,
          name: storeDetails.name,
          phone: storeDetails.phone,
          address: storeDetails.address,
          city: storeDetails.city,
          state: storeDetails.state,
          country: storeDetails.country,
          currency: storeDetails.currency,
          category: storeDetails.category,
          gstNumber: storeDetails.gstNumber,
          receiptHeader: storeDetails.receiptHeader,
          receiptFooter: storeDetails.receiptFooter
        });
        setCurrentStep(nextStep);
      } else {
        // Final completion step
        await api.updateOnboarding({
          step: 4,
          completed: true,
          name: storeDetails.name,
          phone: storeDetails.phone,
          address: storeDetails.address,
          city: storeDetails.city,
          state: storeDetails.state,
          country: storeDetails.country,
          currency: storeDetails.currency,
          category: storeDetails.category,
          gstNumber: storeDetails.gstNumber,
          receiptHeader: storeDetails.receiptHeader,
          receiptFooter: storeDetails.receiptFooter
        });

        updateStoreState({
          name: storeDetails.name,
          onboardingCompleted: true,
          onboardingStep: 4
        });

        onNavigate('/dashboard');
      }
    } catch (err) {
      setError(err.message || 'Failed to save store configuration.');
    } finally {
      setIsLoading(false);
    }
  };

  const handleBack = () => {
    if (currentStep > 1) {
      setCurrentStep(currentStep - 1);
    }
  };

  const steps = [
    { number: 1, title: 'Store Info', icon: Store },
    { number: 2, title: 'Business & GST', icon: FileCheck2 },
    { number: 3, title: 'Configuration', icon: Sliders },
    { number: 4, title: 'Complete Setup', icon: CheckCircle2 }
  ];

  return (
    <div
      style={{
        minHeight: '100vh',
        backgroundColor: 'var(--bg-page)',
        padding: '2.5rem 1.5rem',
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center'
      }}
    >
      <div style={{ width: '100%', maxWidth: '780px' }} className="animate-fade-in">
        {/* Header Branding */}
        <div style={{ textAlign: 'center', marginBottom: '2rem' }}>
          <div
            style={{
              width: '40px',
              height: '40px',
              borderRadius: '10px',
              backgroundColor: '#7EAFD0',
              display: 'inline-flex',
              alignItems: 'center',
              justifyContent: 'center',
              color: '#FFFFFF',
              fontWeight: '700',
              fontSize: '1.25rem',
              marginBottom: '0.75rem',
              boxShadow: '0 4px 10px rgba(126, 175, 208, 0.25)'
            }}
          >
            W
          </div>
          <h1 style={{ fontSize: '1.5rem', fontWeight: '700', color: 'var(--text-main)', margin: '0 0 4px 0' }}>
            Store Onboarding Wizard
          </h1>
          <p style={{ fontSize: '0.875rem', color: 'var(--text-muted)' }}>
            Configure your clothing store workspace before accessing the management dashboard.
          </p>
        </div>

        {/* Step Progress Bar */}
        <div
          style={{
            backgroundColor: '#FFFFFF',
            borderRadius: 'var(--radius-lg)',
            border: '1px solid var(--border-color)',
            padding: '1.25rem 1.5rem',
            marginBottom: '1.75rem',
            boxShadow: 'var(--shadow-sm)'
          }}
        >
          <div
            style={{
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'space-between',
              position: 'relative'
            }}
          >
            {steps.map((s, idx) => {
              const StepIcon = s.icon;
              const isActive = currentStep === s.number;
              const isPast = currentStep > s.number;

              return (
                <div
                  key={s.number}
                  style={{
                    display: 'flex',
                    flexDirection: 'column',
                    alignItems: 'center',
                    gap: '6px',
                    position: 'relative',
                    zIndex: 2,
                    flex: 1
                  }}
                >
                  <div
                    style={{
                      width: '38px',
                      height: '38px',
                      borderRadius: '50%',
                      backgroundColor: isActive || isPast ? '#7EAFD0' : 'var(--bg-page)',
                      color: isActive || isPast ? '#FFFFFF' : 'var(--text-muted)',
                      border: `2px solid ${isActive || isPast ? '#7EAFD0' : 'var(--border-color)'}`,
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'center',
                      fontWeight: '600',
                      fontSize: '0.875rem',
                      transition: 'all 0.2s ease',
                      boxShadow: isActive ? '0 0 0 4px rgba(126, 175, 208, 0.25)' : 'none'
                    }}
                  >
                    {isPast ? <CheckCircle2 size={18} /> : <StepIcon size={18} />}
                  </div>

                  <span
                    style={{
                      fontSize: '0.75rem',
                      fontWeight: isActive ? '600' : '500',
                      color: isActive ? 'var(--text-main)' : isPast ? '#4B7C9E' : 'var(--text-light)',
                      textAlign: 'center'
                    }}
                  >
                    STEP {s.number}
                    <div style={{ fontSize: '0.75rem', fontWeight: '400', display: 'none' }} className="brand-subtitle">
                      {s.title}
                    </div>
                  </span>
                </div>
              );
            })}
          </div>
        </div>

        {error && (
          <Alert variant="danger" style={{ marginBottom: '1.5rem' }} onDismiss={() => setError(null)}>
            {error}
          </Alert>
        )}

        {/* STEP 1: STORE INFORMATION */}
        {currentStep === 1 && (
          <Card className="animate-fade-in">
            <CardHeader>
              <CardTitle>STEP 1: Store Information</CardTitle>
              <CardDescription>
                Confirm your retail store identity, location, and retail specialty.
              </CardDescription>
            </CardHeader>

            <CardContent>
              <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(280px, 1fr))', gap: '1.25rem' }}>
                <Input
                  label="Store Name"
                  id="ob-storeName"
                  name="name"
                  value={storeDetails.name}
                  onChange={handleChange}
                  required
                  startIcon={<Store size={16} />}
                  helperText="Default demo: 'Westsides'."
                />

                <Input
                  label="Store Contact Phone"
                  id="ob-phone"
                  name="phone"
                  value={storeDetails.phone}
                  onChange={handleChange}
                  placeholder="+91 98765 00000"
                />

                <div style={{ gridColumn: '1 / -1' }}>
                  <Input
                    label="Retail Store Address"
                    id="ob-address"
                    name="address"
                    value={storeDetails.address}
                    onChange={handleChange}
                    placeholder="Floor 2, Linking Road, Bandra West"
                    startIcon={<MapPin size={16} />}
                  />
                </div>

                <Input
                  label="City"
                  id="ob-city"
                  name="city"
                  value={storeDetails.city}
                  onChange={handleChange}
                  placeholder="Mumbai"
                />

                <Input
                  label="State"
                  id="ob-state"
                  name="state"
                  value={storeDetails.state}
                  onChange={handleChange}
                  placeholder="Maharashtra"
                />

                <div style={{ display: 'flex', flexDirection: 'column', gap: '6px' }}>
                  <label style={{ fontSize: '0.875rem', fontWeight: '500', color: 'var(--text-main)' }}>
                    Store Category
                  </label>
                  <select
                    name="category"
                    value={storeDetails.category}
                    onChange={handleChange}
                    style={{
                      padding: '9px 12px',
                      borderRadius: 'var(--radius-md)',
                      border: '1px solid var(--border-color)',
                      backgroundColor: '#FFFFFF',
                      fontSize: '0.875rem',
                      color: 'var(--text-main)',
                      outline: 'none'
                    }}
                  >
                    <option value="Apparel & Fashion">Apparel & Fashion (Clothing)</option>
                    <option value="Men's Formal & Casual">Men's Formal & Casual</option>
                    <option value="Women's Ethnic & Western">Women's Ethnic & Western</option>
                    <option value="Kids & Family Fashion">Kids & Family Fashion</option>
                    <option value="Designer Boutique">Designer Boutique</option>
                  </select>
                </div>

                <div style={{ display: 'flex', flexDirection: 'column', gap: '6px' }}>
                  <label style={{ fontSize: '0.875rem', fontWeight: '500', color: 'var(--text-main)' }}>
                    Operating Currency
                  </label>
                  <select
                    name="currency"
                    value={storeDetails.currency}
                    onChange={handleChange}
                    style={{
                      padding: '9px 12px',
                      borderRadius: 'var(--radius-md)',
                      border: '1px solid var(--border-color)',
                      backgroundColor: '#FFFFFF',
                      fontSize: '0.875rem',
                      color: 'var(--text-main)',
                      outline: 'none'
                    }}
                  >
                    <option value="INR">INR (₹) - Indian Rupee</option>
                    <option value="USD">USD ($) - US Dollar</option>
                    <option value="EUR">EUR (€) - Euro</option>
                    <option value="GBP">GBP (£) - British Pound</option>
                    <option value="AED">AED (د.إ) - UAE Dirham</option>
                  </select>
                </div>
              </div>
            </CardContent>

            <CardFooter>
              <Button variant="primary" size="md" onClick={handleNext} isLoading={isLoading}>
                <span>Continue to Step 2</span>
                <ArrowRight size={16} style={{ marginLeft: '6px' }} />
              </Button>
            </CardFooter>
          </Card>
        )}

        {/* STEP 2: BUSINESS / GST INFORMATION */}
        {currentStep === 2 && (
          <Card className="animate-fade-in">
            <CardHeader>
              <CardTitle>STEP 2: Business & GST Information</CardTitle>
              <CardDescription>
                Configure tax settings and legal registration for compliance on retail invoices.
              </CardDescription>
            </CardHeader>

            <CardContent>
              <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(280px, 1fr))', gap: '1.25rem' }}>
                <Input
                  label="GSTIN / Tax ID"
                  id="ob-gstNumber"
                  name="gstNumber"
                  placeholder="e.g. 27AABCS1429B1Z2"
                  value={storeDetails.gstNumber}
                  onChange={handleChange}
                  helperText="15-digit Goods & Services Tax Number."
                />

                <Input
                  label="Registered Legal Entity Name"
                  id="ob-legalName"
                  name="legalName"
                  placeholder="Legal Company Name"
                  value={storeDetails.legalName}
                  onChange={handleChange}
                />

                <Input
                  label="State Code"
                  id="ob-stateCode"
                  placeholder="e.g. 27 (Maharashtra)"
                  defaultValue="27"
                  disabled
                  helperText="Derived automatically from state & GST structure."
                />

                <Input
                  label="Tax System"
                  id="ob-taxSystem"
                  defaultValue="Standard Multi-Tier Clothing GST (5% / 12%)"
                  disabled
                  helperText="Apparel slab based on product price bracket."
                />
              </div>
            </CardContent>

            <CardFooter style={{ justifyContent: 'space-between' }}>
              <Button variant="secondary" size="md" onClick={handleBack} disabled={isLoading}>
                <ArrowLeft size={16} style={{ marginRight: '6px' }} />
                <span>Back</span>
              </Button>
              <Button variant="primary" size="md" onClick={handleNext} isLoading={isLoading}>
                <span>Continue to Step 3</span>
                <ArrowRight size={16} style={{ marginLeft: '6px' }} />
              </Button>
            </CardFooter>
          </Card>
        )}

        {/* STEP 3: BASIC STORE CONFIGURATION */}
        {currentStep === 3 && (
          <Card className="animate-fade-in">
            <CardHeader>
              <CardTitle>STEP 3: Basic Store Configuration</CardTitle>
              <CardDescription>
                Customize receipt printing headers, barcode scanning preferences, and defaults.
              </CardDescription>
            </CardHeader>

            <CardContent>
              <div style={{ display: 'flex', flexDirection: 'column', gap: '1.25rem' }}>
                <Input
                  label="Receipt Header Title"
                  id="ob-receiptHeader"
                  name="receiptHeader"
                  value={storeDetails.receiptHeader}
                  onChange={handleChange}
                  helperText="Printed at the top of customer sales receipts in future POS."
                />

                <Input
                  label="Receipt Footer / Return Policy"
                  id="ob-receiptFooter"
                  name="receiptFooter"
                  value={storeDetails.receiptFooter}
                  onChange={handleChange}
                  helperText="Printed at the bottom of customer receipts."
                />

                <div
                  style={{
                    display: 'grid',
                    gridTemplateColumns: 'repeat(auto-fit, minmax(280px, 1fr))',
                    gap: '1.25rem',
                    paddingTop: '0.5rem'
                  }}
                >
                  <div style={{ display: 'flex', flexDirection: 'column', gap: '6px' }}>
                    <label style={{ fontSize: '0.875rem', fontWeight: '500', color: 'var(--text-main)' }}>
                      Barcode Scanner Mode
                    </label>
                    <select
                      name="barcodeMode"
                      value={storeDetails.barcodeMode}
                      onChange={handleChange}
                      style={{
                        padding: '9px 12px',
                        borderRadius: 'var(--radius-md)',
                        border: '1px solid var(--border-color)',
                        backgroundColor: '#FFFFFF',
                        fontSize: '0.875rem',
                        color: 'var(--text-main)',
                        outline: 'none'
                      }}
                    >
                      <option value="enabled">Standard USB/Bluetooth Barcode Scanner (Recommended)</option>
                      <option value="manual">Manual SKU / Code Entry Only</option>
                    </select>
                  </div>

                  <div style={{ display: 'flex', flexDirection: 'column', gap: '6px' }}>
                    <label style={{ fontSize: '0.875rem', fontWeight: '500', color: 'var(--text-main)' }}>
                      Default Inventory Unit
                    </label>
                    <select
                      name="defaultUnit"
                      value={storeDetails.defaultUnit}
                      onChange={handleChange}
                      style={{
                        padding: '9px 12px',
                        borderRadius: 'var(--radius-md)',
                        border: '1px solid var(--border-color)',
                        backgroundColor: '#FFFFFF',
                        fontSize: '0.875rem',
                        color: 'var(--text-main)',
                        outline: 'none'
                      }}
                    >
                      <option value="Pieces (Pcs)">Pieces (Pcs) - Standard Clothing</option>
                      <option value="Sets (Set)">Sets (Suit, Kurta-Pajama set)</option>
                      <option value="Pairs (Pr)">Pairs (Socks, Gloves)</option>
                    </select>
                  </div>
                </div>
              </div>
            </CardContent>

            <CardFooter style={{ justifyContent: 'space-between' }}>
              <Button variant="secondary" size="md" onClick={handleBack} disabled={isLoading}>
                <ArrowLeft size={16} style={{ marginRight: '6px' }} />
                <span>Back</span>
              </Button>
              <Button variant="primary" size="md" onClick={handleNext} isLoading={isLoading}>
                <span>Review & Complete</span>
                <ArrowRight size={16} style={{ marginLeft: '6px' }} />
              </Button>
            </CardFooter>
          </Card>
        )}

        {/* STEP 4: COMPLETE SETUP */}
        {currentStep === 4 && (
          <Card className="animate-fade-in">
            <CardHeader>
              <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                <Sparkles size={20} color="#7EAFD0" />
                <CardTitle>STEP 4: Complete Setup & Activation</CardTitle>
              </div>
              <CardDescription>
                Review your store foundation parameters before entering the Westsides Management Dashboard.
              </CardDescription>
            </CardHeader>

            <CardContent>
              <div
                style={{
                  backgroundColor: 'var(--primary-light)',
                  border: '1px solid #D4E6F1',
                  borderRadius: 'var(--radius-md)',
                  padding: '1.25rem',
                  marginBottom: '1.5rem'
                }}
              >
                <div style={{ display: 'flex', alignItems: 'center', gap: '8px', marginBottom: '8px' }}>
                  <ShieldCheck size={18} color="#7EAFD0" />
                  <span style={{ fontWeight: '600', fontSize: '0.9375rem', color: '#2C5773' }}>
                    Multi-Tenant Verification Summary
                  </span>
                </div>
                <p style={{ fontSize: '0.8125rem', color: '#4B7C9E', lineHeight: '1.4' }}>
                  Your store has been provisioned with an isolated tenant boundary in the database. Only users explicitly assigned to this store will have access to your clothing store data.
                </p>
              </div>

              <div
                style={{
                  display: 'grid',
                  gridTemplateColumns: 'repeat(auto-fit, minmax(240px, 1fr))',
                  gap: '1rem',
                  fontSize: '0.875rem'
                }}
              >
                <div style={{ padding: '0.75rem', backgroundColor: 'var(--bg-page)', borderRadius: 'var(--radius-md)' }}>
                  <div style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>Store Name</div>
                  <div style={{ fontWeight: '600', color: 'var(--text-main)', marginTop: '2px' }}>{storeDetails.name}</div>
                </div>

                <div style={{ padding: '0.75rem', backgroundColor: 'var(--bg-page)', borderRadius: 'var(--radius-md)' }}>
                  <div style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>Owner Account</div>
                  <div style={{ fontWeight: '600', color: 'var(--text-main)', marginTop: '2px' }}>{user?.name} ({user?.email})</div>
                </div>

                <div style={{ padding: '0.75rem', backgroundColor: 'var(--bg-page)', borderRadius: 'var(--radius-md)' }}>
                  <div style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>Assigned Role</div>
                  <div style={{ fontWeight: '600', color: '#4B7C9E', marginTop: '2px' }}>{role || 'OWNER'} (Full Platform Access)</div>
                </div>

                <div style={{ padding: '0.75rem', backgroundColor: 'var(--bg-page)', borderRadius: 'var(--radius-md)' }}>
                  <div style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>GST / Tax Number</div>
                  <div style={{ fontWeight: '600', color: 'var(--text-main)', marginTop: '2px' }}>
                    {storeDetails.gstNumber || 'Not configured'}
                  </div>
                </div>

                <div style={{ padding: '0.75rem', backgroundColor: 'var(--bg-page)', borderRadius: 'var(--radius-md)' }}>
                  <div style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>Category & Currency</div>
                  <div style={{ fontWeight: '600', color: 'var(--text-main)', marginTop: '2px' }}>
                    {storeDetails.category} • {storeDetails.currency}
                  </div>
                </div>

                <div style={{ padding: '0.75rem', backgroundColor: 'var(--bg-page)', borderRadius: 'var(--radius-md)' }}>
                  <div style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>Location</div>
                  <div style={{ fontWeight: '600', color: 'var(--text-main)', marginTop: '2px' }}>
                    {storeDetails.city || 'Mumbai'}, {storeDetails.state || 'Maharashtra'}
                  </div>
                </div>
              </div>
            </CardContent>

            <CardFooter style={{ justifyContent: 'space-between' }}>
              <Button variant="secondary" size="md" onClick={handleBack} disabled={isLoading}>
                <ArrowLeft size={16} style={{ marginRight: '6px' }} />
                <span>Back</span>
              </Button>
              <Button variant="primary" size="lg" onClick={handleNext} isLoading={isLoading}>
                <CheckCircle2 size={18} style={{ marginRight: '8px' }} />
                <span>Launch Westsides Dashboard</span>
              </Button>
            </CardFooter>
          </Card>
        )}
      </div>
    </div>
  );
}
