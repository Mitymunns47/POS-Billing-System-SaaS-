const express = require('express');
const router = express.Router();
const UserModel = require('../models/userModel');
const StoreModel = require('../models/storeModel');
const StoreUserModel = require('../models/storeUserModel');
const SessionModel = require('../models/sessionModel');
const UserPermissionModel = require('../models/userPermissionModel');
const authMiddleware = require('../middleware/auth');
const PlatformAdminModel = require('../models/platformAdminModel'); // Phase 7
const { ROLES, ROLE_PERMISSIONS } = require('../constants/roles');

// Helper: Email validation regex
const EMAIL_REGEX = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

/**
 * POST /api/auth/signup
 * Create store + owner user + assign OWNER role + initiate session
 */
router.post('/signup', (req, res) => {
  try {
    const {
      ownerName,
      email,
      phone,
      password,
      confirmPassword,
      storeName,
      storeAddress,
      city,
      state,
      country,
      gstNumber,
      storePhone
    } = req.body;

    // Validation (Supports web form ownerName and mobile API name)
    const effectiveOwnerName = ownerName || req.body.name;
    const effectiveConfirmPassword = confirmPassword !== undefined ? confirmPassword : password;

    if (!effectiveOwnerName || !effectiveOwnerName.trim()) {
      return res.status(400).json({ success: false, error: 'Owner name is required.' });
    }

    if (!email || !EMAIL_REGEX.test(email.trim())) {
      return res.status(400).json({ success: false, error: 'A valid email address is required.' });
    }

    if (!password || password.length < 6) {
      return res.status(400).json({ success: false, error: 'Password must be at least 6 characters long.' });
    }

    if (password !== effectiveConfirmPassword) {
      return res.status(400).json({ success: false, error: 'Passwords do not match.' });
    }

    const finalStoreName = (storeName && storeName.trim()) ? storeName.trim() : 'Westsides';

    // Duplicate email check
    const existingUser = UserModel.findByEmail(email);
    if (existingUser) {
      return res.status(400).json({
        success: false,
        error: 'An account with this email already exists. Please log in or use another email.'
      });
    }

    // 1. Create Store
    const store = StoreModel.create({
      name: finalStoreName,
      address: storeAddress || '',
      city: city || '',
      state: state || '',
      country: country || 'India',
      gstNumber: gstNumber || '',
      phone: storePhone || phone || ''
    });

    // 2. Create User (Owner)
    const user = UserModel.create({
      name: effectiveOwnerName,
      email: email,
      phone: phone || '',
      password: password
    });

    // 3. Assign OWNER role in store_users
    const storeUser = StoreUserModel.create({
      storeId: store.id,
      userId: user.id,
      role: ROLES.OWNER
    });

    // 4. Create authenticated session
    const session = SessionModel.create({
      userId: user.id,
      storeId: store.id
    });

    // Set cookie
    res.cookie('westsides_session', session.token, {
      httpOnly: true,
      secure: process.env.NODE_ENV === 'production',
      sameSite: 'lax',
      maxAge: 24 * 60 * 60 * 1000
    });

    return res.status(201).json({
      success: true,
      message: 'Store and Owner account created successfully.',
      token: session.token,
      user: {
        id: user.id,
        name: user.name,
        email: user.email,
        phone: user.phone
      },
      store: {
        id: store.id,
        name: store.name,
        onboardingCompleted: store.onboardingCompleted,
        onboardingStep: store.onboardingStep
      },
      role: storeUser.role,
      permissions: ROLE_PERMISSIONS[storeUser.role]
    });
  } catch (err) {
    console.error('Signup error:', err);
    return res.status(500).json({
      success: false,
      error: 'An error occurred while creating your store. Please check your information and try again.'
    });
  }
});

/**
 * POST /api/auth/login
 * Authenticate existing user, resolve store & role, create session
 */
router.post('/login', (req, res) => {
  try {
    const { email, password, rememberMe } = req.body;

    if (!email || !email.trim()) {
      return res.status(400).json({ success: false, error: 'Please enter your email or username.' });
    }

    if (!password) {
      return res.status(400).json({ success: false, error: 'Please enter your password.' });
    }

    const user = UserModel.findByEmail(email);
    if (!user) {
      return res.status(401).json({
        success: false,
        error: 'Invalid email or password. Please verify your credentials.'
      });
    }

    const isMatch = UserModel.verifyPassword(password, user.passwordHash);
    if (!isMatch) {
      return res.status(401).json({
        success: false,
        error: 'Invalid email or password. Please verify your credentials.'
      });
    }

    // Resolve store for user
    const stores = StoreUserModel.getStoresForUser(user.id);
    if (!stores || stores.length === 0) {
      return res.status(403).json({
        success: false,
        error: 'No active store associated with this account. Please contact SaaS support.'
      });
    }

    // Default to the first store
    const primaryStore = stores[0];

    // Check if staff account is deactivated
    if (primaryStore.staffStatus === 'INACTIVE') {
      return res.status(403).json({
        success: false,
        code: 'ACCOUNT_INACTIVE',
        error: 'This staff account has been deactivated. Please contact your store administrator.'
      });
    }

    // Update last login timestamp
    try {
      const now = new Date().toISOString();
      const db = require('../db/database');
      db.prepare('UPDATE store_users SET lastLoginAt = ? WHERE storeId = ? AND userId = ?').run(now, primaryStore.id, user.id);
    } catch {
      // Ignore
    }

    // Create session
    const session = SessionModel.create({
      userId: user.id,
      storeId: primaryStore.id
    });

    const cookieMaxAge = rememberMe ? 7 * 24 * 60 * 60 * 1000 : 24 * 60 * 60 * 1000;

    res.cookie('westsides_session', session.token, {
      httpOnly: true,
      secure: process.env.NODE_ENV === 'production',
      sameSite: 'lax',
      maxAge: cookieMaxAge
    });

    const permissions = UserPermissionModel.getUserPermissions(primaryStore.id, user.id, primaryStore.role);

    return res.json({
      success: true,
      message: 'Logged in successfully.',
      token: session.token,
      user: {
        id: user.id,
        name: user.name,
        email: user.email,
        phone: user.phone
      },
      store: {
        id: primaryStore.id,
        name: primaryStore.name,
        onboardingCompleted: primaryStore.onboardingCompleted,
        onboardingStep: primaryStore.onboardingStep
      },
      role: primaryStore.role,
      permissions
    });
  } catch (err) {
    console.error('Login error:', err);
    return res.status(500).json({
      success: false,
      error: 'An unexpected authentication error occurred. Please try again.'
    });
  }
});

/**
 * GET /api/auth/me
 * Validate current session and retrieve tenant, user, and role details
 */
router.get('/me', authMiddleware, (req, res) => {
  return res.json({
    success: true,
    user: {
      id: req.auth.userId,
      name: req.auth.userName,
      email: req.auth.userEmail,
      phone: req.auth.userPhone
    },
    store: {
      id: req.auth.storeId,
      name: req.auth.storeName,
      onboardingCompleted: req.auth.onboardingCompleted,
      onboardingStep: req.auth.onboardingStep
    },
    role: req.auth.role,
    permissions: req.auth.permissions
  });
});

/**
 * POST /api/auth/logout
 * Invalidate session from database and clear cookie
 */
router.post('/logout', (req, res) => {
  let token = null;
  if (req.cookies && req.cookies.westsides_session) {
    token = req.cookies.westsides_session;
  } else if (req.headers.authorization && req.headers.authorization.startsWith('Bearer ')) {
    token = req.headers.authorization.substring(7);
  }

  if (token) {
    SessionModel.delete(token);
  }

  res.clearCookie('westsides_session');
  return res.json({
    success: true,
    message: 'Logged out successfully. Authenticated session destroyed.'
  });
});

/**
 * POST /api/auth/forgot-password
 * Handles password reset request
 */
router.post('/forgot-password', (req, res) => {
  const { email } = req.body;

  if (!email || !EMAIL_REGEX.test(email.trim())) {
    return res.status(400).json({
      success: false,
      error: 'Please enter a valid registered email address.'
    });
  }

  const user = UserModel.findByEmail(email);

  // Return a friendly message regardless of whether user exists for security
  return res.json({
    success: true,
    message: user
      ? `Password reset instructions have been sent to ${email.trim()}.`
      : 'If an account exists with this email, password reset instructions have been dispatched.'
  });
});

/**
 * PUT /api/auth/profile
 * Update user profile details
 */
router.put('/profile', authMiddleware, (req, res) => {
  try {
    const { name, phone } = req.body;
    if (!name || !name.trim()) {
      return res.status(400).json({ success: false, error: 'Name cannot be empty.' });
    }

    const updated = UserModel.updateProfile(req.auth.userId, { name, phone });
    return res.json({
      success: true,
      message: 'Profile updated successfully.',
      user: {
        id: updated.id,
        name: updated.name,
        email: updated.email,
        phone: updated.phone
      }
    });
  } catch (err) {
    console.error('Update profile error:', err);
    return res.status(500).json({ success: false, error: 'Could not update profile.' });
  }
});

/**
 * POST /api/auth/admin-login
 * Phase 7: Platform Super Admin login — only succeeds if user is in platform_admins table.
 */
router.post('/admin-login', (req, res) => {
  try {
    const { email, password } = req.body;

    if (!email || !email.trim()) {
      return res.status(400).json({ success: false, error: 'Email is required.' });
    }
    if (!password) {
      return res.status(400).json({ success: false, error: 'Password is required.' });
    }

    const user = UserModel.findByEmail(email.trim().toLowerCase());
    if (!user) {
      return res.status(401).json({ success: false, error: 'Invalid credentials.' });
    }

    const isMatch = UserModel.verifyPassword(password, user.passwordHash);
    if (!isMatch) {
      return res.status(401).json({ success: false, error: 'Invalid credentials.' });
    }

    // CRITICAL: verify this user is actually a Super Admin
    const isAdmin = PlatformAdminModel.isSuperAdmin(user.id);
    if (!isAdmin) {
      return res.status(403).json({
        success: false,
        error: 'Access denied. This account does not have Super Admin platform privileges.'
      });
    }

    // Find the platform HQ store for session creation
    const db = require('../db/database');
    const platformStore = db.prepare("SELECT * FROM store_users su JOIN stores s ON su.storeId = s.id WHERE su.userId = ? AND s.name = 'Westsides Platform' LIMIT 1").get(user.id);
    if (!platformStore) {
      return res.status(500).json({ success: false, error: 'Platform admin store not configured. Run seed-superadmin.js first.' });
    }

    const session = SessionModel.create({ userId: user.id, storeId: platformStore.storeId });

    res.cookie('westsides_session', session.token, {
      httpOnly: true,
      secure: process.env.NODE_ENV === 'production',
      sameSite: 'lax',
      maxAge: 8 * 60 * 60 * 1000 // 8 hours for admin sessions
    });

    return res.json({
      success: true,
      message: 'Super Admin login successful.',
      token: session.token,
      isSuperAdmin: true,
      user: {
        id: user.id,
        name: user.name,
        email: user.email
      }
    });
  } catch (err) {
    console.error('Admin login error:', err);
    return res.status(500).json({ success: false, error: 'Authentication error. Please try again.' });
  }
});

module.exports = router;
