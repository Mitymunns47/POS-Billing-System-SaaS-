import React, { useState } from 'react';
import { api } from '../services/api';
import { Button } from '../components/ui/Button';
import { Input } from '../components/ui/Input';
import { Card, CardContent } from '../components/ui/Card';
import { Alert } from '../components/ui/Alert';
import { Mail, ArrowLeft, CheckCircle2, Shield } from 'lucide-react';

export function ForgotPasswordPage({ onNavigate }) {
  const [email, setEmail] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [alert, setAlert] = useState(null);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setAlert(null);

    if (!email.trim()) {
      setAlert({ variant: 'danger', message: 'Please enter your registered email address.' });
      return;
    }

    setIsLoading(true);

    try {
      const res = await api.forgotPassword(email);
      setAlert({
        variant: 'success',
        message: res.message || 'Password reset instructions have been dispatched.'
      });
    } catch (err) {
      setAlert({
        variant: 'danger',
        message: err.message || 'Unable to process password reset request.'
      });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div
      style={{
        minHeight: '100vh',
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center',
        justifyContent: 'center',
        backgroundColor: 'var(--bg-page)',
        padding: '1.5rem'
      }}
    >
      <div style={{ width: '100%', maxWidth: '420px' }} className="animate-fade-in">
        <div style={{ textAlign: 'center', marginBottom: '2rem' }}>
          <div
            style={{
              width: '44px',
              height: '44px',
              borderRadius: '10px',
              backgroundColor: '#7EAFD0',
              display: 'inline-flex',
              alignItems: 'center',
              justifyContent: 'center',
              color: '#FFFFFF',
              fontWeight: '700',
              fontSize: '1.25rem',
              boxShadow: '0 4px 10px rgba(126, 175, 208, 0.3)',
              marginBottom: '0.75rem'
            }}
          >
            W
          </div>
          <h1 style={{ fontSize: '1.5rem', fontWeight: '700', color: 'var(--text-main)', margin: '0 0 4px 0' }}>
            Reset Password
          </h1>
          <p style={{ fontSize: '0.8125rem', color: 'var(--text-muted)' }}>
            Enter your registered store email to receive password recovery instructions.
          </p>
        </div>

        <Card style={{ padding: '0.5rem' }}>
          <CardContent>
            {alert && (
              <Alert variant={alert.variant} style={{ marginBottom: '1.25rem' }}>
                {alert.message}
              </Alert>
            )}

            <form onSubmit={handleSubmit} style={{ display: 'flex', flexDirection: 'column', gap: '1.25rem' }}>
              <Input
                label="Registered Email"
                id="reset-email"
                type="email"
                placeholder="storeowner@westsides.com"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                required
                startIcon={<Mail size={16} />}
              />

              <Button
                type="submit"
                variant="primary"
                size="lg"
                isLoading={isLoading}
                style={{ width: '100%' }}
              >
                Send Reset Link
              </Button>
            </form>
          </CardContent>
        </Card>

        <div style={{ marginTop: '1.5rem', textAlign: 'center' }}>
          <button
            type="button"
            onClick={() => onNavigate('/login')}
            style={{
              display: 'inline-flex',
              alignItems: 'center',
              gap: '6px',
              background: 'none',
              border: 'none',
              color: '#7EAFD0',
              fontWeight: '500',
              fontSize: '0.875rem',
              cursor: 'pointer'
            }}
          >
            <ArrowLeft size={16} />
            <span>Return to Sign In</span>
          </button>
        </div>
      </div>
    </div>
  );
}
