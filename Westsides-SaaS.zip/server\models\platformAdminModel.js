const crypto = require('crypto');
const db = require('../db/database');

const PlatformAdminModel = {
  /** Check if a userId has SUPER_ADMIN platform role */
  isSuperAdmin: (userId) => {
    const row = db.prepare(
      'SELECT id FROM platform_admins WHERE userId = ? AND isActive = 1'
    ).get(userId);
    return !!row;
  },

  findByUserId: (userId) => {
    return db.prepare(`
      SELECT pa.*, u.name as userName, u.email as userEmail
      FROM platform_admins pa
      JOIN users u ON pa.userId = u.id
      WHERE pa.userId = ?
    `).get(userId);
  },

  create: ({ userId, platformRole = 'SUPER_ADMIN', createdBy = null }) => {
    const id = 'padm_' + crypto.randomBytes(8).toString('hex');
    const now = new Date().toISOString();
    db.prepare(`
      INSERT INTO platform_admins (id, userId, platformRole, isActive, createdBy, createdAt, updatedAt)
      VALUES (?, ?, ?, 1, ?, ?, ?)
    `).run(id, userId, platformRole, createdBy, now, now);
    return PlatformAdminModel.findByUserId(userId);
  },

  listAll: () => {
    return db.prepare(`
      SELECT pa.*, u.name as userName, u.email as userEmail, u.phone as userPhone
      FROM platform_admins pa
      JOIN users u ON pa.userId = u.id
      ORDER BY pa.createdAt ASC
    `).all();
  }
};

module.exports = PlatformAdminModel;
