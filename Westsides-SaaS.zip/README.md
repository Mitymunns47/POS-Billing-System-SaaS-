# Westsides — Enterprise Multi-Tenant Clothing Store Management SaaS

Westsides is a complete, production-ready multi-tenant SaaS application built for modern apparel, boutique, and clothing retail stores. It provides end-to-end store operations—from barcode scanning and POS checkout to inventory tracking, customer loyalty CRM, expense management, returns/refunds, real-time analytics, and platform-level subscription management—while strictly isolating each tenant's data.

---

## 🎨 Visual Identity & Brand Guidelines
- **Product Name**: Westsides
- **Primary Color**: `#7EAFD0` (Sky-Blue Accent)
- **Background**: `#F7FAFC`
- **Surface / Card**: `#FFFFFF`
- **Dark Text**: `#172033`
- **Secondary Text**: `#64748B`
- **Border**: `#E2E8F0`
- **Aesthetic**: Minimal, clean, white-first design with subtle shadows, responsive tables, and collapsible sidebar.

---

## 🏗️ Architecture & Technology Stack
- **Backend**: Node.js (v20+ / v24) with Express
- **Database**: SQLite with native WAL mode (`node:sqlite` DatabaseSync)
- **Security & Middlewares**:
  - `securityHeaders`: X-Content-Type-Options, X-Frame-Options, Referrer-Policy, Cache-Control
  - `idempotencyMiddleware`: Prevents duplicate POS checkouts, returns, and expenses
  - `rateLimiter`: Protects authentication against brute-force attacks
  - `tenantIsolationMiddleware`: Strict query scoping by authenticated `storeId`
  - `requireSuperAdmin`: Separate authorization using `platform_admins` table
- **Frontend**: React 19, Vanilla CSS design system, Lucide icons, Vite 8
- **Mobile API Foundation**: Dual-mounted API at `/api` and `/api/v1` supporting `Authorization: Bearer <token>` for future iOS/Android native applications.

---

## 📦 Feature Modules (Phases 1–8)

1. **Authentication & Multi-Tenant Store Setup**:
   - Secure store owner registration and tenant onboarding wizard.
   - HttpOnly session cookies + Bearer token support.
   - User roles: `OWNER`, `MANAGER`, `CASHIER`, `STAFF`.
2. **Apparel Product Catalog & Variant Engine**:
   - Clothing categories, brands, colors, sizes, barcodes, and SKUs.
   - Product archiving (preserves historical sales data).
3. **Inventory & Stock Movements**:
   - Real-time stock counts with atomic deductions on sale.
   - Stock adjustments with audit trail and movement history.
   - Low-stock and out-of-stock operational warnings.
4. **Point of Sale (POS) & Billing**:
   - Fast product search and barcode scanner support.
   - Cart calculations with discounts, GST tax, and cash change.
   - Atomic checkout with sequential, collision-safe invoice numbers (`WS-000001`).
   - Idempotency protection against double-clicks.
5. **Customer Relationship Management (CRM)**:
   - Customer directory with search by phone/name.
   - Lifetime order counts and spend tracking.
6. **Business Intelligence & Financial Reports**:
   - Real-time dashboard KPI cards.
   - Date-filtered sales, inventory valuation, and category breakdown.
   - One-click CSV export for external bookkeeping.
7. **Operational Controls, Returns & Expenses**:
   - Pro-rated returns & refunds with automatic inventory restocking.
   - Categorized operating expense tracker.
   - Store settings: GST tax toggle, invoice prefix, discount caps.
8. **SaaS Platform Administration (`/admin`)**:
   - Platform dashboard with Monthly Recurring Revenue (MRR) and tenant counts.
   - Plan tiers (`Free`, `Basic`, `Pro`, `Enterprise`) and entitlement enforcement.
   - Tenant lifecycle: suspend and reactivate stores with audit tracking.
   - Platform billing invoices and collection tracking.

---

## 🚀 Getting Started Locally

### 1. Environment Configuration
Copy `.env.example` to `.env`:
```bash
cp .env.example .env
```

### 2. Install Dependencies
```bash
npm install
```

### 3. Seed Default Super Admin & Store Subscriptions
```bash
npm run seed:superadmin
npm run seed:subscriptions
```

### 4. Build Frontend Bundle
```bash
npm run build
```

### 5. Start the Production Server
```bash
npm start
```
The server will be running on `http://localhost:5000`.

---

## 🔑 Default Credentials

| Portal | Role | URL | Email | Password |
|---|---|---|---|---|
| **Platform Admin** | Super Admin | `http://localhost:5000/admin` | `superadmin@westsides.com` | `Westsides@SuperAdmin2026!` |
| **Store Portal** | Store Owner | `http://localhost:5000/login` | Register a new store via `/signup` or use existing store login |

---

## 🧪 Testing & Quality Assurance

Run the comprehensive Phase 8 End-to-End Test Suite:
```bash
npm run test:e2e
```
This tests all 7 core workflows (A–G), multi-tenant isolation, idempotency duplicate prevention, and rate-limiting across 48 automated assertions.

Run multi-tenant foundation isolation tests:
```bash
npm test
```

---

## 🛡️ Production & Disaster Recovery Protocol

### 1. Database Backup Strategy
The SQLite database operates in **WAL mode** (`westsides_saas.sqlite-wal`). For consistent backups without downtime:
- Run a SQLite VACUUM INTO backup command:
  ```bash
  node -e "const db = require('./server/db/database'); db.exec(\"VACUUM INTO 'backup-\" + Date.now() + \".sqlite'\");"
  ```
- Schedule a daily cron job to copy the generated backup file to encrypted offsite object storage (AWS S3, Google Cloud Storage, or Azure Blob).

### 2. Restore Procedure
1. Stop the application server: `pm2 stop westsides` (or `systemctl stop westsides`).
2. Replace `westsides_saas.sqlite` with the backup file.
3. Remove any remaining `-wal` or `-shm` temporary files.
4. Restart the server: `pm2 start server/server.js`.

### 3. Production Deployment Sequence
1. Set `NODE_ENV=production` in `.env`.
2. Generate secure 32+ character keys for `JWT_SECRET` and `SESSION_SECRET`.
3. Build the frontend: `npm run build`.
4. Run the test suite: `npm run test:e2e`.
5. Use a reverse proxy (Nginx or Caddy) with SSL/TLS termination (HTTPS).
6. Run the Node process using PM2 or Docker:
   ```bash
   pm2 start server/server.js --name "westsides-saas"
   ```

---

## 📱 Mobile Application API Reference
For complete documentation on integrating mobile applications using `/api/v1/*` with Bearer tokens and idempotency keys, see [`docs/api.md`](./docs/api.md).
