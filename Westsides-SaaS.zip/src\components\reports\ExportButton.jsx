import React, { useState } from 'react';
import { Download } from 'lucide-react';
import { Button } from '../ui/Button';
import { api } from '../../services/api';

export function ExportButton({ type, params = {}, filename = 'report.csv', label = 'Export CSV' }) {
  const [exporting, setExporting] = useState(false);

  const handleExport = async () => {
    try {
      setExporting(true);
      const url = api.getExportUrl(type, params);
      const token = api.token;

      const response = await fetch(url, {
        headers: {
          ...(token ? { Authorization: `Bearer ${token}` } : {})
        },
        credentials: 'include'
      });

      if (!response.ok) {
        throw new Error('Export failed. Please check permissions.');
      }

      const blob = await response.blob();
      const downloadUrl = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = downloadUrl;
      a.download = filename;
      document.body.appendChild(a);
      a.click();
      a.remove();
      window.URL.revokeObjectURL(downloadUrl);
    } catch (err) {
      console.error('Export error:', err);
      alert(err.message || 'Could not export report.');
    } finally {
      setExporting(false);
    }
  };

  return (
    <Button
      variant="outline"
      size="sm"
      onClick={handleExport}
      isLoading={exporting}
      style={{ display: 'flex', alignItems: 'center', gap: '6px' }}
    >
      <Download size={15} />
      <span>{label}</span>
    </Button>
  );
}
