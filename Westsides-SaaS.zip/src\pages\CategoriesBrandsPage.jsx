import React, { useState, useEffect, useCallback } from 'react';
import { api } from '../services/api';
import { Button } from '../components/ui/Button';
import { Input } from '../components/ui/Input';
import { Badge } from '../components/ui/Badge';
import { Alert } from '../components/ui/Alert';
import { Modal } from '../components/ui/Modal';
import { Plus, Edit2, Trash2, Tag, Layers } from 'lucide-react';

const inputSx = {
  padding: '8px 12px', borderRadius: '6px', border: '1px solid var(--border-color)',
  fontSize: '0.875rem', color: 'var(--text-main)', backgroundColor: '#fff',
  width: '100%', outline: 'none', fontFamily: 'inherit'
};

// ── Generic CRUD manager for categories or brands ─────────────────────────────
function CatalogManager({ title, icon: Icon, items, onAdd, onEdit, onDelete, placeholder }) {
  const [editItem, setEditItem] = useState(null);
  const [newName, setNewName] = useState('');
  const [newDesc, setNewDesc] = useState('');
  const [showForm, setShowForm] = useState(false);
  const [saving, setSaving] = useState(false);
  const [deleting, setDeleting] = useState(null);
  const [localAlert, setLocalAlert] = useState(null);

  const resetForm = () => { setNewName(''); setNewDesc(''); setEditItem(null); setShowForm(false); };

  const handleSave = async () => {
    if (!newName.trim()) { setLocalAlert({ variant: 'danger', message: `${title.slice(0, -1)} name is required.` }); return; }
    setSaving(true);
    setLocalAlert(null);
    try {
      if (editItem) {
        await onEdit(editItem.id, { name: newName, description: newDesc });
      } else {
        await onAdd({ name: newName, description: newDesc });
      }
      resetForm();
    } catch (err) {
      setLocalAlert({ variant: 'danger', message: err.message });
    } finally {
      setSaving(false);
    }
  };

  const handleDelete = async (id) => {
    setDeleting(id);
    try {
      await onDelete(id);
    } catch (err) {
      setLocalAlert({ variant: 'danger', message: err.message });
    } finally {
      setDeleting(null);
    }
  };

  return (
    <div style={{ backgroundColor: '#fff', borderRadius: 'var(--radius-lg)', border: '1px solid var(--border-color)', overflow: 'hidden', boxShadow: 'var(--shadow-sm)' }}>
      {/* Header */}
      <div style={{ padding: '1rem 1.25rem', borderBottom: '1px solid var(--border-subtle)', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
          <Icon size={18} color="#7EAFD0" />
          <span style={{ fontWeight: '600', fontSize: '1rem', color: 'var(--text-main)' }}>{title}</span>
          <Badge variant="neutral" size="sm">{items.length}</Badge>
        </div>
        <Button variant="outline" size="sm" onClick={() => { setNewName(''); setNewDesc(''); setEditItem(null); setShowForm(true); }}>
          <Plus size={13} style={{ marginRight: '4px' }} /> Add
        </Button>
      </div>

      {localAlert && (
        <div style={{ padding: '0.75rem 1.25rem', borderBottom: '1px solid var(--border-subtle)' }}>
          <Alert variant={localAlert.variant} onDismiss={() => setLocalAlert(null)}>{localAlert.message}</Alert>
        </div>
      )}

      {/* List */}
      <div style={{ maxHeight: '380px', overflowY: 'auto' }}>
        {items.length === 0 ? (
          <div style={{ padding: '2rem', textAlign: 'center', color: 'var(--text-muted)', fontSize: '0.875rem' }}>
            No {title.toLowerCase()} yet. Click "Add" to create one.
          </div>
        ) : items.map((item, idx) => (
          <div key={item.id} style={{
            padding: '10px 1.25rem', display: 'flex', alignItems: 'center', justifyContent: 'space-between',
            borderBottom: idx < items.length - 1 ? '1px solid var(--border-subtle)' : 'none'
          }}>
            <div>
              <div style={{ fontSize: '0.875rem', fontWeight: '500', color: 'var(--text-main)' }}>{item.name}</div>
              {item.description && <div style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>{item.description}</div>}
            </div>
            <div style={{ display: 'flex', gap: '4px' }}>
              <button onClick={() => { setEditItem(item); setNewName(item.name); setNewDesc(item.description || ''); setShowForm(true); }}
                style={{ background: 'none', border: 'none', cursor: 'pointer', color: 'var(--text-muted)', padding: '4px', borderRadius: '4px' }}>
                <Edit2 size={13} />
              </button>
              <button onClick={() => handleDelete(item.id)} disabled={deleting === item.id}
                style={{ background: 'none', border: 'none', cursor: 'pointer', color: 'var(--danger)', padding: '4px', borderRadius: '4px' }}>
                <Trash2 size={13} />
              </button>
            </div>
          </div>
        ))}
      </div>

      {/* Add/Edit modal */}
      <Modal isOpen={showForm} onClose={resetForm} title={editItem ? `Edit ${title.slice(0, -1)}` : `Add ${title.slice(0, -1)}`} width="440px">
        <div style={{ display: 'flex', flexDirection: 'column', gap: '1rem' }}>
          <Input label="Name" id={`${title}-name`} value={newName} onChange={e => setNewName(e.target.value)} required placeholder={placeholder} />
          <div style={{ display: 'flex', flexDirection: 'column', gap: '6px' }}>
            <label style={{ fontSize: '0.875rem', fontWeight: '500', color: 'var(--text-main)' }}>Description <span style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>(optional)</span></label>
            <textarea value={newDesc} onChange={e => setNewDesc(e.target.value)} rows={2} style={{ ...inputSx, resize: 'vertical' }} />
          </div>
          <div style={{ display: 'flex', justifyContent: 'flex-end', gap: '0.75rem' }}>
            <Button variant="secondary" size="md" onClick={resetForm} disabled={saving}>Cancel</Button>
            <Button variant="primary" size="md" isLoading={saving} onClick={handleSave}>
              {editItem ? 'Save Changes' : 'Create'}
            </Button>
          </div>
        </div>
      </Modal>
    </div>
  );
}

// ── Categories & Brands Page ──────────────────────────────────────────────────
export function CategoriesBrandsPage({ onNavigate }) {
  const [categories, setCategories] = useState([]);
  const [brands, setBrands] = useState([]);
  const [loading, setLoading] = useState(true);
  const [pageAlert, setPageAlert] = useState(null);

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const [cRes, bRes] = await Promise.all([api.getCategories(), api.getBrands()]);
      if (cRes.success) setCategories(cRes.categories);
      if (bRes.success) setBrands(bRes.brands);
    } catch (err) {
      setPageAlert({ variant: 'danger', message: err.message });
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { load(); }, [load]);

  const wrapAction = (fn) => async (...args) => {
    const res = await fn(...args);
    if (res.success) { setPageAlert({ variant: 'success', message: res.message }); await load(); }
  };

  return (
    <div style={{ maxWidth: '1100px', margin: '0 auto' }} className="animate-fade-in">
      {/* Header */}
      <div style={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', marginBottom: '1.5rem', flexWrap: 'wrap', gap: '0.75rem' }}>
        <div>
          <h1 style={{ fontSize: '1.5rem', fontWeight: '700', color: 'var(--text-main)', margin: '0 0 4px 0' }}>Categories & Brands</h1>
          <p style={{ fontSize: '0.875rem', color: 'var(--text-muted)', margin: 0 }}>Organize your clothing catalog with custom categories and brands.</p>
        </div>
        <Button variant="secondary" size="md" onClick={() => onNavigate('/products')}>
          ← Back to Products
        </Button>
      </div>

      {pageAlert && (
        <Alert variant={pageAlert.variant} style={{ marginBottom: '1.25rem' }} onDismiss={() => setPageAlert(null)}>
          {pageAlert.message}
        </Alert>
      )}

      {loading ? (
        <div style={{ padding: '3rem', textAlign: 'center', color: 'var(--text-muted)', fontSize: '0.875rem' }}>Loading…</div>
      ) : (
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(340px, 1fr))', gap: '1.5rem' }}>
          <CatalogManager
            title="Categories"
            icon={Tag}
            items={categories}
            placeholder="e.g. Men, T-Shirts, Jeans…"
            onAdd={wrapAction((d) => api.createCategory(d))}
            onEdit={wrapAction((id, d) => api.updateCategory(id, d))}
            onDelete={wrapAction((id) => api.deleteCategory(id))}
          />
          <CatalogManager
            title="Brands"
            icon={Layers}
            items={brands}
            placeholder="e.g. Levis, H&M, Zara…"
            onAdd={wrapAction((d) => api.createBrand(d))}
            onEdit={wrapAction((id, d) => api.updateBrand(id, d))}
            onDelete={wrapAction((id) => api.deleteBrand(id))}
          />
        </div>
      )}
    </div>
  );
}
