import React, { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext';
import { api } from '../services/api';
import { Card, CardHeader, CardTitle, CardDescription, CardContent, CardFooter } from '../components/ui/Card';
import { Button } from '../components/ui/Button';
import { Input } from '../components/ui/Input';
import { Badge } from '../components/ui/Badge';
import { Alert } from '../components/ui/Alert';
import {
  User,
  Store,
  Shield,
  CheckCircle,
  Save,
  Key,
  Layers,
  MapPin,
  Building,
  Phone,
  Mail,
  Receipt
} from 'lucide-react';

export function ProfilePage({ initialTab = 'profile' }) {
  const { user, store, role, permissions, updateUserState, updateStoreState } = useAuth();
  const [activeTab, setActiveTab] = useState(role === 'OWNER' ? initialTab : 'profile');

  useEffect(() => {
    if (role !== 'OWNER' && activeTab !== 'profile') {
      setActiveTab('profile');
    }
  }, [role, activeTab]);

  // User form state
  const [userName, setUserName] = useState(user?.name || '');
  const [userPhone, setUserPhone] = useState(user?.phone || '');
  const [savingUser, setSavingUser] = useState(false);
  const [userAlert, setUserAlert] = useState(null);

  // Store form state
  const [storeForm, setStoreForm] = useState({
    name: '',
    phone: '',
    address: '',
    city: '',
    state: '',
    country: 'India',
    gstNumber: '',
    currency: 'INR',
    receiptHeader: '',
    receiptFooter: ''
  });
  const [savingStore, setSavingStore] = useState(false);
  const [storeAlert, setStoreAlert] = useState(null);

  useEffect(() => {
    async function loadStore() {
      try {
        const res = await api.getCurrentStore();
        if (res.success && res.store) {
          setStoreForm({
            name: res.store.name || '',
            phone: res.store.phone || '',
            address: res.store.address || '',
            city: res.store.city || '',
            state: res.store.state || '',
            country: res.store.country || 'India',
            gstNumber: res.store.gstNumber || '',
            currency: res.store.currency || 'INR',
            receiptHeader: res.store.receiptHeader || '',
            receiptFooter: res.store.receiptFooter || ''
          });
        }
      } catch (err) {
        console.error('Failed to load store settings:', err);
      }
    }
    loadStore();
  }, []);

  const handleSaveProfile = async (e) => {
    e.preventDefault();
    setUserAlert(null);
    setSavingUser(true);

    try {
      const res = await api.updateProfile({ name: userName, phone: userPhone });
      if (res.success) {
        updateUserState({ name: userName, phone: userPhone });
        setUserAlert({ variant: 'success', message: 'Profile updated successfully.' });
      }
    } catch (err) {
      setUserAlert({ variant: 'danger', message: err.message || 'Failed to update profile.' });
    } finally {
      setSavingUser(false);
    }
  };

  const handleSaveStore = async (e) => {
    e.preventDefault();
    setStoreAlert(null);
    setSavingStore(true);

    try {
      const res = await api.updateStore(storeForm);
      if (res.success) {
        updateStoreState({ name: storeForm.name });
        setStoreAlert({ variant: 'success', message: 'Store configuration saved successfully.' });
      }
    } catch (err) {
      setStoreAlert({ variant: 'danger', message: err.message || 'Failed to update store settings.' });
    } finally {
      setSavingStore(false);
    }
  };

  const allModulePermissions = [
    { code: 'dashboard.view', label: 'View Dashboard & Summaries', phase: 'Phase 1' },
    { code: 'billing.view', label: 'View POS & Invoices', phase: 'Phase 4' },
    { code: 'billing.create', label: 'Create New Invoices / Checkout', phase: 'Phase 4' },
    { code: 'products.view', label: 'View Apparel Catalog', phase: 'Phase 2' },
    { code: 'products.create', label: 'Add/Edit Clothing Products', phase: 'Phase 2' },
    { code: 'inventory.view', label: 'View Inventory & Stock Levels', phase: 'Phase 3' },
    { code: 'customers.view', label: 'View Retail Customer Directory', phase: 'Phase 5' },
    { code: 'reports.view', label: 'Access Sales & Tax Reports', phase: 'Phase 6' },
    { code: 'expenses.view', label: 'View Store Operating Expenses', phase: 'Phase 7' },
    { code: 'staff.view', label: 'View Staff & Role Assignments', phase: 'Phase 8' },
    { code: 'settings.view', label: 'Manage Store Configuration', phase: 'Phase 1' }
  ];

  return (
    <div style={{ maxWidth: '960px', margin: '0 auto' }} className="animate-fade-in">
      <div style={{ marginBottom: '1.5rem' }}>
        <h1 style={{ fontSize: '1.5rem', fontWeight: '700', color: 'var(--text-main)', margin: '0 0 4px 0' }}>
          Account & Store Settings
        </h1>
        <p style={{ fontSize: '0.875rem', color: 'var(--text-muted)' }}>
          Manage your personal credentials, store metadata, and role permissions.
        </p>
      </div>

      {/* Tabs */}
      <div
        style={{
          display: 'flex',
          gap: '8px',
          borderBottom: '1px solid var(--border-color)',
          marginBottom: '1.5rem'
        }}
      >
        <button
          onClick={() => setActiveTab('profile')}
          style={{
            padding: '10px 16px',
            border: 'none',
            background: 'none',
            fontSize: '0.875rem',
            fontWeight: activeTab === 'profile' ? '600' : '500',
            color: activeTab === 'profile' ? '#7EAFD0' : 'var(--text-muted)',
            borderBottom: `2px solid ${activeTab === 'profile' ? '#7EAFD0' : 'transparent'}`,
            cursor: 'pointer',
            display: 'flex',
            alignItems: 'center',
            gap: '8px'
          }}
        >
          <User size={16} />
          <span>My Profile</span>
        </button>

        {role === 'OWNER' && (
          <button
            onClick={() => setActiveTab('store')}
            style={{
              padding: '10px 16px',
              border: 'none',
              background: 'none',
              fontSize: '0.875rem',
              fontWeight: activeTab === 'store' ? '600' : '500',
              color: activeTab === 'store' ? '#7EAFD0' : 'var(--text-muted)',
              borderBottom: `2px solid ${activeTab === 'store' ? '#7EAFD0' : 'transparent'}`,
              cursor: 'pointer',
              display: 'flex',
              alignItems: 'center',
              gap: '8px'
            }}
          >
            <Store size={16} />
            <span>Store Details</span>
          </button>
        )}

        {role === 'OWNER' && (
          <button
            onClick={() => setActiveTab('permissions')}
            style={{
              padding: '10px 16px',
              border: 'none',
              background: 'none',
              fontSize: '0.875rem',
              fontWeight: activeTab === 'permissions' ? '600' : '500',
              color: activeTab === 'permissions' ? '#7EAFD0' : 'var(--text-muted)',
              borderBottom: `2px solid ${activeTab === 'permissions' ? '#7EAFD0' : 'transparent'}`,
              cursor: 'pointer',
              display: 'flex',
              alignItems: 'center',
              gap: '8px'
            }}
          >
            <Shield size={16} />
            <span>Role & Permissions</span>
          </button>
        )}
      </div>

      {/* TAB 1: USER PROFILE */}
      {activeTab === 'profile' && (
        <Card>
          <CardHeader>
            <CardTitle>User Profile</CardTitle>
            <CardDescription>Personal credentials associated with this store account.</CardDescription>
          </CardHeader>

          <CardContent>
            {userAlert && (
              <Alert variant={userAlert.variant} style={{ marginBottom: '1.25rem' }}>
                {userAlert.message}
              </Alert>
            )}

            <form onSubmit={handleSaveProfile}>
              <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(280px, 1fr))', gap: '1.25rem' }}>
                <Input
                  label="Full Name"
                  id="profile-name"
                  value={userName}
                  onChange={(e) => setUserName(e.target.value)}
                  required
                  startIcon={<User size={16} />}
                />

                <Input
                  label="Email Address"
                  id="profile-email"
                  value={user?.email || ''}
                  disabled
                  helperText="Email is bound to multi-tenant user identity."
                  startIcon={<Mail size={16} />}
                />

                <Input
                  label="Phone Number"
                  id="profile-phone"
                  value={userPhone}
                  onChange={(e) => setUserPhone(e.target.value)}
                  placeholder="+91 98765 43210"
                  startIcon={<Phone size={16} />}
                />

                <div style={{ display: 'flex', flexDirection: 'column', gap: '6px' }}>
                  <label style={{ fontSize: '0.875rem', fontWeight: '500', color: 'var(--text-main)' }}>
                    Current Role
                  </label>
                  <div style={{ paddingTop: '6px' }}>
                    <Badge variant="primary" size="md">
                      {role || 'OWNER'}
                    </Badge>
                  </div>
                </div>
              </div>

              <div style={{ marginTop: '1.5rem', display: 'flex', justifyContent: 'flex-end' }}>
                <Button type="submit" variant="primary" size="md" isLoading={savingUser}>
                  <Save size={16} style={{ marginRight: '6px' }} />
                  <span>Update Profile</span>
                </Button>
              </div>
            </form>
          </CardContent>
        </Card>
      )}

      {/* TAB 2: STORE SETTINGS */}
      {role === 'OWNER' && activeTab === 'store' && (
        <Card>
          <CardHeader>
            <CardTitle>Store & Business Configuration</CardTitle>
            <CardDescription>Multi-tenant retail settings for {storeForm.name || 'Westsides'}.</CardDescription>
          </CardHeader>

          <CardContent>
            {storeAlert && (
              <Alert variant={storeAlert.variant} style={{ marginBottom: '1.25rem' }}>
                {storeAlert.message}
              </Alert>
            )}

            <form onSubmit={handleSaveStore}>
              <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(280px, 1fr))', gap: '1.25rem' }}>
                <Input
                  label="Store Name"
                  id="store-name"
                  value={storeForm.name}
                  onChange={(e) => setStoreForm({ ...storeForm, name: e.target.value })}
                  required
                  startIcon={<Store size={16} />}
                />

                <Input
                  label="Store Phone"
                  id="store-phone"
                  value={storeForm.phone}
                  onChange={(e) => setStoreForm({ ...storeForm, phone: e.target.value })}
                  startIcon={<Phone size={16} />}
                />

                <div style={{ gridColumn: '1 / -1' }}>
                  <Input
                    label="Store Address"
                    id="store-address"
                    value={storeForm.address}
                    onChange={(e) => setStoreForm({ ...storeForm, address: e.target.value })}
                    startIcon={<MapPin size={16} />}
                  />
                </div>

                <Input
                  label="City"
                  id="store-city"
                  value={storeForm.city}
                  onChange={(e) => setStoreForm({ ...storeForm, city: e.target.value })}
                />

                <Input
                  label="State"
                  id="store-state"
                  value={storeForm.state}
                  onChange={(e) => setStoreForm({ ...storeForm, state: e.target.value })}
                />

                <Input
                  label="Country"
                  id="store-country"
                  value={storeForm.country}
                  onChange={(e) => setStoreForm({ ...storeForm, country: e.target.value })}
                />

                <Input
                  label="GST / Tax Identification Number"
                  id="store-gst"
                  value={storeForm.gstNumber}
                  onChange={(e) => setStoreForm({ ...storeForm, gstNumber: e.target.value })}
                />

                <div style={{ gridColumn: '1 / -1' }}>
                  <Input
                    label="Receipt Header"
                    id="store-receipt-header"
                    value={storeForm.receiptHeader}
                    onChange={(e) => setStoreForm({ ...storeForm, receiptHeader: e.target.value })}
                    helperText="Printed on sales bill header."
                  />
                </div>

                <div style={{ gridColumn: '1 / -1' }}>
                  <Input
                    label="Receipt Footer"
                    id="store-receipt-footer"
                    value={storeForm.receiptFooter}
                    onChange={(e) => setStoreForm({ ...storeForm, receiptFooter: e.target.value })}
                    helperText="Printed on sales bill footer."
                  />
                </div>
              </div>

              <div style={{ marginTop: '1.5rem', display: 'flex', justifyContent: 'flex-end' }}>
                <Button type="submit" variant="primary" size="md" isLoading={savingStore}>
                  <Save size={16} style={{ marginRight: '6px' }} />
                  <span>Save Store Settings</span>
                </Button>
              </div>
            </form>
          </CardContent>
        </Card>
      )}

      {/* TAB 3: ROLE & PERMISSIONS ARCHITECTURE */}
      {role === 'OWNER' && activeTab === 'permissions' && (
        <Card>
          <CardHeader>
            <CardTitle>Role & Permission Matrix</CardTitle>
            <CardDescription>
              Phase 1 foundation for role-based access control (RBAC). Your assigned role is <strong>{role || 'OWNER'}</strong>.
            </CardDescription>
          </CardHeader>

          <CardContent>
            <div
              style={{
                border: '1px solid var(--border-color)',
                borderRadius: 'var(--radius-md)',
                overflow: 'hidden'
              }}
            >
              <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: '0.875rem' }}>
                <thead>
                  <tr style={{ backgroundColor: 'var(--bg-page)', borderBottom: '1px solid var(--border-color)' }}>
                    <th style={{ textAlign: 'left', padding: '10px 14px', fontWeight: '600', color: 'var(--text-main)' }}>
                      Permission Code
                    </th>
                    <th style={{ textAlign: 'left', padding: '10px 14px', fontWeight: '600', color: 'var(--text-main)' }}>
                      Description
                    </th>
                    <th style={{ textAlign: 'left', padding: '10px 14px', fontWeight: '600', color: 'var(--text-main)' }}>
                      Target Phase
                    </th>
                    <th style={{ textAlign: 'center', padding: '10px 14px', fontWeight: '600', color: 'var(--text-main)' }}>
                      Your Access
                    </th>
                  </tr>
                </thead>
                <tbody>
                  {allModulePermissions.map((perm, idx) => {
                    const isGranted = (permissions || []).includes(perm.code) || role === 'OWNER';

                    return (
                      <tr
                        key={perm.code}
                        style={{
                          borderBottom: idx !== allModulePermissions.length - 1 ? '1px solid var(--border-subtle)' : 'none'
                        }}
                      >
                        <td style={{ padding: '10px 14px', fontFamily: 'monospace', color: '#4B7C9E', fontSize: '0.8125rem' }}>
                          {perm.code}
                        </td>
                        <td style={{ padding: '10px 14px', color: 'var(--text-main)' }}>
                          {perm.label}
                        </td>
                        <td style={{ padding: '10px 14px', color: 'var(--text-muted)', fontSize: '0.8125rem' }}>
                          {perm.phase}
                        </td>
                        <td style={{ padding: '10px 14px', textAlign: 'center' }}>
                          {isGranted ? (
                            <Badge variant="success" size="sm">Granted</Badge>
                          ) : (
                            <Badge variant="neutral" size="sm">Restricted</Badge>
                          )}
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
