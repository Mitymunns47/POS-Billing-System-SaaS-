import React, { useState, useEffect } from 'react';
import { useAuth } from './context/AuthContext';
import { AdminApp } from './pages/AdminApp'; // Phase 7
import { LoginPage } from './pages/LoginPage';
import { SignupPage } from './pages/SignupPage';
import { OnboardingPage } from './pages/OnboardingPage';
import { DashboardPage } from './pages/DashboardPage';
import { ProfilePage } from './pages/ProfilePage';
import { ForgotPasswordPage } from './pages/ForgotPasswordPage';
import { ProductsPage } from './pages/ProductsPage';
import { CategoriesBrandsPage } from './pages/CategoriesBrandsPage';
import { InventoryPage } from './pages/InventoryPage';
import { InventoryHistoryPage } from './pages/InventoryHistoryPage';
import { POSPage } from './pages/POSPage';
import { SalesPage } from './pages/SalesPage';
import { CustomersPage } from './pages/CustomersPage';
import { CustomerProfilePage } from './pages/CustomerProfilePage';
import { StaffPage } from './pages/StaffPage';
import { StaffPermissionsPage } from './pages/StaffPermissionsPage';
import { ReportsPage } from './pages/ReportsPage';
import { ExpensesPage } from './pages/ExpensesPage';
import { ReturnsPage } from './pages/ReturnsPage';
import { SettingsPage } from './pages/SettingsPage';
import { NotificationsPage } from './pages/NotificationsPage';
import { DashboardLayout } from './components/layout/DashboardLayout';

export function App() {
  const { isAuthenticated, isLoading, store, role } = useAuth();
  const isAdmin = role === 'OWNER';

  const [currentPath, setCurrentPath] = useState(() => {
    return window.location.pathname || '/login';
  });

  // Phase 7: If path starts with /admin, render the standalone Admin Portal
  if (currentPath.startsWith('/admin')) {
    return <AdminApp />;
  }

  const navigate = (path) => {
    window.history.pushState({}, '', path);
    setCurrentPath(path.split('?')[0]);
  };

  useEffect(() => {
    const handlePopState = () => {
      setCurrentPath(window.location.pathname);
    };
    window.addEventListener('popstate', handlePopState);
    return () => window.removeEventListener('popstate', handlePopState);
  }, []);

  useEffect(() => {
    if (isLoading) return;

    if (!isAuthenticated) {
      const publicRoutes = ['/login', '/signup', '/forgot-password'];
      if (!publicRoutes.includes(currentPath)) {
        navigate('/login');
      }
    } else {
      if (!store?.onboardingCompleted && currentPath !== '/onboarding') {
        navigate('/onboarding');
      } else if (store?.onboardingCompleted && (currentPath === '/login' || currentPath === '/signup' || currentPath === '/')) {
        navigate('/dashboard');
      }
    }
  }, [isAuthenticated, isLoading, store?.onboardingCompleted, currentPath]);

  if (isLoading) {
    return (
      <div
        style={{
          minHeight: '100vh',
          display: 'flex',
          flexDirection: 'column',
          alignItems: 'center',
          justifyContent: 'center',
          backgroundColor: 'var(--bg-page)',
          gap: '1rem'
        }}
      >
        <div
          style={{
            width: '40px',
            height: '40px',
            borderRadius: '10px',
            backgroundColor: '#7EAFD0',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            color: '#FFFFFF',
            fontWeight: '700',
            fontSize: '1.25rem'
          }}
        >
          W
        </div>
        <div style={{ display: 'flex', alignItems: 'center', gap: '8px', color: 'var(--text-muted)', fontSize: '0.875rem' }}>
          <div
            style={{
              width: '16px',
              height: '16px',
              border: '2px solid #7EAFD0',
              borderTopColor: 'transparent',
              borderRadius: '50%',
              animation: 'spin 0.8s linear infinite'
            }}
          />
          <style>{`@keyframes spin { 100% { transform: rotate(360deg); } }`}</style>
          <span>Loading Westsides SaaS...</span>
        </div>
      </div>
    );
  }

  // Pages that require authentication and have a dashboard layout
  const protectedInLayout = (page) => {
    if (!isAuthenticated) return <LoginPage onNavigate={navigate} />;
    return (
      <DashboardLayout currentPath={currentPath} onNavigate={navigate}>
        {page}
      </DashboardLayout>
    );
  };

  // Dynamic customer profile route: /customers/:id
  if (currentPath.startsWith('/customers/') && currentPath !== '/customers') {
    const customerId = currentPath.replace('/customers/', '').split('/')[0];
    return protectedInLayout(<CustomerProfilePage customerId={customerId} onNavigate={navigate} />);
  }

  // Dynamic staff permissions route: /staff/:id/permissions
  if (currentPath.startsWith('/staff/') && currentPath.endsWith('/permissions')) {
    if (!isAdmin) return protectedInLayout(<DashboardPage onNavigate={navigate} />);
    const parts = currentPath.split('/');
    const staffId = parts[2];
    return protectedInLayout(<StaffPermissionsPage staffId={staffId} onNavigate={navigate} />);
  }

  // Dynamic return processing route: /returns/:saleId
  if (currentPath.startsWith('/returns/') && currentPath !== '/returns/history') {
    const saleId = currentPath.replace('/returns/', '').split('/')[0];
    return protectedInLayout(<ReturnsPage saleIdFromUrl={saleId} onNavigate={navigate} />);
  }

  switch (currentPath) {
    case '/login':
      return <LoginPage onNavigate={navigate} />;

    case '/signup':
      return <SignupPage onNavigate={navigate} />;

    case '/forgot-password':
      return <ForgotPasswordPage onNavigate={navigate} />;

    case '/onboarding':
      if (!isAuthenticated) return <LoginPage onNavigate={navigate} />;
      return <OnboardingPage onNavigate={navigate} />;

    case '/profile':
      return protectedInLayout(
        <ProfilePage initialTab={window.location.search.includes('tab=store') ? 'store' : 'profile'} />
      );

    // Phase 2 — Products
    case '/products':
      return protectedInLayout(<ProductsPage onNavigate={navigate} />);

    case '/products/categories':
      return protectedInLayout(<CategoriesBrandsPage onNavigate={navigate} />);

    // Phase 2 — Inventory
    case '/inventory':
      return protectedInLayout(<InventoryPage onNavigate={navigate} />);

    case '/inventory/history':
      return protectedInLayout(<InventoryHistoryPage onNavigate={navigate} />);

    // Phase 3 — POS & Billing
    case '/pos':
    case '/billing':
      return protectedInLayout(<POSPage onNavigate={navigate} />);

    // Phase 3 — Sales & Invoices
    case '/sales':
      return protectedInLayout(<SalesPage onNavigate={navigate} />);

    // Phase 4 — Customer CRM
    case '/customers':
      return protectedInLayout(<CustomersPage onNavigate={navigate} />);

    // Phase 4 — Staff & Permissions
    case '/staff':
      if (!isAdmin) return protectedInLayout(<DashboardPage onNavigate={navigate} />);
      return protectedInLayout(<StaffPage initialTab="directory" onNavigate={navigate} />);

    case '/staff/activity':
      if (!isAdmin) return protectedInLayout(<DashboardPage onNavigate={navigate} />);
      return protectedInLayout(<StaffPage initialTab="activity" onNavigate={navigate} />);

    case '/staff/attendance':
      if (!isAdmin) return protectedInLayout(<DashboardPage onNavigate={navigate} />);
      return protectedInLayout(<StaffPage initialTab="attendance" onNavigate={navigate} />);

    // Phase 5 — Reports & Business Intelligence
    case '/reports':
      return protectedInLayout(<ReportsPage initialTab="sales" onNavigate={navigate} />);

    case '/reports/sales':
      return protectedInLayout(<ReportsPage initialTab="sales" onNavigate={navigate} />);

    case '/reports/products':
      return protectedInLayout(<ReportsPage initialTab="products" onNavigate={navigate} />);

    case '/reports/inventory':
      return protectedInLayout(<ReportsPage initialTab="inventory" onNavigate={navigate} />);

    case '/reports/customers':
      return protectedInLayout(<ReportsPage initialTab="customers" onNavigate={navigate} />);

    case '/reports/staff':
      if (!isAdmin) return protectedInLayout(<DashboardPage onNavigate={navigate} />);
      return protectedInLayout(<ReportsPage initialTab="staff" onNavigate={navigate} />);

    case '/reports/finance':
      return protectedInLayout(<ReportsPage initialTab="finance" onNavigate={navigate} />);

    // Phase 5 — Operating Expenses
    case '/expenses':
      return protectedInLayout(<ExpensesPage onNavigate={navigate} />);

    // Phase 6 — Returns & Refunds
    case '/returns':
      return protectedInLayout(<ReturnsPage initialTab="process" onNavigate={navigate} />);

    case '/returns/history':
      return protectedInLayout(<ReturnsPage initialTab="history" onNavigate={navigate} />);

    // Phase 6 — Store Settings
    case '/settings':
      if (!isAdmin) return protectedInLayout(<DashboardPage onNavigate={navigate} />);
      return protectedInLayout(<SettingsPage onNavigate={navigate} />);

    // Phase 6 — Notification Center
    case '/notifications':
      return protectedInLayout(<NotificationsPage onNavigate={navigate} />);

    case '/dashboard':
    default:
      return protectedInLayout(<DashboardPage onNavigate={navigate} />);
  }
}
