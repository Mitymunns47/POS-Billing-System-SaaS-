const crypto = require('crypto');
const db = require('../db/database');

const ActivityLogModel = {
  /**
   * Log an activity record
   */
  log: ({ storeId, userId, userName, action, module: mod, description, recordId = null }) => {
    if (!storeId || !userId || !action || !mod) return null;
    const id = 'act_' + crypto.randomBytes(8).toString('hex');
    const now = new Date().toISOString();

    db.prepare(`
      INSERT INTO activity_logs (id, storeId, userId, userName, action, module, description, recordId, createdAt)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `).run(id, storeId, userId, userName || 'Staff', action, mod, description || '', recordId, now);

    return { id, storeId, userId, userName, action, module: mod, description, recordId, createdAt: now };
  },

  logActivity: (args) => ActivityLogModel.log(args),

  /**
   * Query paginated activity logs for a store
   */
  findAll: ({ storeId, search = '', userId = '', module: mod = '', action = '', startDate = '', endDate = '', page = 1, limit = 20 }) => {
    const offset = (page - 1) * limit;
    const conditions = ['a.storeId = ?'];
    const params = [storeId];

    if (userId) {
      conditions.push('a.userId = ?');
      params.push(userId);
    }
    if (mod) {
      conditions.push('a.module = ?');
      params.push(mod);
    }
    if (action) {
      conditions.push('a.action = ?');
      params.push(action);
    }
    if (startDate) {
      conditions.push('a.createdAt >= ?');
      params.push(startDate);
    }
    if (endDate) {
      conditions.push('a.createdAt <= ?');
      params.push(endDate + 'T23:59:59.999Z');
    }
    if (search) {
      conditions.push('(a.userName LIKE ? OR a.description LIKE ? OR a.action LIKE ? OR a.recordId LIKE ?)');
      const q = `%${search.trim()}%`;
      params.push(q, q, q, q);
    }

    const where = conditions.join(' AND ');
    const total = db.prepare(`SELECT COUNT(*) AS cnt FROM activity_logs a WHERE ${where}`).get(...params).cnt;
    const rows = db.prepare(`
      SELECT a.*
      FROM activity_logs a
      WHERE ${where}
      ORDER BY a.createdAt DESC
      LIMIT ? OFFSET ?
    `).all(...params, limit, offset);

    return {
      activities: rows,
      total,
      page: Number(page),
      limit: Number(limit),
      totalPages: Math.ceil(total / limit)
    };
  }
};

module.exports = ActivityLogModel;
