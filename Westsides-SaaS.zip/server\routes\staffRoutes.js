const express = require('express');
const router = express.Router();
const StaffModel = require('../models/staffModel');
const UserPermissionModel = require('../models/userPermissionModel');
const ActivityLogModel = require('../models/activityLogModel');
const AttendanceModel = require('../models/attendanceModel');
const authMiddleware = require('../middleware/auth');
const { requirePermission } = require('../middleware/roles');
const { PERMISSIONS, PERMISSION_CATALOG, ROLES } = require('../constants/roles');

router.use(authMiddleware);

const EMAIL_REGEX = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

// GET /api/staff — List staff members
router.get('/', requirePermission(PERMISSIONS.STAFF_VIEW), (req, res) => {
  try {
    const { search, role, status, page = 1, limit = 20 } = req.query;

    const result = StaffModel.findAll({
      storeId: req.storeId,
      search: search || '',
      role: role || '',
      status: status || '',
      page: parseInt(page) || 1,
      limit: Math.min(parseInt(limit) || 20, 100)
    });

    res.json({ success: true, ...result });
  } catch (err) {
    console.error('List staff error:', err);
    res.status(500).json({ success: false, error: 'Could not load staff directory.' });
  }
});

// GET /api/staff/activity — Activity audit log
router.get('/activity', requirePermission(PERMISSIONS.STAFF_VIEW_ACTIVITY), (req, res) => {
  try {
    const { search, userId, module: mod, action, startDate, endDate, page = 1, limit = 25 } = req.query;

    const result = ActivityLogModel.findAll({
      storeId: req.storeId,
      search: search || '',
      userId: userId || '',
      module: mod || '',
      action: action || '',
      startDate: startDate || '',
      endDate: endDate || '',
      page: parseInt(page) || 1,
      limit: Math.min(parseInt(limit) || 25, 100)
    });

    res.json({ success: true, ...result });
  } catch (err) {
    console.error('List activity log error:', err);
    res.status(500).json({ success: false, error: 'Could not load activity log.' });
  }
});

// GET /api/staff/permissions/catalog — Permission catalog grouped by module
router.get('/permissions/catalog', (req, res) => {
  res.json({ success: true, catalog: PERMISSION_CATALOG });
});

// GET /api/staff/attendance — Attendance logs
router.get('/attendance', requirePermission(PERMISSIONS.ATTENDANCE_VIEW), (req, res) => {
  try {
    const { date, userId, status, page = 1, limit = 30 } = req.query;

    const result = AttendanceModel.findAll({
      storeId: req.storeId,
      date: date || '',
      userId: userId || '',
      status: status || '',
      page: parseInt(page) || 1,
      limit: Math.min(parseInt(limit) || 30, 100)
    });

    res.json({ success: true, ...result });
  } catch (err) {
    console.error('List attendance error:', err);
    res.status(500).json({ success: false, error: 'Could not load attendance records.' });
  }
});

// POST /api/staff/attendance — Record attendance
router.post('/attendance', requirePermission(PERMISSIONS.ATTENDANCE_MANAGE), (req, res) => {
  try {
    const { userId, date, checkIn, checkOut, status, notes } = req.body;

    if (!userId) return res.status(400).json({ success: false, error: 'Staff member is required.' });
    if (!date) return res.status(400).json({ success: false, error: 'Date is required.' });

    // Verify staff belongs to this store
    const staff = StaffModel.findById(userId, req.storeId);
    if (!staff) return res.status(404).json({ success: false, error: 'Staff member not found in this store.' });

    const record = AttendanceModel.record({
      storeId: req.storeId,
      userId,
      date,
      checkIn,
      checkOut,
      status: status || 'PRESENT',
      notes
    });

    ActivityLogModel.log({
      storeId: req.storeId,
      userId: req.auth.userId,
      userName: req.auth.userName,
      action: 'ATTENDANCE_RECORDED',
      module: 'Attendance',
      description: `Recorded attendance for ${staff.name} on ${date}: ${status}`,
      recordId: record.id
    });

    res.json({ success: true, message: 'Attendance recorded successfully.', record });
  } catch (err) {
    console.error('Record attendance error:', err);
    res.status(400).json({ success: false, error: err.message || 'Could not record attendance.' });
  }
});

// GET /api/staff/:id — Single staff details
router.get('/:id', requirePermission(PERMISSIONS.STAFF_VIEW), (req, res) => {
  try {
    const staff = StaffModel.findById(req.params.id, req.storeId);
    if (!staff) {
      return res.status(404).json({ success: false, error: 'Staff member not found in this store.' });
    }

    const permissions = UserPermissionModel.getUserPermissions(req.storeId, req.params.id, staff.role);

    res.json({ success: true, staff, permissions });
  } catch (err) {
    console.error('Get staff error:', err);
    res.status(500).json({ success: false, error: 'Could not load staff member.' });
  }
});

// POST /api/staff — Create staff member
router.post('/', requirePermission(PERMISSIONS.STAFF_CREATE), (req, res) => {
  try {
    const { name, email, phone, role, password } = req.body;

    if (!name || !name.trim()) return res.status(400).json({ success: false, error: 'Name is required.' });
    if (!email || !EMAIL_REGEX.test(email.trim())) return res.status(400).json({ success: false, error: 'Valid email is required.' });
    if (!password || password.length < 6) return res.status(400).json({ success: false, error: 'Password must be at least 6 characters.' });
    if (!role) return res.status(400).json({ success: false, error: 'Role is required.' });

    const staff = StaffModel.createStaff({
      storeId: req.storeId,
      name,
      email,
      phone,
      role,
      password,
      actorRole: req.role
    });

    // Activity Log
    ActivityLogModel.log({
      storeId: req.storeId,
      userId: req.auth.userId,
      userName: req.auth.userName,
      action: 'STAFF_CREATED',
      module: 'Staff',
      description: `Created staff account: ${staff.name} (${staff.email}) with role ${staff.role}`,
      recordId: staff.id
    });

    res.status(201).json({ success: true, message: 'Staff member created successfully.', staff });
  } catch (err) {
    console.error('Create staff error:', err);
    res.status(400).json({ success: false, error: err.message || 'Could not create staff member.' });
  }
});

// PUT /api/staff/:id — Update staff profile
router.put('/:id', requirePermission(PERMISSIONS.STAFF_EDIT), (req, res) => {
  try {
    const { name, phone } = req.body;

    const staff = StaffModel.updateProfile(req.params.id, req.storeId, { name, phone });
    if (!staff) {
      return res.status(404).json({ success: false, error: 'Staff member not found.' });
    }

    ActivityLogModel.log({
      storeId: req.storeId,
      userId: req.auth.userId,
      userName: req.auth.userName,
      action: 'STAFF_UPDATED',
      module: 'Staff',
      description: `Updated profile for staff member: ${staff.name}`,
      recordId: staff.id
    });

    res.json({ success: true, message: 'Staff profile updated.', staff });
  } catch (err) {
    console.error('Update staff error:', err);
    res.status(400).json({ success: false, error: err.message || 'Could not update staff profile.' });
  }
});

// PATCH /api/staff/:id/role — Change staff role
router.patch('/:id/role', requirePermission(PERMISSIONS.STAFF_CHANGE_ROLE), (req, res) => {
  try {
    const { role } = req.body;
    if (!role) return res.status(400).json({ success: false, error: 'New role is required.' });

    const staff = StaffModel.updateRole(req.params.id, req.storeId, role, req.role);

    ActivityLogModel.log({
      storeId: req.storeId,
      userId: req.auth.userId,
      userName: req.auth.userName,
      action: 'STAFF_ROLE_CHANGED',
      module: 'Staff',
      description: `Changed role for ${staff.name} to ${role}`,
      recordId: staff.id
    });

    res.json({ success: true, message: `Staff role changed to ${role}.`, staff });
  } catch (err) {
    console.error('Change role error:', err);
    const isForbidden = err.message && (
      err.message.includes('Owner') ||
      err.message.includes('permission') ||
      err.message.includes('privilege') ||
      err.message.includes('authority') ||
      err.message.includes('Only the store Owner')
    );
    res.status(isForbidden ? 403 : 400).json({ success: false, error: err.message || 'Could not change staff role.' });
  }
});

// PATCH /api/staff/:id/status — Activate / Deactivate staff
router.patch('/:id/status', (req, res) => {
  try {
    const { status } = req.body;
    if (!['ACTIVE', 'INACTIVE'].includes(status)) {
      return res.status(400).json({ success: false, error: 'Status must be ACTIVE or INACTIVE.' });
    }

    // Permission check based on intended action
    const requiredPerm = status === 'ACTIVE' ? PERMISSIONS.STAFF_ACTIVATE : PERMISSIONS.STAFF_DEACTIVATE;
    if (req.role !== ROLES.OWNER && !req.auth.permissions.includes(requiredPerm)) {
      return res.status(403).json({ success: false, error: `Access denied. Missing permission: ${requiredPerm}` });
    }

    const staff = StaffModel.setStatus(req.params.id, req.storeId, status, req.role);

    ActivityLogModel.log({
      storeId: req.storeId,
      userId: req.auth.userId,
      userName: req.auth.userName,
      action: status === 'ACTIVE' ? 'STAFF_ACTIVATED' : 'STAFF_DEACTIVATED',
      module: 'Staff',
      description: `${status === 'ACTIVE' ? 'Activated' : 'Deactivated'} staff member: ${staff.name}`,
      recordId: staff.id
    });

    res.json({ success: true, message: `Staff member ${status === 'ACTIVE' ? 'activated' : 'deactivated'} successfully.`, staff });
  } catch (err) {
    console.error('Change staff status error:', err);
    const isForbidden = err.message && (
      err.message.includes('Owner') ||
      err.message.includes('permission') ||
      err.message.includes('privilege') ||
      err.message.includes('Only the store Owner')
    );
    res.status(isForbidden ? 403 : 400).json({ success: false, error: err.message || 'Could not change staff status.' });
  }
});

// POST /api/staff/:id/reset-password — Reset staff password
router.post('/:id/reset-password', requirePermission(PERMISSIONS.STAFF_EDIT), (req, res) => {
  try {
    const { newPassword } = req.body;
    if (!newPassword || newPassword.length < 6) {
      return res.status(400).json({ success: false, error: 'New password must be at least 6 characters long.' });
    }

    StaffModel.resetPassword(req.params.id, req.storeId, newPassword, req.role);

    const staff = StaffModel.findById(req.params.id, req.storeId);

    ActivityLogModel.log({
      storeId: req.storeId,
      userId: req.auth.userId,
      userName: req.auth.userName,
      action: 'STAFF_PASSWORD_RESET',
      module: 'Staff',
      description: `Reset password for staff member: ${staff?.name || req.params.id}`,
      recordId: req.params.id
    });

    res.json({ success: true, message: 'Password has been reset successfully.' });
  } catch (err) {
    console.error('Reset password error:', err);
    res.status(400).json({ success: false, error: err.message || 'Could not reset password.' });
  }
});

// GET /api/staff/:id/permissions — Get staff permissions and raw overrides
router.get('/:id/permissions', requirePermission(PERMISSIONS.STAFF_PERMISSIONS), (req, res) => {
  try {
    const staff = StaffModel.findById(req.params.id, req.storeId);
    if (!staff) {
      return res.status(404).json({ success: false, error: 'Staff member not found.' });
    }

    const effective = UserPermissionModel.getUserPermissions(req.storeId, req.params.id, staff.role);
    const overrides = UserPermissionModel.getOverrides(req.storeId, req.params.id);

    res.json({
      success: true,
      staff,
      catalog: PERMISSION_CATALOG,
      effectivePermissions: effective,
      overrides,
      isOwner: staff.role === ROLES.OWNER
    });
  } catch (err) {
    console.error('Get staff permissions error:', err);
    res.status(500).json({ success: false, error: 'Could not load staff permissions.' });
  }
});

// PUT & PATCH /api/staff/:id/permissions — Update staff permissions overrides
const handlePermissionsUpdate = (req, res) => {
  try {
    const staff = StaffModel.findById(req.params.id, req.storeId);
    if (!staff) {
      return res.status(404).json({ success: false, error: 'Staff member not found.' });
    }

    // Owner protection: Owner permissions cannot be modified
    if (staff.role === ROLES.OWNER) {
      return res.status(400).json({
        success: false,
        error: 'The store Owner possesses full permissions which cannot be restricted.'
      });
    }

    // Managers cannot grant permissions they do not possess themselves
    if (req.role !== ROLES.OWNER) {
      const myPerms = req.auth.permissions || [];
      const attemptedOverrides = req.body.overrides || {};
      for (const [permKey, allowed] of Object.entries(attemptedOverrides)) {
        if (allowed && !myPerms.includes(permKey)) {
          return res.status(403).json({
            success: false,
            error: `You cannot grant permission "${permKey}" because you do not have it yourself.`
          });
        }
      }
    }

    const { overrides } = req.body;
    if (overrides && typeof overrides === 'object') {
      UserPermissionModel.bulkSetOverrides(req.storeId, req.params.id, overrides);
    }

    ActivityLogModel.log({
      storeId: req.storeId,
      userId: req.auth.userId,
      userName: req.auth.userName,
      action: 'PERMISSIONS_UPDATED',
      module: 'Staff',
      description: `Adjusted permission overrides for: ${staff.name}`,
      recordId: staff.id
    });

    const updatedEffective = UserPermissionModel.getUserPermissions(req.storeId, req.params.id, staff.role);
    const updatedOverrides = UserPermissionModel.getOverrides(req.storeId, req.params.id);

    res.json({
      success: true,
      message: 'Permissions updated successfully.',
      effectivePermissions: updatedEffective,
      overrides: updatedOverrides
    });
  } catch (err) {
    console.error('Update staff permissions error:', err);
    res.status(400).json({ success: false, error: err.message || 'Could not update permissions.' });
  }
};

router.put('/:id/permissions', requirePermission(PERMISSIONS.STAFF_PERMISSIONS), handlePermissionsUpdate);
router.patch('/:id/permissions', requirePermission(PERMISSIONS.STAFF_PERMISSIONS), handlePermissionsUpdate);

// DELETE /api/staff/:id — Remove staff member from store
router.delete('/:id', requirePermission(PERMISSIONS.STAFF_DEACTIVATE), (req, res) => {
  try {
    const staffId = req.params.id;
    if (staffId === req.auth.userId) {
      return res.status(400).json({ success: false, error: 'You cannot remove your own account.' });
    }

    const staff = StaffModel.findById(staffId, req.storeId);
    if (!staff) {
      return res.status(404).json({ success: false, error: 'Staff member not found.' });
    }

    if (staff.role === ROLES.OWNER) {
      return res.status(400).json({ success: false, error: 'The store Owner cannot be removed.' });
    }

    StaffModel.deleteStaff(staffId, req.storeId);

    ActivityLogModel.log({
      storeId: req.storeId,
      userId: req.auth.userId,
      userName: req.auth.userName,
      action: 'REMOVE_STAFF',
      module: 'Staff',
      description: `Removed staff member: ${staff.name} (${staff.email})`,
      recordId: staffId
    });

    res.json({ success: true, message: `Staff member "${staff.name}" removed successfully.` });
  } catch (err) {
    console.error('Delete staff error:', err);
    res.status(400).json({ success: false, error: err.message || 'Could not remove staff member.' });
  }
});

module.exports = router;
