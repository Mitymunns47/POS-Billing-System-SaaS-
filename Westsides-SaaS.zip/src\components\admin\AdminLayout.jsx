/**
 * AdminLayout.jsx — Phase 7
 * Dark sidebar layout for the Platform Administration portal.
 */
import React, { useState } from 'react';
import { useAdminAuth } from '../../context/AdminAuthContext';

const NAV = [
  { path: '/admin/dashboard', icon: '◉', label: 'Dashboard' },
  { path: '/admin/stores', icon: '🏪', label: 'Tenant Stores' },
  { path: '/admin/plans', icon: '📋', label: 'Subscription Plans' },
  { path: '/admin/invoices', icon: '🧾', label: 'Billing Invoices' },
  { path: '/admin/analytics', icon: '📊', label: 'Analytics' },
  { path: '/admin/audit', icon: '🔍', label: 'Audit Log' },
  { path: '/admin/settings', icon: '⚙️', label: 'Platform Settings' }
];

export function AdminLayout({ children, currentPath, onNavigate }) {
  const { adminUser, adminLogout } = useAdminAuth();
  const [mobileOpen, setMobileOpen] = useState(false);

  const handleLogout = async () => {
    await adminLogout();
    onNavigate('/admin');
  };

  const Sidebar = () => (
    <div style={{
      width: '240px', flexShrink: 0,
      background: '#0F172A',
      borderRight: '1px solid rgba(126,175,208,0.1)',
      display: 'flex', flexDirection: 'column',
      height: '100vh', position: 'fixed', left: 0, top: 0, zIndex: 100,
      fontFamily: "'Inter', 'Segoe UI', sans-serif"
    }}>
      {/* Logo */}
      <div style={{ padding: '1.25rem 1.25rem 0.75rem', borderBottom: '1px solid rgba(126,175,208,0.08)' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: '0.625rem', marginBottom: '0.5rem' }}>
          <div style={{
            width: '34px', height: '34px', borderRadius: '8px',
            background: 'linear-gradient(135deg, #7EAFD0, #5B91B8)',
            display: 'flex', alignItems: 'center', justifyContent: 'center',
            flexShrink: 0
          }}>
            <span style={{ color: '#fff', fontWeight: '800', fontSize: '1rem' }}>W</span>
          </div>
          <div>
            <div style={{ color: '#F1F5F9', fontSize: '0.875rem', fontWeight: '700', lineHeight: 1.2 }}>Westsides</div>
            <div style={{ color: '#7EAFD0', fontSize: '0.625rem', fontWeight: '600', textTransform: 'uppercase', letterSpacing: '0.08em' }}>Platform Admin</div>
          </div>
        </div>
      </div>

      {/* Nav */}
      <nav style={{ flex: 1, padding: '0.75rem 0.75rem', overflowY: 'auto' }}>
        {NAV.map(item => {
          const active = currentPath === item.path || (item.path !== '/admin/dashboard' && currentPath.startsWith(item.path));
          return (
            <button
              key={item.path}
              onClick={() => onNavigate(item.path)}
              style={{
                width: '100%', display: 'flex', alignItems: 'center', gap: '0.625rem',
                padding: '0.625rem 0.75rem', borderRadius: '8px',
                border: 'none', cursor: 'pointer', textAlign: 'left',
                marginBottom: '2px',
                background: active ? 'rgba(126,175,208,0.12)' : 'transparent',
                color: active ? '#7EAFD0' : '#94A3B8',
                fontSize: '0.875rem', fontWeight: active ? '600' : '400',
                transition: 'all 0.15s'
              }}
            >
              <span style={{ fontSize: '0.875rem', flexShrink: 0 }}>{item.icon}</span>
              {item.label}
            </button>
          );
        })}
      </nav>

      {/* Admin user info */}
      <div style={{
        padding: '1rem', borderTop: '1px solid rgba(126,175,208,0.08)',
        display: 'flex', alignItems: 'center', gap: '0.625rem'
      }}>
        <div style={{
          width: '32px', height: '32px', borderRadius: '50%',
          background: 'linear-gradient(135deg, #334155, #1E293B)',
          border: '1px solid rgba(126,175,208,0.2)',
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          flexShrink: 0
        }}>
          <span style={{ color: '#7EAFD0', fontSize: '0.875rem' }}>👤</span>
        </div>
        <div style={{ flex: 1, minWidth: 0 }}>
          <div style={{ color: '#CBD5E1', fontSize: '0.8125rem', fontWeight: '500', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>
            {adminUser?.userName || adminUser?.name || 'Super Admin'}
          </div>
          <div style={{ color: '#475569', fontSize: '0.6875rem' }}>SUPER_ADMIN</div>
        </div>
        <button
          onClick={handleLogout}
          title="Logout"
          style={{
            background: 'none', border: 'none', cursor: 'pointer',
            color: '#475569', fontSize: '0.875rem', padding: '0.25rem',
            flexShrink: 0, borderRadius: '4px'
          }}
        >
          ⎋
        </button>
      </div>
    </div>
  );

  return (
    <div style={{ display: 'flex', minHeight: '100vh', background: '#0F172A', fontFamily: "'Inter', 'Segoe UI', sans-serif" }}>
      <Sidebar />
      <main style={{ marginLeft: '240px', flex: 1, minWidth: 0, overflow: 'auto' }}>
        {children}
      </main>
    </div>
  );
}
