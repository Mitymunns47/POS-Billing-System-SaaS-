import React from 'react';
import { useAuth } from '../../context/AuthContext';
import {
  LayoutDashboard,
  ReceiptText,
  Shirt,
  Boxes,
  Users,
  BarChart3,
  Wallet,
  ShieldCheck,
  Settings,
  FileText
} from 'lucide-react';

export function Sidebar({ currentPath = '/dashboard', onNavigate, isOpen, onClose, isCollapsed = false }) {
  const { store, role, user } = useAuth();

  const navItems = [
    {
      id: 'dashboard',
      label: 'Dashboard',
      icon: LayoutDashboard,
      path: '/dashboard',
      status: 'active'
    },
    {
      id: 'pos',
      label: 'POS Register',
      icon: ReceiptText,
      path: '/pos',
      status: 'active'
    },
    {
      id: 'sales',
      label: 'Sales & Invoices',
      icon: FileText,
      path: '/sales',
      status: 'active'
    },
    {
      id: 'products',
      label: 'Products',
      icon: Shirt,
      path: '/products',
      status: 'active'
    },
    {
      id: 'inventory',
      label: 'Inventory',
      icon: Boxes,
      path: '/inventory',
      status: 'active'
    },
    {
      id: 'customers',
      label: 'Customers',
      icon: Users,
      path: '/customers',
      status: 'active'
    },
    {
      id: 'reports',
      label: 'Reports & Analytics',
      icon: BarChart3,
      path: '/reports',
      status: 'active'
    },
    {
      id: 'expenses',
      label: 'Expenses',
      icon: Wallet,
      path: '/expenses',
      status: 'active'
    },
    {
      id: 'staff',
      label: 'Staff & Roles',
      icon: ShieldCheck,
      path: '/staff',
      status: 'active',
      adminOnly: true
    },
    {
      id: 'settings',
      label: 'Store Settings',
      icon: Settings,
      path: '/settings',
      status: 'active',
      adminOnly: true
    }
  ];

  const isStaffPortal = user?.email === 'staff@westsides.com' || role === 'STAFF' || role === 'CASHIER' || (role && role !== 'OWNER');
  const isAdmin = !isStaffPortal && (role === 'OWNER' || user?.email === 'admin@westsides.com');
  const visibleNavItems = navItems.filter((item) => {
    if (item.id === 'staff' || item.id === 'settings' || item.adminOnly) {
      return Boolean(isAdmin);
    }
    return true;
  });

  return (
    <>
      {/* Mobile backdrop */}
      {isOpen && (
        <div
          onClick={onClose}
          style={{
            position: 'fixed',
            inset: 0,
            backgroundColor: 'rgba(23, 32, 51, 0.4)',
            zIndex: 45,
            transition: 'opacity 0.2s ease'
          }}
          className="sidebar-backdrop"
        />
      )}

      <aside
        style={{
          width: isCollapsed ? '68px' : '260px',
          backgroundColor: '#FFFFFF',
          borderRight: '1px solid var(--border-color)',
          display: 'flex',
          flexDirection: 'column',
          justifyContent: 'space-between',
          height: 'calc(100vh - 64px)',
          position: 'sticky',
          top: '64px',
          zIndex: 46,
          transition: 'width 0.2s cubic-bezier(0.4, 0, 0.2, 1), transform 0.25s ease-in-out',
          flexShrink: 0,
          overflowX: 'hidden'
        }}
        className={`saas-sidebar ${isOpen ? 'open' : ''} ${isCollapsed ? 'collapsed' : ''}`}
      >
        <div style={{ padding: isCollapsed ? '1rem 0.5rem' : '1.25rem 0.875rem', overflowY: 'auto' }}>
          {!isCollapsed ? (
            <div style={{ padding: '0 0.75rem 0.75rem', fontSize: '0.6875rem', fontWeight: '700', color: 'var(--text-muted)', textTransform: 'uppercase', letterSpacing: '0.05em', whiteSpace: 'nowrap' }}>
              Store Operations
            </div>
          ) : (
            <div style={{ height: '1px', backgroundColor: 'var(--border-subtle)', margin: '0 0.5rem 0.75rem' }} />
          )}

          <nav style={{ display: 'flex', flexDirection: 'column', gap: '4px' }}>
            {visibleNavItems.map((item) => {
              const Icon = item.icon;
              const isCurrent = item.path === '/profile?tab=store'
                ? currentPath === '/profile'
                : currentPath.startsWith(item.path);
              const isComingSoon = item.status === 'coming-soon';

              return (
                <button
                  key={item.id}
                  disabled={isComingSoon}
                  onClick={() => {
                    if (!isComingSoon && onNavigate) {
                      onNavigate(item.path);
                      if (onClose) onClose();
                    }
                  }}
                  style={{
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: isCollapsed ? 'center' : 'space-between',
                    width: '100%',
                    padding: isCollapsed ? '10px 0' : '8px 12px',
                    borderRadius: 'var(--radius-md)',
                    border: 'none',
                    background: isCurrent ? 'var(--primary-light)' : 'transparent',
                    color: isCurrent
                      ? '#4B7C9E'
                      : isComingSoon
                      ? 'var(--text-light)'
                      : 'var(--text-main)',
                    fontWeight: isCurrent ? '600' : '400',
                    fontSize: '0.875rem',
                    cursor: isComingSoon ? 'not-allowed' : 'pointer',
                    textAlign: 'left',
                    transition: 'all 0.15s ease'
                  }}
                  onMouseEnter={(e) => {
                    if (!isComingSoon && !isCurrent) {
                      e.currentTarget.style.backgroundColor = 'var(--bg-page)';
                    }
                  }}
                  onMouseLeave={(e) => {
                    if (!isComingSoon && !isCurrent) {
                      e.currentTarget.style.backgroundColor = 'transparent';
                    }
                  }}
                  title={item.label}
                  aria-label={item.label}
                >
                  <div style={{ display: 'flex', alignItems: 'center', gap: isCollapsed ? '0' : '10px', justifyContent: isCollapsed ? 'center' : 'flex-start', width: isCollapsed ? '100%' : 'auto' }}>
                    <Icon size={19} color={isCurrent ? '#4B7C9E' : isComingSoon ? '#CBD5E1' : '#64748B'} />
                    {!isCollapsed && <span style={{ whiteSpace: 'nowrap' }}>{item.label}</span>}
                  </div>

                  {!isCollapsed && isComingSoon && (
                    <span
                      style={{
                        fontSize: '0.6875rem',
                        fontWeight: '500',
                        padding: '1px 6px',
                        borderRadius: '4px',
                        backgroundColor: '#F1F5F9',
                        color: '#94A3B8'
                      }}
                    >
                      Soon
                    </span>
                  )}
                </button>
              );
            })}
          </nav>
        </div>
      </aside>
    </>
  );
}
