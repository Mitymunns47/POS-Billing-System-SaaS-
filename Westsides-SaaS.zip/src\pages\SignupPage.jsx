import React, { useState } from 'react';
import { useAuth } from '../context/AuthContext';
import { Button } from '../components/ui/Button';
import { Input } from '../components/ui/Input';
import { Card, CardHeader, CardTitle, CardDescription, CardContent } from '../components/ui/Card';
import { Alert } from '../components/ui/Alert';
import { User, Store, Mail, Phone, Lock, Eye, EyeOff, MapPin, Building, FileText, ArrowRight } from 'lucide-react';

export function SignupPage({ onNavigate }) {
  const { signup } = useAuth();

  const [formData, setFormData] = useState({
    ownerName: '',
    email: '',
    phone: '',
    password: '',
    confirmPassword: '',
    storeName: 'Westsides',
    storeAddress: '',
    city: '',
    state: '',
    country: 'India',
    gstNumber: '',
    storePhone: ''
  });

  const [showPassword, setShowPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState(null);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError(null);

    // Validation
    if (!formData.ownerName.trim()) {
      setError('Owner name is required.');
      return;
    }

    if (!formData.email.trim()) {
      setError('Email address is required.');
      return;
    }

    if (!formData.password || formData.password.length < 6) {
      setError('Password must be at least 6 characters long.');
      return;
    }

    if (formData.password !== formData.confirmPassword) {
      setError('Passwords do not match.');
      return;
    }

    if (!formData.storeName.trim()) {
      setError('Store name is required.');
      return;
    }

    setIsLoading(true);

    try {
      const result = await signup(formData);
      if (result.success) {
        onNavigate('/onboarding');
      }
    } catch (err) {
      setError(err.message || 'Failed to create your store. Please verify your details.');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div
      style={{
        minHeight: '100vh',
        backgroundColor: 'var(--bg-page)',
        padding: '2rem 1.5rem',
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center'
      }}
    >
      <div style={{ width: '100%', maxWidth: '720px' }} className="animate-fade-in">
        {/* Top Header */}
        <div style={{ textAlign: 'center', marginBottom: '2rem' }}>
          <div
            style={{
              width: '44px',
              height: '44px',
              borderRadius: '10px',
              backgroundColor: '#7EAFD0',
              display: 'inline-flex',
              alignItems: 'center',
              justifyContent: 'center',
              color: '#FFFFFF',
              fontWeight: '700',
              fontSize: '1.375rem',
              boxShadow: '0 4px 10px rgba(126, 175, 208, 0.3)',
              marginBottom: '0.75rem'
            }}
          >
            W
          </div>
          <h1
            style={{
              fontSize: '1.5rem',
              fontWeight: '700',
              color: 'var(--text-main)',
              margin: '0 0 4px 0'
            }}
          >
            Create Your Westsides Store
          </h1>
          <p style={{ fontSize: '0.875rem', color: 'var(--text-muted)' }}>
            Start your multi-tenant clothing store management workspace in minutes.
          </p>
        </div>

        {error && (
          <Alert variant="danger" style={{ marginBottom: '1.5rem' }} onDismiss={() => setError(null)}>
            {error}
          </Alert>
        )}

        <form onSubmit={handleSubmit}>
          {/* SECTION 1: OWNER INFORMATION */}
          <Card style={{ marginBottom: '1.5rem' }}>
            <CardHeader>
              <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                <User size={18} color="#7EAFD0" />
                <CardTitle style={{ fontSize: '1rem' }}>Owner Information</CardTitle>
              </div>
              <CardDescription>
                Primary administrator details for store ownership and access management.
              </CardDescription>
            </CardHeader>

            <CardContent>
              <div
                style={{
                  display: 'grid',
                  gridTemplateColumns: 'repeat(auto-fit, minmax(280px, 1fr))',
                  gap: '1.25rem'
                }}
              >
                <Input
                  label="Owner Full Name"
                  id="ownerName"
                  name="ownerName"
                  placeholder="e.g. John Doe"
                  value={formData.ownerName}
                  onChange={handleChange}
                  required
                  startIcon={<User size={16} />}
                />

                <Input
                  label="Email Address"
                  id="email"
                  name="email"
                  type="email"
                  placeholder="owner@domain.com"
                  value={formData.email}
                  onChange={handleChange}
                  required
                  startIcon={<Mail size={16} />}
                  helperText="Used for login and multi-tenant authentication."
                />

                <Input
                  label="Phone Number"
                  id="phone"
                  name="phone"
                  type="tel"
                  placeholder="+91 98765 43210"
                  value={formData.phone}
                  onChange={handleChange}
                  startIcon={<Phone size={16} />}
                />

                <Input
                  label="Password"
                  id="password"
                  name="password"
                  type={showPassword ? 'text' : 'password'}
                  placeholder="At least 6 characters"
                  value={formData.password}
                  onChange={handleChange}
                  required
                  startIcon={<Lock size={16} />}
                  endIcon={
                    <button
                      type="button"
                      onClick={() => setShowPassword(!showPassword)}
                      style={{ background: 'none', border: 'none', cursor: 'pointer', color: 'var(--text-muted)' }}
                    >
                      {showPassword ? <EyeOff size={16} /> : <Eye size={16} />}
                    </button>
                  }
                />

                <Input
                  label="Confirm Password"
                  id="confirmPassword"
                  name="confirmPassword"
                  type={showConfirmPassword ? 'text' : 'password'}
                  placeholder="Re-enter password"
                  value={formData.confirmPassword}
                  onChange={handleChange}
                  required
                  startIcon={<Lock size={16} />}
                  endIcon={
                    <button
                      type="button"
                      onClick={() => setShowConfirmPassword(!showConfirmPassword)}
                      style={{ background: 'none', border: 'none', cursor: 'pointer', color: 'var(--text-muted)' }}
                    >
                      {showConfirmPassword ? <EyeOff size={16} /> : <Eye size={16} />}
                    </button>
                  }
                />
              </div>
            </CardContent>
          </Card>

          {/* SECTION 2: STORE INFORMATION */}
          <Card style={{ marginBottom: '1.5rem' }}>
            <CardHeader>
              <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                <Store size={18} color="#7EAFD0" />
                <CardTitle style={{ fontSize: '1rem' }}>Store Information</CardTitle>
              </div>
              <CardDescription>
                Business identification for your clothing retail store. Prefilled with "Westsides".
              </CardDescription>
            </CardHeader>

            <CardContent>
              <div
                style={{
                  display: 'grid',
                  gridTemplateColumns: 'repeat(auto-fit, minmax(280px, 1fr))',
                  gap: '1.25rem'
                }}
              >
                <Input
                  label="Store Name"
                  id="storeName"
                  name="storeName"
                  placeholder="Store Name"
                  value={formData.storeName}
                  onChange={handleChange}
                  required
                  startIcon={<Store size={16} />}
                  helperText="Default demo: 'Westsides' (fully editable)."
                />

                <Input
                  label="Store Phone Number"
                  id="storePhone"
                  name="storePhone"
                  type="tel"
                  placeholder="Store contact number"
                  value={formData.storePhone}
                  onChange={handleChange}
                  startIcon={<Phone size={16} />}
                />

                <div style={{ gridColumn: '1 / -1' }}>
                  <Input
                    label="Store Address"
                    id="storeAddress"
                    name="storeAddress"
                    placeholder="Street, Landmark, Shop Number"
                    value={formData.storeAddress}
                    onChange={handleChange}
                    startIcon={<MapPin size={16} />}
                  />
                </div>

                <Input
                  label="City"
                  id="city"
                  name="city"
                  placeholder="e.g. Mumbai"
                  value={formData.city}
                  onChange={handleChange}
                  startIcon={<Building size={16} />}
                />

                <Input
                  label="State / Province"
                  id="state"
                  name="state"
                  placeholder="e.g. Maharashtra"
                  value={formData.state}
                  onChange={handleChange}
                />

                <Input
                  label="Country"
                  id="country"
                  name="country"
                  placeholder="e.g. India"
                  value={formData.country}
                  onChange={handleChange}
                />

                <Input
                  label="GST / Tax Identification Number"
                  id="gstNumber"
                  name="gstNumber"
                  placeholder="e.g. 27AABCS1429B1Z2"
                  value={formData.gstNumber}
                  onChange={handleChange}
                  startIcon={<FileText size={16} />}
                  helperText="Optional for initial setup; can be configured later."
                />
              </div>
            </CardContent>
          </Card>

          {/* Actions */}
          <div style={{ display: 'flex', flexDirection: 'column', gap: '1rem', alignItems: 'center' }}>
            <Button
              type="submit"
              variant="primary"
              size="lg"
              isLoading={isLoading}
              style={{ width: '100%', maxWidth: '320px', gap: '8px' }}
            >
              <span>Create Your Store</span>
              <ArrowRight size={18} />
            </Button>

            <div style={{ fontSize: '0.875rem', color: 'var(--text-muted)' }}>
              Already have an active store?{' '}
              <button
                type="button"
                onClick={() => onNavigate('/login')}
                style={{
                  background: 'none',
                  border: 'none',
                  padding: 0,
                  color: '#7EAFD0',
                  fontWeight: '600',
                  cursor: 'pointer'
                }}
              >
                Sign In
              </button>
            </div>
          </div>
        </form>
      </div>
    </div>
  );
}
