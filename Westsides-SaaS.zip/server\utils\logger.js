/**
 * Structured Server-Side Logger (Phase 8)
 * Formats timestamps, log levels, request tracing, and tenant context.
 * Never outputs sensitive credentials (passwords, tokens, cookies).
 */

function sanitize(data) {
  if (!data || typeof data !== 'object') return data;
  const clean = { ...data };
  const sensitiveKeys = ['password', 'passwordHash', 'token', 'westsides_session', 'secret', 'authorization'];
  for (const k of Object.keys(clean)) {
    if (sensitiveKeys.some(sk => k.toLowerCase().includes(sk))) {
      clean[k] = '[REDACTED]';
    } else if (typeof clean[k] === 'object') {
      clean[k] = sanitize(clean[k]);
    }
  }
  return clean;
}

const Logger = {
  format: (level, message, meta = {}) => {
    const timestamp = new Date().toISOString();
    const cleanMeta = sanitize(meta);
    const metaStr = Object.keys(cleanMeta).length > 0 ? ` ${JSON.stringify(cleanMeta)}` : '';
    return `[${timestamp}] [${level}] ${message}${metaStr}`;
  },

  info: (message, meta = {}) => {
    console.log(Logger.format('INFO', message, meta));
  },

  warn: (message, meta = {}) => {
    console.warn(Logger.format('WARN', message, meta));
  },

  error: (message, meta = {}) => {
    console.error(Logger.format('ERROR', message, meta));
  },

  security: (message, meta = {}) => {
    console.warn(Logger.format('SECURITY', message, meta));
  },

  requestMiddleware: (req, res, next) => {
    const start = Date.now();
    res.on('finish', () => {
      // Don't clutter logs with static assets unless error
      if (req.url.startsWith('/assets') || req.url.endsWith('.ico') || req.url.endsWith('.js') || req.url.endsWith('.css')) {
        return;
      }
      const duration = Date.now() - start;
      const meta = {
        method: req.method,
        url: req.originalUrl || req.url,
        status: res.statusCode,
        durationMs: duration,
        storeId: req.storeId || req.auth?.storeId || undefined,
        userId: req.userId || req.auth?.userId || undefined,
        ip: req.ip || req.connection?.remoteAddress
      };

      if (res.statusCode >= 500) {
        Logger.error(`HTTP ${req.method} ${req.originalUrl} - ${res.statusCode}`, meta);
      } else if (res.statusCode >= 400) {
        Logger.warn(`HTTP ${req.method} ${req.originalUrl} - ${res.statusCode}`, meta);
      } else if (process.env.NODE_ENV !== 'production' || req.originalUrl.startsWith('/api')) {
        Logger.info(`HTTP ${req.method} ${req.originalUrl} - ${res.statusCode} (${duration}ms)`, meta);
      }
    });
    next();
  }
};

module.exports = Logger;
