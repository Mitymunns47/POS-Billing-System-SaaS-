const express = require('express');
const router = express.Router();
const CategoryModel = require('../models/categoryModel');
const BrandModel = require('../models/brandModel');
const authMiddleware = require('../middleware/auth');
const { requirePermission } = require('../middleware/roles');
const { PERMISSIONS } = require('../constants/roles');

router.use(authMiddleware);

// ── CATEGORIES ────────────────────────────────────────────────────────────────

router.get('/categories', requirePermission(PERMISSIONS.CATEGORIES_VIEW), (req, res) => {
  try {
    const categories = CategoryModel.findAll(req.storeId);
    res.json({ success: true, categories });
  } catch (err) {
    console.error('List categories error:', err);
    res.status(500).json({ success: false, error: 'Could not load categories.' });
  }
});

router.post('/categories', requirePermission(PERMISSIONS.CATEGORIES_CREATE), (req, res) => {
  try {
    const { name, description } = req.body;
    if (!name || !name.trim()) return res.status(400).json({ success: false, error: 'Category name is required.' });
    if (CategoryModel.checkDuplicate(req.storeId, name)) {
      return res.status(400).json({ success: false, error: `Category "${name.trim()}" already exists.` });
    }
    const category = CategoryModel.create({ storeId: req.storeId, name, description });
    res.status(201).json({ success: true, message: 'Category created.', category });
  } catch (err) {
    console.error('Create category error:', err);
    res.status(500).json({ success: false, error: 'Could not create category.' });
  }
});

router.put('/categories/:id', requirePermission(PERMISSIONS.CATEGORIES_EDIT), (req, res) => {
  try {
    const { name, description, active } = req.body;
    if (name && CategoryModel.checkDuplicate(req.storeId, name, req.params.id)) {
      return res.status(400).json({ success: false, error: `Category "${name.trim()}" already exists.` });
    }
    const updated = CategoryModel.update(req.params.id, req.storeId, { name, description, active });
    if (!updated) return res.status(404).json({ success: false, error: 'Category not found.' });
    res.json({ success: true, message: 'Category updated.', category: updated });
  } catch (err) {
    res.status(500).json({ success: false, error: 'Could not update category.' });
  }
});

router.delete('/categories/:id', requirePermission(PERMISSIONS.CATEGORIES_DELETE), (req, res) => {
  try {
    const ok = CategoryModel.delete(req.params.id, req.storeId);
    if (!ok) return res.status(404).json({ success: false, error: 'Category not found.' });
    res.json({ success: true, message: 'Category deactivated.' });
  } catch (err) {
    res.status(500).json({ success: false, error: 'Could not delete category.' });
  }
});

// ── BRANDS ────────────────────────────────────────────────────────────────────

router.get('/brands', requirePermission(PERMISSIONS.BRANDS_VIEW), (req, res) => {
  try {
    const brands = BrandModel.findAll(req.storeId);
    res.json({ success: true, brands });
  } catch (err) {
    res.status(500).json({ success: false, error: 'Could not load brands.' });
  }
});

router.post('/brands', requirePermission(PERMISSIONS.BRANDS_CREATE), (req, res) => {
  try {
    const { name, description } = req.body;
    if (!name || !name.trim()) return res.status(400).json({ success: false, error: 'Brand name is required.' });
    if (BrandModel.checkDuplicate(req.storeId, name)) {
      return res.status(400).json({ success: false, error: `Brand "${name.trim()}" already exists.` });
    }
    const brand = BrandModel.create({ storeId: req.storeId, name, description });
    res.status(201).json({ success: true, message: 'Brand created.', brand });
  } catch (err) {
    res.status(500).json({ success: false, error: 'Could not create brand.' });
  }
});

router.put('/brands/:id', requirePermission(PERMISSIONS.BRANDS_EDIT), (req, res) => {
  try {
    const { name, description, active } = req.body;
    if (name && BrandModel.checkDuplicate(req.storeId, name, req.params.id)) {
      return res.status(400).json({ success: false, error: `Brand "${name.trim()}" already exists.` });
    }
    const updated = BrandModel.update(req.params.id, req.storeId, { name, description, active });
    if (!updated) return res.status(404).json({ success: false, error: 'Brand not found.' });
    res.json({ success: true, message: 'Brand updated.', brand: updated });
  } catch (err) {
    res.status(500).json({ success: false, error: 'Could not update brand.' });
  }
});

router.delete('/brands/:id', requirePermission(PERMISSIONS.BRANDS_DELETE), (req, res) => {
  try {
    const ok = BrandModel.delete(req.params.id, req.storeId);
    if (!ok) return res.status(404).json({ success: false, error: 'Brand not found.' });
    res.json({ success: true, message: 'Brand deactivated.' });
  } catch (err) {
    res.status(500).json({ success: false, error: 'Could not delete brand.' });
  }
});

module.exports = router;
