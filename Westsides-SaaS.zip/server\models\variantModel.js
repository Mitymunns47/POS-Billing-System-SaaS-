const crypto = require('crypto');
const db = require('../db/database');

const VariantModel = {
  create: ({ productId, storeId, size, color, sku, barcode, price, stock, minimumStock }) => {
    const id = 'var_' + crypto.randomBytes(8).toString('hex');
    const now = new Date().toISOString();
    db.prepare(`
      INSERT INTO product_variants
        (id, productId, storeId, size, color, sku, barcode, price, stock, minimumStock, active, createdAt, updatedAt)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 1, ?, ?)
    `).run(
      id, productId, storeId,
      size ? size.trim() : null,
      color ? color.trim() : null,
      sku ? sku.trim().toUpperCase() : null,
      barcode ? barcode.trim() : null,
      price !== undefined && price !== null ? Number(price) : null,
      Number(stock) || 0,
      Number(minimumStock) || 0,
      now, now
    );
    return VariantModel.findById(id, storeId);
  },

  findById: (id, storeId) => {
    const row = db.prepare(
      'SELECT * FROM product_variants WHERE id = ? AND storeId = ?'
    ).get(id, storeId);
    return row ? { ...row, active: Boolean(row.active) } : null;
  },

  findByProduct: (productId, storeId) => {
    return db.prepare(
      'SELECT * FROM product_variants WHERE productId = ? AND storeId = ? ORDER BY size ASC, color ASC'
    ).all(productId, storeId).map(r => ({
      ...r,
      active: Boolean(r.active),
      stockStatus: r.stock === 0 ? 'OUT_OF_STOCK' : r.stock <= r.minimumStock ? 'LOW_STOCK' : 'IN_STOCK'
    }));
  },

  update: (id, storeId, fields) => {
    const now = new Date().toISOString();
    if (!VariantModel.findById(id, storeId)) return null;
    const allowed = ['size', 'color', 'sku', 'barcode', 'price', 'stock', 'minimumStock', 'active'];
    const sets = [];
    const vals = [];
    for (const key of allowed) {
      if (fields[key] !== undefined) {
        sets.push(`${key} = ?`);
        if (key === 'sku') vals.push(fields[key] ? String(fields[key]).trim().toUpperCase() : null);
        else if (key === 'active') vals.push(fields[key] ? 1 : 0);
        else vals.push(fields[key] !== null ? fields[key] : null);
      }
    }
    if (sets.length === 0) return VariantModel.findById(id, storeId);
    sets.push('updatedAt = ?');
    vals.push(now, id, storeId);
    db.prepare(`UPDATE product_variants SET ${sets.join(', ')} WHERE id = ? AND storeId = ?`).run(...vals);
    return VariantModel.findById(id, storeId);
  },

  delete: (id, storeId) => {
    const info = db.prepare(
      'DELETE FROM product_variants WHERE id = ? AND storeId = ?'
    ).run(id, storeId);
    return info.changes > 0;
  },

  checkDuplicateBarcode: (storeId, barcode, excludeId = null) => {
    if (!barcode || !barcode.trim()) return false;
    const sql = excludeId
      ? 'SELECT id FROM product_variants WHERE storeId = ? AND barcode = ? AND id != ?'
      : 'SELECT id FROM product_variants WHERE storeId = ? AND barcode = ?';
    const params = excludeId ? [storeId, barcode.trim(), excludeId] : [storeId, barcode.trim()];
    return !!db.prepare(sql).get(...params);
  },

  // Inventory adjustment — direct stock change and returns delta
  adjustStock: (id, storeId, newStock) => {
    const variant = VariantModel.findById(id, storeId);
    if (!variant) return null;
    const prev = variant.stock;
    VariantModel.update(id, storeId, { stock: newStock });
    return { prev, current: newStock };
  }
};

module.exports = VariantModel;
