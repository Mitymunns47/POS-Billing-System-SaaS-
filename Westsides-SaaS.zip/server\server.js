const express = require('express');
const path = require('path');
const cors = require('cors');
const cookieParser = require('cookie-parser');
const config = require('./config');
const db = require('./db/database');
const logger = require('./utils/logger');
const securityHeaders = require('./middleware/securityHeaders');
const idempotencyMiddleware = require('./middleware/idempotency');
const { authLimiter } = require('./middleware/rateLimiter');

// Feature Route Modules
const authRoutes = require('./routes/authRoutes');
const storeRoutes = require('./routes/storeRoutes');
const catalogRoutes = require('./routes/catalogRoutes');
const productRoutes = require('./routes/productRoutes');
const inventoryRoutes = require('./routes/inventoryRoutes');
const customerRoutes = require('./routes/customerRoutes');
const posRoutes = require('./routes/posRoutes');
const staffRoutes = require('./routes/staffRoutes');
const reportRoutes = require('./routes/reportRoutes');
const expenseRoutes = require('./routes/expenseRoutes');
const returnRoutes = require('./routes/returnRoutes');
const settingsRoutes = require('./routes/settingsRoutes');
const notificationRoutes = require('./routes/notificationRoutes');
const adminRoutes = require('./routes/adminRoutes'); // Phase 7

const app = express();

// ── Security & Utility Middlewares ──────────────────────────────────────────
app.use(securityHeaders);
app.use(logger.requestMiddleware);
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true, limit: '10mb' }));
app.use(cookieParser());

// CORS configuration (supports credentials for web + headers for mobile)
app.use(cors({
  origin: true,
  credentials: true,
  methods: ['GET', 'POST', 'PUT', 'PATCH', 'DELETE', 'OPTIONS'],
  allowedHeaders: ['Content-Type', 'Authorization', 'Idempotency-Key', 'X-Idempotency-Key']
}));

// Idempotency for duplicate request prevention (POS sales, refunds, expenses)
app.use(idempotencyMiddleware());

// ── Unified API Router (Phase 8 Mobile & Web Foundation) ─────────────────────
// Mounts feature routes onto a single router mounted at both `/api` and `/api/v1`
const apiRouter = express.Router();

// Rate limiting on sensitive authentication routes
apiRouter.use('/auth/login', authLimiter);
apiRouter.use('/auth/signup', authLimiter);
apiRouter.use('/auth/admin-login', authLimiter);

apiRouter.use('/auth', authRoutes);
apiRouter.use('/store', storeRoutes);
apiRouter.use('/catalog', catalogRoutes);
apiRouter.use('/products', productRoutes);
apiRouter.use('/inventory', inventoryRoutes);
apiRouter.use('/customers', customerRoutes);
apiRouter.use('/pos', posRoutes);
apiRouter.use('/staff', staffRoutes);
apiRouter.use('/reports', reportRoutes);
apiRouter.use('/expenses', expenseRoutes);
apiRouter.use('/returns', returnRoutes);
apiRouter.use('/settings', settingsRoutes);
apiRouter.use('/notifications', notificationRoutes);
apiRouter.use('/admin', adminRoutes); // Super Admin Platform (SUPER_ADMIN only)

// Healthcheck handler function
function handleHealth(req, res) {
  let dbStatus = 'healthy';
  let dbLatencyMs = 0;
  try {
    const start = Date.now();
    db.prepare('SELECT 1').get();
    dbLatencyMs = Date.now() - start;
  } catch (err) {
    dbStatus = 'degraded';
  }

  res.json({
    status: dbStatus === 'healthy' ? 'healthy' : 'degraded',
    application: 'Westsides Clothing Store Management SaaS',
    version: '1.0.0',
    phase: 'Phase 8 - Final Production Readiness, Security, Testing, Optimization, Deployment & Mobile API Foundation',
    environment: config.nodeEnv,
    uptimeSeconds: Math.floor(process.uptime()),
    database: {
      status: dbStatus,
      latencyMs: dbLatencyMs,
      engine: 'SQLite WAL mode'
    },
    mobileApi: {
      version: 'v1',
      supportedPrefix: '/api/v1',
      auth: 'Bearer <token> or Cookie'
    },
    timestamp: new Date().toISOString()
  });
}

// Register health endpoints
app.get('/api/health', handleHealth);
app.get('/api/v1/health', handleHealth);

// Register both /api and /api/v1 (mobile foundation)
app.use('/api', apiRouter);
app.use('/api/v1', apiRouter);

// ── Static Frontend & SPA Fallback ───────────────────────────────────────────
const distPath = path.join(__dirname, '..', 'dist');
app.use(express.static(distPath));

// Fallback to index.html for SPA client-side routing
app.use((req, res, next) => {
  if (req.method !== 'GET' || req.path.startsWith('/api')) {
    return next();
  }
  const indexPath = path.join(distPath, 'index.html');
  res.sendFile(indexPath, (err) => {
    if (err) {
      res.status(200).send(`
        <!DOCTYPE html>
        <html>
          <head><title>Westsides SaaS</title></head>
          <body style="font-family: sans-serif; padding: 40px; text-align: center;">
            <h2>Westsides Backend Running</h2>
            <p>Frontend is currently building or running in Vite dev mode.</p>
          </body>
        </html>
      `);
    }
  });
});

// ── Global Error Handler (Sanitized for Production) ─────────────────────────
app.use((err, req, res, next) => {
  logger.error('Unhandled server error', {
    error: err.message,
    path: req.originalUrl,
    method: req.method,
    stack: process.env.NODE_ENV === 'development' ? err.stack : undefined
  });

  res.status(err.status || 500).json({
    success: false,
    error: process.env.NODE_ENV === 'production' 
      ? 'An unexpected server error occurred. Please contact support.'
      : (err.message || 'Internal server error occurred.')
  });
});

const server = app.listen(config.port, () => {
  logger.info(`[Westsides SaaS] Server running on http://localhost:${config.port}`);
});

module.exports = { app, server };
