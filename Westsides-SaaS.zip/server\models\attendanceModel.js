const crypto = require('crypto');
const db = require('../db/database');

const AttendanceModel = {
  /**
   * Record or update staff attendance for a specific date
   */
  record: ({ storeId, userId, date, checkIn, checkOut, status = 'PRESENT', notes }) => {
    if (!['PRESENT', 'ABSENT', 'LATE', 'LEAVE'].includes(status)) {
      throw new Error('Status must be PRESENT, ABSENT, LATE, or LEAVE.');
    }

    const now = new Date().toISOString();
    const id = 'att_' + crypto.randomBytes(8).toString('hex');

    db.prepare(`
      INSERT INTO attendance (id, storeId, userId, date, checkIn, checkOut, status, notes, createdAt, updatedAt)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
      ON CONFLICT(storeId, userId, date) DO UPDATE SET
        checkIn = COALESCE(excluded.checkIn, attendance.checkIn),
        checkOut = COALESCE(excluded.checkOut, attendance.checkOut),
        status = excluded.status,
        notes = COALESCE(excluded.notes, attendance.notes),
        updatedAt = excluded.updatedAt
    `).run(id, storeId, userId, date, checkIn || null, checkOut || null, status, notes ? notes.trim() : null, now, now);

    return AttendanceModel.findByDateAndUser(storeId, userId, date);
  },

  /**
   * Find single attendance record
   */
  findByDateAndUser: (storeId, userId, date) => {
    return db.prepare(`
      SELECT a.*, u.name as staffName, u.email as staffEmail, su.role as staffRole
      FROM attendance a
      JOIN users u ON a.userId = u.id
      JOIN store_users su ON (a.userId = su.userId AND a.storeId = su.storeId)
      WHERE a.storeId = ? AND a.userId = ? AND a.date = ?
    `).get(storeId, userId, date) || null;
  },

  /**
   * List attendance records for a store
   */
  findAll: ({ storeId, date = '', userId = '', status = '', page = 1, limit = 30 }) => {
    const offset = (page - 1) * limit;
    const conditions = ['a.storeId = ?'];
    const params = [storeId];

    if (date) {
      conditions.push('a.date = ?');
      params.push(date);
    }
    if (userId) {
      conditions.push('a.userId = ?');
      params.push(userId);
    }
    if (status) {
      conditions.push('a.status = ?');
      params.push(status);
    }

    const where = conditions.join(' AND ');

    const total = db.prepare(`SELECT COUNT(*) AS cnt FROM attendance a WHERE ${where}`).get(...params).cnt;

    const rows = db.prepare(`
      SELECT
        a.*, u.name as staffName, u.email as staffEmail, su.role as staffRole
      FROM attendance a
      JOIN users u ON a.userId = u.id
      JOIN store_users su ON (a.userId = su.userId AND a.storeId = su.storeId)
      WHERE ${where}
      ORDER BY a.date DESC, u.name ASC
      LIMIT ? OFFSET ?
    `).all(...params, limit, offset);

    return {
      attendance: rows,
      records: rows,
      total,
      page: Number(page),
      limit: Number(limit),
      totalPages: Math.ceil(total / limit)
    };
  }
};

module.exports = AttendanceModel;
