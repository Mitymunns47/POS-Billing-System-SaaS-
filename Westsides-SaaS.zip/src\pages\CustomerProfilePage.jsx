import React, { useState, useEffect, useCallback } from 'react';
import { api } from '../services/api';
import { useAuth } from '../context/AuthContext';
import { Button } from '../components/ui/Button';
import { Input } from '../components/ui/Input';
import { Alert } from '../components/ui/Alert';
import { Badge } from '../components/ui/Badge';
import { Modal } from '../components/ui/Modal';
import {
  ArrowLeft,
  User,
  Phone,
  Mail,
  MapPin,
  Calendar,
  ShoppingBag,
  IndianRupee,
  Receipt,
  RotateCcw,
  Edit2,
  Archive,
  RefreshCw,
  Printer,
  ChevronLeft,
  ChevronRight,
  TrendingUp,
  Clock,
  Tag
} from 'lucide-react';

const fmt = (n) => Number(n || 0).toFixed(2);

export function CustomerProfilePage({ customerId, onNavigate }) {
  const { store } = useAuth();

  const [customer, setCustomer] = useState(null);
  const [purchaseSummary, setPurchaseSummary] = useState(null);
  const [sales, setSales] = useState([]);
  const [pagination, setPagination] = useState({ page: 1, limit: 10, total: 0, pages: 1 });
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [successMsg, setSuccessMsg] = useState(null);

  // Edit Modal State
  const [isEditModalOpen, setIsEditModalOpen] = useState(false);
  const [editForm, setEditForm] = useState({});
  const [editErrors, setEditErrors] = useState({});
  const [savingEdit, setSavingEdit] = useState(false);

  // Invoice Receipt Modal State
  const [selectedInvoice, setSelectedInvoice] = useState(null);
  const [loadingInvoice, setLoadingInvoice] = useState(false);

  // Archive / Restore Confirmation
  const [confirmArchive, setConfirmArchive] = useState(false);
  const [confirmRestore, setConfirmRestore] = useState(false);
  const [actionLoading, setActionLoading] = useState(false);

  // Returns History State
  const [activeHistoryTab, setActiveHistoryTab] = useState('orders'); // 'orders' | 'returns'
  const [customerReturns, setCustomerReturns] = useState([]);
  const [returnsPagination, setReturnsPagination] = useState({ page: 1, limit: 10, total: 0, pages: 1 });

  // Load Customer Profile & Summary
  const loadProfile = useCallback(async () => {
    if (!customerId) return;
    setLoading(true);
    setError(null);
    try {
      const res = await api.getCustomer(customerId);
      if (res.success) {
        setCustomer(res.customer);
        setPurchaseSummary(res.purchaseSummary);
      }
    } catch (err) {
      setError(err.message || 'Could not load customer profile.');
    } finally {
      setLoading(false);
    }
  }, [customerId]);

  // Load Sales History
  const loadSalesHistory = useCallback(async (page = 1) => {
    if (!customerId) return;
    try {
      const res = await api.getCustomerSales(customerId, { page, limit: pagination.limit });
      if (res.success) {
        setSales(res.sales || []);
        setPagination({
          page: res.page || 1,
          limit: res.limit || 10,
          total: res.total || 0,
          pages: res.totalPages || 1
        });
      }
    } catch (err) {
      console.error('Failed to load sales history:', err);
    }
  }, [customerId, pagination.limit]);

  // Load Returns History
  const loadReturnsHistory = useCallback(async (page = 1) => {
    if (!customerId) return;
    try {
      const res = await api.getCustomerReturns(customerId, { page, limit: 10 });
      if (res.success) {
        setCustomerReturns(res.returns || []);
        setReturnsPagination({
          page: res.page || 1,
          limit: res.limit || 10,
          total: res.total || 0,
          pages: res.totalPages || 1
        });
      }
    } catch (err) {
      console.error('Failed to load returns history:', err);
    }
  }, [customerId]);

  useEffect(() => {
    loadProfile();
    loadSalesHistory(1);
    loadReturnsHistory(1);
  }, [loadProfile, loadSalesHistory, loadReturnsHistory]);

  // Open Edit Modal
  const handleOpenEdit = () => {
    if (!customer) return;
    setEditForm({
      name: customer.name || '',
      phone: customer.phone || '',
      email: customer.email || '',
      dateOfBirth: customer.dateOfBirth || '',
      gender: customer.gender || '',
      address: customer.address || '',
      city: customer.city || '',
      state: customer.state || '',
      postalCode: customer.postalCode || '',
      notes: customer.notes || ''
    });
    setEditErrors({});
    setIsEditModalOpen(true);
  };

  // Submit Edit
  const handleSaveEdit = async (e) => {
    e.preventDefault();
    if (!editForm.name?.trim()) {
      setEditErrors({ name: 'Full name is required.' });
      return;
    }

    setSavingEdit(true);
    setEditErrors({});
    try {
      const res = await api.updateCustomer(customerId, editForm);
      if (res.success) {
        setCustomer(res.customer);
        setIsEditModalOpen(false);
        setSuccessMsg('Customer profile updated successfully.');
      }
    } catch (err) {
      setEditErrors({ submit: err.message || 'Failed to update customer.' });
    } finally {
      setSavingEdit(false);
    }
  };

  // Archive
  const handleArchive = async () => {
    setActionLoading(true);
    try {
      const res = await api.archiveCustomer(customerId);
      if (res.success) {
        setCustomer(res.customer);
        setConfirmArchive(false);
        setSuccessMsg('Customer archived successfully.');
      }
    } catch (err) {
      setError(err.message || 'Failed to archive customer.');
    } finally {
      setActionLoading(false);
    }
  };

  // Restore
  const handleRestore = async () => {
    setActionLoading(true);
    try {
      const res = await api.restoreCustomer(customerId);
      if (res.success) {
        setCustomer(res.customer);
        setConfirmRestore(false);
        setSuccessMsg('Customer restored to active status.');
      }
    } catch (err) {
      setError(err.message || 'Failed to restore customer.');
    } finally {
      setActionLoading(false);
    }
  };

  // View Invoice Receipt
  const handleViewInvoice = async (sale) => {
    setSelectedInvoice(sale);
    setLoadingInvoice(true);
    try {
      const res = await api.getSale(sale.id);
      if (res.success) {
        setSelectedInvoice(res.sale);
      }
    } catch (err) {
      console.error('Failed to load invoice items:', err);
    } finally {
      setLoadingInvoice(false);
    }
  };

  if (loading) {
    return (
      <div style={{ padding: '3rem 1rem', textAlign: 'center', color: 'var(--text-muted)' }}>
        <div style={{ display: 'inline-block', width: '24px', height: '24px', border: '2px solid #7EAFD0', borderTopColor: 'transparent', borderRadius: '50%', animation: 'spin 0.8s linear infinite', marginBottom: '8px' }} />
        <div>Loading customer profile...</div>
      </div>
    );
  }

  if (error || !customer) {
    return (
      <div style={{ maxWidth: '800px', margin: '0 auto', display: 'flex', flexDirection: 'column', gap: '1rem' }}>
        <Button variant="ghost" onClick={() => onNavigate('/customers')} style={{ alignSelf: 'flex-start' }}>
          <ArrowLeft size={16} style={{ marginRight: '6px' }} /> Back to Customers
        </Button>
        <Alert variant="danger">
          {error || 'Customer profile not found.'}
        </Alert>
      </div>
    );
  }

  return (
    <div style={{ maxWidth: '1200px', margin: '0 auto', display: 'flex', flexDirection: 'column', gap: '1.5rem' }}>
      {/* Back button & Action Header */}
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: '1rem' }}>
        <Button
          variant="outline"
          size="sm"
          onClick={() => onNavigate('/customers')}
          style={{ display: 'flex', alignItems: 'center', gap: '6px' }}
        >
          <ArrowLeft size={15} />
          Back to Customer Directory
        </Button>

        <div style={{ display: 'flex', gap: '0.75rem' }}>
          <Button
            variant="outline"
            size="sm"
            onClick={handleOpenEdit}
            style={{ display: 'flex', alignItems: 'center', gap: '6px' }}
          >
            <Edit2 size={14} />
            Edit Profile
          </Button>

          {customer.status === 'ARCHIVED' ? (
            <Button
              variant="outline"
              size="sm"
              onClick={() => setConfirmRestore(true)}
              style={{ display: 'flex', alignItems: 'center', gap: '6px', color: '#10B981' }}
            >
              <RefreshCw size={14} />
              Restore Customer
            </Button>
          ) : (
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setConfirmArchive(true)}
              style={{ display: 'flex', alignItems: 'center', gap: '6px', color: '#EF4444' }}
            >
              <Archive size={14} />
              Archive
            </Button>
          )}
        </div>
      </div>

      {successMsg && (
        <Alert variant="success" onClose={() => setSuccessMsg(null)}>
          {successMsg}
        </Alert>
      )}

      {/* Profile Overview Card */}
      <div style={{ backgroundColor: '#FFFFFF', borderRadius: 'var(--radius-lg)', border: '1px solid var(--border-color)', padding: '1.5rem', boxShadow: 'var(--shadow-sm)' }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', flexWrap: 'wrap', gap: '1rem' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '1rem' }}>
            <div style={{ width: '56px', height: '56px', borderRadius: '50%', backgroundColor: 'rgba(126, 175, 208, 0.15)', color: '#7EAFD0', display: 'flex', alignItems: 'center', justifyContent: 'center', fontWeight: '800', fontSize: '1.375rem' }}>
              {customer.name.charAt(0).toUpperCase()}
            </div>
            <div>
              <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
                <h1 style={{ margin: 0, fontSize: '1.375rem', fontWeight: '700', color: 'var(--text-main)' }}>
                  {customer.name}
                </h1>
                <Badge variant={customer.status === 'ARCHIVED' ? 'neutral' : 'success'} size="sm">
                  {customer.status === 'ARCHIVED' ? 'Archived' : 'Active Shopper'}
                </Badge>
              </div>
              <div style={{ display: 'flex', alignItems: 'center', gap: '1rem', marginTop: '6px', color: 'var(--text-muted)', fontSize: '0.8125rem', flexWrap: 'wrap' }}>
                {customer.phone && (
                  <span style={{ display: 'flex', alignItems: 'center', gap: '4px' }}>
                    <Phone size={13} /> {customer.phone}
                  </span>
                )}
                {customer.email && (
                  <span style={{ display: 'flex', alignItems: 'center', gap: '4px' }}>
                    <Mail size={13} /> {customer.email}
                  </span>
                )}
                <span>Customer since {new Date(customer.createdAt).toLocaleDateString('en-IN', { month: 'short', year: 'numeric' })}</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Calculated Purchase Summary Cards */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(210px, 1fr))', gap: '1rem' }}>
        <div style={{ backgroundColor: '#FFFFFF', padding: '1.25rem', borderRadius: 'var(--radius-lg)', border: '1px solid var(--border-color)', boxShadow: 'var(--shadow-sm)' }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: '8px' }}>
            <span style={{ fontSize: '0.8125rem', fontWeight: '600', color: 'var(--text-muted)' }}>Total Amount Spent</span>
            <div style={{ width: '32px', height: '32px', borderRadius: '8px', backgroundColor: 'rgba(126, 175, 208, 0.15)', display: 'flex', alignItems: 'center', justifyContent: 'center', color: '#7EAFD0' }}>
              <IndianRupee size={16} />
            </div>
          </div>
          <div style={{ fontSize: '1.5rem', fontWeight: '800', color: 'var(--text-main)' }}>
            ₹{fmt(purchaseSummary?.totalSpent || 0)}
          </div>
          <div style={{ fontSize: '0.75rem', color: 'var(--text-muted)', marginTop: '4px' }}>
            Lifetime customer spend
          </div>
        </div>

        <div style={{ backgroundColor: '#FFFFFF', padding: '1.25rem', borderRadius: 'var(--radius-lg)', border: '1px solid var(--border-color)', boxShadow: 'var(--shadow-sm)' }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: '8px' }}>
            <span style={{ fontSize: '0.8125rem', fontWeight: '600', color: 'var(--text-muted)' }}>Total Orders</span>
            <div style={{ width: '32px', height: '32px', borderRadius: '8px', backgroundColor: 'rgba(16, 185, 129, 0.12)', display: 'flex', alignItems: 'center', justifyContent: 'center', color: '#10B981' }}>
              <ShoppingBag size={16} />
            </div>
          </div>
          <div style={{ fontSize: '1.5rem', fontWeight: '800', color: 'var(--text-main)' }}>
            {purchaseSummary?.totalOrders || 0}
          </div>
          <div style={{ fontSize: '0.75rem', color: 'var(--text-muted)', marginTop: '4px' }}>
            Completed checkout visits
          </div>
        </div>

        <div style={{ backgroundColor: '#FFFFFF', padding: '1.25rem', borderRadius: 'var(--radius-lg)', border: '1px solid var(--border-color)', boxShadow: 'var(--shadow-sm)' }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: '8px' }}>
            <span style={{ fontSize: '0.8125rem', fontWeight: '600', color: 'var(--text-muted)' }}>Items Purchased</span>
            <div style={{ width: '32px', height: '32px', borderRadius: '8px', backgroundColor: 'rgba(59, 130, 246, 0.12)', display: 'flex', alignItems: 'center', justifyContent: 'center', color: '#3B82F6' }}>
              <Tag size={16} />
            </div>
          </div>
          <div style={{ fontSize: '1.5rem', fontWeight: '800', color: 'var(--text-main)' }}>
            {purchaseSummary?.totalItems || 0}
          </div>
          <div style={{ fontSize: '0.75rem', color: 'var(--text-muted)', marginTop: '4px' }}>
            Total garment units bought
          </div>
        </div>

        <div style={{ backgroundColor: '#FFFFFF', padding: '1.25rem', borderRadius: 'var(--radius-lg)', border: '1px solid var(--border-color)', boxShadow: 'var(--shadow-sm)' }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: '8px' }}>
            <span style={{ fontSize: '0.8125rem', fontWeight: '600', color: 'var(--text-muted)' }}>Average Order Value</span>
            <div style={{ width: '32px', height: '32px', borderRadius: '8px', backgroundColor: 'rgba(245, 158, 11, 0.12)', display: 'flex', alignItems: 'center', justifyContent: 'center', color: '#F59E0B' }}>
              <TrendingUp size={16} />
            </div>
          </div>
          <div style={{ fontSize: '1.5rem', fontWeight: '800', color: 'var(--text-main)' }}>
            ₹{fmt(purchaseSummary?.averageOrderValue || 0)}
          </div>
          <div style={{ fontSize: '0.75rem', color: 'var(--text-muted)', marginTop: '4px' }}>
            Per shopping session
          </div>
        </div>
      </div>

      {/* Details & Address Section */}
      <div style={{ backgroundColor: '#FFFFFF', borderRadius: 'var(--radius-lg)', border: '1px solid var(--border-color)', padding: '1.5rem', boxShadow: 'var(--shadow-sm)' }}>
        <h2 style={{ fontSize: '1rem', fontWeight: '700', color: 'var(--text-main)', margin: '0 0 1rem 0' }}>
          Customer Information & Profile
        </h2>

        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(240px, 1fr))', gap: '1.25rem', fontSize: '0.875rem' }}>
          <div>
            <span style={{ color: 'var(--text-muted)', fontSize: '0.75rem', textTransform: 'uppercase', fontWeight: '600', display: 'block', marginBottom: '4px' }}>Gender</span>
            <span style={{ fontWeight: '500', color: 'var(--text-main)' }}>{customer.gender || 'Not specified'}</span>
          </div>

          <div>
            <span style={{ color: 'var(--text-muted)', fontSize: '0.75rem', textTransform: 'uppercase', fontWeight: '600', display: 'block', marginBottom: '4px' }}>Date of Birth</span>
            <span style={{ fontWeight: '500', color: 'var(--text-main)' }}>
              {customer.dateOfBirth ? new Date(customer.dateOfBirth).toLocaleDateString('en-IN') : 'Not specified'}
            </span>
          </div>

          <div>
            <span style={{ color: 'var(--text-muted)', fontSize: '0.75rem', textTransform: 'uppercase', fontWeight: '600', display: 'block', marginBottom: '4px' }}>City & State</span>
            <span style={{ fontWeight: '500', color: 'var(--text-main)' }}>
              {[customer.city, customer.state].filter(Boolean).join(', ') || 'Not specified'}
            </span>
          </div>

          <div>
            <span style={{ color: 'var(--text-muted)', fontSize: '0.75rem', textTransform: 'uppercase', fontWeight: '600', display: 'block', marginBottom: '4px' }}>Postal Code</span>
            <span style={{ fontWeight: '500', color: 'var(--text-main)' }}>{customer.postalCode || 'Not specified'}</span>
          </div>

          <div style={{ gridColumn: '1 / -1' }}>
            <span style={{ color: 'var(--text-muted)', fontSize: '0.75rem', textTransform: 'uppercase', fontWeight: '600', display: 'block', marginBottom: '4px' }}>Street Address</span>
            <span style={{ fontWeight: '500', color: 'var(--text-main)' }}>{customer.address || 'No street address provided.'}</span>
          </div>

          {customer.notes && (
            <div style={{ gridColumn: '1 / -1', padding: '10px 14px', backgroundColor: 'var(--bg-page)', borderRadius: 'var(--radius-md)', border: '1px solid var(--border-subtle)' }}>
              <span style={{ color: 'var(--text-muted)', fontSize: '0.75rem', textTransform: 'uppercase', fontWeight: '600', display: 'block', marginBottom: '4px' }}>Notes & Preferences</span>
              <span style={{ color: 'var(--text-main)', fontSize: '0.8125rem' }}>{customer.notes}</span>
            </div>
          )}
        </div>
      </div>

      {/* Real Purchase History Table */}
      <div style={{ backgroundColor: '#FFFFFF', borderRadius: 'var(--radius-lg)', border: '1px solid var(--border-color)', boxShadow: 'var(--shadow-sm)', overflow: 'hidden' }}>
        <div style={{ padding: '1rem 1.25rem', borderBottom: '1px solid var(--border-color)', display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: '0.75rem' }}>
          <div>
            <h2 style={{ fontSize: '1rem', fontWeight: '700', color: 'var(--text-main)', margin: 0 }}>
              Transaction Records
            </h2>
            <p style={{ margin: '2px 0 0 0', color: 'var(--text-muted)', fontSize: '0.75rem' }}>
              Real POS orders and customer return records.
            </p>
          </div>

          <div style={{ display: 'flex', backgroundColor: 'var(--bg-page)', border: '1px solid var(--border-color)', borderRadius: 'var(--radius-md)', padding: '2px' }}>
            <button
              onClick={() => setActiveHistoryTab('orders')}
              style={{
                padding: '5px 12px',
                fontSize: '0.8125rem',
                fontWeight: '600',
                borderRadius: 'var(--radius-sm)',
                border: 'none',
                cursor: 'pointer',
                backgroundColor: activeHistoryTab === 'orders' ? '#FFFFFF' : 'transparent',
                color: activeHistoryTab === 'orders' ? 'var(--text-main)' : 'var(--text-muted)',
                boxShadow: activeHistoryTab === 'orders' ? '0 1px 2px rgba(0,0,0,0.05)' : 'none'
              }}
            >
              Orders ({pagination.total})
            </button>
            <button
              onClick={() => setActiveHistoryTab('returns')}
              style={{
                padding: '5px 12px',
                fontSize: '0.8125rem',
                fontWeight: '600',
                borderRadius: 'var(--radius-sm)',
                border: 'none',
                cursor: 'pointer',
                backgroundColor: activeHistoryTab === 'returns' ? '#FFFFFF' : 'transparent',
                color: activeHistoryTab === 'returns' ? 'var(--text-main)' : 'var(--text-muted)',
                boxShadow: activeHistoryTab === 'returns' ? '0 1px 2px rgba(0,0,0,0.05)' : 'none'
              }}
            >
              Returns ({returnsPagination.total})
            </button>
          </div>
        </div>

        {activeHistoryTab === 'orders' ? (
          <>
            <div style={{ overflowX: 'auto' }}>
              <table style={{ width: '100%', borderCollapse: 'collapse', textAlign: 'left', fontSize: '0.875rem' }}>
                <thead>
                  <tr style={{ backgroundColor: 'var(--bg-page)', borderBottom: '1px solid var(--border-color)' }}>
                    <th style={{ padding: '0.875rem 1rem', fontWeight: '600', color: 'var(--text-muted)', fontSize: '0.75rem', textTransform: 'uppercase', letterSpacing: '0.04em' }}>Invoice #</th>
                    <th style={{ padding: '0.875rem 1rem', fontWeight: '600', color: 'var(--text-muted)', fontSize: '0.75rem', textTransform: 'uppercase', letterSpacing: '0.04em' }}>Date & Time</th>
                    <th style={{ padding: '0.875rem 1rem', fontWeight: '600', color: 'var(--text-muted)', fontSize: '0.75rem', textTransform: 'uppercase', letterSpacing: '0.04em' }}>Items</th>
                    <th style={{ padding: '0.875rem 1rem', fontWeight: '600', color: 'var(--text-muted)', fontSize: '0.75rem', textTransform: 'uppercase', letterSpacing: '0.04em' }}>Payment</th>
                    <th style={{ padding: '0.875rem 1rem', fontWeight: '600', color: 'var(--text-muted)', fontSize: '0.75rem', textTransform: 'uppercase', letterSpacing: '0.04em', textAlign: 'right' }}>Total</th>
                    <th style={{ padding: '0.875rem 1rem', fontWeight: '600', color: 'var(--text-muted)', fontSize: '0.75rem', textTransform: 'uppercase', letterSpacing: '0.04em' }}>Status</th>
                    <th style={{ padding: '0.875rem 1rem', fontWeight: '600', color: 'var(--text-muted)', fontSize: '0.75rem', textTransform: 'uppercase', letterSpacing: '0.04em', textAlign: 'right' }}>Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {sales.length === 0 ? (
                    <tr>
                      <td colSpan="7" style={{ padding: '3rem 1rem', textAlign: 'center', color: 'var(--text-muted)' }}>
                        <Receipt size={24} style={{ marginBottom: '8px', opacity: 0.5 }} />
                        <div style={{ fontWeight: '600', color: 'var(--text-main)', marginBottom: '4px' }}>No purchases on record yet</div>
                        <div style={{ fontSize: '0.8125rem' }}>When this customer buys at POS, completed bills will automatically appear here.</div>
                      </td>
                    </tr>
                  ) : (
                    sales.map((sale) => {
                      const date = new Date(sale.createdAt);
                      const isCompleted = sale.status === 'COMPLETED';

                      return (
                        <tr key={sale.id} style={{ borderBottom: '1px solid var(--border-subtle)' }}>
                          <td style={{ padding: '0.875rem 1rem', fontWeight: '600', color: '#172033' }}>
                            <span
                              onClick={() => handleViewInvoice(sale)}
                              style={{ cursor: 'pointer', color: '#7EAFD0', textDecoration: 'underline' }}
                            >
                              {sale.invoiceNumber}
                            </span>
                          </td>

                          <td style={{ padding: '0.875rem 1rem', color: 'var(--text-muted)' }}>
                            <div>{date.toLocaleDateString('en-IN', { day: '2-digit', month: 'short', year: 'numeric' })}</div>
                            <div style={{ fontSize: '0.75rem' }}>{date.toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit' })}</div>
                          </td>

                          <td style={{ padding: '0.875rem 1rem', color: 'var(--text-main)' }}>
                            <span style={{ fontWeight: '600' }}>{sale.totalQuantity || sale.itemCount || 1}</span> pcs ({sale.itemCount || 1} item{sale.itemCount === 1 ? '' : 's'})
                          </td>

                          <td style={{ padding: '0.875rem 1rem' }}>
                            <span style={{
                              display: 'inline-flex',
                              alignItems: 'center',
                              padding: '2px 8px',
                              borderRadius: 'var(--radius-sm)',
                              fontSize: '0.75rem',
                              fontWeight: '600',
                              backgroundColor: 'var(--bg-page)',
                              color: 'var(--text-main)',
                              border: '1px solid var(--border-subtle)'
                            }}>
                              {sale.paymentMethod}
                            </span>
                          </td>

                          <td style={{ padding: '0.875rem 1rem', textAlign: 'right', fontWeight: '700', color: isCompleted ? 'var(--text-main)' : 'var(--text-muted)' }}>
                            <span style={{ textDecoration: isCompleted ? 'none' : 'line-through' }}>
                              ₹{fmt(sale.totalAmount)}
                            </span>
                          </td>

                          <td style={{ padding: '0.875rem 1rem' }}>
                            <Badge variant={isCompleted ? 'success' : 'danger'} size="sm">
                              {isCompleted ? 'Completed' : 'Cancelled'}
                            </Badge>
                          </td>

                          <td style={{ padding: '0.875rem 1rem', textAlign: 'right' }}>
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => handleViewInvoice(sale)}
                              style={{ display: 'inline-flex', alignItems: 'center', gap: '4px', padding: '4px 8px' }}
                            >
                              <Printer size={14} />
                              <span>Receipt</span>
                            </Button>
                          </td>
                        </tr>
                      );
                    })
                  )}
                </tbody>
              </table>
            </div>

            {/* Pagination */}
            {pagination.pages > 1 && (
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '0.875rem 1.25rem', borderTop: '1px solid var(--border-color)', backgroundColor: 'var(--bg-page)', fontSize: '0.8125rem', color: 'var(--text-muted)' }}>
                <div>
                  Showing {((pagination.page - 1) * pagination.limit) + 1} to {Math.min(pagination.page * pagination.limit, pagination.total)} of {pagination.total} sales
                </div>
                <div style={{ display: 'flex', gap: '6px' }}>
                  <Button
                    variant="outline"
                    size="sm"
                    disabled={pagination.page <= 1}
                    onClick={() => loadSalesHistory(pagination.page - 1)}
                  >
                    <ChevronLeft size={14} /> Previous
                  </Button>
                  <div style={{ display: 'flex', alignItems: 'center', padding: '0 8px', fontWeight: '600', color: 'var(--text-main)' }}>
                    {pagination.page} / {pagination.pages}
                  </div>
                  <Button
                    variant="outline"
                    size="sm"
                    disabled={pagination.page >= pagination.pages}
                    onClick={() => loadSalesHistory(pagination.page + 1)}
                  >
                    Next <ChevronRight size={14} />
                  </Button>
                </div>
              </div>
            )}
          </>
        ) : (
          <>
            <div style={{ overflowX: 'auto' }}>
              <table style={{ width: '100%', borderCollapse: 'collapse', textAlign: 'left', fontSize: '0.875rem' }}>
                <thead>
                  <tr style={{ backgroundColor: 'var(--bg-page)', borderBottom: '1px solid var(--border-color)' }}>
                    <th style={{ padding: '0.875rem 1rem', fontWeight: '600', color: 'var(--text-muted)', fontSize: '0.75rem', textTransform: 'uppercase', letterSpacing: '0.04em' }}>Return ID</th>
                    <th style={{ padding: '0.875rem 1rem', fontWeight: '600', color: 'var(--text-muted)', fontSize: '0.75rem', textTransform: 'uppercase', letterSpacing: '0.04em' }}>Original Invoice</th>
                    <th style={{ padding: '0.875rem 1rem', fontWeight: '600', color: 'var(--text-muted)', fontSize: '0.75rem', textTransform: 'uppercase', letterSpacing: '0.04em' }}>Date & Time</th>
                    <th style={{ padding: '0.875rem 1rem', fontWeight: '600', color: 'var(--text-muted)', fontSize: '0.75rem', textTransform: 'uppercase', letterSpacing: '0.04em' }}>Items</th>
                    <th style={{ padding: '0.875rem 1rem', fontWeight: '600', color: 'var(--text-muted)', fontSize: '0.75rem', textTransform: 'uppercase', letterSpacing: '0.04em' }}>Reason</th>
                    <th style={{ padding: '0.875rem 1rem', fontWeight: '600', color: 'var(--text-muted)', fontSize: '0.75rem', textTransform: 'uppercase', letterSpacing: '0.04em', textAlign: 'right' }}>Refund Amount</th>
                    <th style={{ padding: '0.875rem 1rem', fontWeight: '600', color: 'var(--text-muted)', fontSize: '0.75rem', textTransform: 'uppercase', letterSpacing: '0.04em' }}>Method</th>
                    <th style={{ padding: '0.875rem 1rem', fontWeight: '600', color: 'var(--text-muted)', fontSize: '0.75rem', textTransform: 'uppercase', letterSpacing: '0.04em' }}>Status</th>
                  </tr>
                </thead>
                <tbody>
                  {customerReturns.length === 0 ? (
                    <tr>
                      <td colSpan="8" style={{ padding: '3rem 1rem', textAlign: 'center', color: 'var(--text-muted)' }}>
                        <RotateCcw size={24} style={{ marginBottom: '8px', opacity: 0.5 }} />
                        <div style={{ fontWeight: '600', color: 'var(--text-main)', marginBottom: '4px' }}>No returns on record yet</div>
                        <div style={{ fontSize: '0.8125rem' }}>This customer has not returned any purchased garments.</div>
                      </td>
                    </tr>
                  ) : (
                    customerReturns.map(ret => (
                      <tr key={ret.id} style={{ borderBottom: '1px solid var(--border-subtle)' }}>
                        <td style={{ padding: '0.875rem 1rem', fontFamily: 'monospace', fontSize: '0.8125rem', color: 'var(--text-muted)' }}>
                          {ret.id.substring(0, 12)}...
                        </td>
                        <td style={{ padding: '0.875rem 1rem', fontWeight: '600', color: 'var(--text-main)' }}>
                          {ret.invoiceNumber}
                        </td>
                        <td style={{ padding: '0.875rem 1rem', color: 'var(--text-muted)' }}>
                          {ret.createdAt ? ret.createdAt.replace('T', ' ').substring(0, 16) : ''}
                        </td>
                        <td style={{ padding: '0.875rem 1rem', fontWeight: '600' }}>
                          {ret.totalItemsReturned} item{ret.totalItemsReturned === 1 ? '' : 's'}
                        </td>
                        <td style={{ padding: '0.875rem 1rem', color: 'var(--text-main)' }}>
                          {ret.reason}
                        </td>
                        <td style={{ padding: '0.875rem 1rem', textAlign: 'right', fontWeight: '700', color: '#166534' }}>
                          ₹{fmt(ret.totalRefundAmount)}
                        </td>
                        <td style={{ padding: '0.875rem 1rem' }}>
                          <Badge variant="secondary" size="sm">{ret.refundMethod}</Badge>
                        </td>
                        <td style={{ padding: '0.875rem 1rem' }}>
                          <Badge variant="success" size="sm">{ret.status}</Badge>
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>

            {returnsPagination.pages > 1 && (
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '0.875rem 1.25rem', borderTop: '1px solid var(--border-color)', backgroundColor: 'var(--bg-page)', fontSize: '0.8125rem', color: 'var(--text-muted)' }}>
                <div>
                  Showing {((returnsPagination.page - 1) * returnsPagination.limit) + 1} to {Math.min(returnsPagination.page * returnsPagination.limit, returnsPagination.total)} of {returnsPagination.total} returns
                </div>
                <div style={{ display: 'flex', gap: '6px' }}>
                  <Button
                    variant="outline"
                    size="sm"
                    disabled={returnsPagination.page <= 1}
                    onClick={() => loadReturnsHistory(returnsPagination.page - 1)}
                  >
                    <ChevronLeft size={14} /> Previous
                  </Button>
                  <div style={{ display: 'flex', alignItems: 'center', padding: '0 8px', fontWeight: '600', color: 'var(--text-main)' }}>
                    {returnsPagination.page} / {returnsPagination.pages}
                  </div>
                  <Button
                    variant="outline"
                    size="sm"
                    disabled={returnsPagination.page >= returnsPagination.pages}
                    onClick={() => loadReturnsHistory(returnsPagination.page + 1)}
                  >
                    Next <ChevronRight size={14} />
                  </Button>
                </div>
              </div>
            )}
          </>
        )}
      </div>

      {/* Edit Customer Modal */}
      <Modal
        isOpen={isEditModalOpen}
        onClose={() => setIsEditModalOpen(false)}
        title="Edit Customer Profile"
        width="560px"
      >
        <form onSubmit={handleSaveEdit} style={{ display: 'flex', flexDirection: 'column', gap: '1rem' }}>
          {editErrors.submit && (
            <Alert variant="danger">
              {editErrors.submit}
            </Alert>
          )}

          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(220px, 1fr))', gap: '1rem' }}>
            <Input
              label="Full Name *"
              value={editForm.name}
              onChange={(e) => setEditForm({ ...editForm, name: e.target.value })}
              error={editErrors.name}
              required
            />
            <Input
              label="Phone Number"
              value={editForm.phone}
              onChange={(e) => setEditForm({ ...editForm, phone: e.target.value })}
              error={editErrors.phone}
            />
          </div>

          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(220px, 1fr))', gap: '1rem' }}>
            <Input
              label="Email Address"
              type="email"
              value={editForm.email}
              onChange={(e) => setEditForm({ ...editForm, email: e.target.value })}
              error={editErrors.email}
            />
            <div>
              <label style={{ display: 'block', fontSize: '0.8125rem', fontWeight: '600', color: 'var(--text-main)', marginBottom: '4px' }}>
                Gender
              </label>
              <select
                value={editForm.gender}
                onChange={(e) => setEditForm({ ...editForm, gender: e.target.value })}
                style={{
                  width: '100%',
                  padding: '0.625rem 0.875rem',
                  border: '1px solid var(--border-color)',
                  borderRadius: 'var(--radius-md)',
                  fontSize: '0.875rem',
                  color: 'var(--text-main)',
                  backgroundColor: 'var(--bg-page)',
                  outline: 'none'
                }}
              >
                <option value="">Select Gender</option>
                <option value="Male">Male</option>
                <option value="Female">Female</option>
                <option value="Other">Other</option>
              </select>
            </div>
          </div>

          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(220px, 1fr))', gap: '1rem' }}>
            <Input
              label="Date of Birth"
              type="date"
              value={editForm.dateOfBirth}
              onChange={(e) => setEditForm({ ...editForm, dateOfBirth: e.target.value })}
            />
            <Input
              label="City"
              value={editForm.city}
              onChange={(e) => setEditForm({ ...editForm, city: e.target.value })}
            />
          </div>

          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(220px, 1fr))', gap: '1rem' }}>
            <Input
              label="State"
              value={editForm.state}
              onChange={(e) => setEditForm({ ...editForm, state: e.target.value })}
            />
            <Input
              label="Postal Code"
              value={editForm.postalCode}
              onChange={(e) => setEditForm({ ...editForm, postalCode: e.target.value })}
            />
          </div>

          <div>
            <label style={{ display: 'block', fontSize: '0.8125rem', fontWeight: '600', color: 'var(--text-main)', marginBottom: '4px' }}>
              Street Address
            </label>
            <input
              type="text"
              value={editForm.address}
              onChange={(e) => setEditForm({ ...editForm, address: e.target.value })}
              style={{
                width: '100%',
                padding: '0.625rem 0.875rem',
                border: '1px solid var(--border-color)',
                borderRadius: 'var(--radius-md)',
                fontSize: '0.875rem',
                color: 'var(--text-main)',
                backgroundColor: 'var(--bg-page)',
                outline: 'none'
              }}
            />
          </div>

          <div>
            <label style={{ display: 'block', fontSize: '0.8125rem', fontWeight: '600', color: 'var(--text-main)', marginBottom: '4px' }}>
              Notes / Apparel Preferences
            </label>
            <textarea
              rows="2"
              value={editForm.notes}
              onChange={(e) => setEditForm({ ...editForm, notes: e.target.value })}
              style={{
                width: '100%',
                padding: '0.625rem 0.875rem',
                border: '1px solid var(--border-color)',
                borderRadius: 'var(--radius-md)',
                fontSize: '0.875rem',
                color: 'var(--text-main)',
                backgroundColor: 'var(--bg-page)',
                resize: 'vertical',
                outline: 'none',
                fontFamily: 'inherit'
              }}
            />
          </div>

          <div style={{ display: 'flex', justifyContent: 'flex-end', gap: '0.75rem', marginTop: '0.5rem' }}>
            <Button
              type="button"
              variant="outline"
              onClick={() => setIsEditModalOpen(false)}
              disabled={savingEdit}
            >
              Cancel
            </Button>
            <Button
              type="submit"
              variant="primary"
              loading={savingEdit}
            >
              Save Changes
            </Button>
          </div>
        </form>
      </Modal>

      {/* Archive Modal */}
      {confirmArchive && (
        <Modal
          isOpen={confirmArchive}
          onClose={() => setConfirmArchive(false)}
          title="Archive Customer"
          width="440px"
        >
          <div style={{ display: 'flex', flexDirection: 'column', gap: '1rem' }}>
            <p style={{ margin: 0, fontSize: '0.875rem', color: 'var(--text-muted)', lineHeight: '1.5' }}>
              Are you sure you want to archive <strong>{customer.name}</strong>? Their historical purchases will remain accessible in records and can be restored at any time.
            </p>
            <div style={{ display: 'flex', justifyContent: 'flex-end', gap: '0.75rem' }}>
              <Button variant="outline" disabled={actionLoading} onClick={() => setConfirmArchive(false)}>
                Cancel
              </Button>
              <Button variant="danger" loading={actionLoading} onClick={handleArchive}>
                Archive Customer
              </Button>
            </div>
          </div>
        </Modal>
      )}

      {/* Restore Modal */}
      {confirmRestore && (
        <Modal
          isOpen={confirmRestore}
          onClose={() => setConfirmRestore(false)}
          title="Restore Customer"
          width="440px"
        >
          <div style={{ display: 'flex', flexDirection: 'column', gap: '1rem' }}>
            <p style={{ margin: 0, fontSize: '0.875rem', color: 'var(--text-muted)', lineHeight: '1.5' }}>
              Restore <strong>{customer.name}</strong> to the active customer directory and POS search?
            </p>
            <div style={{ display: 'flex', justifyContent: 'flex-end', gap: '0.75rem' }}>
              <Button variant="outline" disabled={actionLoading} onClick={() => setConfirmRestore(false)}>
                Cancel
              </Button>
              <Button variant="primary" loading={actionLoading} onClick={handleRestore}>
                Restore Customer
              </Button>
            </div>
          </div>
        </Modal>
      )}

      {/* Invoice Receipt Modal */}
      {selectedInvoice && (
        <Modal
          isOpen={Boolean(selectedInvoice)}
          onClose={() => setSelectedInvoice(null)}
          title={`Invoice ${selectedInvoice.invoiceNumber}`}
          width="560px"
        >
          <div id="customer-invoice-print" style={{ padding: '1rem', border: '1px solid var(--border-color)', borderRadius: 'var(--radius-md)', backgroundColor: '#FFFFFF', marginBottom: '1.25rem' }}>
            {/* Header */}
            <div style={{ textAlign: 'center', paddingBottom: '0.75rem', borderBottom: '1px dashed var(--border-color)', marginBottom: '0.75rem' }}>
              <div style={{ fontSize: '1.25rem', fontWeight: '800', color: '#172033' }}>{store?.name || 'Westsides'}</div>
              {store?.address && <div style={{ fontSize: '0.8125rem', color: 'var(--text-muted)' }}>{store.address}</div>}
              {store?.phone && <div style={{ fontSize: '0.8125rem', color: 'var(--text-muted)' }}>Ph: {store.phone}</div>}
              {store?.gstin && <div style={{ fontSize: '0.75rem', fontWeight: '600', color: 'var(--text-main)', marginTop: '2px' }}>GSTIN: {store.gstin}</div>}
            </div>

            {/* Meta */}
            <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '0.8125rem', marginBottom: '0.75rem' }}>
              <div>
                <div><strong>Invoice:</strong> {selectedInvoice.invoiceNumber}</div>
                <div><strong>Date:</strong> {new Date(selectedInvoice.createdAt).toLocaleString('en-IN')}</div>
              </div>
              <div style={{ textAlign: 'right' }}>
                <div><strong>Cashier:</strong> {selectedInvoice.cashierName || 'Staff'}</div>
                <div><strong>Payment:</strong> {selectedInvoice.paymentMethod}</div>
              </div>
            </div>

            {/* Items */}
            <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: '0.8125rem', marginBottom: '0.75rem' }}>
              <thead>
                <tr style={{ borderBottom: '2px solid var(--border-color)' }}>
                  <th style={{ padding: '6px 4px', textAlign: 'left', fontWeight: '600', color: 'var(--text-muted)' }}>Item</th>
                  <th style={{ padding: '6px 4px', textAlign: 'right', fontWeight: '600', color: 'var(--text-muted)' }}>Qty</th>
                  <th style={{ padding: '6px 4px', textAlign: 'right', fontWeight: '600', color: 'var(--text-muted)' }}>Rate</th>
                  <th style={{ padding: '6px 4px', textAlign: 'right', fontWeight: '600', color: 'var(--text-muted)' }}>Total</th>
                </tr>
              </thead>
              <tbody>
                {(selectedInvoice.items || []).map((item, idx) => (
                  <tr key={idx} style={{ borderBottom: '1px solid var(--border-subtle)' }}>
                    <td style={{ padding: '6px 4px' }}>
                      <div style={{ fontWeight: '600', color: 'var(--text-main)' }}>{item.productNameSnapshot}</div>
                      <div style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>
                        {[item.sizeSnapshot, item.colorSnapshot].filter(Boolean).join(' / ')}
                      </div>
                    </td>
                    <td style={{ padding: '6px 4px', textAlign: 'right', color: 'var(--text-muted)' }}>{item.quantity}</td>
                    <td style={{ padding: '6px 4px', textAlign: 'right', color: 'var(--text-main)' }}>₹{fmt(item.unitPrice)}</td>
                    <td style={{ padding: '6px 4px', textAlign: 'right', fontWeight: '600', color: 'var(--text-main)' }}>₹{fmt(item.lineTotal)}</td>
                  </tr>
                ))}
              </tbody>
            </table>

            {/* Totals */}
            <div style={{ borderTop: '1px solid var(--border-color)', paddingTop: '0.5rem', display: 'flex', flexDirection: 'column', gap: '4px', alignItems: 'flex-end', fontSize: '0.8125rem' }}>
              <div style={{ display: 'flex', gap: '1.5rem' }}>
                <span style={{ color: 'var(--text-muted)' }}>Subtotal:</span>
                <span style={{ fontWeight: '500', minWidth: '70px', textAlign: 'right' }}>₹{fmt(selectedInvoice.subtotal)}</span>
              </div>
              {Number(selectedInvoice.discountAmount) > 0 && (
                <div style={{ display: 'flex', gap: '1.5rem', color: '#10B981' }}>
                  <span>Discount:</span>
                  <span style={{ fontWeight: '500', minWidth: '70px', textAlign: 'right' }}>-₹{fmt(selectedInvoice.discountAmount)}</span>
                </div>
              )}
              <div style={{ display: 'flex', gap: '1.5rem', borderTop: '2px solid var(--border-color)', paddingTop: '4px', marginTop: '2px', fontSize: '0.9375rem' }}>
                <span style={{ fontWeight: '700' }}>Grand Total:</span>
                <span style={{ fontWeight: '800', color: '#7EAFD0', minWidth: '70px', textAlign: 'right' }}>₹{fmt(selectedInvoice.totalAmount)}</span>
              </div>
            </div>
          </div>

          <div style={{ display: 'flex', justifyContent: 'space-between', gap: '0.75rem' }}>
            <Button variant="outline" onClick={() => setSelectedInvoice(null)}>
              Close
            </Button>
            <Button variant="primary" onClick={() => window.print()} style={{ display: 'flex', alignItems: 'center', gap: '6px' }}>
              <Printer size={15} /> Print Receipt
            </Button>
          </div>
        </Modal>
      )}

      {/* Print CSS */}
      <style>{`
        @media print {
          body * { visibility: hidden !important; }
          #customer-invoice-print, #customer-invoice-print * { visibility: visible !important; }
          #customer-invoice-print {
            position: fixed !important;
            top: 0 !important;
            left: 0 !important;
            right: 0 !important;
            width: 100% !important;
            max-width: 400px !important;
            margin: 0 auto !important;
            box-shadow: none !important;
            border: none !important;
          }
        }
      `}</style>
    </div>
  );
}
