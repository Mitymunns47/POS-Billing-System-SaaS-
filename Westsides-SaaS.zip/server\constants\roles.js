const ROLES = {
  OWNER: 'OWNER',
  MANAGER: 'MANAGER',
  CASHIER: 'CASHIER',
  STAFF: 'STAFF'
};

const PERMISSIONS = {
  // Phase 1 — Dashboard & Settings
  DASHBOARD_VIEW: 'dashboard.view',
  SETTINGS_VIEW: 'settings.view',
  SETTINGS_EDIT: 'settings.edit',

  // Phase 2 — Products
  PRODUCTS_VIEW: 'products.view',
  PRODUCTS_CREATE: 'products.create',
  PRODUCTS_EDIT: 'products.edit',
  PRODUCTS_DELETE: 'products.delete',

  // Phase 2 — Inventory
  INVENTORY_VIEW: 'inventory.view',
  INVENTORY_ADJUST: 'inventory.adjust',
  INVENTORY_TRANSFER: 'inventory.transfer',
  INVENTORY_HISTORY: 'inventory.history',

  // Phase 2 — Categories & Brands
  CATEGORIES_VIEW: 'categories.view',
  CATEGORIES_CREATE: 'categories.create',
  CATEGORIES_EDIT: 'categories.edit',
  CATEGORIES_DELETE: 'categories.delete',
  BRANDS_VIEW: 'brands.view',
  BRANDS_CREATE: 'brands.create',
  BRANDS_EDIT: 'brands.edit',
  BRANDS_DELETE: 'brands.delete',

  // Phase 3 — Billing & POS
  BILLING_VIEW: 'billing.view',
  BILLING_CREATE: 'billing.create',
  BILLING_CANCEL: 'billing.cancel',
  BILLING_REPRINT: 'billing.reprint',

  // Phase 3 — Sales & Invoices
  SALES_VIEW: 'sales.view',
  SALES_VIEW_ALL: 'sales.view_all',

  // Phase 4 — Customers
  CUSTOMERS_VIEW: 'customers.view',
  CUSTOMERS_CREATE: 'customers.create',
  CUSTOMERS_EDIT: 'customers.edit',
  CUSTOMERS_ARCHIVE: 'customers.archive',
  CUSTOMERS_VIEW_HISTORY: 'customers.view_history',

  // Phase 4 — Staff Management
  STAFF_VIEW: 'staff.view',
  STAFF_CREATE: 'staff.create',
  STAFF_EDIT: 'staff.edit',
  STAFF_CHANGE_ROLE: 'staff.change_role',
  STAFF_ACTIVATE: 'staff.activate',
  STAFF_DEACTIVATE: 'staff.deactivate',
  STAFF_VIEW_ACTIVITY: 'staff.view_activity',
  STAFF_PERMISSIONS: 'staff.permissions',

  // Phase 4 — Attendance
  ATTENDANCE_VIEW: 'attendance.view',
  ATTENDANCE_MANAGE: 'attendance.manage',

  // Phase 5 — Reports & Expenses
  REPORTS_VIEW: 'reports.view',
  EXPENSES_VIEW: 'expenses.view',
  EXPENSES_MANAGE: 'expenses.manage',
  EXPENSES_CREATE: 'expenses.create',
  EXPENSES_EDIT: 'expenses.edit',
  EXPENSES_ARCHIVE: 'expenses.archive',

  // Phase 6 — Returns & Refunds
  RETURNS_VIEW: 'returns.view',
  RETURNS_CREATE: 'returns.create',
  RETURNS_APPROVE: 'returns.approve',
  RETURNS_COMPLETE: 'returns.complete',
  RETURNS_CANCEL: 'returns.cancel',

  // Phase 6 — Tax & Invoicing
  TAX_VIEW: 'tax.view',
  TAX_EDIT: 'tax.edit',
  INVOICE_VIEW: 'invoice.view',
  INVOICE_EDIT: 'invoice.edit',

  // Phase 6 — Notifications & Alert Center
  NOTIFICATIONS_VIEW: 'notifications.view',
  NOTIFICATIONS_MANAGE: 'notifications.manage'
};

const PERMISSION_CATALOG = [
  {
    module: 'Customers',
    description: 'Customer profiles, contact records, and order history',
    permissions: [
      { key: PERMISSIONS.CUSTOMERS_VIEW, label: 'View Customers', description: 'Search and view customer directory' },
      { key: PERMISSIONS.CUSTOMERS_CREATE, label: 'Create Customer', description: 'Add new customers in CRM and POS' },
      { key: PERMISSIONS.CUSTOMERS_EDIT, label: 'Edit Customer', description: 'Update customer contact info and details' },
      { key: PERMISSIONS.CUSTOMERS_ARCHIVE, label: 'Archive / Restore Customer', description: 'Archive inactive customers or restore them' },
      { key: PERMISSIONS.CUSTOMERS_VIEW_HISTORY, label: 'View Customer History', description: 'Inspect lifetime purchases and sales history' }
    ]
  },
  {
    module: 'Products',
    description: 'Garment catalog, sizing, pricing, and barcodes',
    permissions: [
      { key: PERMISSIONS.PRODUCTS_VIEW, label: 'View Products', description: 'Browse and search clothing catalog' },
      { key: PERMISSIONS.PRODUCTS_CREATE, label: 'Create Products', description: 'Add new apparel styles and variants' },
      { key: PERMISSIONS.PRODUCTS_EDIT, label: 'Edit Products', description: 'Modify pricing, descriptions, and variants' },
      { key: PERMISSIONS.PRODUCTS_DELETE, label: 'Archive Products', description: 'Deactivate or delete catalog items' }
    ]
  },
  {
    module: 'Inventory',
    description: 'Stock levels, restocks, adjustments, and audit trail',
    permissions: [
      { key: PERMISSIONS.INVENTORY_VIEW, label: 'View Inventory', description: 'View stock counts and low inventory warnings' },
      { key: PERMISSIONS.INVENTORY_ADJUST, label: 'Adjust Stock', description: 'Perform manual stock additions or deductions' },
      { key: PERMISSIONS.INVENTORY_TRANSFER, label: 'Transfer Inventory', description: 'Batch movements and garment transfers' },
      { key: PERMISSIONS.INVENTORY_HISTORY, label: 'Inventory History', description: 'Inspect immutable inventory transaction log' }
    ]
  },
  {
    module: 'POS & Billing',
    description: 'Checkout counter, barcode scan, and billing operations',
    permissions: [
      { key: PERMISSIONS.BILLING_VIEW, label: 'Open POS Register', description: 'Access POS checkout terminal' },
      { key: PERMISSIONS.BILLING_CREATE, label: 'Process Checkout', description: 'Complete sales and generate invoices' },
      { key: PERMISSIONS.BILLING_CANCEL, label: 'Cancel Bills', description: 'Cancel sales and restore variant stock' },
      { key: PERMISSIONS.BILLING_REPRINT, label: 'Reprint Receipts', description: 'Print or export copies of receipts' }
    ]
  },
  {
    module: 'Sales & Invoices',
    description: 'Transaction records, payment tracking, and invoice audit',
    permissions: [
      { key: PERMISSIONS.SALES_VIEW, label: 'View Own Sales', description: 'View cashier sales history' },
      { key: PERMISSIONS.SALES_VIEW_ALL, label: 'View All Store Sales', description: 'View all cashier and store-wide sales history' }
    ]
  },
  {
    module: 'Staff Management',
    description: 'Employee access, roles, permissions, and audit logs',
    permissions: [
      { key: PERMISSIONS.STAFF_VIEW, label: 'View Staff Directory', description: 'Inspect team members and active accounts' },
      { key: PERMISSIONS.STAFF_CREATE, label: 'Create Staff', description: 'Add new employee user accounts' },
      { key: PERMISSIONS.STAFF_EDIT, label: 'Edit Staff Profile', description: 'Update staff contact details and password' },
      { key: PERMISSIONS.STAFF_CHANGE_ROLE, label: 'Change Staff Role', description: 'Promote or modify staff roles' },
      { key: PERMISSIONS.STAFF_ACTIVATE, label: 'Activate Staff', description: 'Restore login access for deactivated staff' },
      { key: PERMISSIONS.STAFF_DEACTIVATE, label: 'Deactivate Staff', description: 'Suspend staff login access' },
      { key: PERMISSIONS.STAFF_PERMISSIONS, label: 'Manage Permissions', description: 'Configure granular permission overrides' },
      { key: PERMISSIONS.STAFF_VIEW_ACTIVITY, label: 'View Activity Log', description: 'Inspect staff audit log actions' }
    ]
  },
  {
    module: 'Attendance',
    description: 'Staff daily attendance records and check-ins',
    permissions: [
      { key: PERMISSIONS.ATTENDANCE_VIEW, label: 'View Attendance', description: 'View employee check-in logs' },
      { key: PERMISSIONS.ATTENDANCE_MANAGE, label: 'Manage Attendance', description: 'Mark or edit attendance records' }
    ]
  },
  {
    module: 'Reports & Analytics',
    description: 'Store revenue, sales trends, and tax summaries',
    permissions: [
      { key: PERMISSIONS.REPORTS_VIEW, label: 'View Reports', description: 'Access store performance summaries' }
    ]
  },
  {
    module: 'Expenses',
    description: 'Store operating costs, bills, and expenditure tracking',
    permissions: [
      { key: PERMISSIONS.EXPENSES_VIEW, label: 'View Expenses', description: 'Browse and inspect store expenses' },
      { key: PERMISSIONS.EXPENSES_MANAGE, label: 'Manage Expenses', description: 'Create, edit, and archive expenses' }
    ]
  },
  {
    module: 'Returns & Refunds',
    description: 'Item returns, restocking, damaged goods, and customer refunds',
    permissions: [
      { key: PERMISSIONS.RETURNS_VIEW, label: 'View Returns', description: 'Search and inspect return receipts' },
      { key: PERMISSIONS.RETURNS_CREATE, label: 'Process Return', description: 'Initiate returns and issue customer refunds' },
      { key: PERMISSIONS.RETURNS_APPROVE, label: 'Approve Returns', description: 'Authorize high-value return exceptions' },
      { key: PERMISSIONS.RETURNS_CANCEL, label: 'Cancel Return', description: 'Void or cancel return requests' }
    ]
  },
  {
    module: 'Settings',
    description: 'Store configurations, receipt templates, and tax rates',
    permissions: [
      { key: PERMISSIONS.SETTINGS_VIEW, label: 'View Settings', description: 'Inspect store profile and configurations' },
      { key: PERMISSIONS.SETTINGS_EDIT, label: 'Edit Settings', description: 'Update store details, tax rates, and policies' },
      { key: PERMISSIONS.TAX_EDIT, label: 'Manage Tax & GST', description: 'Configure tax rates and inclusive/exclusive rules' },
      { key: PERMISSIONS.INVOICE_EDIT, label: 'Invoice & Receipts', description: 'Customize prefixes, footer notes and return policies' }
    ]
  },
  {
    module: 'Notifications & Alerts',
    description: 'Low stock warnings, sales alerts, and system notices',
    permissions: [
      { key: PERMISSIONS.NOTIFICATIONS_VIEW, label: 'View Notifications', description: 'Receive inventory alerts and store updates' },
      { key: PERMISSIONS.NOTIFICATIONS_MANAGE, label: 'Manage Notifications', description: 'Dismiss, mark read, or configure alerts' }
    ]
  }
];

const ALL_PERMISSION_KEYS = Object.values(PERMISSIONS);

const ROLE_PERMISSIONS = {
  [ROLES.OWNER]: ALL_PERMISSION_KEYS,

  [ROLES.MANAGER]: [
    PERMISSIONS.DASHBOARD_VIEW,
    // Customers
    PERMISSIONS.CUSTOMERS_VIEW, PERMISSIONS.CUSTOMERS_CREATE, PERMISSIONS.CUSTOMERS_EDIT, PERMISSIONS.CUSTOMERS_ARCHIVE, PERMISSIONS.CUSTOMERS_VIEW_HISTORY,
    // Products
    PERMISSIONS.PRODUCTS_VIEW, PERMISSIONS.PRODUCTS_CREATE, PERMISSIONS.PRODUCTS_EDIT,
    // Inventory
    PERMISSIONS.INVENTORY_VIEW, PERMISSIONS.INVENTORY_ADJUST, PERMISSIONS.INVENTORY_TRANSFER, PERMISSIONS.INVENTORY_HISTORY,
    // Categories & Brands
    PERMISSIONS.CATEGORIES_VIEW, PERMISSIONS.CATEGORIES_CREATE, PERMISSIONS.CATEGORIES_EDIT,
    PERMISSIONS.BRANDS_VIEW, PERMISSIONS.BRANDS_CREATE, PERMISSIONS.BRANDS_EDIT,
    // POS & Sales
    PERMISSIONS.BILLING_VIEW, PERMISSIONS.BILLING_CREATE, PERMISSIONS.BILLING_CANCEL, PERMISSIONS.BILLING_REPRINT,
    PERMISSIONS.SALES_VIEW, PERMISSIONS.SALES_VIEW_ALL,
    // Returns & Refunds
    PERMISSIONS.RETURNS_VIEW, PERMISSIONS.RETURNS_CREATE, PERMISSIONS.RETURNS_APPROVE, PERMISSIONS.RETURNS_COMPLETE, PERMISSIONS.RETURNS_CANCEL,
    // Staff & Attendance
    PERMISSIONS.STAFF_VIEW, PERMISSIONS.STAFF_CREATE, PERMISSIONS.STAFF_EDIT, PERMISSIONS.STAFF_CHANGE_ROLE,
    PERMISSIONS.STAFF_ACTIVATE, PERMISSIONS.STAFF_DEACTIVATE, PERMISSIONS.STAFF_PERMISSIONS, PERMISSIONS.STAFF_VIEW_ACTIVITY,
    PERMISSIONS.ATTENDANCE_VIEW, PERMISSIONS.ATTENDANCE_MANAGE,
    // Reports & Expenses & Settings & Notifications
    PERMISSIONS.REPORTS_VIEW, PERMISSIONS.EXPENSES_VIEW, PERMISSIONS.EXPENSES_MANAGE,
    PERMISSIONS.SETTINGS_VIEW, PERMISSIONS.SETTINGS_EDIT, PERMISSIONS.TAX_VIEW, PERMISSIONS.TAX_EDIT, PERMISSIONS.INVOICE_VIEW, PERMISSIONS.INVOICE_EDIT,
    PERMISSIONS.NOTIFICATIONS_VIEW, PERMISSIONS.NOTIFICATIONS_MANAGE
  ],

  [ROLES.CASHIER]: [
    PERMISSIONS.DASHBOARD_VIEW,
    // Billing & POS
    PERMISSIONS.BILLING_VIEW, PERMISSIONS.BILLING_CREATE, PERMISSIONS.BILLING_REPRINT,
    PERMISSIONS.SALES_VIEW,
    // Returns
    PERMISSIONS.RETURNS_VIEW, PERMISSIONS.RETURNS_CREATE,
    // Catalog view
    PERMISSIONS.PRODUCTS_VIEW, PERMISSIONS.INVENTORY_VIEW,
    PERMISSIONS.CATEGORIES_VIEW, PERMISSIONS.BRANDS_VIEW,
    // Customers
    PERMISSIONS.CUSTOMERS_VIEW, PERMISSIONS.CUSTOMERS_CREATE, PERMISSIONS.CUSTOMERS_VIEW_HISTORY,
    // Attendance & Notifications
    PERMISSIONS.ATTENDANCE_VIEW,
    PERMISSIONS.NOTIFICATIONS_VIEW
  ],

  [ROLES.STAFF]: [
    PERMISSIONS.DASHBOARD_VIEW,
    // POS & Billing
    PERMISSIONS.BILLING_VIEW,
    PERMISSIONS.BILLING_CREATE,
    PERMISSIONS.BILLING_REPRINT,
    PERMISSIONS.SALES_VIEW,
    // Catalog & Inventory
    PERMISSIONS.PRODUCTS_VIEW,
    PERMISSIONS.INVENTORY_VIEW,
    PERMISSIONS.CATEGORIES_VIEW,
    PERMISSIONS.BRANDS_VIEW,
    // Customers
    PERMISSIONS.CUSTOMERS_VIEW,
    PERMISSIONS.CUSTOMERS_CREATE,
    PERMISSIONS.CUSTOMERS_VIEW_HISTORY,
    // Returns & Refunds
    PERMISSIONS.RETURNS_VIEW,
    PERMISSIONS.RETURNS_CREATE,
    // Attendance & Notifications
    PERMISSIONS.ATTENDANCE_VIEW,
    PERMISSIONS.NOTIFICATIONS_VIEW
  ]
};

function hasPermission(role, permission) {
  if (role === ROLES.OWNER) return true;
  const permissions = ROLE_PERMISSIONS[role] || [];
  return permissions.includes(permission);
}

module.exports = {
  ROLES,
  PERMISSIONS,
  PERMISSION_CATALOG,
  ALL_PERMISSION_KEYS,
  ROLE_PERMISSIONS,
  hasPermission
};
