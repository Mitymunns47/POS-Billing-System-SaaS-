import React, { useState, useEffect, useCallback } from 'react';
import { api } from '../services/api';
import { Button } from '../components/ui/Button';
import { Input } from '../components/ui/Input';
import { Select } from '../components/ui/Select';
import { Badge } from '../components/ui/Badge';
import { Alert } from '../components/ui/Alert';
import { Modal } from '../components/ui/Modal';
import {
  Search, RefreshCw, ChevronLeft, ChevronRight, Package,
  AlertTriangle, TrendingDown, SlidersHorizontal, History, CheckCircle
} from 'lucide-react';

const ADJUSTMENT_ACTIONS = [
  { value: 'ADD_STOCK', label: 'Add Stock', description: 'Increase current stock' },
  { value: 'REMOVE_STOCK', label: 'Remove Stock', description: 'Decrease current stock' },
  { value: 'ADJUST_STOCK', label: 'Set Stock', description: 'Set stock to exact quantity' },
  { value: 'TRANSFER_IN', label: 'Transfer In', description: 'Received from another location' },
  { value: 'TRANSFER_OUT', label: 'Transfer Out', description: 'Sent to another location' }
];

function StockStatusBadge({ status }) {
  const map = {
    IN_STOCK: { variant: 'success', label: 'In Stock' },
    LOW_STOCK: { variant: 'warning', label: 'Low Stock' },
    OUT_OF_STOCK: { variant: 'danger', label: 'Out of Stock' }
  };
  const { variant, label } = map[status] || { variant: 'neutral', label: '-' };
  return <Badge variant={variant} size="sm">{label}</Badge>;
}

// ── Adjustment Modal ──────────────────────────────────────────────────────────
function AdjustModal({ product, variants, onSubmit, onCancel, isLoading }) {
  const [variantId, setVariantId] = useState(variants.length === 1 ? variants[0].id : '');
  const [action, setAction] = useState('ADD_STOCK');
  const [quantity, setQuantity] = useState('');
  const [reason, setReason] = useState('');
  const [note, setNote] = useState('');
  const [localError, setLocalError] = useState(null);

  const selectedVariant = variants.find(v => v.id === variantId);
  const selectedAction = ADJUSTMENT_ACTIONS.find(a => a.value === action);

  const handleSubmit = () => {
    if (!variantId) { setLocalError('Please select a variant.'); return; }
    if (!quantity || isNaN(parseInt(quantity)) || parseInt(quantity) <= 0) { setLocalError('Quantity must be a positive integer.'); return; }
    setLocalError(null);
    onSubmit({ productId: product.id, variantId, action, quantity: parseInt(quantity), reason, note });
  };

  const newStock = selectedVariant !== undefined && quantity !== '' ? (() => {
    const q = parseInt(quantity) || 0;
    if (action === 'ADD_STOCK' || action === 'TRANSFER_IN') return selectedVariant.stock + q;
    if (action === 'REMOVE_STOCK' || action === 'TRANSFER_OUT') return Math.max(0, selectedVariant.stock - q);
    if (action === 'ADJUST_STOCK') return q;
    return selectedVariant.stock;
  })() : null;

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '1rem' }}>
      {localError && <Alert variant="danger" onDismiss={() => setLocalError(null)}>{localError}</Alert>}

      <div style={{ fontWeight: '600', fontSize: '0.9375rem', color: 'var(--text-main)' }}>{product.name}</div>

      <Select label="Variant" id="adj-variant" value={variantId} onChange={e => setVariantId(e.target.value)} required>
        <option value="">— Select Variant —</option>
        {variants.map(v => (
          <option key={v.id} value={v.id}>
            {[v.size, v.color].filter(Boolean).join(' / ') || 'Default'} — Current Stock: {v.stock}
          </option>
        ))}
      </Select>

      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '1rem' }}>
        <Select label="Action" id="adj-action" value={action} onChange={e => setAction(e.target.value)} required>
          {ADJUSTMENT_ACTIONS.map(a => <option key={a.value} value={a.value}>{a.label}</option>)}
        </Select>
        <Input label="Quantity" id="adj-qty" type="number" min="1" value={quantity} onChange={e => setQuantity(e.target.value)} required
          helperText={selectedAction?.description} />
      </div>

      {selectedVariant && quantity !== '' && newStock !== null && (
        <div style={{ padding: '10px 14px', borderRadius: 'var(--radius-md)', backgroundColor: 'var(--bg-page)', border: '1px solid var(--border-subtle)', display: 'flex', gap: '1.5rem' }}>
          <div><span style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>Current</span><div style={{ fontWeight: '700', fontSize: '1.125rem', color: 'var(--text-main)' }}>{selectedVariant.stock}</div></div>
          <div style={{ fontSize: '1.5rem', color: 'var(--text-light)', display: 'flex', alignItems: 'center' }}>→</div>
          <div><span style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>After</span><div style={{ fontWeight: '700', fontSize: '1.125rem', color: newStock < selectedVariant.stock ? 'var(--danger)' : 'var(--success)' }}>{newStock}</div></div>
        </div>
      )}

      <Select label="Reason" id="adj-reason" value={reason} onChange={e => setReason(e.target.value)}>
        <option value="">— Select Reason —</option>
        <option value="Purchase Order">Purchase Order</option>
        <option value="Return / Restock">Return / Restock</option>
        <option value="Damaged / Defective">Damaged / Defective</option>
        <option value="Shrinkage / Loss">Shrinkage / Loss</option>
        <option value="Physical Count Correction">Physical Count Correction</option>
        <option value="Inter-store Transfer">Inter-store Transfer</option>
        <option value="Other">Other</option>
      </Select>

      <div style={{ display: 'flex', flexDirection: 'column', gap: '6px' }}>
        <label style={{ fontSize: '0.875rem', fontWeight: '500', color: 'var(--text-main)' }}>Note <span style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>(optional)</span></label>
        <textarea
          value={note}
          onChange={e => setNote(e.target.value)}
          rows={2}
          placeholder="e.g. PO #123, batch 004…"
          style={{
            padding: '8px 12px', borderRadius: '6px', border: '1px solid var(--border-color)',
            fontSize: '0.875rem', color: 'var(--text-main)', backgroundColor: '#fff',
            width: '100%', outline: 'none', resize: 'vertical', fontFamily: 'inherit'
          }}
        />
      </div>

      <div style={{ display: 'flex', justifyContent: 'flex-end', gap: '0.75rem', paddingTop: '0.5rem', borderTop: '1px solid var(--border-subtle)' }}>
        <Button variant="secondary" size="md" onClick={onCancel} disabled={isLoading}>Cancel</Button>
        <Button variant="primary" size="md" isLoading={isLoading} onClick={handleSubmit}>
          <SlidersHorizontal size={14} style={{ marginRight: '6px' }} /> Apply Adjustment
        </Button>
      </div>
    </div>
  );
}

// ── Inventory Page ────────────────────────────────────────────────────────────
export function InventoryPage({ onNavigate }) {
  const [items, setItems] = useState([]);
  const [stats, setStats] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [alert, setAlert] = useState(null);

  const [search, setSearch] = useState('');
  const [filterStatus, setFilterStatus] = useState('');
  const [page, setPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);
  const [total, setTotal] = useState(0);

  // Adjustment state
  const [adjustProduct, setAdjustProduct] = useState(null);
  const [adjustVariants, setAdjustVariants] = useState([]);
  const [showAdjust, setShowAdjust] = useState(false);
  const [adjusting, setAdjusting] = useState(false);

  const loadData = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const [statRes, invRes] = await Promise.all([
        api.getInventoryStats(),
        api.getInventory({ search, status: filterStatus, page, limit: 20 })
      ]);
      if (statRes.success) setStats(statRes.stats);
      if (invRes.success) {
        setItems(invRes.products || []);
        setTotalPages(invRes.totalPages || 1);
        setTotal(invRes.total || 0);
      }
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  }, [search, filterStatus, page]);

  useEffect(() => { loadData(); }, [loadData]);

  const openAdjust = async (product) => {
    try {
      const res = await api.getVariants(product.id);
      if (res.success) {
        setAdjustVariants(res.variants || []);
        setAdjustProduct(product);
        setShowAdjust(true);
      }
    } catch (err) {
      setAlert({ variant: 'danger', message: 'Could not load product variants.' });
    }
  };

  const handleAdjust = async (data) => {
    setAdjusting(true);
    try {
      const res = await api.adjustStock(data);
      if (res.success) {
        setAlert({ variant: 'success', message: `Stock adjusted. New quantity: ${res.newStock}` });
        setShowAdjust(false);
        loadData();
      }
    } catch (err) {
      setAlert({ variant: 'danger', message: err.message });
    } finally {
      setAdjusting(false);
    }
  };

  return (
    <div style={{ maxWidth: '1200px', margin: '0 auto' }} className="animate-fade-in">
      {/* Header */}
      <div style={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', marginBottom: '1.5rem', flexWrap: 'wrap', gap: '1rem' }}>
        <div>
          <h1 style={{ fontSize: '1.5rem', fontWeight: '700', color: 'var(--text-main)', margin: '0 0 4px 0' }}>Inventory</h1>
          <p style={{ fontSize: '0.875rem', color: 'var(--text-muted)', margin: 0 }}>Monitor and adjust stock levels across your product catalog.</p>
        </div>
        <Button variant="secondary" size="md" onClick={() => onNavigate('/inventory/history')}>
          <History size={16} style={{ marginRight: '6px' }} /> View History
        </Button>
      </div>

      {alert && (
        <Alert variant={alert.variant} style={{ marginBottom: '1.25rem' }} onDismiss={() => setAlert(null)}>
          {alert.message}
        </Alert>
      )}

      {/* Stats */}
      {stats && (
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(180px, 1fr))', gap: '1rem', marginBottom: '1.5rem' }}>
          {[
            { label: 'Total Products', value: stats.total, icon: Package, color: '#7EAFD0' },
            { label: 'Total Units in Stock', value: stats.totalUnits, icon: CheckCircle, color: '#10B981' },
            { label: 'Low Stock', value: stats.lowStock, icon: TrendingDown, color: '#F59E0B' },
            { label: 'Out of Stock', value: stats.outOfStock, icon: AlertTriangle, color: '#EF4444' }
          ].map(s => {
            const Icon = s.icon;
            return (
              <div key={s.label} style={{ backgroundColor: '#fff', borderRadius: 'var(--radius-lg)', border: '1px solid var(--border-color)', padding: '1.125rem 1.25rem', boxShadow: 'var(--shadow-sm)', display: 'flex', alignItems: 'center', gap: '1rem' }}>
                <div style={{ padding: '10px', borderRadius: '8px', backgroundColor: `${s.color}18` }}>
                  <Icon size={20} color={s.color} />
                </div>
                <div>
                  <div style={{ fontSize: '1.5rem', fontWeight: '700', color: 'var(--text-main)', lineHeight: 1 }}>{s.value}</div>
                  <div style={{ fontSize: '0.75rem', color: 'var(--text-muted)', marginTop: '2px' }}>{s.label}</div>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Filters */}
      <div style={{ backgroundColor: '#fff', borderRadius: 'var(--radius-lg)', border: '1px solid var(--border-color)', padding: '0.875rem 1.25rem', marginBottom: '1.25rem', boxShadow: 'var(--shadow-sm)', display: 'flex', flexWrap: 'wrap', gap: '0.75rem', alignItems: 'center' }}>
        <div style={{ flex: '1 1 200px' }}>
          <Input id="inv-search" placeholder="Search products…" value={search} onChange={e => { setSearch(e.target.value); setPage(1); }} startIcon={<Search size={16} />} />
        </div>
        <select value={filterStatus} onChange={e => { setFilterStatus(e.target.value); setPage(1); }} style={{ padding: '9px 12px', borderRadius: '6px', border: '1px solid var(--border-color)', fontSize: '0.875rem', color: 'var(--text-main)', backgroundColor: '#fff', outline: 'none', minWidth: '150px' }}>
          <option value="">All Stock Status</option>
          <option value="IN_STOCK">In Stock</option>
          <option value="LOW_STOCK">Low Stock</option>
          <option value="OUT_OF_STOCK">Out of Stock</option>
        </select>
        <Button variant="ghost" size="md" onClick={() => { setSearch(''); setFilterStatus(''); setPage(1); }}>Clear</Button>
      </div>

      {/* Inventory table */}
      <div style={{ backgroundColor: '#fff', borderRadius: 'var(--radius-lg)', border: '1px solid var(--border-color)', boxShadow: 'var(--shadow-sm)', overflow: 'hidden' }}>
        <div style={{ padding: '0.875rem 1.25rem', borderBottom: '1px solid var(--border-subtle)', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
          <span style={{ fontSize: '0.8125rem', color: 'var(--text-muted)' }}>
            {loading ? 'Loading…' : `${total} product${total !== 1 ? 's' : ''}`}
          </span>
          <button onClick={loadData} style={{ background: 'none', border: 'none', cursor: 'pointer', color: 'var(--text-muted)', display: 'flex', alignItems: 'center', gap: '4px', fontSize: '0.8125rem' }}>
            <RefreshCw size={13} /> Refresh
          </button>
        </div>

        {error ? (
          <div style={{ padding: '2rem', textAlign: 'center', color: 'var(--danger)', fontSize: '0.875rem' }}>{error}</div>
        ) : loading ? (
          <div style={{ padding: '3rem', textAlign: 'center', color: 'var(--text-muted)', fontSize: '0.875rem' }}>Loading inventory…</div>
        ) : items.length === 0 ? (
          <div style={{ padding: '3rem', textAlign: 'center' }}>
            <Package size={40} color="#CBD5E1" style={{ marginBottom: '0.75rem' }} />
            <p style={{ color: 'var(--text-muted)', fontSize: '0.9375rem', fontWeight: '500' }}>No inventory records found</p>
            <p style={{ color: 'var(--text-light)', fontSize: '0.875rem', marginTop: '4px' }}>Add products first to manage inventory.</p>
          </div>
        ) : (
          <div style={{ overflowX: 'auto' }}>
            <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: '0.875rem' }}>
              <thead>
                <tr style={{ backgroundColor: 'var(--bg-page)', borderBottom: '1px solid var(--border-color)' }}>
                  {['Product', 'SKU', 'Variants', 'Total Stock', 'Min Stock', 'Status', 'Adjust Stock'].map(h => (
                    <th key={h} style={{ padding: '10px 14px', textAlign: 'left', fontWeight: '600', color: 'var(--text-main)', whiteSpace: 'nowrap', fontSize: '0.8125rem' }}>{h}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {items.map((item, idx) => (
                  <tr key={item.id} style={{ borderBottom: idx < items.length - 1 ? '1px solid var(--border-subtle)' : 'none' }}>
                    <td style={{ padding: '11px 14px' }}>
                      <div style={{ fontWeight: '600', color: 'var(--text-main)' }}>{item.name}</div>
                      {item.categoryName && <div style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>{item.categoryName}</div>}
                    </td>
                    <td style={{ padding: '11px 14px', fontFamily: 'monospace', fontSize: '0.8125rem', color: 'var(--text-muted)' }}>{item.sku}</td>
                    <td style={{ padding: '11px 14px', color: 'var(--text-muted)', textAlign: 'center' }}>{item.variantCount || 0}</td>
                    <td style={{ padding: '11px 14px', fontWeight: '700', fontSize: '1rem', color: item.totalStock === 0 ? 'var(--danger)' : item.totalStock <= item.minimumStock ? '#D97706' : 'var(--text-main)', textAlign: 'center' }}>
                      {item.totalStock}
                    </td>
                    <td style={{ padding: '11px 14px', color: 'var(--text-muted)', textAlign: 'center' }}>{item.minimumStock || 0}</td>
                    <td style={{ padding: '11px 14px' }}><StockStatusBadge status={item.stockStatus} /></td>
                    <td style={{ padding: '11px 14px' }}>
                      <Button variant="outline" size="sm" onClick={() => openAdjust(item)}>
                        <SlidersHorizontal size={13} style={{ marginRight: '4px' }} /> Adjust
                      </Button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}

        {/* Pagination */}
        {totalPages > 1 && (
          <div style={{ padding: '1rem 1.25rem', borderTop: '1px solid var(--border-subtle)', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
            <span style={{ fontSize: '0.8125rem', color: 'var(--text-muted)' }}>Page {page} of {totalPages}</span>
            <div style={{ display: 'flex', gap: '0.5rem' }}>
              <Button variant="secondary" size="sm" onClick={() => setPage(p => Math.max(1, p - 1))} disabled={page <= 1}><ChevronLeft size={14} /></Button>
              <Button variant="secondary" size="sm" onClick={() => setPage(p => Math.min(totalPages, p + 1))} disabled={page >= totalPages}><ChevronRight size={14} /></Button>
            </div>
          </div>
        )}
      </div>

      {/* Adjust Modal */}
      <Modal isOpen={showAdjust} onClose={() => setShowAdjust(false)} title="Adjust Stock" width="520px">
        {adjustProduct && (
          <AdjustModal
            product={adjustProduct}
            variants={adjustVariants}
            onSubmit={handleAdjust}
            onCancel={() => setShowAdjust(false)}
            isLoading={adjusting}
          />
        )}
      </Modal>
    </div>
  );
}
