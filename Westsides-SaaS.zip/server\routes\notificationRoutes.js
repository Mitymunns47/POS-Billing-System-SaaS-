const express = require('express');
const router = express.Router();
const authMiddleware = require('../middleware/auth');
const { requirePermission } = require('../middleware/roles');
const { PERMISSIONS } = require('../constants/roles');
const NotificationModel = require('../models/notificationModel');

router.use(authMiddleware);

/**
 * GET /api/notifications — Retrieve notifications for the current user
 */
router.get('/', requirePermission(PERMISSIONS.NOTIFICATIONS_VIEW), (req, res) => {
  try {
    const { isRead = null, limit = 50, page = 1 } = req.query;
    const result = NotificationModel.findAll({
      storeId: req.storeId,
      userId: req.user.id,
      role: req.user.role,
      isRead: isRead !== null ? isRead === 'true' || isRead === '1' : null,
      limit: parseInt(limit, 10) || 50,
      page: parseInt(page, 10) || 1
    });

    res.json({ success: true, data: result });
  } catch (err) {
    console.error('Get notifications error:', err);
    res.status(500).json({ success: false, error: 'Failed to retrieve notifications.' });
  }
});

/**
 * GET /api/notifications/unread-count — Quick unread count for badge
 */
router.get('/unread-count', requirePermission(PERMISSIONS.NOTIFICATIONS_VIEW), (req, res) => {
  try {
    const count = NotificationModel.getUnreadCount(
      req.storeId,
      req.user.id,
      req.user.role
    );
    res.json({ success: true, count });
  } catch (err) {
    console.error('Get unread count error:', err);
    res.status(500).json({ success: false, error: 'Failed to get unread count.' });
  }
});

/**
 * PATCH /api/notifications/:id/read — Mark single notification as read
 */
router.patch('/:id/read', requirePermission(PERMISSIONS.NOTIFICATIONS_VIEW), (req, res) => {
  try {
    NotificationModel.markAsRead(req.params.id, req.storeId);
    res.json({ success: true, message: 'Notification marked as read.' });
  } catch (err) {
    console.error('Mark read error:', err);
    res.status(500).json({ success: false, error: 'Failed to update notification.' });
  }
});

/**
 * POST /api/notifications/read-all — Mark all eligible notifications as read
 */
router.post('/read-all', requirePermission(PERMISSIONS.NOTIFICATIONS_VIEW), (req, res) => {
  try {
    NotificationModel.markAllAsRead(req.storeId, req.user.id, req.user.role);
    res.json({ success: true, message: 'All notifications marked as read.' });
  } catch (err) {
    console.error('Mark all read error:', err);
    res.status(500).json({ success: false, error: 'Failed to mark notifications read.' });
  }
});

module.exports = router;
