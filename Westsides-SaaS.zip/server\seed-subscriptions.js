const db = require('./db/database');
const SubscriptionModel = require('./models/subscriptionModel');

function seedSubscriptions() {
  console.log('--- Seeding Subscriptions for Existing Stores ---');
  
  const stores = db.prepare("SELECT * FROM stores WHERE id != 'str_platform_e162f383'").all();
  const plans = SubscriptionModel.listPlans();
  
  if (plans.length === 0) {
    console.error('No subscription plans found. Aborting.');
    return;
  }

  const planMap = {
    free: plans.find(p => p.slug === 'free') || plans[0],
    basic: plans.find(p => p.slug === 'basic') || plans[1] || plans[0],
    pro: plans.find(p => p.slug === 'pro') || plans[2] || plans[0],
    enterprise: plans.find(p => p.slug === 'enterprise') || plans[3] || plans[0]
  };

  const planDistribution = [
    planMap.pro,
    planMap.basic,
    planMap.enterprise,
    planMap.pro,
    planMap.basic,
    planMap.free,
    planMap.pro,
    planMap.enterprise
  ];

  let createdSubs = 0;
  let createdInvoices = 0;

  for (let i = 0; i < stores.length; i++) {
    const store = stores[i];
    const existingSub = SubscriptionModel.getStoreSubscription(store.id);
    
    let sub = existingSub;
    if (!existingSub) {
      const plan = planDistribution[i % planDistribution.length];
      const status = i === 1 ? 'TRIALING' : 'ACTIVE';
      sub = SubscriptionModel.createSubscription({
        storeId: store.id,
        planId: plan.id,
        status: status,
        trialDays: 14
      });
      createdSubs++;

      // Create an invoice for paid plans
      if (plan.price > 0) {
        const now = new Date();
        const start = new Date(now.getFullYear(), now.getMonth(), 1).toISOString();
        const end = new Date(now.getFullYear(), now.getMonth() + 1, 0).toISOString();
        const due = new Date(now.getFullYear(), now.getMonth(), 15).toISOString();

        const inv = SubscriptionModel.createInvoice({
          storeId: store.id,
          subscriptionId: sub.id,
          planId: plan.id,
          planName: plan.name,
          amount: plan.price,
          billingPeriodStart: start,
          billingPeriodEnd: end,
          dueDate: due
        });

        // Mark older ones or even-indexed ones as paid
        if (i % 2 === 0) {
          SubscriptionModel.markInvoicePaid(inv.id);
        }
        createdInvoices++;
      }
    }
  }

  console.log(`Seeded ${createdSubs} store subscriptions and ${createdInvoices} invoices.`);
}

if (require.main === module) {
  seedSubscriptions();
}

module.exports = seedSubscriptions;
