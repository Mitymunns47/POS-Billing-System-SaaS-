const crypto = require('crypto');
const db = require('./db/database');
const ProductModel = require('./models/productModel');
const VariantModel = require('./models/variantModel');
const CategoryModel = require('./models/categoryModel');
const BrandModel = require('./models/brandModel');

function seedStoreCatalog() {
  console.log('--- Seeding Realistic Apparel Catalog for Westsides ---');
  const storeId = 'str_fb298790e53d5c83';

  // 1. Restore Fleece Hoodie
  db.prepare('UPDATE products SET active = 1, archived = 0 WHERE id = ?').run('prd_4345809075e1e61a');
  console.log('✓ Restored Fleece Hoodie to active');

  // 2. Categories
  let shirtsCat = db.prepare('SELECT * FROM categories WHERE storeId = ? AND name = ?').get(storeId, 'Shirts');
  if (!shirtsCat) {
    shirtsCat = CategoryModel.create({ storeId, name: 'Shirts', description: 'Formal, casual & oxford shirts' });
  }
  let denimCat = db.prepare('SELECT * FROM categories WHERE storeId = ? AND name = ?').get(storeId, 'Denim & Jeans');
  if (!denimCat) {
    denimCat = CategoryModel.create({ storeId, name: 'Denim & Jeans', description: 'Slim, regular, and relaxed denim' });
  }
  let tshirtsCat = db.prepare('SELECT * FROM categories WHERE storeId = ? AND name = ?').get(storeId, 'T-Shirts');
  if (!tshirtsCat) {
    tshirtsCat = CategoryModel.create({ storeId, name: 'T-Shirts', description: 'Cotton tees & henleys' });
  }

  // 3. Brands
  let westsideBrand = db.prepare('SELECT * FROM brands WHERE storeId = ? AND name = ?').get(storeId, 'Westsides Urban');
  if (!westsideBrand) {
    westsideBrand = BrandModel.create({ storeId, name: 'Westsides Urban', description: 'Premium modern essentials' });
  }
  let nuonBrand = db.prepare('SELECT * FROM brands WHERE storeId = ? AND name = ?').get(storeId, 'Nuon');
  if (!nuonBrand) {
    nuonBrand = BrandModel.create({ storeId, name: 'Nuon', description: 'Casual youth wear' });
  }

  // 4. Products to seed
  const productsToSeed = [
    {
      name: 'Oxford Cotton Button-Down Shirt',
      sku: 'SHT-OXF-001',
      categoryId: shirtsCat.id,
      brandId: westsideBrand.id,
      description: '100% combed cotton, breathable weave with button-down collar',
      costPrice: 450,
      mrp: 1499,
      sellingPrice: 1199,
      barcode: '890123400101',
      minimumStock: 5,
      variants: [
        { size: 'S', color: 'White', sku: 'SHT-OXF-001-S-WHT', barcode: '890123400102', stock: 15, minimumStock: 3 },
        { size: 'M', color: 'White', sku: 'SHT-OXF-001-M-WHT', barcode: '890123400103', stock: 24, minimumStock: 5 },
        { size: 'L', color: 'White', sku: 'SHT-OXF-001-L-WHT', barcode: '890123400104', stock: 18, minimumStock: 4 },
        { size: 'M', color: 'Light Blue', sku: 'SHT-OXF-001-M-BLU', barcode: '890123400105', stock: 12, minimumStock: 3 }
      ]
    },
    {
      name: 'Slim Stretch Tapered Jeans',
      sku: 'JNS-SLM-002',
      categoryId: denimCat.id,
      brandId: westsideBrand.id,
      description: 'Mid-rise stretch denim with washed aesthetic and 5-pocket styling',
      costPrice: 650,
      mrp: 2299,
      sellingPrice: 1799,
      barcode: '890123400201',
      minimumStock: 4,
      variants: [
        { size: '30', color: 'Dark Indigo', sku: 'JNS-SLM-002-30-IND', barcode: '890123400202', stock: 10, minimumStock: 2 },
        { size: '32', color: 'Dark Indigo', sku: 'JNS-SLM-002-32-IND', barcode: '890123400203', stock: 20, minimumStock: 4 },
        { size: '34', color: 'Dark Indigo', sku: 'JNS-SLM-002-34-IND', barcode: '890123400204', stock: 14, minimumStock: 3 }
      ]
    },
    {
      name: 'Classic Pima Cotton Crew Tee',
      sku: 'TEE-PIM-003',
      categoryId: tshirtsCat.id,
      brandId: nuonBrand.id,
      description: 'Super-soft 220 GSM heavyweight combed pima cotton t-shirt',
      costPrice: 220,
      mrp: 899,
      sellingPrice: 699,
      barcode: '890123400301',
      minimumStock: 8,
      variants: [
        { size: 'S', color: 'Black', sku: 'TEE-PIM-003-S-BLK', barcode: '890123400302', stock: 25, minimumStock: 5 },
        { size: 'M', color: 'Black', sku: 'TEE-PIM-003-M-BLK', barcode: '890123400303', stock: 35, minimumStock: 8 },
        { size: 'L', color: 'Black', sku: 'TEE-PIM-003-L-BLK', barcode: '890123400304', stock: 30, minimumStock: 6 },
        { size: 'M', color: 'Sage Green', sku: 'TEE-PIM-003-M-GRN', barcode: '890123400305', stock: 16, minimumStock: 4 }
      ]
    }
  ];

  for (const pData of productsToSeed) {
    let existing = db.prepare('SELECT * FROM products WHERE storeId = ? AND sku = ?').get(storeId, pData.sku);
    let prodId;
    if (!existing) {
      const prod = ProductModel.create({
        storeId,
        name: pData.name,
        sku: pData.sku,
        categoryId: pData.categoryId,
        brandId: pData.brandId,
        description: pData.description,
        costPrice: pData.costPrice,
        mrp: pData.mrp,
        sellingPrice: pData.sellingPrice,
        barcode: pData.barcode,
        minimumStock: pData.minimumStock
      });
      prodId = prod.id;
      console.log(`✓ Created product: "${pData.name}" (${pData.sku})`);
    } else {
      prodId = existing.id;
      db.prepare('UPDATE products SET active = 1, archived = 0 WHERE id = ?').run(prodId);
      console.log(`✓ Product already exists: "${pData.name}" (${pData.sku})`);
    }

    for (const vData of pData.variants) {
      const existingVar = db.prepare('SELECT * FROM product_variants WHERE productId = ? AND size = ? AND color = ?').get(prodId, vData.size, vData.color);
      if (!existingVar) {
        VariantModel.create({
          productId: prodId,
          storeId,
          size: vData.size,
          color: vData.color,
          sku: vData.sku,
          barcode: vData.barcode,
          stock: vData.stock,
          minimumStock: vData.minimumStock
        });
        console.log(`  + Variant ${vData.size} / ${vData.color} (Stock: ${vData.stock}, Barcode: ${vData.barcode})`);
      } else {
        // Ensure stock is healthy
        if (existingVar.stock < 5) {
          db.prepare('UPDATE product_variants SET stock = ?, active = 1 WHERE id = ?').run(vData.stock, existingVar.id);
        }
      }
    }
  }

  console.log('\n--- Seeding Completed Successfully ---');
}

seedStoreCatalog();
