/**
 * AdminStoreDetailPage.jsx — Phase 7
 * Detailed view of a single tenant store.
 */
import React, { useEffect, useState } from 'react';
import { api } from '../../services/api';

const COLORS = {
  bg: '#0F172A', card: '#1E293B', border: 'rgba(126,175,208,0.12)',
  text: '#F1F5F9', muted: '#64748B', accent: '#7EAFD0',
  success: '#10B981', warn: '#F59E0B', danger: '#EF4444'
};

const STATUS_BADGE = {
  ACTIVE: { bg: '#10B98120', color: '#10B981', label: 'Active' },
  SUSPENDED: { bg: '#F59E0B20', color: '#F59E0B', label: 'Suspended' },
  CANCELLED: { bg: '#EF444420', color: '#EF4444', label: 'Cancelled' },
  TRIALING: { bg: '#7EAFD020', color: '#7EAFD0', label: 'Trialing' }
};

function Badge({ map, value }) {
  const b = map[value] || { bg: '#33415530', color: '#64748B', label: value || '—' };
  return <span style={{ background: b.bg, color: b.color, borderRadius: '6px', padding: '2px 8px', fontSize: '0.75rem', fontWeight: '600' }}>{b.label}</span>;
}

function MetCard({ label, value, color = COLORS.text }) {
  return (
    <div style={{ background: '#263348', border: `1px solid ${COLORS.border}`, borderRadius: '10px', padding: '1rem', textAlign: 'center' }}>
      <div style={{ color, fontSize: '1.5rem', fontWeight: '700' }}>{value}</div>
      <div style={{ color: COLORS.muted, fontSize: '0.75rem', marginTop: '0.25rem' }}>{label}</div>
    </div>
  );
}

export function AdminStoreDetailPage({ storeId, onNavigate }) {
  const [data, setData] = useState(null);
  const [plans, setPlans] = useState([]);
  const [loading, setLoading] = useState(true);
  const [actionLoading, setActionLoading] = useState(false);
  const [msg, setMsg] = useState('');
  const [error, setError] = useState('');
  const [selectedPlan, setSelectedPlan] = useState('');

  useEffect(() => {
    Promise.all([
      api.adminGetStore(storeId),
      api.adminListPlans()
    ]).then(([storeRes, plansRes]) => {
      if (storeRes.success) setData(storeRes);
      if (plansRes.success) setPlans(plansRes.plans);
      if (storeRes.success) setSelectedPlan(storeRes.store.planId || '');
    }).catch(err => setError(err.message))
      .finally(() => setLoading(false));
  }, [storeId]);

  const handleSuspend = async () => {
    const reason = window.prompt(`Reason for suspending "${data.store.name}":`, 'Administrative action');
    if (!reason) return;
    setActionLoading(true);
    try {
      const res = await api.adminSuspendStore(storeId, reason);
      if (res.success) { setMsg(res.message); const r = await api.adminGetStore(storeId); if (r.success) setData(r); }
    } catch (err) { setError(err.message); }
    finally { setActionLoading(false); }
  };

  const handleReactivate = async () => {
    setActionLoading(true);
    try {
      const res = await api.adminReactivateStore(storeId);
      if (res.success) { setMsg(res.message); const r = await api.adminGetStore(storeId); if (r.success) setData(r); }
    } catch (err) { setError(err.message); }
    finally { setActionLoading(false); }
  };

  const handleChangePlan = async () => {
    if (!selectedPlan) return;
    setActionLoading(true);
    try {
      const res = await api.adminChangePlan(storeId, selectedPlan);
      if (res.success) { setMsg(res.message); const r = await api.adminGetStore(storeId); if (r.success) setData(r); }
    } catch (err) { setError(err.message); }
    finally { setActionLoading(false); }
  };

  const handleGenerateInvoice = async () => {
    setActionLoading(true);
    try {
      const res = await api.adminGenerateInvoice(storeId);
      if (res.success) { setMsg(`Invoice generated: ₹${res.invoice.amount}`); }
    } catch (err) { setError(err.message); }
    finally { setActionLoading(false); }
  };

  if (loading) return <div style={{ color: COLORS.muted, padding: '3rem', textAlign: 'center' }}>Loading store details...</div>;
  if (error && !data) return <div style={{ color: COLORS.danger, padding: '2rem' }}>{error}</div>;
  if (!data) return null;

  const { store, staff, invoices, metrics } = data;
  const storeStatus = store.status || 'ACTIVE';

  return (
    <div style={{ padding: '1.75rem', fontFamily: "'Inter', 'Segoe UI', sans-serif" }}>
      {/* Breadcrumb */}
      <div style={{ marginBottom: '1rem' }}>
        <button onClick={() => onNavigate('/admin/stores')} style={{ background: 'none', border: 'none', color: COLORS.muted, cursor: 'pointer', fontSize: '0.875rem' }}>
          ← Back to Stores
        </button>
      </div>

      {msg && <div style={{ background: '#10B98120', border: '1px solid #10B98140', borderRadius: '8px', padding: '0.75rem 1rem', color: '#10B981', fontSize: '0.875rem', marginBottom: '1rem' }}>{msg} <button onClick={() => setMsg('')} style={{ float: 'right', background: 'none', border: 'none', color: '#10B981', cursor: 'pointer' }}>✕</button></div>}
      {error && <div style={{ background: '#EF444420', border: '1px solid #EF444440', borderRadius: '8px', padding: '0.75rem 1rem', color: '#EF4444', fontSize: '0.875rem', marginBottom: '1rem' }}>{error} <button onClick={() => setError('')} style={{ float: 'right', background: 'none', border: 'none', color: '#EF4444', cursor: 'pointer' }}>✕</button></div>}

      {/* Header */}
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: '1.5rem', flexWrap: 'wrap', gap: '1rem' }}>
        <div>
          <div style={{ display: 'flex', alignItems: 'center', gap: '0.75rem', flexWrap: 'wrap' }}>
            <h1 style={{ color: COLORS.text, fontSize: '1.375rem', fontWeight: '700', margin: 0 }}>{store.name}</h1>
            <Badge map={STATUS_BADGE} value={storeStatus} />
            <Badge map={STATUS_BADGE} value={store.subStatus || 'ACTIVE'} />
          </div>
          <p style={{ color: COLORS.muted, fontSize: '0.875rem', margin: '0.25rem 0 0' }}>
            {store.city}{store.state ? `, ${store.state}` : ''} · {store.id}
          </p>
        </div>
        <div style={{ display: 'flex', gap: '0.5rem', flexWrap: 'wrap' }}>
          {storeStatus === 'ACTIVE' ? (
            <button onClick={handleSuspend} disabled={actionLoading} style={{ padding: '0.625rem 1.25rem', background: 'rgba(245,158,11,0.12)', border: '1px solid rgba(245,158,11,0.3)', borderRadius: '8px', color: '#F59E0B', cursor: 'pointer', fontSize: '0.875rem', fontWeight: '600' }}>
              Suspend Store
            </button>
          ) : (
            <button onClick={handleReactivate} disabled={actionLoading} style={{ padding: '0.625rem 1.25rem', background: 'rgba(16,185,129,0.12)', border: '1px solid rgba(16,185,129,0.3)', borderRadius: '8px', color: '#10B981', cursor: 'pointer', fontSize: '0.875rem', fontWeight: '600' }}>
              Reactivate Store
            </button>
          )}
          <button onClick={handleGenerateInvoice} disabled={actionLoading} style={{ padding: '0.625rem 1.25rem', background: 'rgba(126,175,208,0.12)', border: '1px solid rgba(126,175,208,0.2)', borderRadius: '8px', color: COLORS.accent, cursor: 'pointer', fontSize: '0.875rem', fontWeight: '600' }}>
            Generate Invoice
          </button>
        </div>
      </div>

      {/* Metrics */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(150px, 1fr))', gap: '0.875rem', marginBottom: '1.25rem' }}>
        <MetCard label="Products" value={metrics.totalProducts} />
        <MetCard label="Sales" value={metrics.totalSales} />
        <MetCard label="Customers" value={metrics.totalCustomers} />
        <MetCard label="Store Revenue" value={`₹${(metrics.totalRevenue || 0).toLocaleString('en-IN')}`} color={COLORS.success} />
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '1.25rem', marginBottom: '1.25rem' }}>
        {/* Store Info */}
        <div style={{ background: COLORS.card, border: `1px solid ${COLORS.border}`, borderRadius: '12px', padding: '1.25rem' }}>
          <h3 style={{ color: COLORS.text, fontSize: '0.9375rem', fontWeight: '600', margin: '0 0 1rem' }}>Store Information</h3>
          {[
            ['Phone', store.phone], ['GST No.', store.gstNumber], ['Country', store.country],
            ['Created', store.createdAt ? new Date(store.createdAt).toLocaleDateString('en-IN') : '—'],
            ['Onboarding', store.onboardingCompleted ? '✅ Completed' : '⏳ Pending']
          ].map(([label, value]) => (
            <div key={label} style={{ display: 'flex', justifyContent: 'space-between', padding: '0.5rem 0', borderBottom: `1px solid ${COLORS.border}`, fontSize: '0.875rem' }}>
              <span style={{ color: COLORS.muted }}>{label}</span>
              <span style={{ color: COLORS.text }}>{value || '—'}</span>
            </div>
          ))}
        </div>

        {/* Subscription Info */}
        <div style={{ background: COLORS.card, border: `1px solid ${COLORS.border}`, borderRadius: '12px', padding: '1.25rem' }}>
          <h3 style={{ color: COLORS.text, fontSize: '0.9375rem', fontWeight: '600', margin: '0 0 1rem' }}>Subscription</h3>
          {[
            ['Current Plan', store.planName || '—'],
            ['Plan Price', store.planPrice ? `₹${store.planPrice}/month` : '—'],
            ['Sub Status', store.subStatus || '—'],
            ['Trial Ends', store.trialEndDate ? new Date(store.trialEndDate).toLocaleDateString('en-IN') : '—'],
            ['Period Ends', store.currentPeriodEnd ? new Date(store.currentPeriodEnd).toLocaleDateString('en-IN') : '—'],
            ['Suspended At', store.suspendedAt ? new Date(store.suspendedAt).toLocaleDateString('en-IN') : '—'],
            ['Suspension Reason', store.suspensionReason || '—']
          ].map(([label, value]) => (
            <div key={label} style={{ display: 'flex', justifyContent: 'space-between', padding: '0.5rem 0', borderBottom: `1px solid ${COLORS.border}`, fontSize: '0.875rem' }}>
              <span style={{ color: COLORS.muted }}>{label}</span>
              <span style={{ color: COLORS.text }}>{value}</span>
            </div>
          ))}
          {/* Change Plan */}
          <div style={{ marginTop: '1rem' }}>
            <label style={{ color: COLORS.muted, fontSize: '0.8125rem', display: 'block', marginBottom: '0.5rem' }}>Change Plan</label>
            <div style={{ display: 'flex', gap: '0.5rem' }}>
              <select
                value={selectedPlan}
                onChange={e => setSelectedPlan(e.target.value)}
                style={{ flex: 1, padding: '0.5rem', background: '#263348', border: `1px solid ${COLORS.border}`, borderRadius: '6px', color: COLORS.text, fontSize: '0.875rem', outline: 'none' }}
              >
                {plans.map(p => <option key={p.id} value={p.id}>{p.name} — ₹{p.price}/mo</option>)}
              </select>
              <button
                onClick={handleChangePlan}
                disabled={actionLoading}
                style={{ padding: '0.5rem 1rem', background: 'rgba(126,175,208,0.15)', border: `1px solid ${COLORS.border}`, borderRadius: '6px', color: COLORS.accent, cursor: 'pointer', fontSize: '0.8125rem', fontWeight: '600' }}
              >
                Apply
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Staff List */}
      <div style={{ background: COLORS.card, border: `1px solid ${COLORS.border}`, borderRadius: '12px', padding: '1.25rem', marginBottom: '1.25rem' }}>
        <h3 style={{ color: COLORS.text, fontSize: '0.9375rem', fontWeight: '600', margin: '0 0 1rem' }}>Staff Accounts ({staff.length})</h3>
        {staff.length === 0 ? <p style={{ color: COLORS.muted, fontSize: '0.875rem' }}>No staff accounts.</p> : (
          <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: '0.8125rem' }}>
            <thead>
              <tr style={{ borderBottom: `1px solid ${COLORS.border}` }}>
                {['Name', 'Email', 'Role', 'Status', 'Last Login'].map(h => (
                  <th key={h} style={{ color: COLORS.muted, textAlign: 'left', padding: '0.5rem 0.75rem', fontWeight: '500' }}>{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {staff.map(s => (
                <tr key={s.id} style={{ borderBottom: `1px solid ${COLORS.border}` }}>
                  <td style={{ color: COLORS.text, padding: '0.6rem 0.75rem', fontWeight: '500' }}>{s.name}</td>
                  <td style={{ color: COLORS.muted, padding: '0.6rem 0.75rem' }}>{s.email}</td>
                  <td style={{ color: COLORS.accent, padding: '0.6rem 0.75rem' }}>{s.role}</td>
                  <td style={{ padding: '0.6rem 0.75rem' }}>
                    <span style={{ color: s.status === 'ACTIVE' ? COLORS.success : COLORS.danger, fontSize: '0.75rem', fontWeight: '600' }}>{s.status}</span>
                  </td>
                  <td style={{ color: COLORS.muted, padding: '0.6rem 0.75rem' }}>
                    {s.lastLoginAt ? new Date(s.lastLoginAt).toLocaleDateString('en-IN') : '—'}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>

      {/* Subscription Invoices */}
      <div style={{ background: COLORS.card, border: `1px solid ${COLORS.border}`, borderRadius: '12px', padding: '1.25rem' }}>
        <h3 style={{ color: COLORS.text, fontSize: '0.9375rem', fontWeight: '600', margin: '0 0 1rem' }}>Subscription Invoices</h3>
        {invoices.length === 0 ? <p style={{ color: COLORS.muted, fontSize: '0.875rem' }}>No invoices yet.</p> : (
          <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: '0.8125rem' }}>
            <thead>
              <tr style={{ borderBottom: `1px solid ${COLORS.border}` }}>
                {['Invoice ID', 'Plan', 'Amount', 'Status', 'Due Date', 'Paid At'].map(h => (
                  <th key={h} style={{ color: COLORS.muted, textAlign: 'left', padding: '0.5rem 0.75rem', fontWeight: '500' }}>{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {invoices.map(inv => (
                <tr key={inv.id} style={{ borderBottom: `1px solid ${COLORS.border}` }}>
                  <td style={{ color: COLORS.muted, padding: '0.6rem 0.75rem', fontSize: '0.75rem' }}>{inv.id}</td>
                  <td style={{ color: COLORS.text, padding: '0.6rem 0.75rem' }}>{inv.planName}</td>
                  <td style={{ color: COLORS.success, padding: '0.6rem 0.75rem', fontWeight: '600' }}>₹{inv.amount}</td>
                  <td style={{ padding: '0.6rem 0.75rem' }}>
                    <span style={{ color: inv.paymentStatus === 'PAID' ? COLORS.success : COLORS.warn, fontSize: '0.75rem', fontWeight: '600' }}>{inv.paymentStatus}</span>
                  </td>
                  <td style={{ color: COLORS.muted, padding: '0.6rem 0.75rem' }}>{inv.dueDate ? new Date(inv.dueDate).toLocaleDateString('en-IN') : '—'}</td>
                  <td style={{ color: COLORS.muted, padding: '0.6rem 0.75rem' }}>{inv.paidAt ? new Date(inv.paidAt).toLocaleDateString('en-IN') : '—'}</td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </div>
  );
}
