const crypto = require('crypto');
const db = require('../db/database');

const CustomerModel = {
  /**
   * Create a new customer with full CRM fields
   */
  create: ({ storeId, name, phone, email, dateOfBirth, gender, address, city, state, postalCode, notes }) => {
    const id = 'cus_' + crypto.randomBytes(8).toString('hex');
    const now = new Date().toISOString();

    const cleanPhone = phone ? phone.trim() : null;
    const cleanEmail = email ? email.trim().toLowerCase() : null;

    // Check duplicate phone in same store if phone provided
    if (cleanPhone) {
      const existing = CustomerModel.findByPhone(storeId, cleanPhone);
      if (existing) {
        throw new Error(`A customer with phone number "${cleanPhone}" already exists (${existing.name}).`);
      }
    }

    db.prepare(`
      INSERT INTO customers (
        id, storeId, name, phone, email,
        dateOfBirth, gender, address, city, state, postalCode, notes,
        totalPurchases, totalSpent, active, status, createdAt, updatedAt
      )
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 0, 0, 1, 'ACTIVE', ?, ?)
    `).run(
      id, storeId, name.trim(), cleanPhone, cleanEmail,
      dateOfBirth || null, gender || null, address ? address.trim() : null,
      city ? city.trim() : null, state ? state.trim() : null,
      postalCode ? postalCode.trim() : null, notes ? notes.trim() : null,
      now, now
    );

    return CustomerModel.findById(id, storeId, true);
  },

  /**
   * Find customer by ID (tenant isolated)
   */
  findById: (id, storeId, includeArchived = true) => {
    const query = includeArchived
      ? 'SELECT * FROM customers WHERE id = ? AND storeId = ?'
      : "SELECT * FROM customers WHERE id = ? AND storeId = ? AND status = 'ACTIVE'";

    const row = db.prepare(query).get(id, storeId);
    if (!row) return null;

    return {
      ...row,
      active: Boolean(row.active),
      isArchived: row.status === 'ARCHIVED'
    };
  },

  /**
   * Find customer by phone in same store
   */
  findByPhone: (storeId, phone, excludeId = null) => {
    if (!phone) return null;
    const clean = phone.trim();
    let query = 'SELECT * FROM customers WHERE storeId = ? AND phone = ?';
    const params = [storeId, clean];

    if (excludeId) {
      query += ' AND id != ?';
      params.push(excludeId);
    }

    return db.prepare(query).get(...params) || null;
  },

  /**
   * Search active customers for POS and autocomplete
   */
  search: (storeId, query, limit = 15) => {
    if (!query || !query.trim()) {
      return db.prepare(`
        SELECT * FROM customers
        WHERE storeId = ? AND status = 'ACTIVE'
        ORDER BY name ASC LIMIT ?
      `).all(storeId, limit).map(r => ({ ...r, active: Boolean(r.active) }));
    }

    const q = `%${query.trim()}%`;
    return db.prepare(`
      SELECT * FROM customers
      WHERE storeId = ? AND status = 'ACTIVE'
        AND (name LIKE ? OR phone LIKE ? OR email LIKE ?)
      ORDER BY name ASC LIMIT ?
    `).all(storeId, q, q, q, limit).map(r => ({ ...r, active: Boolean(r.active) }));
  },

  /**
   * Update customer profile
   */
  update: (id, storeId, { name, phone, email, dateOfBirth, gender, address, city, state, postalCode, notes }) => {
    const existing = CustomerModel.findById(id, storeId, true);
    if (!existing) return null;

    const cleanPhone = phone !== undefined ? (phone ? phone.trim() : null) : existing.phone;
    const cleanEmail = email !== undefined ? (email ? email.trim().toLowerCase() : null) : existing.email;

    // Check duplicate phone if phone changed
    if (cleanPhone && cleanPhone !== existing.phone) {
      const dup = CustomerModel.findByPhone(storeId, cleanPhone, id);
      if (dup) {
        throw new Error(`A customer with phone number "${cleanPhone}" already exists (${dup.name}).`);
      }
    }

    const now = new Date().toISOString();

    db.prepare(`
      UPDATE customers SET
        name = COALESCE(?, name),
        phone = ?,
        email = ?,
        dateOfBirth = COALESCE(?, dateOfBirth),
        gender = COALESCE(?, gender),
        address = COALESCE(?, address),
        city = COALESCE(?, city),
        state = COALESCE(?, state),
        postalCode = COALESCE(?, postalCode),
        notes = COALESCE(?, notes),
        updatedAt = ?
      WHERE id = ? AND storeId = ?
    `).run(
      name !== undefined ? name.trim() : null,
      cleanPhone,
      cleanEmail,
      dateOfBirth !== undefined ? dateOfBirth : null,
      gender !== undefined ? gender : null,
      address !== undefined ? address : null,
      city !== undefined ? city : null,
      state !== undefined ? state : null,
      postalCode !== undefined ? postalCode : null,
      notes !== undefined ? notes : null,
      now,
      id,
      storeId
    );

    return CustomerModel.findById(id, storeId, true);
  },

  /**
   * Archive customer (does not permanently delete if linked to sales)
   */
  archive: (id, storeId) => {
    const now = new Date().toISOString();
    db.prepare(`
      UPDATE customers SET
        status = 'ARCHIVED',
        active = 0,
        updatedAt = ?
      WHERE id = ? AND storeId = ?
    `).run(now, id, storeId);

    return CustomerModel.findById(id, storeId, true);
  },

  /**
   * Restore archived customer
   */
  restore: (id, storeId) => {
    const now = new Date().toISOString();
    db.prepare(`
      UPDATE customers SET
        status = 'ACTIVE',
        active = 1,
        updatedAt = ?
      WHERE id = ? AND storeId = ?
    `).run(now, id, storeId);

    return CustomerModel.findById(id, storeId, true);
  },

  /**
   * Update stats when a sale completes
   */
  recordPurchase: (id, storeId, amount) => {
    const now = new Date().toISOString();
    db.prepare(`
      UPDATE customers SET
        totalPurchases = totalPurchases + 1,
        totalSpent = totalSpent + ?,
        updatedAt = ?
      WHERE id = ? AND storeId = ?
    `).run(amount, now, id, storeId);
  },

  /**
   * Get purchase summary with live metrics calculated from sales
   */
  getPurchaseSummary: (customerId, storeId) => {
    // 1. Sales summary (only completed sales)
    const salesStats = db.prepare(`
      SELECT
        COUNT(*) AS totalOrders,
        COALESCE(SUM(totalAmount), 0) AS totalSpent,
        MAX(createdAt) AS lastPurchaseDate
      FROM sales
      WHERE customerId = ? AND storeId = ? AND status = 'COMPLETED'
    `).get(customerId, storeId);

    // 2. Returns & Refunds summary
    const returnStats = db.prepare(`
      SELECT
        COUNT(*) AS totalReturns,
        COALESCE(SUM(totalRefundAmount), 0) AS totalRefunded
      FROM returns
      WHERE customerId = ? AND storeId = ? AND status != 'CANCELLED'
    `).get(customerId, storeId);

    // 3. Total items purchased across all completed sales
    const itemsStats = db.prepare(`
      SELECT COALESCE(SUM(si.quantity), 0) AS totalItems
      FROM sale_items si
      JOIN sales s ON si.saleId = s.id
      WHERE s.customerId = ? AND s.storeId = ? AND s.status = 'COMPLETED'
    `).get(customerId, storeId);

    const totalOrders = Number(salesStats?.totalOrders) || 0;
    const grossSpent = Number(salesStats?.totalSpent) || 0;
    const totalRefunded = Number(returnStats?.totalRefunded) || 0;
    const netSpent = Math.max(0, Math.round((grossSpent - totalRefunded) * 100) / 100);
    const totalItems = Number(itemsStats?.totalItems) || 0;
    const averageOrderValue = totalOrders > 0 ? Math.round((netSpent / totalOrders) * 100) / 100 : 0;

    return {
      totalOrders,
      totalItems,
      grossSpent,
      totalRefunded,
      netSpent,
      totalSpent: netSpent,
      averageOrderValue,
      lastPurchaseDate: salesStats?.lastPurchaseDate || null
    };
  },

  /**
   * Get paginated returns history for a specific customer
   */
  getCustomerReturns: (customerId, storeId, { page = 1, limit = 15 } = {}) => {
    const offset = (page - 1) * limit;

    const total = db.prepare(`
      SELECT COUNT(*) AS cnt
      FROM returns
      WHERE customerId = ? AND storeId = ?
    `).get(customerId, storeId).cnt;

    const rows = db.prepare(`
      SELECT r.*,
        (SELECT COUNT(*) FROM return_items WHERE returnId = r.id) as itemCount,
        (SELECT COALESCE(SUM(quantity), 0) FROM return_items WHERE returnId = r.id) as totalItemsReturned
      FROM returns r
      WHERE r.customerId = ? AND r.storeId = ?
      ORDER BY r.createdAt DESC
      LIMIT ? OFFSET ?
    `).all(customerId, storeId, limit, offset);

    const totalRefundedSum = db.prepare(`
      SELECT COALESCE(SUM(totalRefundAmount), 0) AS totalRefunded
      FROM returns
      WHERE customerId = ? AND storeId = ? AND status != 'CANCELLED'
    `).get(customerId, storeId).totalRefunded;

    return {
      returns: rows.map(r => ({
        ...r,
        totalRefundAmount: Number(r.totalRefundAmount),
        itemCount: Number(r.itemCount),
        totalItemsReturned: Number(r.totalItemsReturned)
      })),
      totalRefunded: Number(totalRefundedSum) || 0,
      total,
      page: Number(page),
      limit: Number(limit),
      totalPages: Math.ceil(total / limit)
    };
  },

  /**
   * Get paginated sales history for a specific customer
   */
  getCustomerSales: (customerId, storeId, { page = 1, limit = 15 } = {}) => {
    const offset = (page - 1) * limit;

    const total = db.prepare(`
      SELECT COUNT(*) AS cnt
      FROM sales
      WHERE customerId = ? AND storeId = ?
    `).get(customerId, storeId).cnt;

    const rows = db.prepare(`
      SELECT s.*,
        (SELECT COUNT(*) FROM sale_items WHERE saleId = s.id) AS itemCount,
        (SELECT COALESCE(SUM(quantity), 0) FROM sale_items WHERE saleId = s.id) AS totalQuantity
      FROM sales s
      WHERE s.customerId = ? AND s.storeId = ?
      ORDER BY s.createdAt DESC
      LIMIT ? OFFSET ?
    `).all(customerId, storeId, limit, offset);

    return {
      sales: rows,
      total,
      page: Number(page),
      limit: Number(limit),
      totalPages: Math.ceil(total / limit)
    };
  },

  /**
   * Filterable, sortable, paginated customer directory
   */
  findAll: ({ storeId, search = '', status = 'ACTIVE', sortBy = 'name', sortDir = 'ASC', page = 1, limit = 20 }) => {
    const offset = (page - 1) * limit;
    const conditions = ['storeId = ?'];
    const params = [storeId];

    // Status filter
    if (status && status !== 'ALL') {
      conditions.push('status = ?');
      params.push(status);
    }

    // Search filter
    if (search && search.trim()) {
      conditions.push('(name LIKE ? OR phone LIKE ? OR email LIKE ? OR city LIKE ?)');
      const q = `%${search.trim()}%`;
      params.push(q, q, q, q);
    }

    const where = conditions.join(' AND ');

    // Sort validation
    const allowedSorts = ['name', 'totalSpent', 'totalPurchases', 'createdAt', 'updatedAt'];
    const safeSort = allowedSorts.includes(sortBy) ? sortBy : 'name';
    const safeDir = sortDir === 'DESC' ? 'DESC' : 'ASC';

    const total = db.prepare(`SELECT COUNT(*) AS cnt FROM customers WHERE ${where}`).get(...params).cnt;

    const rows = db.prepare(`
      SELECT *
      FROM customers
      WHERE ${where}
      ORDER BY ${safeSort} ${safeDir}
      LIMIT ? OFFSET ?
    `).all(...params, limit, offset);

    return {
      customers: rows.map(r => ({
        ...r,
        active: Boolean(r.active),
        isArchived: r.status === 'ARCHIVED'
      })),
      total,
      page: Number(page),
      limit: Number(limit),
      totalPages: Math.ceil(total / limit)
    };
  }
};

module.exports = CustomerModel;
