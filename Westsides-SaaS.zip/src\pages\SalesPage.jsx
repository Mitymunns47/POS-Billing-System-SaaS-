import React, { useState, useEffect, useCallback } from 'react';
import { api } from '../services/api';
import { useAuth } from '../context/AuthContext';
import { Button } from '../components/ui/Button';
import { Input } from '../components/ui/Input';
import { Badge } from '../components/ui/Badge';
import { Alert } from '../components/ui/Alert';
import { Modal } from '../components/ui/Modal';
import {
  Receipt,
  Search,
  Filter,
  Calendar,
  IndianRupee,
  RotateCcw,
  Printer,
  ChevronLeft,
  ChevronRight,
  User,
  CreditCard,
  Smartphone,
  Banknote,
  CheckCircle2,
  XCircle,
  Clock,
  ArrowUpRight,
  FileText
} from 'lucide-react';

const fmt = (n) => Number(n || 0).toFixed(2);

export function SalesPage({ onNavigate }) {
  const { store, hasPermission } = useAuth();

  const [sales, setSales] = useState([]);
  const [pagination, setPagination] = useState({ page: 1, limit: 15, total: 0, pages: 1 });
  const [stats, setStats] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  // Filters
  const [search, setSearch] = useState('');
  const [paymentMethod, setPaymentMethod] = useState('');
  const [status, setStatus] = useState('');
  const [dateFilter, setDateFilter] = useState('all');

  // Modals
  const [selectedSale, setSelectedSale] = useState(null);
  const [saleDetails, setSaleDetails] = useState(null);
  const [loadingDetails, setLoadingDetails] = useState(false);
  const [cancellingSale, setCancellingSale] = useState(null);
  const [cancelling, setCancelling] = useState(false);
  const [cancelError, setCancelError] = useState(null);

  // Load stats
  const loadStats = useCallback(async () => {
    try {
      const res = await api.getSalesStats();
      if (res.success) {
        setStats(res.stats);
      }
    } catch (err) {
      console.error('Failed to load sales stats:', err);
    }
  }, []);

  // Compute dates based on filter
  const getDateRange = useCallback(() => {
    const now = new Date();
    if (dateFilter === 'today') {
      const todayStr = now.toISOString().split('T')[0];
      return { startDate: todayStr, endDate: todayStr };
    }
    if (dateFilter === 'yesterday') {
      const yest = new Date(now);
      yest.setDate(yest.getDate() - 1);
      const yestStr = yest.toISOString().split('T')[0];
      return { startDate: yestStr, endDate: yestStr };
    }
    if (dateFilter === 'week') {
      const weekAgo = new Date(now);
      weekAgo.setDate(weekAgo.getDate() - 7);
      return { startDate: weekAgo.toISOString().split('T')[0], endDate: now.toISOString().split('T')[0] };
    }
    if (dateFilter === 'month') {
      const monthStart = new Date(now.getFullYear(), now.getMonth(), 1);
      return { startDate: monthStart.toISOString().split('T')[0], endDate: now.toISOString().split('T')[0] };
    }
    return { startDate: null, endDate: null };
  }, [dateFilter]);

  // Load sales list
  const loadSales = useCallback(async (page = 1) => {
    setLoading(true);
    setError(null);
    try {
      const dates = getDateRange();
      const res = await api.getSales({
        page,
        limit: pagination.limit,
        search: search.trim() || undefined,
        paymentMethod: paymentMethod || undefined,
        status: status || undefined,
        startDate: dates.startDate || undefined,
        endDate: dates.endDate || undefined
      });
      if (res.success) {
        setSales(res.sales || []);
        setPagination({
          page: res.pagination?.page || 1,
          limit: res.pagination?.limit || 15,
          total: res.pagination?.total || 0,
          pages: res.pagination?.pages || 1
        });
      }
    } catch (err) {
      setError(err.message || 'Failed to load sales history.');
    } finally {
      setLoading(false);
    }
  }, [search, paymentMethod, status, dateFilter, pagination.limit, getDateRange]);

  useEffect(() => {
    loadSales(1);
    loadStats();
  }, [loadSales, loadStats]);

  // View sale details
  const handleViewSale = async (sale) => {
    setSelectedSale(sale);
    setLoadingDetails(true);
    try {
      const res = await api.getSale(sale.id);
      if (res.success) {
        setSaleDetails(res.sale);
      }
    } catch (err) {
      console.error('Failed to get sale details:', err);
      setSaleDetails(sale);
    } finally {
      setLoadingDetails(false);
    }
  };

  // Cancel sale
  const handleCancelSale = async () => {
    if (!cancellingSale) return;
    setCancelling(true);
    setCancelError(null);
    try {
      const res = await api.cancelSale(cancellingSale.id);
      if (res.success) {
        setCancellingSale(null);
        if (selectedSale?.id === cancellingSale.id) {
          setSelectedSale(null);
          setSaleDetails(null);
        }
        loadSales(pagination.page);
        loadStats();
      }
    } catch (err) {
      setCancelError(err.message || 'Failed to cancel sale.');
    } finally {
      setCancelling(false);
    }
  };

  return (
    <div style={{ maxWidth: '1400px', margin: '0 auto', display: 'flex', flexDirection: 'column', gap: '1.5rem' }}>
      {/* Top Header */}
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: '1rem' }}>
        <div>
          <h1 style={{ fontSize: '1.5rem', fontWeight: '700', color: 'var(--text-main)', margin: '0 0 4px 0', letterSpacing: '-0.02em' }}>
            Sales & Invoices
          </h1>
          <p style={{ margin: 0, color: 'var(--text-muted)', fontSize: '0.875rem' }}>
            Complete audit trail of store billing, payment tracking, and receipt reprints.
          </p>
        </div>

        <div style={{ display: 'flex', gap: '0.75rem' }}>
          <Button
            variant="outline"
            onClick={() => { loadSales(pagination.page); loadStats(); }}
            style={{ display: 'flex', alignItems: 'center', gap: '6px' }}
          >
            <RotateCcw size={15} />
            Refresh
          </Button>
          <Button
            variant="primary"
            onClick={() => onNavigate && onNavigate('/pos')}
            style={{ display: 'flex', alignItems: 'center', gap: '6px' }}
          >
            <Receipt size={16} />
            Open POS Register
          </Button>
        </div>
      </div>

      {/* Stats Cards */}
      {stats && (
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(220px, 1fr))', gap: '1rem' }}>
          <div style={{ backgroundColor: '#FFFFFF', padding: '1.25rem', borderRadius: 'var(--radius-lg)', border: '1px solid var(--border-color)', boxShadow: 'var(--shadow-sm)' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: '8px' }}>
              <span style={{ fontSize: '0.8125rem', fontWeight: '600', color: 'var(--text-muted)' }}>Today's Revenue</span>
              <div style={{ width: '32px', height: '32px', borderRadius: '8px', backgroundColor: 'rgba(126, 175, 208, 0.15)', display: 'flex', alignItems: 'center', justifyContent: 'center', color: '#7EAFD0' }}>
                <IndianRupee size={16} />
              </div>
            </div>
            <div style={{ fontSize: '1.5rem', fontWeight: '800', color: 'var(--text-main)' }}>
              ₹{fmt(stats.revenue)}
            </div>
            <div style={{ fontSize: '0.75rem', color: 'var(--text-muted)', marginTop: '4px' }}>
              {stats.salesCount} bill{stats.salesCount === 1 ? '' : 's'} completed today
            </div>
          </div>

          <div style={{ backgroundColor: '#FFFFFF', padding: '1.25rem', borderRadius: 'var(--radius-lg)', border: '1px solid var(--border-color)', boxShadow: 'var(--shadow-sm)' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: '8px' }}>
              <span style={{ fontSize: '0.8125rem', fontWeight: '600', color: 'var(--text-muted)' }}>Cash Collected</span>
              <div style={{ width: '32px', height: '32px', borderRadius: '8px', backgroundColor: 'rgba(16, 185, 129, 0.12)', display: 'flex', alignItems: 'center', justifyContent: 'center', color: '#10B981' }}>
                <Banknote size={16} />
              </div>
            </div>
            <div style={{ fontSize: '1.5rem', fontWeight: '800', color: 'var(--text-main)' }}>
              ₹{fmt(stats.byPaymentMethod?.CASH || 0)}
            </div>
            <div style={{ fontSize: '0.75rem', color: 'var(--text-muted)', marginTop: '4px' }}>
              In-drawer cash transactions
            </div>
          </div>

          <div style={{ backgroundColor: '#FFFFFF', padding: '1.25rem', borderRadius: 'var(--radius-lg)', border: '1px solid var(--border-color)', boxShadow: 'var(--shadow-sm)' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: '8px' }}>
              <span style={{ fontSize: '0.8125rem', fontWeight: '600', color: 'var(--text-muted)' }}>Digital / UPI / Card</span>
              <div style={{ width: '32px', height: '32px', borderRadius: '8px', backgroundColor: 'rgba(59, 130, 246, 0.12)', display: 'flex', alignItems: 'center', justifyContent: 'center', color: '#3B82F6' }}>
                <Smartphone size={16} />
              </div>
            </div>
            <div style={{ fontSize: '1.5rem', fontWeight: '800', color: 'var(--text-main)' }}>
              ₹{fmt((Number(stats.byPaymentMethod?.UPI || 0) + Number(stats.byPaymentMethod?.CARD || 0)))}
            </div>
            <div style={{ fontSize: '0.75rem', color: 'var(--text-muted)', marginTop: '4px' }}>
              UPI: ₹{fmt(stats.byPaymentMethod?.UPI || 0)} • Card: ₹{fmt(stats.byPaymentMethod?.CARD || 0)}
            </div>
          </div>

          <div style={{ backgroundColor: '#FFFFFF', padding: '1.25rem', borderRadius: 'var(--radius-lg)', border: '1px solid var(--border-color)', boxShadow: 'var(--shadow-sm)' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: '8px' }}>
              <span style={{ fontSize: '0.8125rem', fontWeight: '600', color: 'var(--text-muted)' }}>Avg Order Value</span>
              <div style={{ width: '32px', height: '32px', borderRadius: '8px', backgroundColor: 'rgba(245, 158, 11, 0.12)', display: 'flex', alignItems: 'center', justifyContent: 'center', color: '#F59E0B' }}>
                <ArrowUpRight size={16} />
              </div>
            </div>
            <div style={{ fontSize: '1.5rem', fontWeight: '800', color: 'var(--text-main)' }}>
              ₹{fmt(stats.averageOrderValue || 0)}
            </div>
            <div style={{ fontSize: '0.75rem', color: 'var(--text-muted)', marginTop: '4px' }}>
              Per completed bill
            </div>
          </div>
        </div>
      )}

      {/* Filters Card */}
      <div style={{ backgroundColor: '#FFFFFF', borderRadius: 'var(--radius-lg)', border: '1px solid var(--border-color)', padding: '1.25rem', boxShadow: 'var(--shadow-sm)' }}>
        <div style={{ display: 'flex', flexWrap: 'wrap', gap: '1rem', alignItems: 'center' }}>
          {/* Search */}
          <div style={{ flex: '1 1 260px', position: 'relative' }}>
            <Search size={16} style={{ position: 'absolute', left: '12px', top: '50%', transform: 'translateY(-50%)', color: 'var(--text-muted)' }} />
            <input
              type="text"
              placeholder="Search by Invoice # or Customer name / phone..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              style={{
                width: '100%',
                padding: '0.625rem 0.875rem 0.625rem 2.25rem',
                border: '1px solid var(--border-color)',
                borderRadius: 'var(--radius-md)',
                fontSize: '0.875rem',
                color: 'var(--text-main)',
                backgroundColor: 'var(--bg-page)'
              }}
            />
          </div>

          {/* Payment Method filter */}
          <div style={{ minWidth: '150px' }}>
            <select
              value={paymentMethod}
              onChange={(e) => setPaymentMethod(e.target.value)}
              style={{
                width: '100%',
                padding: '0.625rem 0.875rem',
                border: '1px solid var(--border-color)',
                borderRadius: 'var(--radius-md)',
                fontSize: '0.875rem',
                color: 'var(--text-main)',
                backgroundColor: 'var(--bg-page)'
              }}
            >
              <option value="">All Payment Modes</option>
              <option value="CASH">Cash</option>
              <option value="UPI">UPI / QR</option>
              <option value="CARD">Card</option>
            </select>
          </div>

          {/* Status filter */}
          <div style={{ minWidth: '140px' }}>
            <select
              value={status}
              onChange={(e) => setStatus(e.target.value)}
              style={{
                width: '100%',
                padding: '0.625rem 0.875rem',
                border: '1px solid var(--border-color)',
                borderRadius: 'var(--radius-md)',
                fontSize: '0.875rem',
                color: 'var(--text-main)',
                backgroundColor: 'var(--bg-page)'
              }}
            >
              <option value="">All Statuses</option>
              <option value="COMPLETED">Completed</option>
              <option value="CANCELLED">Cancelled</option>
            </select>
          </div>

          {/* Date range filter */}
          <div style={{ minWidth: '140px' }}>
            <select
              value={dateFilter}
              onChange={(e) => setDateFilter(e.target.value)}
              style={{
                width: '100%',
                padding: '0.625rem 0.875rem',
                border: '1px solid var(--border-color)',
                borderRadius: 'var(--radius-md)',
                fontSize: '0.875rem',
                color: 'var(--text-main)',
                backgroundColor: 'var(--bg-page)'
              }}
            >
              <option value="all">All Dates</option>
              <option value="today">Today</option>
              <option value="yesterday">Yesterday</option>
              <option value="week">Last 7 Days</option>
              <option value="month">This Month</option>
            </select>
          </div>

          {(search || paymentMethod || status || dateFilter !== 'all') && (
            <Button
              variant="ghost"
              size="sm"
              onClick={() => {
                setSearch('');
                setPaymentMethod('');
                setStatus('');
                setDateFilter('all');
              }}
              style={{ color: 'var(--text-muted)' }}
            >
              Reset Filters
            </Button>
          )}
        </div>
      </div>

      {error && (
        <Alert variant="danger" onClose={() => setError(null)}>
          {error}
        </Alert>
      )}

      {/* Sales Table */}
      <div style={{ backgroundColor: '#FFFFFF', borderRadius: 'var(--radius-lg)', border: '1px solid var(--border-color)', boxShadow: 'var(--shadow-sm)', overflow: 'hidden' }}>
        <div style={{ overflowX: 'auto' }}>
          <table style={{ width: '100%', borderCollapse: 'collapse', textAlign: 'left', fontSize: '0.875rem' }}>
            <thead>
              <tr style={{ backgroundColor: 'var(--bg-page)', borderBottom: '1px solid var(--border-color)' }}>
                <th style={{ padding: '0.875rem 1rem', fontWeight: '600', color: 'var(--text-muted)', fontSize: '0.75rem', textTransform: 'uppercase', letterSpacing: '0.04em' }}>Invoice #</th>
                <th style={{ padding: '0.875rem 1rem', fontWeight: '600', color: 'var(--text-muted)', fontSize: '0.75rem', textTransform: 'uppercase', letterSpacing: '0.04em' }}>Date & Time</th>
                <th style={{ padding: '0.875rem 1rem', fontWeight: '600', color: 'var(--text-muted)', fontSize: '0.75rem', textTransform: 'uppercase', letterSpacing: '0.04em' }}>Customer</th>
                <th style={{ padding: '0.875rem 1rem', fontWeight: '600', color: 'var(--text-muted)', fontSize: '0.75rem', textTransform: 'uppercase', letterSpacing: '0.04em' }}>Items</th>
                <th style={{ padding: '0.875rem 1rem', fontWeight: '600', color: 'var(--text-muted)', fontSize: '0.75rem', textTransform: 'uppercase', letterSpacing: '0.04em', textAlign: 'right' }}>Amount</th>
                <th style={{ padding: '0.875rem 1rem', fontWeight: '600', color: 'var(--text-muted)', fontSize: '0.75rem', textTransform: 'uppercase', letterSpacing: '0.04em' }}>Payment</th>
                <th style={{ padding: '0.875rem 1rem', fontWeight: '600', color: 'var(--text-muted)', fontSize: '0.75rem', textTransform: 'uppercase', letterSpacing: '0.04em' }}>Status</th>
                <th style={{ padding: '0.875rem 1rem', fontWeight: '600', color: 'var(--text-muted)', fontSize: '0.75rem', textTransform: 'uppercase', letterSpacing: '0.04em' }}>Cashier</th>
                <th style={{ padding: '0.875rem 1rem', fontWeight: '600', color: 'var(--text-muted)', fontSize: '0.75rem', textTransform: 'uppercase', letterSpacing: '0.04em', textAlign: 'right' }}>Actions</th>
              </tr>
            </thead>
            <tbody>
              {loading ? (
                <tr>
                  <td colSpan="9" style={{ padding: '3rem 1rem', textAlign: 'center', color: 'var(--text-muted)' }}>
                    <div style={{ display: 'inline-block', width: '20px', height: '20px', border: '2px solid #7EAFD0', borderTopColor: 'transparent', borderRadius: '50%', animation: 'spin 0.8s linear infinite', marginBottom: '8px' }} />
                    <div>Loading sales records...</div>
                  </td>
                </tr>
              ) : sales.length === 0 ? (
                <tr>
                  <td colSpan="9" style={{ padding: '3.5rem 1rem', textAlign: 'center' }}>
                    <div style={{ width: '48px', height: '48px', borderRadius: '50%', backgroundColor: 'var(--bg-page)', display: 'inline-flex', alignItems: 'center', justifyContent: 'center', color: 'var(--text-muted)', marginBottom: '12px' }}>
                      <FileText size={24} />
                    </div>
                    <div style={{ fontWeight: '600', color: 'var(--text-main)', marginBottom: '4px' }}>No sales recorded</div>
                    <div style={{ color: 'var(--text-muted)', fontSize: '0.8125rem', marginBottom: '1rem' }}>
                      {search || paymentMethod || status || dateFilter !== 'all'
                        ? 'Try clearing the search or filters to see more results.'
                        : 'Open the POS register to complete your first bill.'}
                    </div>
                    <Button variant="primary" size="sm" onClick={() => onNavigate && onNavigate('/pos')}>
                      Open POS Register
                    </Button>
                  </td>
                </tr>
              ) : (
                sales.map((sale) => {
                  const date = new Date(sale.createdAt);
                  const isCompleted = sale.status === 'COMPLETED';

                  return (
                    <tr key={sale.id} style={{ borderBottom: '1px solid var(--border-subtle)', transition: 'background-color 0.15s ease' }}>
                      {/* Invoice No */}
                      <td style={{ padding: '0.875rem 1rem', fontWeight: '600', color: '#172033', whiteSpace: 'nowrap' }}>
                        <span
                          onClick={() => handleViewSale(sale)}
                          style={{ cursor: 'pointer', color: '#7EAFD0', textDecoration: 'underline' }}
                        >
                          {sale.invoiceNumber}
                        </span>
                      </td>

                      {/* Date & Time */}
                      <td style={{ padding: '0.875rem 1rem', color: 'var(--text-muted)', whiteSpace: 'nowrap' }}>
                        <div>{date.toLocaleDateString('en-IN', { day: '2-digit', month: 'short', year: 'numeric' })}</div>
                        <div style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>{date.toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit' })}</div>
                      </td>

                      {/* Customer */}
                      <td style={{ padding: '0.875rem 1rem' }}>
                        {sale.customerName ? (
                          <div>
                            <div style={{ fontWeight: '500', color: 'var(--text-main)' }}>{sale.customerName}</div>
                            {sale.customerPhone && <div style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>{sale.customerPhone}</div>}
                          </div>
                        ) : (
                          <span style={{ color: 'var(--text-muted)', fontStyle: 'italic', fontSize: '0.8125rem' }}>Walk-in Customer</span>
                        )}
                      </td>

                      {/* Items */}
                      <td style={{ padding: '0.875rem 1rem', color: 'var(--text-main)' }}>
                        <span style={{ fontWeight: '500' }}>{sale.itemCount || 1}</span> item{(sale.itemCount || 1) === 1 ? '' : 's'}
                      </td>

                      {/* Total Amount */}
                      <td style={{ padding: '0.875rem 1rem', textAlign: 'right', fontWeight: '700', color: isCompleted ? 'var(--text-main)' : 'var(--text-muted)' }}>
                        <span style={{ textDecoration: isCompleted ? 'none' : 'line-through' }}>
                          ₹{fmt(sale.totalAmount)}
                        </span>
                      </td>

                      {/* Payment */}
                      <td style={{ padding: '0.875rem 1rem' }}>
                        <span style={{
                          display: 'inline-flex',
                          alignItems: 'center',
                          gap: '4px',
                          padding: '3px 8px',
                          borderRadius: 'var(--radius-sm)',
                          fontSize: '0.75rem',
                          fontWeight: '600',
                          backgroundColor: sale.paymentMethod === 'CASH' ? 'rgba(16, 185, 129, 0.1)' : sale.paymentMethod === 'UPI' ? 'rgba(59, 130, 246, 0.1)' : 'rgba(139, 92, 246, 0.1)',
                          color: sale.paymentMethod === 'CASH' ? '#10B981' : sale.paymentMethod === 'UPI' ? '#3B82F6' : '#8B5CF6'
                        }}>
                          {sale.paymentMethod === 'CASH' && <Banknote size={12} />}
                          {sale.paymentMethod === 'UPI' && <Smartphone size={12} />}
                          {sale.paymentMethod === 'CARD' && <CreditCard size={12} />}
                          {sale.paymentMethod}
                        </span>
                      </td>

                      {/* Status */}
                      <td style={{ padding: '0.875rem 1rem' }}>
                        {isCompleted ? (
                          <Badge variant="success" size="sm">Completed</Badge>
                        ) : (
                          <Badge variant="danger" size="sm">Cancelled</Badge>
                        )}
                      </td>

                      {/* Cashier */}
                      <td style={{ padding: '0.875rem 1rem', color: 'var(--text-muted)', fontSize: '0.8125rem' }}>
                        {sale.cashierName || 'Staff'}
                      </td>

                      {/* Actions */}
                      <td style={{ padding: '0.875rem 1rem', textAlign: 'right', whiteSpace: 'nowrap' }}>
                        <div style={{ display: 'inline-flex', gap: '6px' }}>
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => handleViewSale(sale)}
                            title="View & Reprint Receipt"
                            style={{ padding: '4px 8px' }}
                          >
                            <Printer size={15} />
                          </Button>
                          {isCompleted && (
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => { setCancellingSale(sale); setCancelError(null); }}
                              title="Cancel Sale & Restore Stock"
                              style={{ padding: '4px 8px', color: '#EF4444' }}
                            >
                              <RotateCcw size={15} />
                            </Button>
                          )}
                        </div>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>

        {/* Pagination Bar */}
        {pagination.pages > 1 && (
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '0.875rem 1.25rem', borderTop: '1px solid var(--border-color)', backgroundColor: 'var(--bg-page)', fontSize: '0.8125rem', color: 'var(--text-muted)' }}>
            <div>
              Showing {((pagination.page - 1) * pagination.limit) + 1} to {Math.min(pagination.page * pagination.limit, pagination.total)} of {pagination.total} sales
            </div>
            <div style={{ display: 'flex', gap: '6px' }}>
              <Button
                variant="outline"
                size="sm"
                disabled={pagination.page <= 1}
                onClick={() => loadSales(pagination.page - 1)}
              >
                <ChevronLeft size={14} /> Previous
              </Button>
              <div style={{ display: 'flex', alignItems: 'center', padding: '0 8px', fontWeight: '600', color: 'var(--text-main)' }}>
                {pagination.page} / {pagination.pages}
              </div>
              <Button
                variant="outline"
                size="sm"
                disabled={pagination.page >= pagination.pages}
                onClick={() => loadSales(pagination.page + 1)}
              >
                Next <ChevronRight size={14} />
              </Button>
            </div>
          </div>
        )}
      </div>

      {/* Invoice Receipt Modal */}
      {selectedSale && (
        <Modal
          isOpen={Boolean(selectedSale)}
          onClose={() => { setSelectedSale(null); setSaleDetails(null); }}
          title={`Invoice ${selectedSale.invoiceNumber}`}
          width="580px"
        >
          {loadingDetails ? (
            <div style={{ padding: '2rem', textAlign: 'center', color: 'var(--text-muted)' }}>
              Loading receipt details...
            </div>
          ) : (
            <div>
              <div id="sales-invoice-print" style={{ padding: '1rem', border: '1px solid var(--border-color)', borderRadius: 'var(--radius-md)', backgroundColor: '#FFFFFF', marginBottom: '1.25rem' }}>
                {/* Store Header */}
                <div style={{ textAlign: 'center', paddingBottom: '1rem', borderBottom: '1px dashed var(--border-color)', marginBottom: '1rem' }}>
                  <div style={{ fontSize: '1.25rem', fontWeight: '800', color: '#172033', letterSpacing: '-0.02em' }}>
                    {store?.name || 'Westsides'}
                  </div>
                  {store?.address && (
                    <div style={{ fontSize: '0.8125rem', color: 'var(--text-muted)', marginTop: '2px' }}>
                      {store.address}
                    </div>
                  )}
                  {store?.phone && (
                    <div style={{ fontSize: '0.8125rem', color: 'var(--text-muted)' }}>
                      Ph: {store.phone}
                    </div>
                  )}
                  {store?.gstin && (
                    <div style={{ fontSize: '0.75rem', fontWeight: '600', color: 'var(--text-main)', marginTop: '3px' }}>
                      GSTIN: {store.gstin}
                    </div>
                  )}
                </div>

                {/* Metadata */}
                <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '0.8125rem', marginBottom: '1rem' }}>
                  <div>
                    <div><strong>Invoice:</strong> {saleDetails?.invoiceNumber || selectedSale.invoiceNumber}</div>
                    <div><strong>Date:</strong> {new Date(saleDetails?.createdAt || selectedSale.createdAt).toLocaleString('en-IN')}</div>
                    <div><strong>Cashier:</strong> {saleDetails?.cashierName || selectedSale.cashierName || 'Staff'}</div>
                  </div>
                  <div style={{ textAlign: 'right' }}>
                    <div><strong>Customer:</strong> {saleDetails?.customerName || selectedSale.customerName || 'Walk-in'}</div>
                    {(saleDetails?.customerPhone || selectedSale.customerPhone) && (
                      <div><strong>Phone:</strong> {saleDetails?.customerPhone || selectedSale.customerPhone}</div>
                    )}
                    <div>
                      <strong>Status:</strong>{' '}
                      <span style={{ color: (saleDetails?.status || selectedSale.status) === 'COMPLETED' ? '#10B981' : '#EF4444', fontWeight: '700' }}>
                        {saleDetails?.status || selectedSale.status}
                      </span>
                    </div>
                  </div>
                </div>

                {/* Items Table */}
                <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: '0.8125rem', marginBottom: '1rem' }}>
                  <thead>
                    <tr style={{ borderBottom: '2px solid var(--border-color)' }}>
                      <th style={{ padding: '6px 4px', textAlign: 'left', fontWeight: '600', color: 'var(--text-muted)' }}>Item</th>
                      <th style={{ padding: '6px 4px', textAlign: 'right', fontWeight: '600', color: 'var(--text-muted)' }}>Qty</th>
                      <th style={{ padding: '6px 4px', textAlign: 'right', fontWeight: '600', color: 'var(--text-muted)' }}>Rate</th>
                      <th style={{ padding: '6px 4px', textAlign: 'right', fontWeight: '600', color: 'var(--text-muted)' }}>Amount</th>
                    </tr>
                  </thead>
                  <tbody>
                    {(saleDetails?.items || []).map((item, idx) => (
                      <tr key={idx} style={{ borderBottom: '1px solid var(--border-subtle)' }}>
                        <td style={{ padding: '6px 4px' }}>
                          <div style={{ fontWeight: '600', color: 'var(--text-main)' }}>{item.productNameSnapshot}</div>
                          <div style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>
                            {[item.sizeSnapshot, item.colorSnapshot].filter(Boolean).join(' / ')}
                            {item.skuSnapshot ? ` • ${item.skuSnapshot}` : ''}
                          </div>
                        </td>
                        <td style={{ padding: '6px 4px', textAlign: 'right', color: 'var(--text-muted)' }}>{item.quantity}</td>
                        <td style={{ padding: '6px 4px', textAlign: 'right', color: 'var(--text-main)' }}>₹{fmt(item.unitPrice)}</td>
                        <td style={{ padding: '6px 4px', textAlign: 'right', fontWeight: '600', color: 'var(--text-main)' }}>₹{fmt(item.lineTotal)}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>

                {/* Totals */}
                <div style={{ borderTop: '1px solid var(--border-color)', paddingTop: '0.75rem', display: 'flex', flexDirection: 'column', gap: '4px', alignItems: 'flex-end', fontSize: '0.8125rem' }}>
                  <div style={{ display: 'flex', gap: '1.5rem' }}>
                    <span style={{ color: 'var(--text-muted)' }}>Subtotal:</span>
                    <span style={{ fontWeight: '500', minWidth: '70px', textAlign: 'right' }}>₹{fmt(saleDetails?.subtotal || selectedSale.subtotal)}</span>
                  </div>
                  {Number(saleDetails?.discountAmount || selectedSale.discountAmount) > 0 && (
                    <div style={{ display: 'flex', gap: '1.5rem', color: '#10B981' }}>
                      <span>Discount:</span>
                      <span style={{ fontWeight: '500', minWidth: '70px', textAlign: 'right' }}>-₹{fmt(saleDetails?.discountAmount || selectedSale.discountAmount)}</span>
                    </div>
                  )}
                  {Number(saleDetails?.taxAmount || selectedSale.taxAmount) > 0 && (
                    <div style={{ display: 'flex', gap: '1.5rem' }}>
                      <span style={{ color: 'var(--text-muted)' }}>Tax ({saleDetails?.taxRate || selectedSale.taxRate}%):</span>
                      <span style={{ fontWeight: '500', minWidth: '70px', textAlign: 'right' }}>₹{fmt(saleDetails?.taxAmount || selectedSale.taxAmount)}</span>
                    </div>
                  )}
                  <div style={{ display: 'flex', gap: '1.5rem', borderTop: '2px solid var(--border-color)', paddingTop: '6px', marginTop: '4px', fontSize: '0.9375rem' }}>
                    <span style={{ fontWeight: '700' }}>Grand Total:</span>
                    <span style={{ fontWeight: '800', color: '#7EAFD0', minWidth: '70px', textAlign: 'right' }}>₹{fmt(saleDetails?.totalAmount || selectedSale.totalAmount)}</span>
                  </div>
                </div>

                {/* Payment info */}
                <div style={{ marginTop: '1rem', padding: '8px 12px', backgroundColor: 'var(--bg-page)', borderRadius: 'var(--radius-sm)', display: 'flex', justifyContent: 'space-between', fontSize: '0.8125rem' }}>
                  <div>
                    <span style={{ color: 'var(--text-muted)' }}>Payment Mode: </span>
                    <strong>{saleDetails?.paymentMethod || selectedSale.paymentMethod}</strong>
                  </div>
                  {saleDetails?.paymentMethod === 'CASH' && Number(saleDetails?.changeAmount) > 0 && (
                    <div>
                      <span style={{ color: 'var(--text-muted)' }}>Change Returned: </span>
                      <strong style={{ color: '#10B981' }}>₹{fmt(saleDetails.changeAmount)}</strong>
                    </div>
                  )}
                </div>

                {store?.receiptFooter && (
                  <div style={{ textAlign: 'center', marginTop: '1rem', paddingTop: '0.75rem', borderTop: '1px dashed var(--border-color)', fontSize: '0.75rem', color: 'var(--text-muted)', fontStyle: 'italic' }}>
                    {store.receiptFooter}
                  </div>
                )}
              </div>

              {/* Actions */}
              <div style={{ display: 'flex', justifyContent: 'space-between', gap: '0.75rem' }}>
                <Button
                  variant="outline"
                  onClick={() => { setSelectedSale(null); setSaleDetails(null); }}
                >
                  Close
                </Button>
                <div style={{ display: 'flex', gap: '0.75rem' }}>
                  <Button
                    variant="primary"
                    onClick={() => window.print()}
                    style={{ display: 'flex', alignItems: 'center', gap: '6px' }}
                  >
                    <Printer size={16} />
                    Print Receipt
                  </Button>
                </div>
              </div>
            </div>
          )}
        </Modal>
      )}

      {/* Cancel Confirmation Modal */}
      {cancellingSale && (
        <Modal
          isOpen={Boolean(cancellingSale)}
          onClose={() => { setCancellingSale(null); setCancelError(null); }}
          title="Cancel Sale & Restore Stock"
          width="480px"
        >
          <div style={{ display: 'flex', flexDirection: 'column', gap: '1rem' }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: '12px', color: '#EF4444' }}>
              <div style={{ width: '40px', height: '40px', borderRadius: '50%', backgroundColor: 'rgba(239, 68, 68, 0.1)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                <RotateCcw size={20} />
              </div>
              <div>
                <div style={{ fontWeight: '700', fontSize: '1rem', color: 'var(--text-main)' }}>
                  Cancel Bill {cancellingSale.invoiceNumber}?
                </div>
                <div style={{ fontSize: '0.8125rem', color: 'var(--text-muted)' }}>
                  Total: ₹{fmt(cancellingSale.totalAmount)} • {cancellingSale.itemCount} items
                </div>
              </div>
            </div>

            <p style={{ margin: 0, fontSize: '0.875rem', color: 'var(--text-muted)', lineHeight: '1.5' }}>
              This will mark the bill as <strong>CANCELLED</strong> and automatically return all sold items back to their product variant stock. An inventory audit log will be created. This action cannot be undone.
            </p>

            {cancelError && (
              <Alert variant="danger" onClose={() => setCancelError(null)}>
                {cancelError}
              </Alert>
            )}

            <div style={{ display: 'flex', justifyContent: 'flex-end', gap: '0.75rem', marginTop: '0.5rem' }}>
              <Button
                variant="outline"
                disabled={cancelling}
                onClick={() => { setCancellingSale(null); setCancelError(null); }}
              >
                Keep Bill
              </Button>
              <Button
                variant="danger"
                loading={cancelling}
                onClick={handleCancelSale}
              >
                Confirm Cancellation
              </Button>
            </div>
          </div>
        </Modal>
      )}

      {/* Print CSS */}
      <style>{`
        @media print {
          body * { visibility: hidden !important; }
          #sales-invoice-print, #sales-invoice-print * { visibility: visible !important; }
          #sales-invoice-print {
            position: fixed !important;
            top: 0 !important;
            left: 0 !important;
            right: 0 !important;
            width: 100% !important;
            max-width: 400px !important;
            margin: 0 auto !important;
            box-shadow: none !important;
            border: none !important;
          }
        }
      `}</style>
    </div>
  );
}
