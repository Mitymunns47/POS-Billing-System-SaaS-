const crypto = require('crypto');
const db = require('../db/database');
const { ROLES, ROLE_PERMISSIONS, ALL_PERMISSION_KEYS } = require('../constants/roles');

const UserPermissionModel = {
  /**
   * Get effective permissions for a user in a store:
   * 1. Start with base permissions from role.
   * 2. Apply any custom overrides from user_permissions table.
   * 3. If role is OWNER, ALWAYS return ALL_PERMISSION_KEYS (cannot be removed).
   */
  getUserPermissions: (storeId, userId, role) => {
    if (role === ROLES.OWNER) {
      return [...ALL_PERMISSION_KEYS];
    }

    const basePermissions = new Set(ROLE_PERMISSIONS[role] || []);

    // Fetch overrides
    const overrides = db.prepare(`
      SELECT permissionKey, allowed
      FROM user_permissions
      WHERE storeId = ? AND userId = ?
    `).all(storeId, userId);

    for (const ov of overrides) {
      if (ov.allowed === 1) {
        basePermissions.add(ov.permissionKey);
      } else {
        basePermissions.delete(ov.permissionKey);
      }
    }

    return Array.from(basePermissions);
  },

  /**
   * Get raw overrides map { [permissionKey]: boolean }
   */
  getOverrides: (storeId, userId) => {
    const rows = db.prepare(`
      SELECT permissionKey, allowed
      FROM user_permissions
      WHERE storeId = ? AND userId = ?
    `).all(storeId, userId);

    const map = {};
    for (const r of rows) {
      map[r.permissionKey] = Boolean(r.allowed);
    }
    return map;
  },

  /**
   * Set or remove an override for a user in a store
   */
  setOverride: (storeId, userId, permissionKey, allowed) => {
    const now = new Date().toISOString();
    const id = 'up_' + crypto.randomBytes(8).toString('hex');

    db.prepare(`
      INSERT INTO user_permissions (id, storeId, userId, permissionKey, allowed, updatedAt)
      VALUES (?, ?, ?, ?, ?, ?)
      ON CONFLICT(storeId, userId, permissionKey) DO UPDATE SET
        allowed = excluded.allowed,
        updatedAt = excluded.updatedAt
    `).run(id, storeId, userId, permissionKey, allowed ? 1 : 0, now);
  },

  /**
   * Bulk update overrides map { [permissionKey]: boolean }
   */
  bulkSetOverrides: (storeId, userId, overridesMap) => {
    const now = new Date().toISOString();

    for (const [key, allowed] of Object.entries(overridesMap)) {
      if (typeof allowed === 'boolean') {
        const id = 'up_' + crypto.randomBytes(8).toString('hex');
        db.prepare(`
          INSERT INTO user_permissions (id, storeId, userId, permissionKey, allowed, updatedAt)
          VALUES (?, ?, ?, ?, ?, ?)
          ON CONFLICT(storeId, userId, permissionKey) DO UPDATE SET
            allowed = excluded.allowed,
            updatedAt = excluded.updatedAt
        `).run(id, storeId, userId, key, allowed ? 1 : 0, now);
      }
    }
  },

  /**
   * Clear all custom overrides (revert to role defaults)
   */
  clearOverrides: (storeId, userId) => {
    db.prepare(`
      DELETE FROM user_permissions
      WHERE storeId = ? AND userId = ?
    `).run(storeId, userId);
  }
};

module.exports = UserPermissionModel;
