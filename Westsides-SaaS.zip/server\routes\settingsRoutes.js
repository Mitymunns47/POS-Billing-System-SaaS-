const express = require('express');
const router = express.Router();
const authMiddleware = require('../middleware/auth');
const { requirePermission } = require('../middleware/roles');
const { PERMISSIONS } = require('../constants/roles');
const SettingsModel = require('../models/settingsModel');

router.use(authMiddleware);

/**
 * GET /api/settings — Retrieve store operational settings
 */
router.get('/', requirePermission(PERMISSIONS.SETTINGS_VIEW), (req, res) => {
  try {
    const settings = SettingsModel.getSettings(req.storeId);
    res.json({ success: true, data: settings });
  } catch (err) {
    console.error('Get settings error:', err);
    res.status(500).json({ success: false, error: 'Failed to retrieve store settings.' });
  }
});

/**
 * PUT /api/settings — Update store operational settings
 */
router.put('/', requirePermission(PERMISSIONS.SETTINGS_EDIT), (req, res) => {
  try {
    const updated = SettingsModel.updateSettings(
      req.storeId,
      req.body,
      req.user.id,
      req.user.name
    );
    res.json({
      success: true,
      message: 'Store settings updated successfully.',
      data: updated
    });
  } catch (err) {
    console.error('Update settings error:', err);
    res.status(400).json({ success: false, error: err.message || 'Failed to update store settings.' });
  }
});

module.exports = router;
