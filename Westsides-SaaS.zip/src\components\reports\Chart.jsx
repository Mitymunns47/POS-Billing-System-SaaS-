import React, { useState } from 'react';
import { BarChart3 } from 'lucide-react';

const fmt = (n) => Number(n || 0).toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 });

export function SalesChart({ data = [], loading = false, height = 260, title = 'Sales Over Time' }) {
  const [hoveredIndex, setHoveredIndex] = useState(null);

  if (loading) {
    return (
      <div style={{ height: `${height}px`, display: 'flex', alignItems: 'center', justifyContent: 'center', backgroundColor: '#F8FAFC', borderRadius: 'var(--radius-md)' }}>
        <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: '8px', color: 'var(--text-muted)' }}>
          <div className="animate-spin" style={{ width: '24px', height: '24px', border: '3px solid #E2E8F0', borderTopColor: '#7EAFD0', borderRadius: '50%' }} />
          <span style={{ fontSize: '0.8125rem' }}>Loading sales trend...</span>
        </div>
      </div>
    );
  }

  if (!data || data.length === 0) {
    return (
      <div style={{ height: `${height}px`, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', backgroundColor: '#F8FAFC', borderRadius: 'var(--radius-md)', border: '1px dashed var(--border-color)', padding: '1rem' }}>
        <BarChart3 size={32} color="#94A3B8" style={{ marginBottom: '8px' }} />
        <div style={{ fontSize: '0.9375rem', fontWeight: '600', color: 'var(--text-main)' }}>No sales data yet</div>
        <div style={{ fontSize: '0.8125rem', color: 'var(--text-muted)', marginTop: '2px' }}>
          Completed store sales in this date range will automatically appear here.
        </div>
      </div>
    );
  }

  // Calculate scales
  const maxRevenue = Math.max(...data.map(d => Number(d.revenue || 0)), 100);
  const padding = { top: 20, right: 20, bottom: 35, left: 55 };
  const svgWidth = 600;
  const svgHeight = height;
  const plotWidth = svgWidth - padding.left - padding.right;
  const plotHeight = svgHeight - padding.top - padding.bottom;

  // Grid steps (4 horizontal ticks)
  const yTicks = [0, maxRevenue * 0.33, maxRevenue * 0.66, maxRevenue];

  // Coordinates
  const points = data.map((d, i) => {
    const x = padding.left + (data.length === 1 ? plotWidth / 2 : (i / (data.length - 1)) * plotWidth);
    const y = padding.top + plotHeight - ((Number(d.revenue || 0) / maxRevenue) * plotHeight);
    return { ...d, x, y };
  });

  // SVG path for line and area
  const linePath = points.map((p, i) => (i === 0 ? `M ${p.x} ${p.y}` : `L ${p.x} ${p.y}`)).join(' ');
  const areaPath = points.length > 0
    ? `${linePath} L ${points[points.length - 1].x} ${padding.top + plotHeight} L ${points[0].x} ${padding.top + plotHeight} Z`
    : '';

  const hoveredPoint = hoveredIndex !== null ? points[hoveredIndex] : null;

  return (
    <div style={{ position: 'relative', width: '100%' }}>
      <svg
        viewBox={`0 0 ${svgWidth} ${svgHeight}`}
        style={{ width: '100%', height: `${height}px`, overflow: 'visible' }}
        preserveAspectRatio="none"
      >
        <defs>
          <linearGradient id="salesGrad" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor="#7EAFD0" stopOpacity="0.28" />
            <stop offset="100%" stopColor="#7EAFD0" stopOpacity="0.0" />
          </linearGradient>
        </defs>

        {/* Horizontal grid lines & Y labels */}
        {yTicks.map((val, idx) => {
          const y = padding.top + plotHeight - ((val / maxRevenue) * plotHeight);
          return (
            <g key={idx}>
              <line
                x1={padding.left}
                y1={y}
                x2={svgWidth - padding.right}
                y2={y}
                stroke="#E2E8F0"
                strokeDasharray={idx === 0 ? 'none' : '3 3'}
                strokeWidth="1"
              />
              <text
                x={padding.left - 8}
                y={y + 4}
                textAnchor="end"
                fontSize="10"
                fill="#94A3B8"
              >
                ₹{val >= 1000 ? `${(val / 1000).toFixed(1)}k` : val.toFixed(0)}
              </text>
            </g>
          );
        })}

        {/* Area fill */}
        {areaPath && <path d={areaPath} fill="url(#salesGrad)" />}

        {/* Line path */}
        {linePath && (
          <path
            d={linePath}
            fill="none"
            stroke="#7EAFD0"
            strokeWidth="2.5"
            strokeLinecap="round"
            strokeLinejoin="round"
          />
        )}

        {/* Interactive points */}
        {points.map((p, i) => (
          <g key={i}>
            {/* Invisible larger hover zone */}
            <circle
              cx={p.x}
              cy={p.y}
              r={12}
              fill="transparent"
              style={{ cursor: 'pointer' }}
              onMouseEnter={() => setHoveredIndex(i)}
              onMouseLeave={() => setHoveredIndex(null)}
            />
            {/* Visual circle point */}
            <circle
              cx={p.x}
              cy={p.y}
              r={hoveredIndex === i ? 6 : 3.5}
              fill="#FFFFFF"
              stroke="#7EAFD0"
              strokeWidth={hoveredIndex === i ? 3 : 2}
              style={{ pointerEvents: 'none', transition: 'r 0.15s ease' }}
            />
            {/* X-axis date labels for selected intervals */}
            {(data.length <= 10 || i % Math.ceil(data.length / 7) === 0 || i === data.length - 1) && (
              <text
                x={p.x}
                y={svgHeight - 10}
                textAnchor="middle"
                fontSize="10"
                fill="#64748B"
              >
                {p.label || p.date}
              </text>
            )}
          </g>
        ))}
      </svg>

      {/* Floating Tooltip */}
      {hoveredPoint && (
        <div
          style={{
            position: 'absolute',
            left: `${(hoveredPoint.x / svgWidth) * 100}%`,
            top: `${(hoveredPoint.y / svgHeight) * 100}%`,
            transform: 'translate(-50%, -125%)',
            backgroundColor: '#172033',
            color: '#FFFFFF',
            padding: '6px 10px',
            borderRadius: '6px',
            fontSize: '0.75rem',
            whiteSpace: 'nowrap',
            boxShadow: '0 4px 12px rgba(0, 0, 0, 0.15)',
            pointerEvents: 'none',
            zIndex: 10
          }}
        >
          <div style={{ fontWeight: '600', marginBottom: '2px' }}>{hoveredPoint.date}</div>
          <div style={{ color: '#7EAFD0' }}>Sales: ₹{fmt(hoveredPoint.revenue)}</div>
          <div style={{ color: '#CBD5E1', fontSize: '0.7rem' }}>{hoveredPoint.orders} order{hoveredPoint.orders === 1 ? '' : 's'}</div>
        </div>
      )}
    </div>
  );
}
