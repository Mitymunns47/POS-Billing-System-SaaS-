import React, { useState, useEffect, useCallback } from 'react';
import { api } from '../services/api';
import { Button } from '../components/ui/Button';
import { Input } from '../components/ui/Input';
import { ChevronLeft, ChevronRight, Search, RefreshCw, History, RotateCcw } from 'lucide-react';

const ACTION_LABELS = {
  ADD_STOCK: { label: 'Add Stock', color: '#10B981', bg: '#D1FAE5' },
  REMOVE_STOCK: { label: 'Remove Stock', color: '#EF4444', bg: '#FEE2E2' },
  ADJUST_STOCK: { label: 'Set Stock', color: '#7EAFD0', bg: '#EFF6FF' },
  TRANSFER_IN: { label: 'Transfer In', color: '#10B981', bg: '#D1FAE5' },
  TRANSFER_OUT: { label: 'Transfer Out', color: '#F59E0B', bg: '#FEF3C7' },
  INITIAL_STOCK: { label: 'Initial Stock', color: '#64748B', bg: '#F1F5F9' }
};

function ActionBadge({ action }) {
  const cfg = ACTION_LABELS[action] || { label: action, color: '#64748B', bg: '#F1F5F9' };
  return (
    <span style={{
      padding: '2px 8px', borderRadius: '999px', fontSize: '0.75rem', fontWeight: '500',
      color: cfg.color, backgroundColor: cfg.bg, whiteSpace: 'nowrap'
    }}>
      {cfg.label}
    </span>
  );
}

function QuantityChange({ action, quantity, previousQty, newQty }) {
  const isPositive = ['ADD_STOCK', 'TRANSFER_IN', 'INITIAL_STOCK'].includes(action) || newQty > previousQty;
  const color = isPositive ? '#10B981' : '#EF4444';
  const sign = isPositive ? '+' : '-';
  const displayQty = action === 'ADJUST_STOCK' ? `→${newQty}` : `${sign}${quantity}`;
  return (
    <span style={{ fontWeight: '700', color, fontFamily: 'monospace', fontSize: '0.9rem' }}>{displayQty}</span>
  );
}

export function InventoryHistoryPage({ onNavigate }) {
  const [transactions, setTransactions] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  const [search, setSearch] = useState('');
  const [filterAction, setFilterAction] = useState('');
  const [filterStart, setFilterStart] = useState('');
  const [filterEnd, setFilterEnd] = useState('');
  const [page, setPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);
  const [total, setTotal] = useState(0);

  const loadData = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const res = await api.getInventoryHistory({
        performedBy: search,
        action: filterAction,
        startDate: filterStart,
        endDate: filterEnd,
        page,
        limit: 30
      });
      if (res.success) {
        setTransactions(res.transactions || []);
        setTotalPages(res.totalPages || 1);
        setTotal(res.total || 0);
      }
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  }, [search, filterAction, filterStart, filterEnd, page]);

  useEffect(() => { loadData(); }, [loadData]);

  const formatDate = (iso) => {
    if (!iso) return '—';
    const d = new Date(iso);
    return d.toLocaleString('en-IN', { day: '2-digit', month: 'short', year: 'numeric', hour: '2-digit', minute: '2-digit' });
  };

  return (
    <div style={{ maxWidth: '1200px', margin: '0 auto' }} className="animate-fade-in">
      {/* Header */}
      <div style={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', marginBottom: '1.5rem', flexWrap: 'wrap', gap: '0.75rem' }}>
        <div>
          <h1 style={{ fontSize: '1.5rem', fontWeight: '700', color: 'var(--text-main)', margin: '0 0 4px 0' }}>Inventory History</h1>
          <p style={{ fontSize: '0.875rem', color: 'var(--text-muted)', margin: 0 }}>
            Immutable audit trail of all stock movements and adjustments.
          </p>
        </div>
        <Button variant="secondary" size="md" onClick={() => onNavigate('/inventory')}>
          ← Back to Inventory
        </Button>
      </div>

      {/* Filters */}
      <div style={{ backgroundColor: '#fff', borderRadius: 'var(--radius-lg)', border: '1px solid var(--border-color)', padding: '0.875rem 1.25rem', marginBottom: '1.25rem', boxShadow: 'var(--shadow-sm)', display: 'flex', flexWrap: 'wrap', gap: '0.75rem', alignItems: 'center' }}>
        <div style={{ flex: '1 1 180px' }}>
          <Input id="hist-search" placeholder="Filter by user…" value={search} onChange={e => { setSearch(e.target.value); setPage(1); }} startIcon={<Search size={16} />} />
        </div>
        <select value={filterAction} onChange={e => { setFilterAction(e.target.value); setPage(1); }} style={{ padding: '9px 12px', borderRadius: '6px', border: '1px solid var(--border-color)', fontSize: '0.875rem', color: 'var(--text-main)', backgroundColor: '#fff', outline: 'none', minWidth: '150px' }}>
          <option value="">All Actions</option>
          {Object.entries(ACTION_LABELS).map(([k, v]) => <option key={k} value={k}>{v.label}</option>)}
        </select>
        <Input id="hist-start" type="date" label="" value={filterStart} onChange={e => { setFilterStart(e.target.value); setPage(1); }} helperText="From" />
        <Input id="hist-end" type="date" label="" value={filterEnd} onChange={e => { setFilterEnd(e.target.value); setPage(1); }} helperText="To" />
        <Button variant="ghost" size="md" onClick={() => { setSearch(''); setFilterAction(''); setFilterStart(''); setFilterEnd(''); setPage(1); }}>
          <RotateCcw size={14} style={{ marginRight: '4px' }} /> Clear
        </Button>
      </div>

      {/* Table */}
      <div style={{ backgroundColor: '#fff', borderRadius: 'var(--radius-lg)', border: '1px solid var(--border-color)', boxShadow: 'var(--shadow-sm)', overflow: 'hidden' }}>
        <div style={{ padding: '0.875rem 1.25rem', borderBottom: '1px solid var(--border-subtle)', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '6px' }}>
            <History size={14} color="#7EAFD0" />
            <span style={{ fontSize: '0.8125rem', color: 'var(--text-muted)' }}>{loading ? 'Loading…' : `${total} transaction${total !== 1 ? 's' : ''}`}</span>
          </div>
          <button onClick={loadData} style={{ background: 'none', border: 'none', cursor: 'pointer', color: 'var(--text-muted)', display: 'flex', alignItems: 'center', gap: '4px', fontSize: '0.8125rem' }}>
            <RefreshCw size={13} /> Refresh
          </button>
        </div>

        {error ? (
          <div style={{ padding: '2rem', textAlign: 'center', color: 'var(--danger)', fontSize: '0.875rem' }}>{error}</div>
        ) : loading ? (
          <div style={{ padding: '3rem', textAlign: 'center', color: 'var(--text-muted)', fontSize: '0.875rem' }}>Loading history…</div>
        ) : transactions.length === 0 ? (
          <div style={{ padding: '3rem', textAlign: 'center' }}>
            <History size={40} color="#CBD5E1" style={{ marginBottom: '0.75rem' }} />
            <p style={{ color: 'var(--text-muted)', fontSize: '0.9375rem', fontWeight: '500' }}>No transactions found</p>
            <p style={{ color: 'var(--text-light)', fontSize: '0.875rem', marginTop: '4px' }}>Inventory adjustments will appear here.</p>
          </div>
        ) : (
          <div style={{ overflowX: 'auto' }}>
            <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: '0.8125rem' }}>
              <thead>
                <tr style={{ backgroundColor: 'var(--bg-page)', borderBottom: '1px solid var(--border-color)' }}>
                  {['Date & Time', 'Product', 'Variant', 'Action', 'Change', 'Before', 'After', 'Reason', 'Performed By', 'Note'].map(h => (
                    <th key={h} style={{ padding: '9px 13px', textAlign: 'left', fontWeight: '600', color: 'var(--text-main)', whiteSpace: 'nowrap', fontSize: '0.8125rem' }}>{h}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {transactions.map((tx, idx) => (
                  <tr key={tx.id} style={{ borderBottom: idx < transactions.length - 1 ? '1px solid var(--border-subtle)' : 'none' }}>
                    <td style={{ padding: '10px 13px', whiteSpace: 'nowrap', color: 'var(--text-muted)' }}>{formatDate(tx.createdAt)}</td>
                    <td style={{ padding: '10px 13px' }}>
                      <div style={{ fontWeight: '500', color: 'var(--text-main)' }}>{tx.productName || '—'}</div>
                      <div style={{ fontSize: '0.75rem', color: 'var(--text-muted)', fontFamily: 'monospace' }}>{tx.productSku || ''}</div>
                    </td>
                    <td style={{ padding: '10px 13px', color: 'var(--text-muted)' }}>
                      {tx.variantSize || tx.variantColor ? [tx.variantSize, tx.variantColor].filter(Boolean).join('/') : '—'}
                    </td>
                    <td style={{ padding: '10px 13px' }}><ActionBadge action={tx.action} /></td>
                    <td style={{ padding: '10px 13px', textAlign: 'center' }}>
                      <QuantityChange action={tx.action} quantity={tx.quantity} previousQty={tx.previousQuantity} newQty={tx.newQuantity} />
                    </td>
                    <td style={{ padding: '10px 13px', color: 'var(--text-muted)', textAlign: 'center', fontFamily: 'monospace' }}>{tx.previousQuantity}</td>
                    <td style={{ padding: '10px 13px', color: 'var(--text-main)', textAlign: 'center', fontFamily: 'monospace', fontWeight: '600' }}>{tx.newQuantity}</td>
                    <td style={{ padding: '10px 13px', color: 'var(--text-muted)' }}>{tx.reason || '—'}</td>
                    <td style={{ padding: '10px 13px', color: 'var(--text-muted)' }}>{tx.performedBy || '—'}</td>
                    <td style={{ padding: '10px 13px', color: 'var(--text-muted)', maxWidth: '150px', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }} title={tx.note}>{tx.note || '—'}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}

        {/* Pagination */}
        {totalPages > 1 && (
          <div style={{ padding: '1rem 1.25rem', borderTop: '1px solid var(--border-subtle)', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
            <span style={{ fontSize: '0.8125rem', color: 'var(--text-muted)' }}>Page {page} of {totalPages}</span>
            <div style={{ display: 'flex', gap: '0.5rem' }}>
              <Button variant="secondary" size="sm" onClick={() => setPage(p => Math.max(1, p - 1))} disabled={page <= 1}><ChevronLeft size={14} /></Button>
              <Button variant="secondary" size="sm" onClick={() => setPage(p => Math.min(totalPages, p + 1))} disabled={page >= totalPages}><ChevronRight size={14} /></Button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
