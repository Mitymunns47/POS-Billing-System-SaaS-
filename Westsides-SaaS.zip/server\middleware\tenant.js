/**
 * Tenant Isolation Middleware
 * Prevents Store A users from accessing Store B data under any circumstance.
 */
function tenantIsolationMiddleware(req, res, next) {
  if (!req.storeId) {
    return res.status(403).json({
      success: false,
      error: 'Tenant context missing. Access denied.'
    });
  }

  // Check if storeId is explicitly passed in URL params or query or body
  const targetStoreId = req.params?.storeId || req.query?.storeId || (req.body && req.body.storeId);

  if (targetStoreId && targetStoreId !== req.storeId) {
    return res.status(403).json({
      success: false,
      error: 'Cross-tenant access prohibited. You cannot access another store’s data.',
      code: 'TENANT_ISOLATION_VIOLATION'
    });
  }

  next();
}

module.exports = tenantIsolationMiddleware;
