// Base API client
const API_BASE = '/api';

class ApiService {
  constructor() {
    this.token = localStorage.getItem('westsides_token') || null;
  }

  setToken(token) {
    this.token = token;
    if (token) {
      localStorage.setItem('westsides_token', token);
    } else {
      localStorage.removeItem('westsides_token');
    }
  }

  getToken() {
    return this.token;
  }

  async request(endpoint, options = {}) {
    const url = `${API_BASE}${endpoint}`;
    const headers = {
      'Content-Type': 'application/json',
      ...(options.headers || {})
    };

    if (this.token) {
      headers['Authorization'] = `Bearer ${this.token}`;
    }

    try {
      const response = await fetch(url, {
        ...options,
        headers,
        credentials: 'include' // include session cookies
      });

      const data = await response.json().catch(() => ({}));

      if (!response.ok) {
        const error = new Error(data.error || data.message || `Request failed with status ${response.status}`);
        error.status = response.status;
        error.data = data;
        throw error;
      }

      return data;
    } catch (err) {
      // Clean, user-friendly error formatting
      if (!err.status && err.message.includes('Failed to fetch')) {
        const networkError = new Error('Cannot connect to the Westsides SaaS server. Please check your network or server status.');
        networkError.status = 503;
        throw networkError;
      }
      throw err;
    }
  }

  // Auth Endpoints
  async login(credentials) {
    const data = await this.request('/auth/login', {
      method: 'POST',
      body: JSON.stringify(credentials)
    });
    if (data.token) {
      this.setToken(data.token);
    }
    return data;
  }

  async signup(signupData) {
    const data = await this.request('/auth/signup', {
      method: 'POST',
      body: JSON.stringify(signupData)
    });
    if (data.token) {
      this.setToken(data.token);
    }
    return data;
  }

  async getMe() {
    return this.request('/auth/me');
  }

  async logout() {
    try {
      await this.request('/auth/logout', { method: 'POST' });
    } finally {
      this.setToken(null);
    }
  }

  async forgotPassword(email) {
    return this.request('/auth/forgot-password', {
      method: 'POST',
      body: JSON.stringify({ email })
    });
  }

  async updateProfile(profileData) {
    return this.request('/auth/profile', {
      method: 'PUT',
      body: JSON.stringify(profileData)
    });
  }

  // Store Endpoints
  async getCurrentStore() {
    return this.request('/store/current');
  }

  async updateOnboarding(onboardingData) {
    return this.request('/store/onboarding', {
      method: 'POST',
      body: JSON.stringify(onboardingData)
    });
  }

  async updateStore(storeData) {
    return this.request('/store/update', {
      method: 'PUT',
      body: JSON.stringify(storeData)
    });
  }

  async testTenantIsolation(targetStoreId) {
    return this.request('/store/test-isolation', {
      method: 'POST',
      body: JSON.stringify({ targetStoreId })
    });
  }

  // ── CATALOG: Categories & Brands ────────────────────────────────────────────
  async getCategories() { return this.request('/catalog/categories'); }
  async createCategory(data) { return this.request('/catalog/categories', { method: 'POST', body: JSON.stringify(data) }); }
  async updateCategory(id, data) { return this.request(`/catalog/categories/${id}`, { method: 'PUT', body: JSON.stringify(data) }); }
  async deleteCategory(id) { return this.request(`/catalog/categories/${id}`, { method: 'DELETE' }); }

  async getBrands() { return this.request('/catalog/brands'); }
  async createBrand(data) { return this.request('/catalog/brands', { method: 'POST', body: JSON.stringify(data) }); }
  async updateBrand(id, data) { return this.request(`/catalog/brands/${id}`, { method: 'PUT', body: JSON.stringify(data) }); }
  async deleteBrand(id) { return this.request(`/catalog/brands/${id}`, { method: 'DELETE' }); }

  // ── Products ─────────────────────────────────────────────────────────────────
  async getProducts(params = {}) {
    const qs = new URLSearchParams(Object.entries(params).filter(([, v]) => v !== '' && v !== null && v !== undefined)).toString();
    return this.request(`/products${qs ? '?' + qs : ''}`);
  }
  async getProductStats() { return this.request('/products/stats'); }
  async getProduct(id) { return this.request(`/products/${id}`); }
  async createProduct(data) { return this.request('/products', { method: 'POST', body: JSON.stringify(data) }); }
  async updateProduct(id, data) { return this.request(`/products/${id}`, { method: 'PUT', body: JSON.stringify(data) }); }
  async deleteProduct(id) { return this.request(`/products/${id}`, { method: 'DELETE' }); }

  // ── Variants ─────────────────────────────────────────────────────────────────
  async getVariants(productId) { return this.request(`/products/${productId}/variants`); }
  async createVariant(productId, data) { return this.request(`/products/${productId}/variants`, { method: 'POST', body: JSON.stringify(data) }); }
  async updateVariant(productId, variantId, data) { return this.request(`/products/${productId}/variants/${variantId}`, { method: 'PUT', body: JSON.stringify(data) }); }
  async deleteVariant(productId, variantId) { return this.request(`/products/${productId}/variants/${variantId}`, { method: 'DELETE' }); }

  // ── Inventory ────────────────────────────────────────────────────────────────
  async getInventory(params = {}) {
    const qs = new URLSearchParams(Object.entries(params).filter(([, v]) => v !== '' && v !== null && v !== undefined)).toString();
    return this.request(`/inventory${qs ? '?' + qs : ''}`);
  }
  async getInventoryStats() { return this.request('/inventory/stats'); }
  async adjustStock(data) { return this.request('/inventory/adjust', { method: 'POST', body: JSON.stringify(data) }); }
  async getInventoryHistory(params = {}) {
    const qs = new URLSearchParams(Object.entries(params).filter(([, v]) => v !== '' && v !== null && v !== undefined)).toString();
    return this.request(`/inventory/history${qs ? '?' + qs : ''}`);
  }

  // ── Phase 3: Customers ────────────────────────────────────────────────────────
  async searchCustomers(q) { return this.request(`/customers/search?q=${encodeURIComponent(q || '')}`); }
  async getCustomers(params = {}) {
    const qs = new URLSearchParams(Object.entries(params).filter(([, v]) => v !== '' && v !== null && v !== undefined)).toString();
    return this.request(`/customers${qs ? '?' + qs : ''}`);
  }
  async getCustomer(id) { return this.request(`/customers/${id}`); }
  async createCustomer(data) { return this.request('/customers', { method: 'POST', body: JSON.stringify(data) }); }
  async updateCustomer(id, data) { return this.request(`/customers/${id}`, { method: 'PUT', body: JSON.stringify(data) }); }
  async archiveCustomer(id) { return this.request(`/customers/${id}/archive`, { method: 'PATCH' }); }
  async restoreCustomer(id) { return this.request(`/customers/${id}/restore`, { method: 'PATCH' }); }
  async getCustomerSales(id, params = {}) {
    const qs = new URLSearchParams(Object.entries(params).filter(([, v]) => v !== '' && v !== null && v !== undefined)).toString();
    return this.request(`/customers/${id}/sales${qs ? '?' + qs : ''}`);
  }

  // ── Phase 3: POS ──────────────────────────────────────────────────────────────
  async posSearch(q) { return this.request(`/pos/search?q=${encodeURIComponent(q || '')}`); }
  async posBarcode(code) { return this.request(`/pos/barcode/${encodeURIComponent(code)}`); }
  async getTaxSettings() { return this.request('/pos/tax-settings'); }
  async updateTaxSettings(data) { return this.request('/pos/tax-settings', { method: 'PUT', body: JSON.stringify(data) }); }

  // ── Phase 3: Sales ────────────────────────────────────────────────────────────
  async completeSale(data) { return this.request('/pos/sales', { method: 'POST', body: JSON.stringify(data) }); }
  async getSales(params = {}) {
    const qs = new URLSearchParams(Object.entries(params).filter(([, v]) => v !== '' && v !== null && v !== undefined)).toString();
    return this.request(`/pos/sales${qs ? '?' + qs : ''}`);
  }
  async getSale(id) { return this.request(`/pos/sales/${id}`); }
  async getSalesStats() { return this.request('/pos/sales/stats'); }
  async cancelSale(id) { return this.request(`/pos/sales/${id}/cancel`, { method: 'POST' }); }

  // ── Phase 4: Staff Management ────────────────────────────────────────────────
  async getStaffList(params = {}) {
    const qs = new URLSearchParams(Object.entries(params).filter(([, v]) => v !== '' && v !== null && v !== undefined)).toString();
    return this.request(`/staff${qs ? '?' + qs : ''}`);
  }
  async getStaff(id) { return this.request(`/staff/${id}`); }
  async createStaff(data) { return this.request('/staff', { method: 'POST', body: JSON.stringify(data) }); }
  async updateStaff(id, data) { return this.request(`/staff/${id}`, { method: 'PUT', body: JSON.stringify(data) }); }
  async updateStaffRole(id, role) { return this.request(`/staff/${id}/role`, { method: 'PATCH', body: JSON.stringify({ role }) }); }
  async updateStaffStatus(id, status) { return this.request(`/staff/${id}/status`, { method: 'PATCH', body: JSON.stringify({ status }) }); }
  async resetStaffPassword(id, newPassword) { return this.request(`/staff/${id}/reset-password`, { method: 'POST', body: JSON.stringify({ newPassword }) }); }
  async deleteStaff(id) { return this.request(`/staff/${id}`, { method: 'DELETE' }); }

  // ── Phase 4: Permissions ─────────────────────────────────────────────────────
  async getStaffPermissionsCatalog() { return this.request('/staff/permissions/catalog'); }
  async getStaffPermissions(id) { return this.request(`/staff/${id}/permissions`); }
  async updateStaffPermissions(id, overrides) { return this.request(`/staff/${id}/permissions`, { method: 'PUT', body: JSON.stringify({ overrides }) }); }

  // ── Phase 4: Activity & Attendance ───────────────────────────────────────────
  async getStaffActivity(params = {}) {
    const qs = new URLSearchParams(Object.entries(params).filter(([, v]) => v !== '' && v !== null && v !== undefined)).toString();
    return this.request(`/staff/activity${qs ? '?' + qs : ''}`);
  }
  async getAttendance(params = {}) {
    const qs = new URLSearchParams(Object.entries(params).filter(([, v]) => v !== '' && v !== null && v !== undefined)).toString();
    return this.request(`/staff/attendance${qs ? '?' + qs : ''}`);
  }
  async recordAttendance(data) { return this.request('/staff/attendance', { method: 'POST', body: JSON.stringify(data) }); }

  // ── Phase 5: Business Intelligence & Reports ──────────────────────────────────
  async getDashboardReport(params = {}) {
    const qs = new URLSearchParams(Object.entries(params).filter(([, v]) => v !== '' && v !== null && v !== undefined)).toString();
    return this.request(`/reports/dashboard${qs ? '?' + qs : ''}`);
  }
  async getSalesReport(params = {}) {
    const qs = new URLSearchParams(Object.entries(params).filter(([, v]) => v !== '' && v !== null && v !== undefined)).toString();
    return this.request(`/reports/sales${qs ? '?' + qs : ''}`);
  }
  async getProductsReport(params = {}) {
    const qs = new URLSearchParams(Object.entries(params).filter(([, v]) => v !== '' && v !== null && v !== undefined)).toString();
    return this.request(`/reports/products${qs ? '?' + qs : ''}`);
  }
  async getInventoryReport(params = {}) {
    const qs = new URLSearchParams(Object.entries(params).filter(([, v]) => v !== '' && v !== null && v !== undefined)).toString();
    return this.request(`/reports/inventory${qs ? '?' + qs : ''}`);
  }
  async getCustomersReport(params = {}) {
    const qs = new URLSearchParams(Object.entries(params).filter(([, v]) => v !== '' && v !== null && v !== undefined)).toString();
    return this.request(`/reports/customers${qs ? '?' + qs : ''}`);
  }
  async getStaffPerformanceReport(params = {}) {
    const qs = new URLSearchParams(Object.entries(params).filter(([, v]) => v !== '' && v !== null && v !== undefined)).toString();
    return this.request(`/reports/staff${qs ? '?' + qs : ''}`);
  }
  async getFinanceReport(params = {}) {
    const qs = new URLSearchParams(Object.entries(params).filter(([, v]) => v !== '' && v !== null && v !== undefined)).toString();
    return this.request(`/reports/finance${qs ? '?' + qs : ''}`);
  }
  getExportUrl(type, params = {}) {
    const qs = new URLSearchParams(Object.entries(params).filter(([, v]) => v !== '' && v !== null && v !== undefined)).toString();
    return `${this.baseUrl}/reports/export/${type}${qs ? '?' + qs : ''}`;
  }

  // ── Phase 5: Expenses ─────────────────────────────────────────────────────────
  async getExpenses(params = {}) {
    const qs = new URLSearchParams(Object.entries(params).filter(([, v]) => v !== '' && v !== null && v !== undefined)).toString();
    return this.request(`/expenses${qs ? '?' + qs : ''}`);
  }
  async getExpenseSummary(params = {}) {
    const qs = new URLSearchParams(Object.entries(params).filter(([, v]) => v !== '' && v !== null && v !== undefined)).toString();
    return this.request(`/expenses/summary${qs ? '?' + qs : ''}`);
  }
  async createExpense(data) { return this.request('/expenses', { method: 'POST', body: JSON.stringify(data) }); }
  async updateExpense(id, data) { return this.request(`/expenses/${id}`, { method: 'PUT', body: JSON.stringify(data) }); }
  async archiveExpense(id) { return this.request(`/expenses/${id}/archive`, { method: 'PATCH' }); }
  async restoreExpense(id) { return this.request(`/expenses/${id}/restore`, { method: 'PATCH' }); }

  // ── Phase 6: Customer Returns ────────────────────────────────────────────────
  async getCustomerReturns(id, params = {}) {
    const qs = new URLSearchParams(Object.entries(params).filter(([, v]) => v !== '' && v !== null && v !== undefined)).toString();
    return this.request(`/customers/${id}/returns${qs ? '?' + qs : ''}`);
  }

  // ── Phase 6: Sales Returns & Refunds ──────────────────────────────────────────
  async getReturns(params = {}) {
    const qs = new URLSearchParams(Object.entries(params).filter(([, v]) => v !== '' && v !== null && v !== undefined)).toString();
    return this.request(`/returns${qs ? '?' + qs : ''}`);
  }
  async getReturnableSales(params = {}) {
    const qs = new URLSearchParams(Object.entries(params).filter(([, v]) => v !== '' && v !== null && v !== undefined)).toString();
    return this.request(`/returns/sales${qs ? '?' + qs : ''}`);
  }
  async getSaleReturnDetails(saleId) { return this.request(`/returns/sale/${saleId}`); }
  async getReturn(id) { return this.request(`/returns/${id}`); }
  async createReturn(data) { return this.request('/returns', { method: 'POST', body: JSON.stringify(data) }); }

  // ── Phase 6: Store Settings & Operational Controls ───────────────────────────
  async getSettings() { return this.request('/settings'); }
  async updateSettings(data) { return this.request('/settings', { method: 'PUT', body: JSON.stringify(data) }); }

  // ── Phase 6: Notification & Alert Center ─────────────────────────────────────
  async getNotifications(params = {}) {
    const qs = new URLSearchParams(Object.entries(params).filter(([, v]) => v !== '' && v !== null && v !== undefined)).toString();
    return this.request(`/notifications${qs ? '?' + qs : ''}`);
  }
  async getUnreadNotificationCount() { return this.request('/notifications/unread-count'); }
  async markNotificationRead(id) { return this.request(`/notifications/${id}/read`, { method: 'PATCH' }); }
  async markAllNotificationsRead() { return this.request('/notifications/read-all', { method: 'POST' }); }

  // ── Phase 7: Platform Admin (SUPER_ADMIN only) ─────────────────────────────
  async adminLogin(credentials) { return this.request('/auth/admin-login', { method: 'POST', body: JSON.stringify(credentials) }); }
  async adminGetMe() { return this.request('/admin/me'); }
  async adminGetDashboard() { return this.request('/admin/dashboard'); }

  async adminListStores(params = {}) {
    const qs = new URLSearchParams(Object.entries(params).filter(([,v]) => v !== '' && v !== null && v !== undefined)).toString();
    return this.request(`/admin/stores${qs ? '?' + qs : ''}`);
  }
  async adminGetStore(storeId) { return this.request(`/admin/stores/${storeId}`); }
  async adminSuspendStore(storeId, reason) { return this.request(`/admin/stores/${storeId}/suspend`, { method: 'POST', body: JSON.stringify({ reason }) }); }
  async adminReactivateStore(storeId) { return this.request(`/admin/stores/${storeId}/reactivate`, { method: 'POST' }); }
  async adminChangePlan(storeId, planId) { return this.request(`/admin/stores/${storeId}/change-plan`, { method: 'POST', body: JSON.stringify({ planId }) }); }
  async adminGenerateInvoice(storeId) { return this.request(`/admin/stores/${storeId}/generate-invoice`, { method: 'POST' }); }

  async adminListPlans() { return this.request('/admin/plans'); }
  async adminUpdatePlan(planId, data) { return this.request(`/admin/plans/${planId}`, { method: 'PUT', body: JSON.stringify(data) }); }

  async adminListInvoices(params = {}) {
    const qs = new URLSearchParams(Object.entries(params).filter(([,v]) => v !== '' && v !== null && v !== undefined)).toString();
    return this.request(`/admin/invoices${qs ? '?' + qs : ''}`);
  }
  async adminMarkInvoicePaid(invoiceId) { return this.request(`/admin/invoices/${invoiceId}/mark-paid`, { method: 'POST' }); }

  async adminGetAnalytics() { return this.request('/admin/analytics'); }

  async adminGetAuditLog(params = {}) {
    const qs = new URLSearchParams(Object.entries(params).filter(([,v]) => v !== '' && v !== null && v !== undefined)).toString();
    return this.request(`/admin/audit${qs ? '?' + qs : ''}`);
  }

  async adminGetSettings() { return this.request('/admin/settings'); }
  async adminUpdateSettings(settings) { return this.request('/admin/settings', { method: 'PUT', body: JSON.stringify({ settings }) }); }
}

export const api = new ApiService();


