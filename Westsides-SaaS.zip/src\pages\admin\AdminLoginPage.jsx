/**
 * AdminLoginPage.jsx — Phase 7
 * Platform Super Admin Login.
 * Visually distinct from the store login page.
 */
import React, { useState } from 'react';
import { useAdminAuth } from '../../context/AdminAuthContext';

export function AdminLoginPage({ onNavigate }) {
  const { adminLogin } = useAdminAuth();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');
    setLoading(true);
    try {
      const result = await adminLogin({ email: email.trim(), password });
      if (result.success) {
        onNavigate('/admin/dashboard');
      } else {
        setError(result.error || 'Login failed.');
      }
    } catch (err) {
      setError(err.message || 'Authentication failed. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div style={{
      minHeight: '100vh',
      backgroundColor: '#0F172A',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      padding: '2rem',
      fontFamily: "'Inter', 'Segoe UI', sans-serif",
      backgroundImage: 'radial-gradient(ellipse at 30% 50%, rgba(126,175,208,0.08) 0%, transparent 60%), radial-gradient(ellipse at 70% 20%, rgba(126,175,208,0.05) 0%, transparent 50%)'
    }}>
      <div style={{ width: '100%', maxWidth: '400px' }}>
        {/* Header */}
        <div style={{ textAlign: 'center', marginBottom: '2.5rem' }}>
          <div style={{
            width: '52px', height: '52px', borderRadius: '14px',
            background: 'linear-gradient(135deg, #7EAFD0, #5B91B8)',
            display: 'flex', alignItems: 'center', justifyContent: 'center',
            margin: '0 auto 1rem',
            boxShadow: '0 0 0 1px rgba(126,175,208,0.3), 0 8px 24px rgba(126,175,208,0.2)'
          }}>
            <span style={{ color: '#fff', fontWeight: '800', fontSize: '1.5rem' }}>W</span>
          </div>
          <h1 style={{ color: '#F1F5F9', fontSize: '1.5rem', fontWeight: '700', margin: '0 0 0.25rem' }}>
            Platform Administration
          </h1>
          <p style={{ color: '#64748B', fontSize: '0.875rem', margin: 0 }}>
            Westsides SaaS — Super Admin Portal
          </p>
        </div>

        {/* Form Card */}
        <div style={{
          background: 'rgba(30, 41, 59, 0.8)',
          border: '1px solid rgba(126,175,208,0.15)',
          borderRadius: '16px',
          padding: '2rem',
          backdropFilter: 'blur(10px)'
        }}>
          {error && (
            <div style={{
              background: 'rgba(239,68,68,0.1)', border: '1px solid rgba(239,68,68,0.3)',
              borderRadius: '8px', padding: '0.75rem 1rem', marginBottom: '1.5rem',
              color: '#FCA5A5', fontSize: '0.875rem'
            }}>
              {error}
            </div>
          )}

          <div style={{
            background: 'rgba(126,175,208,0.07)', border: '1px solid rgba(126,175,208,0.15)',
            borderRadius: '8px', padding: '0.75rem 1rem', marginBottom: '1.5rem',
            display: 'flex', alignItems: 'flex-start', gap: '0.5rem'
          }}>
            <span style={{ color: '#7EAFD0', flexShrink: 0, marginTop: '1px' }}>🔐</span>
            <p style={{ color: '#94A3B8', fontSize: '0.8125rem', margin: 0, lineHeight: '1.5' }}>
              This portal is restricted to Westsides Platform Super Administrators only.
            </p>
          </div>

          <form onSubmit={handleSubmit}>
            <div style={{ marginBottom: '1rem' }}>
              <label style={{ display: 'block', color: '#CBD5E1', fontSize: '0.875rem', fontWeight: '500', marginBottom: '0.5rem' }}>
                Admin Email
              </label>
              <input
                id="admin-email"
                type="email"
                value={email}
                onChange={e => setEmail(e.target.value)}
                required
                placeholder="superadmin@westsides.com"
                style={{
                  width: '100%', boxSizing: 'border-box',
                  padding: '0.75rem 1rem',
                  background: 'rgba(15,23,42,0.8)',
                  border: '1px solid rgba(126,175,208,0.2)',
                  borderRadius: '8px', color: '#F1F5F9',
                  fontSize: '0.9375rem', outline: 'none'
                }}
              />
            </div>

            <div style={{ marginBottom: '1.5rem' }}>
              <label style={{ display: 'block', color: '#CBD5E1', fontSize: '0.875rem', fontWeight: '500', marginBottom: '0.5rem' }}>
                Password
              </label>
              <div style={{ position: 'relative' }}>
                <input
                  id="admin-password"
                  type={showPassword ? 'text' : 'password'}
                  value={password}
                  onChange={e => setPassword(e.target.value)}
                  required
                  placeholder="••••••••••••"
                  style={{
                    width: '100%', boxSizing: 'border-box',
                    padding: '0.75rem 3rem 0.75rem 1rem',
                    background: 'rgba(15,23,42,0.8)',
                    border: '1px solid rgba(126,175,208,0.2)',
                    borderRadius: '8px', color: '#F1F5F9',
                    fontSize: '0.9375rem', outline: 'none'
                  }}
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(p => !p)}
                  style={{
                    position: 'absolute', right: '0.75rem', top: '50%', transform: 'translateY(-50%)',
                    background: 'none', border: 'none', cursor: 'pointer',
                    color: '#64748B', fontSize: '1rem', padding: '0.25rem'
                  }}
                >
                  {showPassword ? '🙈' : '👁️'}
                </button>
              </div>
            </div>

            <button
              id="admin-login-btn"
              type="submit"
              disabled={loading}
              style={{
                width: '100%', padding: '0.875rem',
                background: loading ? 'rgba(126,175,208,0.4)' : 'linear-gradient(135deg, #7EAFD0, #5B91B8)',
                border: 'none', borderRadius: '10px',
                color: '#fff', fontSize: '0.9375rem', fontWeight: '600',
                cursor: loading ? 'not-allowed' : 'pointer',
                transition: 'all 0.2s',
                boxShadow: loading ? 'none' : '0 4px 14px rgba(126,175,208,0.3)'
              }}
            >
              {loading ? 'Authenticating...' : 'Access Platform Admin'}
            </button>
          </form>

          <div style={{ marginTop: '1.5rem', textAlign: 'center' }}>
            <button
              onClick={() => onNavigate('/login')}
              style={{ background: 'none', border: 'none', color: '#64748B', fontSize: '0.8125rem', cursor: 'pointer' }}
            >
              ← Back to Store Login
            </button>
          </div>
        </div>

        <p style={{ textAlign: 'center', color: '#334155', fontSize: '0.75rem', marginTop: '1.5rem' }}>
          Westsides Platform Administration © {new Date().getFullYear()}
        </p>
      </div>
    </div>
  );
}
