import React, { useState } from 'react';
import { Calendar, ChevronDown } from 'lucide-react';
import { Button } from '../ui/Button';

export const PRESET_RANGES = [
  { id: 'today', label: 'Today' },
  { id: 'yesterday', label: 'Yesterday' },
  { id: 'last7days', label: 'Last 7 Days' },
  { id: 'last30days', label: 'Last 30 Days' },
  { id: 'thismonth', label: 'This Month' },
  { id: 'lastmonth', label: 'Last Month' },
  { id: 'thisyear', label: 'This Year' },
  { id: 'custom', label: 'Custom Range' }
];

export function DateRangePicker({
  range = 'last30days',
  startDate = '',
  endDate = '',
  onChange
}) {
  const [showCustom, setShowCustom] = useState(range === 'custom');
  const [customStart, setCustomStart] = useState(startDate);
  const [customEnd, setCustomEnd] = useState(endDate);
  const [customError, setCustomError] = useState('');

  const handleSelectPreset = (presetId) => {
    if (presetId === 'custom') {
      setShowCustom(true);
      return;
    }
    setShowCustom(false);
    setCustomError('');
    if (onChange) {
      onChange({ range: presetId, startDate: '', endDate: '' });
    }
  };

  const handleApplyCustom = (e) => {
    e.preventDefault();
    if (!customStart || !customEnd) {
      setCustomError('Both start and end dates are required.');
      return;
    }
    if (new Date(customStart) > new Date(customEnd)) {
      setCustomError('Start date must be on or before end date.');
      return;
    }
    setCustomError('');
    if (onChange) {
      onChange({ range: 'custom', startDate: customStart, endDate: customEnd });
    }
  };

  const currentLabel = PRESET_RANGES.find(r => r.id === range)?.label || 'Select Period';

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: '6px', flexWrap: 'wrap' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: '6px', backgroundColor: '#FFFFFF', border: '1px solid var(--border-color)', borderRadius: 'var(--radius-md)', padding: '4px' }}>
          <div style={{ padding: '4px 8px', display: 'flex', alignItems: 'center', gap: '6px', color: 'var(--text-muted)', fontSize: '0.8125rem' }}>
            <Calendar size={15} color="#7EAFD0" />
            <span style={{ fontWeight: '500' }}>Period:</span>
          </div>
          {PRESET_RANGES.filter(p => p.id !== 'custom').map(p => {
            const isSelected = range === p.id && !showCustom;
            return (
              <button
                key={p.id}
                type="button"
                onClick={() => handleSelectPreset(p.id)}
                style={{
                  padding: '5px 10px',
                  borderRadius: '6px',
                  fontSize: '0.8125rem',
                  fontWeight: isSelected ? '600' : '500',
                  border: 'none',
                  cursor: 'pointer',
                  backgroundColor: isSelected ? '#7EAFD0' : 'transparent',
                  color: isSelected ? '#FFFFFF' : 'var(--text-main)',
                  transition: 'background-color 0.15s ease'
                }}
              >
                {p.label}
              </button>
            );
          })}
          <button
            type="button"
            onClick={() => handleSelectPreset('custom')}
            style={{
              padding: '5px 10px',
              borderRadius: '6px',
              fontSize: '0.8125rem',
              fontWeight: (range === 'custom' || showCustom) ? '600' : '500',
              border: 'none',
              cursor: 'pointer',
              backgroundColor: (range === 'custom' || showCustom) ? '#7EAFD0' : 'transparent',
              color: (range === 'custom' || showCustom) ? '#FFFFFF' : 'var(--text-main)',
              transition: 'background-color 0.15s ease'
            }}
          >
            Custom
          </button>
        </div>
      </div>

      {showCustom && (
        <form onSubmit={handleApplyCustom} style={{ display: 'flex', alignItems: 'center', gap: '8px', flexWrap: 'wrap', backgroundColor: '#FFFFFF', border: '1px solid var(--border-color)', borderRadius: 'var(--radius-md)', padding: '8px 12px', boxShadow: 'var(--shadow-sm)' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '6px' }}>
            <label style={{ fontSize: '0.8125rem', color: 'var(--text-muted)' }}>From:</label>
            <input
              type="date"
              value={customStart}
              onChange={(e) => setCustomStart(e.target.value)}
              style={{
                padding: '4px 8px',
                borderRadius: '6px',
                border: '1px solid var(--border-color)',
                fontSize: '0.8125rem',
                color: 'var(--text-main)'
              }}
              required
            />
          </div>
          <div style={{ display: 'flex', alignItems: 'center', gap: '6px' }}>
            <label style={{ fontSize: '0.8125rem', color: 'var(--text-muted)' }}>To:</label>
            <input
              type="date"
              value={customEnd}
              onChange={(e) => setCustomEnd(e.target.value)}
              style={{
                padding: '4px 8px',
                borderRadius: '6px',
                border: '1px solid var(--border-color)',
                fontSize: '0.8125rem',
                color: 'var(--text-main)'
              }}
              required
            />
          </div>
          <Button type="submit" variant="primary" size="sm">
            Apply Custom Range
          </Button>
          {customError && (
            <span style={{ fontSize: '0.75rem', color: '#DC2626', marginLeft: '4px' }}>
              {customError}
            </span>
          )}
        </form>
      )}
    </div>
  );
}
