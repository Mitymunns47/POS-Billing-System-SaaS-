import React, { useState, useEffect, useCallback } from 'react';
import { api } from '../services/api';
import { useAuth } from '../context/AuthContext';
import { Button } from '../components/ui/Button';
import { Alert } from '../components/ui/Alert';
import { Badge } from '../components/ui/Badge';
import {
  ArrowLeft,
  ShieldCheck,
  RotateCcw,
  Save,
  CheckCircle2,
  Lock,
  Sliders,
  Info
} from 'lucide-react';

export function StaffPermissionsPage({ staffId, onNavigate }) {
  const { role: currentRole } = useAuth();

  const [staff, setStaff] = useState(null);
  const [catalog, setCatalog] = useState([]);
  const [effectivePermissions, setEffectivePermissions] = useState([]);
  const [overrides, setOverrides] = useState({});
  const [isOwner, setIsOwner] = useState(false);

  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState(null);
  const [successMsg, setSuccessMsg] = useState(null);

  // Load Permissions
  const loadData = useCallback(async () => {
    if (!staffId) return;
    setLoading(true);
    setError(null);
    try {
      const res = await api.getStaffPermissions(staffId);
      if (res.success) {
        setStaff(res.staff);
        setCatalog(res.catalog || []);
        setEffectivePermissions(res.effectivePermissions || []);
        setOverrides(res.overrides || {});
        setIsOwner(res.isOwner);
      }
    } catch (err) {
      setError(err.message || 'Failed to load permissions.');
    } finally {
      setLoading(false);
    }
  }, [staffId]);

  useEffect(() => {
    loadData();
  }, [loadData]);

  // Toggle permission
  const handleToggle = (permKey) => {
    if (isOwner) return; // Owner cannot be modified

    const currentlyAllowed = effectivePermissions.includes(permKey);
    const newAllowed = !currentlyAllowed;

    // Update local effective set
    setEffectivePermissions((prev) => {
      const s = new Set(prev);
      if (newAllowed) s.add(permKey);
      else s.delete(permKey);
      return Array.from(s);
    });

    // Record override
    setOverrides((prev) => ({
      ...prev,
      [permKey]: newAllowed
    }));
  };

  // Save overrides
  const handleSave = async () => {
    setSaving(true);
    setError(null);
    try {
      const res = await api.updateStaffPermissions(staffId, overrides);
      if (res.success) {
        setEffectivePermissions(res.effectivePermissions);
        setOverrides(res.overrides);
        setSuccessMsg(`Permissions updated successfully for ${staff?.name}.`);
      }
    } catch (err) {
      setError(err.message || 'Failed to update permissions.');
    } finally {
      setSaving(false);
    }
  };

  if (loading) {
    return (
      <div style={{ padding: '3rem 1rem', textAlign: 'center', color: 'var(--text-muted)' }}>
        <div style={{ display: 'inline-block', width: '24px', height: '24px', border: '2px solid #7EAFD0', borderTopColor: 'transparent', borderRadius: '50%', animation: 'spin 0.8s linear infinite', marginBottom: '8px' }} />
        <div>Loading permissions matrix...</div>
      </div>
    );
  }

  if (error && !staff) {
    return (
      <div style={{ maxWidth: '800px', margin: '0 auto', display: 'flex', flexDirection: 'column', gap: '1rem' }}>
        <Button variant="ghost" onClick={() => onNavigate('/staff')} style={{ alignSelf: 'flex-start' }}>
          <ArrowLeft size={16} style={{ marginRight: '6px' }} /> Back to Staff Directory
        </Button>
        <Alert variant="danger">{error}</Alert>
      </div>
    );
  }

  return (
    <div style={{ maxWidth: '1100px', margin: '0 auto', display: 'flex', flexDirection: 'column', gap: '1.5rem' }}>
      {/* Header Bar */}
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: '1rem' }}>
        <Button
          variant="outline"
          size="sm"
          onClick={() => onNavigate('/staff')}
          style={{ display: 'flex', alignItems: 'center', gap: '6px' }}
        >
          <ArrowLeft size={15} />
          Back to Staff Directory
        </Button>

        {!isOwner && (
          <div style={{ display: 'flex', gap: '0.75rem' }}>
            <Button
              variant="outline"
              size="sm"
              onClick={loadData}
              disabled={saving}
              style={{ display: 'flex', alignItems: 'center', gap: '6px' }}
            >
              <RotateCcw size={14} />
              Reset Changes
            </Button>
            <Button
              variant="primary"
              size="sm"
              loading={saving}
              onClick={handleSave}
              style={{ display: 'flex', alignItems: 'center', gap: '6px' }}
            >
              <Save size={14} />
              Save Permissions
            </Button>
          </div>
        )}
      </div>

      {successMsg && (
        <Alert variant="success" onClose={() => setSuccessMsg(null)}>
          {successMsg}
        </Alert>
      )}

      {error && (
        <Alert variant="danger" onClose={() => setError(null)}>
          {error}
        </Alert>
      )}

      {/* Staff Profile Summary Card */}
      <div style={{ backgroundColor: '#FFFFFF', borderRadius: 'var(--radius-lg)', border: '1px solid var(--border-color)', padding: '1.5rem', boxShadow: 'var(--shadow-sm)' }}>
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', flexWrap: 'wrap', gap: '1rem' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '1rem' }}>
            <div style={{ width: '48px', height: '48px', borderRadius: '50%', backgroundColor: 'rgba(126, 175, 208, 0.15)', color: '#7EAFD0', display: 'flex', alignItems: 'center', justifyContent: 'center', fontWeight: '800', fontSize: '1.25rem' }}>
              {staff?.name.charAt(0).toUpperCase()}
            </div>
            <div>
              <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                <h1 style={{ margin: 0, fontSize: '1.25rem', fontWeight: '700', color: 'var(--text-main)' }}>
                  {staff?.name}
                </h1>
                <Badge variant={staff?.role === 'OWNER' ? 'primary' : 'neutral'} size="sm">
                  {staff?.role}
                </Badge>
              </div>
              <div style={{ fontSize: '0.8125rem', color: 'var(--text-muted)', marginTop: '2px' }}>
                {staff?.email}
              </div>
            </div>
          </div>

          <div style={{ fontSize: '0.8125rem', color: 'var(--text-muted)' }}>
            <strong>{effectivePermissions.length}</strong> active permissions granted
          </div>
        </div>
      </div>

      {/* Owner Notice */}
      {isOwner && (
        <div style={{ padding: '1rem 1.25rem', backgroundColor: '#EFF6FF', borderRadius: 'var(--radius-lg)', border: '1px solid #BFDBFE', display: 'flex', alignItems: 'flex-start', gap: '12px' }}>
          <ShieldCheck size={20} color="#1E40AF" style={{ marginTop: '2px', flexShrink: 0 }} />
          <div>
            <div style={{ fontWeight: '700', color: '#1E40AF', fontSize: '0.875rem' }}>
              Root Administrator Privileges
            </div>
            <div style={{ fontSize: '0.8125rem', color: '#1E3A8A', marginTop: '2px', lineHeight: '1.4' }}>
              The store Owner possesses full, unrestricted access across all modules in accordance with multi-tenant SaaS security policies. Owner permissions cannot be revoked or overridden.
            </div>
          </div>
        </div>
      )}

      {/* Permission Modules Matrix */}
      <div style={{ display: 'flex', flexDirection: 'column', gap: '1.25rem' }}>
        {catalog.map((group) => (
          <div
            key={group.module}
            style={{
              backgroundColor: '#FFFFFF',
              borderRadius: 'var(--radius-lg)',
              border: '1px solid var(--border-color)',
              overflow: 'hidden',
              boxShadow: 'var(--shadow-sm)'
            }}
          >
            {/* Group Header */}
            <div style={{ padding: '1rem 1.25rem', backgroundColor: 'var(--bg-page)', borderBottom: '1px solid var(--border-color)', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
              <div>
                <h3 style={{ margin: 0, fontSize: '0.9375rem', fontWeight: '700', color: 'var(--text-main)' }}>
                  {group.module}
                </h3>
                <p style={{ margin: '2px 0 0 0', fontSize: '0.75rem', color: 'var(--text-muted)' }}>
                  {group.description}
                </p>
              </div>
            </div>

            {/* Permissions List */}
            <div style={{ display: 'flex', flexDirection: 'column' }}>
              {group.permissions.map((p) => {
                const isAllowed = isOwner || effectivePermissions.includes(p.key);
                const hasCustomOverride = overrides[p.key] !== undefined;

                return (
                  <div
                    key={p.key}
                    style={{
                      padding: '0.875rem 1.25rem',
                      borderBottom: '1px solid var(--border-subtle)',
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'space-between',
                      gap: '1rem'
                    }}
                  >
                    <div>
                      <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                        <span style={{ fontWeight: '600', fontSize: '0.875rem', color: 'var(--text-main)' }}>
                          {p.label}
                        </span>
                        <code style={{ fontSize: '0.6875rem', backgroundColor: 'var(--bg-page)', padding: '2px 6px', borderRadius: '4px', color: 'var(--text-muted)' }}>
                          {p.key}
                        </code>
                        {hasCustomOverride && (
                          <span style={{ fontSize: '0.6875rem', padding: '1px 6px', borderRadius: '4px', backgroundColor: 'rgba(126, 175, 208, 0.15)', color: '#4B7C9E', fontWeight: '600' }}>
                            Custom Override
                          </span>
                        )}
                      </div>
                      <div style={{ fontSize: '0.75rem', color: 'var(--text-muted)', marginTop: '2px' }}>
                        {p.description}
                      </div>
                    </div>

                    {/* Toggle Switch */}
                    <div>
                      <button
                        type="button"
                        disabled={isOwner}
                        onClick={() => handleToggle(p.key)}
                        style={{
                          width: '44px',
                          height: '24px',
                          borderRadius: '12px',
                          backgroundColor: isAllowed ? '#7EAFD0' : '#E2E8F0',
                          border: 'none',
                          cursor: isOwner ? 'not-allowed' : 'pointer',
                          position: 'relative',
                          transition: 'background-color 0.2s ease',
                          opacity: isOwner ? 0.7 : 1
                        }}
                      >
                        <div
                          style={{
                            width: '18px',
                            height: '18px',
                            borderRadius: '50%',
                            backgroundColor: '#FFFFFF',
                            position: 'absolute',
                            top: '3px',
                            left: isAllowed ? '23px' : '3px',
                            transition: 'left 0.2s ease',
                            boxShadow: '0 1px 3px rgba(0,0,0,0.2)'
                          }}
                        />
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        ))}
      </div>

      {/* Bottom Save Bar */}
      {!isOwner && (
        <div style={{ display: 'flex', justifyContent: 'flex-end', gap: '0.75rem', padding: '1rem 0' }}>
          <Button variant="outline" onClick={() => onNavigate('/staff')} disabled={saving}>
            Cancel
          </Button>
          <Button variant="primary" loading={saving} onClick={handleSave}>
            Save All Permissions
          </Button>
        </div>
      )}
    </div>
  );
}
