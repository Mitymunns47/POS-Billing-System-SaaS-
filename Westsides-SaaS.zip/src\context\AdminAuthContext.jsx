import React, { createContext, useContext, useState, useEffect, useCallback } from 'react';
import { api } from '../services/api';

const AdminAuthContext = createContext(null);

export function AdminAuthProvider({ children }) {
  const [adminUser, setAdminUser] = useState(null);
  const [isAdminAuthenticated, setIsAdminAuthenticated] = useState(false);
  const [isAdminLoading, setIsAdminLoading] = useState(true);

  const checkAdminAuth = useCallback(async () => {
    setIsAdminLoading(true);
    try {
      const data = await api.adminGetMe();
      if (data.success) {
        setAdminUser(data.admin);
        setIsAdminAuthenticated(true);
      } else {
        setAdminUser(null);
        setIsAdminAuthenticated(false);
      }
    } catch {
      setAdminUser(null);
      setIsAdminAuthenticated(false);
    } finally {
      setIsAdminLoading(false);
    }
  }, []);

  useEffect(() => { checkAdminAuth(); }, [checkAdminAuth]);

  const adminLogin = async (credentials) => {
    const data = await api.adminLogin(credentials);
    if (data.success) {
      api.setToken(data.token);
      setAdminUser(data.user);
      setIsAdminAuthenticated(true);
    }
    return data;
  };

  const adminLogout = async () => {
    try { await api.logout(); } finally {
      api.setToken(null);
      setAdminUser(null);
      setIsAdminAuthenticated(false);
    }
  };

  return (
    <AdminAuthContext.Provider value={{
      adminUser, isAdminAuthenticated, isAdminLoading,
      adminLogin, adminLogout, checkAdminAuth
    }}>
      {children}
    </AdminAuthContext.Provider>
  );
}

export function useAdminAuth() {
  const ctx = useContext(AdminAuthContext);
  if (!ctx) throw new Error('useAdminAuth must be used within AdminAuthProvider');
  return ctx;
}
