const express = require('express');
const router = express.Router();
const { SaleModel, getStoreTaxSettings, updateStoreTaxSettings } = require('../models/saleModel');
const authMiddleware = require('../middleware/auth');
const { requirePermission } = require('../middleware/roles');
const { PERMISSIONS } = require('../constants/roles');

router.use(authMiddleware);

// ── POS Helpers ───────────────────────────────────────────────────────────────

// GET /api/pos/search?q=...  — product search for POS
router.get('/search', requirePermission(PERMISSIONS.BILLING_VIEW), (req, res) => {
  try {
    const { q } = req.query;
    if (!q || !q.trim()) return res.json({ success: true, results: [] });
    const results = SaleModel.searchProducts(req.storeId, q, 20);
    res.json({ success: true, results });
  } catch (err) {
    console.error('POS search error:', err);
    res.status(500).json({ success: false, error: 'Product search failed.' });
  }
});

// GET /api/pos/barcode/:code  — barcode lookup
router.get('/barcode/:code', requirePermission(PERMISSIONS.BILLING_VIEW), (req, res) => {
  try {
    const result = SaleModel.lookupBarcode(req.storeId, req.params.code);
    if (!result) return res.status(404).json({ success: false, error: `No product found for barcode "${req.params.code}".` });
    if (result.stock <= 0) return res.status(400).json({ success: false, error: `Product is out of stock.`, product: result });
    res.json({ success: true, product: result });
  } catch (err) {
    res.status(500).json({ success: false, error: 'Barcode lookup failed.' });
  }
});

// GET /api/pos/tax-settings  — get store tax configuration
router.get('/tax-settings', requirePermission(PERMISSIONS.BILLING_VIEW), (req, res) => {
  try {
    const settings = getStoreTaxSettings(req.storeId);
    res.json({ success: true, settings });
  } catch (err) {
    res.status(500).json({ success: false, error: 'Could not load tax settings.' });
  }
});

// PUT /api/pos/tax-settings  — update store tax configuration (OWNER/MANAGER only)
router.put('/tax-settings', requirePermission(PERMISSIONS.SETTINGS_VIEW), (req, res) => {
  try {
    const { taxEnabled, taxName, taxRate, taxInclusive } = req.body;
    const settings = updateStoreTaxSettings(req.storeId, { taxEnabled, taxName, taxRate, taxInclusive });
    res.json({ success: true, message: 'Tax settings updated.', settings });
  } catch (err) {
    res.status(500).json({ success: false, error: 'Could not update tax settings.' });
  }
});

// ── Sales ─────────────────────────────────────────────────────────────────────

// POST /api/pos/sales  — complete a sale
router.post('/sales', requirePermission(PERMISSIONS.BILLING_CREATE), (req, res) => {
  try {
    const { customerId, items, discountType, discountValue, taxRate, paymentMethod, paymentAmount, note } = req.body;

    // Basic validation
    if (!items || !Array.isArray(items) || items.length === 0) {
      return res.status(400).json({ success: false, error: 'Cart is empty. Please add items before completing the sale.' });
    }
    if (!paymentMethod || !['CASH', 'UPI', 'CARD'].includes(paymentMethod)) {
      return res.status(400).json({ success: false, error: 'Invalid payment method. Must be CASH, UPI, or CARD.' });
    }
    if (paymentAmount === undefined || paymentAmount === null || isNaN(Number(paymentAmount)) || Number(paymentAmount) < 0) {
      return res.status(400).json({ success: false, error: 'Payment amount is required and must be a positive number.' });
    }
    for (const item of items) {
      if (!item.variantId) return res.status(400).json({ success: false, error: 'Each cart item must have a variantId.' });
      if (!item.quantity || item.quantity < 1) return res.status(400).json({ success: false, error: 'Quantity must be at least 1.' });
      if (item.unitPrice === undefined || item.unitPrice < 0) return res.status(400).json({ success: false, error: 'Unit price is invalid.' });
    }
    if (discountValue && (isNaN(discountValue) || discountValue < 0)) {
      return res.status(400).json({ success: false, error: 'Discount value must be non-negative.' });
    }
    if (discountType === 'percentage' && discountValue > 100) {
      return res.status(400).json({ success: false, error: 'Percentage discount cannot exceed 100%.' });
    }

    const sale = SaleModel.create({
      storeId: req.storeId,
      customerId: customerId || null,
      cashierId: req.auth.userId,
      cashierName: req.auth.userName,
      items,
      discountType: discountType || 'none',
      discountValue: Number(discountValue) || 0,
      taxRate: Number(taxRate) || 0,
      paymentMethod,
      paymentAmount: Number(paymentAmount),
      note: note || null
    });

    res.status(201).json({ success: true, message: 'Sale completed successfully.', sale });
  } catch (err) {
    console.error('Sale creation error:', err);
    // Return user-friendly error (not stack trace)
    const message = err.message || 'Could not complete sale. Please try again.';
    res.status(400).json({ success: false, error: message });
  }
});

// GET /api/pos/sales  — sales history
router.get('/sales', requirePermission(PERMISSIONS.SALES_VIEW), (req, res) => {
  try {
    const { search, paymentMethod, status, startDate, endDate, page = 1, limit = 20 } = req.query;

    // Cashiers can only see their own sales unless they have SALES_VIEW_ALL
    const { hasPermission } = require('../constants/roles');
    const cashierId = hasPermission(req.role, PERMISSIONS.SALES_VIEW_ALL)
      ? (req.query.cashierId || null)
      : req.auth.userId;

    const result = SaleModel.findAll({
      storeId: req.storeId,
      cashierId,
      search: search || null,
      paymentMethod: paymentMethod || null,
      status: status || null,
      startDate: startDate || null,
      endDate: endDate || null,
      page: parseInt(page) || 1,
      limit: Math.min(parseInt(limit) || 20, 100)
    });
    res.json({ success: true, ...result });
  } catch (err) {
    res.status(500).json({ success: false, error: 'Could not load sales.' });
  }
});

// GET /api/pos/sales/stats  — today's stats
router.get('/sales/stats', requirePermission(PERMISSIONS.SALES_VIEW), (req, res) => {
  try {
    const stats = SaleModel.getTodayStats(req.storeId);
    res.json({ success: true, stats });
  } catch (err) {
    res.status(500).json({ success: false, error: 'Could not load stats.' });
  }
});

// GET /api/pos/sales/:id  — get single sale
router.get('/sales/:id', requirePermission(PERMISSIONS.SALES_VIEW), (req, res) => {
  try {
    const sale = SaleModel.findById(req.params.id, req.storeId);
    if (!sale) return res.status(404).json({ success: false, error: 'Sale not found.' });
    res.json({ success: true, sale });
  } catch (err) {
    res.status(500).json({ success: false, error: 'Could not load sale.' });
  }
});

// POST /api/pos/sales/:id/cancel  — cancel a sale
router.post('/sales/:id/cancel', requirePermission(PERMISSIONS.BILLING_CANCEL), (req, res) => {
  try {
    const sale = SaleModel.cancel(req.params.id, req.storeId, req.auth.userName);
    if (!sale) return res.status(404).json({ success: false, error: 'Sale not found.' });
    res.json({ success: true, message: 'Sale cancelled. Inventory has been restored.', sale });
  } catch (err) {
    const message = err.message || 'Could not cancel sale.';
    res.status(400).json({ success: false, error: message });
  }
});

module.exports = router;
