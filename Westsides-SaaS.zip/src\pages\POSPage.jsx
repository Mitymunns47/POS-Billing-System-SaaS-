import React, { useState, useEffect, useRef, useCallback } from 'react';
import { api } from '../services/api';
import { useAuth } from '../context/AuthContext';
import { Button } from '../components/ui/Button';
import { Input } from '../components/ui/Input';
import { Alert } from '../components/ui/Alert';
import { Badge } from '../components/ui/Badge';
import {
  Search, Barcode, Plus, Minus, Trash2, X, User, UserPlus,
  ShoppingCart, CheckCircle, ChevronRight, Percent, IndianRupee,
  Tag, RotateCcw, Printer, Receipt
} from 'lucide-react';

// ── Helpers ───────────────────────────────────────────────────────────────────
const fmt = (n) => Number(n || 0).toFixed(2);
const round2 = (n) => Math.round(n * 100) / 100;

function variantLabel(item) {
  const parts = [item.size, item.color].filter(Boolean);
  return parts.length > 0 ? parts.join(' / ') : 'Default';
}

// ── Stock badge ───────────────────────────────────────────────────────────────
function StockBadge({ stock }) {
  if (stock === 0) return <Badge variant="danger" size="sm">Out of Stock</Badge>;
  if (stock <= 3) return <Badge variant="warning" size="sm">{stock} left</Badge>;
  return <Badge variant="success" size="sm">{stock} in stock</Badge>;
}

// ── Customer selector panel ───────────────────────────────────────────────────
function CustomerPanel({ customer, onSelect, onClear }) {
  const [query, setQuery] = useState('');
  const [results, setResults] = useState([]);
  const [showSearch, setShowSearch] = useState(false);
  const [showNewForm, setShowNewForm] = useState(false);
  const [newCust, setNewCust] = useState({ name: '', phone: '', email: '' });
  const [saving, setSaving] = useState(false);
  const [custErr, setCustErr] = useState(null);

  const doSearch = useCallback(async (q) => {
    if (!q.trim()) { setResults([]); return; }
    try {
      const res = await api.searchCustomers(q);
      if (res.success) setResults(res.customers || []);
    } catch { setResults([]); }
  }, []);

  useEffect(() => {
    const t = setTimeout(() => doSearch(query), 250);
    return () => clearTimeout(t);
  }, [query, doSearch]);

  const handleCreate = async () => {
    if (!newCust.name.trim()) { setCustErr('Name is required.'); return; }
    setSaving(true); setCustErr(null);
    try {
      const res = await api.createCustomer(newCust);
      if (res.success) { onSelect(res.customer); setShowNewForm(false); setShowSearch(false); setNewCust({ name: '', phone: '', email: '' }); }
    } catch (e) { setCustErr(e.message); }
    finally { setSaving(false); }
  };

  if (customer) {
    return (
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '10px 14px', backgroundColor: 'var(--bg-page)', borderRadius: 'var(--radius-md)', border: '1px solid var(--border-color)' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
          <div style={{ width: 32, height: 32, borderRadius: '50%', backgroundColor: '#EFF6FF', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
            <User size={16} color="#7EAFD0" />
          </div>
          <div>
            <div style={{ fontWeight: '600', fontSize: '0.875rem', color: 'var(--text-main)' }}>{customer.name}</div>
            {customer.phone && <div style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>{customer.phone}</div>}
          </div>
        </div>
        <button onClick={onClear} style={{ background: 'none', border: 'none', cursor: 'pointer', color: 'var(--text-muted)' }}><X size={14} /></button>
      </div>
    );
  }

  return (
    <div>
      {!showSearch && !showNewForm && (
        <div style={{ display: 'flex', gap: '0.5rem' }}>
          <Button variant="outline" size="sm" onClick={() => setShowSearch(true)} style={{ flex: 1 }}>
            <Search size={13} style={{ marginRight: 4 }} /> Find Customer
          </Button>
          <Button variant="ghost" size="sm" onClick={() => setShowNewForm(true)} style={{ flex: 1 }}>
            <UserPlus size={13} style={{ marginRight: 4 }} /> New Customer
          </Button>
        </div>
      )}

      {showSearch && (
        <div>
          <Input id="cust-search" value={query} onChange={e => setQuery(e.target.value)} placeholder="Search by name or phone…" startIcon={<Search size={14} />} />
          <div style={{ marginTop: '6px', border: '1px solid var(--border-color)', borderRadius: 'var(--radius-md)', overflow: 'hidden', maxHeight: 160, overflowY: 'auto' }}>
            {results.length === 0 ? (
              <div style={{ padding: '10px 14px', color: 'var(--text-muted)', fontSize: '0.8125rem' }}>
                {query.trim() ? 'No customers found.' : 'Start typing to search…'}
              </div>
            ) : results.map(c => (
              <button key={c.id} onClick={() => { onSelect(c); setShowSearch(false); setQuery(''); setResults([]); }}
                style={{ display: 'block', width: '100%', textAlign: 'left', padding: '8px 14px', background: 'none', border: 'none', cursor: 'pointer', borderBottom: '1px solid var(--border-subtle)' }}
                onMouseEnter={e => e.currentTarget.style.backgroundColor = 'var(--bg-page)'}
                onMouseLeave={e => e.currentTarget.style.backgroundColor = 'transparent'}
              >
                <div style={{ fontWeight: '500', fontSize: '0.875rem', color: 'var(--text-main)' }}>{c.name}</div>
                {c.phone && <div style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>{c.phone}</div>}
              </button>
            ))}
          </div>
          <button onClick={() => { setShowSearch(false); setQuery(''); setResults([]); }} style={{ marginTop: 6, background: 'none', border: 'none', cursor: 'pointer', color: 'var(--text-muted)', fontSize: '0.8125rem' }}>Cancel</button>
        </div>
      )}

      {showNewForm && (
        <div style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
          {custErr && <Alert variant="danger" style={{ padding: '6px 10px', fontSize: '0.8125rem' }}>{custErr}</Alert>}
          <Input id="nc-name" label="Name *" value={newCust.name} onChange={e => setNewCust(p => ({ ...p, name: e.target.value }))} placeholder="Customer name" />
          <Input id="nc-phone" label="Phone" value={newCust.phone} onChange={e => setNewCust(p => ({ ...p, phone: e.target.value }))} placeholder="+91 98765 43210" />
          <Input id="nc-email" label="Email" type="email" value={newCust.email} onChange={e => setNewCust(p => ({ ...p, email: e.target.value }))} placeholder="optional" />
          <div style={{ display: 'flex', gap: '0.5rem' }}>
            <Button variant="primary" size="sm" isLoading={saving} onClick={handleCreate} style={{ flex: 1 }}>Save</Button>
            <Button variant="ghost" size="sm" onClick={() => { setShowNewForm(false); setCustErr(null); }} style={{ flex: 1 }}>Cancel</Button>
          </div>
        </div>
      )}
    </div>
  );
}

// ── Main POS Page ─────────────────────────────────────────────────────────────
export function POSPage({ onNavigate }) {
  const { store } = useAuth();

  // Product search state
  const [searchQuery, setSearchQuery] = useState('');
  const [searchResults, setSearchResults] = useState([]);
  const [searching, setSearching] = useState(false);
  const [barcodeInput, setBarcodeInput] = useState('');
  const barcodeRef = useRef(null);

  // Cart
  const [cart, setCart] = useState([]);

  // Customer
  const [customer, setCustomer] = useState(null);

  // Discount
  const [discountType, setDiscountType] = useState('none');
  const [discountValue, setDiscountValue] = useState('');

  // Tax
  const [taxSettings, setTaxSettings] = useState({ taxEnabled: false, taxRate: 18, taxName: 'GST' });

  // Payment
  const [paymentMethod, setPaymentMethod] = useState('CASH');
  const [cashReceived, setCashReceived] = useState('');

  // Sale state
  const [completing, setCompleting] = useState(false);
  const [saleError, setSaleError] = useState(null);
  const [completedSale, setCompletedSale] = useState(null);

  // Load tax settings
  useEffect(() => {
    api.getTaxSettings().then(res => { if (res.success) setTaxSettings(res.settings); }).catch(() => {});
  }, []);

  // Product search with debounce
  useEffect(() => {
    if (!searchQuery.trim()) { setSearchResults([]); return; }
    const t = setTimeout(async () => {
      setSearching(true);
      try {
        const res = await api.posSearch(searchQuery);
        if (res.success) setSearchResults(res.results || []);
      } catch { setSearchResults([]); }
      finally { setSearching(false); }
    }, 280);
    return () => clearTimeout(t);
  }, [searchQuery]);

  // Add item to cart
  const addToCart = useCallback((product) => {
    if (product.stock <= 0) {
      setSaleError(`"${product.productName}" is out of stock.`);
      return;
    }
    setCart(prev => {
      const existing = prev.find(i => i.variantId === product.variantId);
      if (existing) {
        const newQty = existing.quantity + 1;
        if (newQty > product.stock) {
          setSaleError(`Only ${product.stock} units available for ${product.productName} (${variantLabel(product)}).`);
          return prev;
        }
        return prev.map(i => i.variantId === product.variantId ? { ...i, quantity: newQty } : i);
      }
      return [...prev, {
        variantId: product.variantId,
        productId: product.productId,
        productName: product.productName,
        variantSku: product.variantSku || product.productSku,
        size: product.size,
        color: product.color,
        unitPrice: product.effectivePrice,
        quantity: 1,
        availableStock: product.stock
      }];
    });
    setSaleError(null);
    setSearchQuery('');
    setSearchResults([]);
  }, []);

  // Barcode scan handler
  const handleBarcodeSubmit = async (e) => {
    e.preventDefault();
    const code = barcodeInput.trim();
    if (!code) return;
    try {
      const res = await api.posBarcode(code);
      if (res.success) { addToCart(res.product); setBarcodeInput(''); }
    } catch (err) {
      setSaleError(err.message || 'Barcode not found.');
      setBarcodeInput('');
    }
  };

  // Cart operations
  const updateQty = (variantId, delta) => {
    setCart(prev => prev.map(item => {
      if (item.variantId !== variantId) return item;
      const newQty = item.quantity + delta;
      if (newQty <= 0) return item; // handled by remove
      if (newQty > item.availableStock) {
        setSaleError(`Only ${item.availableStock} units available.`);
        return item;
      }
      return { ...item, quantity: newQty };
    }));
  };

  const setQty = (variantId, val) => {
    const qty = parseInt(val) || 1;
    setCart(prev => prev.map(item => {
      if (item.variantId !== variantId) return item;
      if (qty > item.availableStock) {
        setSaleError(`Only ${item.availableStock} units available.`);
        return { ...item, quantity: item.availableStock };
      }
      return { ...item, quantity: Math.max(1, qty) };
    }));
  };

  const removeFromCart = (variantId) => setCart(prev => prev.filter(i => i.variantId !== variantId));

  const clearCart = () => {
    setCart([]);
    setCustomer(null);
    setDiscountType('none');
    setDiscountValue('');
    setCashReceived('');
    setSaleError(null);
    setPaymentMethod('CASH');
  };

  // ── Calculations ──────────────────────────────────────────────────────────────
  const subtotal = round2(cart.reduce((s, i) => s + i.unitPrice * i.quantity, 0));

  let discountAmount = 0;
  const dv = parseFloat(discountValue) || 0;
  if (discountType === 'percentage' && dv > 0) discountAmount = round2(subtotal * dv / 100);
  else if (discountType === 'fixed' && dv > 0) discountAmount = Math.min(dv, subtotal);
  discountAmount = round2(discountAmount);

  const taxableAmount = round2(subtotal - discountAmount);
  const effectiveTaxRate = taxSettings.taxEnabled ? (taxSettings.taxRate || 0) : 0;
  const taxAmount = round2(taxableAmount * effectiveTaxRate / 100);
  const totalAmount = round2(taxableAmount + taxAmount);
  const cashReceivedNum = parseFloat(cashReceived) || 0;
  const changeAmount = round2(Math.max(0, cashReceivedNum - totalAmount));
  const insufficientCash = paymentMethod === 'CASH' && cashReceivedNum > 0 && cashReceivedNum < totalAmount;

  // ── Complete Sale ─────────────────────────────────────────────────────────────
  const handleCompleteSale = async () => {
    if (cart.length === 0) { setSaleError('Cart is empty.'); return; }
    if (paymentMethod === 'CASH' && cashReceivedNum < totalAmount) {
      setSaleError(`Cash received (₹${fmt(cashReceivedNum)}) is less than the total (₹${fmt(totalAmount)}).`);
      return;
    }

    setCompleting(true);
    setSaleError(null);
    try {
      const res = await api.completeSale({
        customerId: customer?.id || null,
        items: cart.map(i => ({ variantId: i.variantId, quantity: i.quantity, unitPrice: i.unitPrice })),
        discountType,
        discountValue: dv,
        taxRate: effectiveTaxRate,
        paymentMethod,
        paymentAmount: paymentMethod === 'CASH' ? cashReceivedNum : totalAmount,
        note: null
      });
      if (res.success) {
        setCompletedSale(res.sale);
        setCart([]);
      }
    } catch (err) {
      setSaleError(err.message || 'Could not complete sale.');
    } finally {
      setCompleting(false);
    }
  };

  // ── Invoice View ──────────────────────────────────────────────────────────────
  if (completedSale) {
    return <InvoiceView sale={completedSale} store={store} onNewSale={() => setCompletedSale(null)} onNavigate={onNavigate} />;
  }

  // ── Main POS Layout ───────────────────────────────────────────────────────────
  return (
    <div style={{ display: 'flex', gap: '1.25rem', alignItems: 'flex-start', maxWidth: '1400px', margin: '0 auto' }}>

      {/* LEFT — Product search + Cart */}
      <div style={{ flex: '1 1 0', minWidth: 0 }}>

        {/* Header */}
        <div style={{ marginBottom: '1.25rem', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
          <div>
            <h1 style={{ fontSize: '1.375rem', fontWeight: '700', color: 'var(--text-main)', margin: 0 }}>Point of Sale</h1>
            <p style={{ fontSize: '0.8125rem', color: 'var(--text-muted)', margin: '2px 0 0' }}>{store?.name}</p>
          </div>
          <div style={{ display: 'flex', gap: '0.5rem' }}>
            <Button variant="secondary" size="sm" onClick={() => onNavigate('/sales')}>
              <Receipt size={14} style={{ marginRight: 4 }} /> Sales History
            </Button>
            {cart.length > 0 && (
              <Button variant="ghost" size="sm" onClick={clearCart}>
                <RotateCcw size={13} style={{ marginRight: 4 }} /> Clear
              </Button>
            )}
          </div>
        </div>

        {saleError && (
          <Alert variant="danger" style={{ marginBottom: '1rem' }} onDismiss={() => setSaleError(null)}>
            {saleError}
          </Alert>
        )}

        {/* Barcode input */}
        <form onSubmit={handleBarcodeSubmit} style={{ marginBottom: '1rem' }}>
          <div style={{ display: 'flex', gap: '0.5rem' }}>
            <div style={{ flex: 1 }}>
              <Input
                id="barcode-input"
                ref={barcodeRef}
                value={barcodeInput}
                onChange={e => setBarcodeInput(e.target.value)}
                placeholder="Scan barcode or enter code…"
                startIcon={<Barcode size={16} />}
                autoComplete="off"
              />
            </div>
            <Button type="submit" variant="secondary" size="md">Scan</Button>
          </div>
        </form>

        {/* Product search */}
        <div style={{ position: 'relative', marginBottom: '1rem' }}>
          <Input
            id="product-search"
            value={searchQuery}
            onChange={e => setSearchQuery(e.target.value)}
            placeholder="Search product name, SKU…"
            startIcon={<Search size={16} />}
            autoComplete="off"
          />
          {searchQuery.trim() && (
            <div style={{ position: 'absolute', top: '100%', left: 0, right: 0, zIndex: 100, backgroundColor: '#FFFFFF', border: '1px solid var(--border-color)', borderRadius: 'var(--radius-md)', boxShadow: '0 10px 25px -5px rgba(0, 0, 0, 0.1), 0 8px 10px -6px rgba(0, 0, 0, 0.1)', maxHeight: 340, overflowY: 'auto', marginTop: 4 }}>
              {searching ? (
                <div style={{ padding: '14px 16px', color: 'var(--text-muted)', fontSize: '0.875rem', display: 'flex', alignItems: 'center', gap: '8px' }}>
                  <div style={{ width: '14px', height: '14px', border: '2px solid #7EAFD0', borderTopColor: 'transparent', borderRadius: '50%', animation: 'spin 0.8s linear infinite' }} />
                  <span>Searching inventory…</span>
                </div>
              ) : searchResults.length === 0 ? (
                <div style={{ padding: '14px 16px', color: 'var(--text-muted)', fontSize: '0.875rem' }}>
                  No products found for "{searchQuery}".
                </div>
              ) : searchResults.map(p => (
                <button
                  key={p.variantId}
                  onClick={() => addToCart(p)}
                  disabled={p.stock === 0}
                  style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', width: '100%', padding: '10px 14px', background: 'none', border: 'none', borderBottom: '1px solid var(--border-subtle)', cursor: p.stock === 0 ? 'not-allowed' : 'pointer', textAlign: 'left', opacity: p.stock === 0 ? 0.55 : 1 }}
                  onMouseEnter={e => { if (p.stock > 0) e.currentTarget.style.backgroundColor = 'var(--bg-page)'; }}
                  onMouseLeave={e => e.currentTarget.style.backgroundColor = 'transparent'}
                >
                  <div>
                    <div style={{ fontWeight: '600', fontSize: '0.875rem', color: 'var(--text-main)' }}>{p.productName}</div>
                    <div style={{ fontSize: '0.75rem', color: 'var(--text-muted)', marginTop: 2 }}>
                      {variantLabel(p)} {p.variantSku ? `• ${p.variantSku}` : ''}
                      {p.categoryName ? ` • ${p.categoryName}` : ''}
                    </div>
                  </div>
                  <div style={{ textAlign: 'right', flexShrink: 0, marginLeft: '1rem' }}>
                    <div style={{ fontWeight: '700', color: 'var(--text-main)', fontSize: '0.9375rem' }}>₹{fmt(p.effectivePrice)}</div>
                    <StockBadge stock={p.stock} />
                  </div>
                </button>
              ))}
            </div>
          )}
        </div>

        {/* Cart */}
        <div style={{ backgroundColor: '#fff', borderRadius: 'var(--radius-lg)', border: '1px solid var(--border-color)', boxShadow: 'var(--shadow-sm)', overflow: 'hidden' }}>
          <div style={{ padding: '0.875rem 1.25rem', borderBottom: '1px solid var(--border-subtle)', display: 'flex', alignItems: 'center', gap: '8px' }}>
            <ShoppingCart size={16} color="#7EAFD0" />
            <span style={{ fontWeight: '600', fontSize: '0.9375rem', color: 'var(--text-main)' }}>Cart</span>
            {cart.length > 0 && <Badge variant="default" size="sm">{cart.length} item{cart.length !== 1 ? 's' : ''}</Badge>}
          </div>

          {cart.length === 0 ? (
            <div style={{ padding: '2.5rem', textAlign: 'center', color: 'var(--text-muted)' }}>
              <ShoppingCart size={36} color="#CBD5E1" style={{ marginBottom: '0.75rem' }} />
              <p style={{ fontSize: '0.9375rem', fontWeight: '500', marginBottom: 4 }}>Cart is empty</p>
              <p style={{ fontSize: '0.8125rem' }}>Search or scan a product to begin.</p>
            </div>
          ) : (
            <div style={{ overflowX: 'auto' }}>
              <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: '0.875rem' }}>
                <thead>
                  <tr style={{ backgroundColor: 'var(--bg-page)', borderBottom: '1px solid var(--border-color)' }}>
                    {['Product', 'Unit Price', 'Qty', 'Total', ''].map(h => (
                      <th key={h} style={{ padding: '9px 12px', textAlign: 'left', fontWeight: '600', color: 'var(--text-muted)', fontSize: '0.75rem', whiteSpace: 'nowrap', textTransform: 'uppercase', letterSpacing: '0.04em' }}>{h}</th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {cart.map((item, idx) => (
                    <tr key={item.variantId} style={{ borderBottom: idx < cart.length - 1 ? '1px solid var(--border-subtle)' : 'none' }}>
                      <td style={{ padding: '10px 12px' }}>
                        <div style={{ fontWeight: '600', color: 'var(--text-main)' }}>{item.productName}</div>
                        <div style={{ fontSize: '0.75rem', color: 'var(--text-muted)', marginTop: 2 }}>
                          {variantLabel(item)} {item.variantSku ? `• ${item.variantSku}` : ''}
                        </div>
                      </td>
                      <td style={{ padding: '10px 12px', fontWeight: '500' }}>₹{fmt(item.unitPrice)}</td>
                      <td style={{ padding: '10px 12px' }}>
                        <div style={{ display: 'flex', alignItems: 'center', gap: '6px' }}>
                          <button onClick={() => item.quantity <= 1 ? removeFromCart(item.variantId) : updateQty(item.variantId, -1)}
                            style={{ width: 26, height: 26, borderRadius: '5px', border: '1px solid var(--border-color)', background: '#fff', cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                            {item.quantity <= 1 ? <Trash2 size={12} color="var(--danger)" /> : <Minus size={12} />}
                          </button>
                          <input type="number" min="1" max={item.availableStock} value={item.quantity}
                            onChange={e => setQty(item.variantId, e.target.value)}
                            style={{ width: 44, textAlign: 'center', border: '1px solid var(--border-color)', borderRadius: '5px', padding: '3px 4px', fontSize: '0.875rem', fontFamily: 'inherit', color: 'var(--text-main)' }}
                          />
                          <button onClick={() => updateQty(item.variantId, 1)} disabled={item.quantity >= item.availableStock}
                            style={{ width: 26, height: 26, borderRadius: '5px', border: '1px solid var(--border-color)', background: '#fff', cursor: item.quantity >= item.availableStock ? 'not-allowed' : 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center', opacity: item.quantity >= item.availableStock ? 0.4 : 1 }}>
                            <Plus size={12} />
                          </button>
                        </div>
                      </td>
                      <td style={{ padding: '10px 12px', fontWeight: '700', color: 'var(--text-main)' }}>₹{fmt(item.unitPrice * item.quantity)}</td>
                      <td style={{ padding: '10px 12px' }}>
                        <button onClick={() => removeFromCart(item.variantId)} style={{ background: 'none', border: 'none', cursor: 'pointer', color: 'var(--danger)', padding: '4px' }}>
                          <Trash2 size={14} />
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      </div>

      {/* RIGHT — Order summary + Checkout */}
      <div style={{ width: '360px', flexShrink: 0, display: 'flex', flexDirection: 'column', gap: '1rem' }}>

        {/* Customer */}
        <div style={{ backgroundColor: '#fff', borderRadius: 'var(--radius-lg)', border: '1px solid var(--border-color)', padding: '1rem', boxShadow: 'var(--shadow-sm)' }}>
          <div style={{ fontSize: '0.75rem', fontWeight: '700', textTransform: 'uppercase', letterSpacing: '0.05em', color: 'var(--text-muted)', marginBottom: '0.75rem' }}>Customer</div>
          <CustomerPanel customer={customer} onSelect={setCustomer} onClear={() => setCustomer(null)} />
          {!customer && <div style={{ marginTop: '6px', fontSize: '0.75rem', color: 'var(--text-muted)' }}>Walking-in customer if not selected.</div>}
        </div>

        {/* Discount */}
        <div style={{ backgroundColor: '#fff', borderRadius: 'var(--radius-lg)', border: '1px solid var(--border-color)', padding: '1rem', boxShadow: 'var(--shadow-sm)' }}>
          <div style={{ fontSize: '0.75rem', fontWeight: '700', textTransform: 'uppercase', letterSpacing: '0.05em', color: 'var(--text-muted)', marginBottom: '0.75rem' }}>Discount</div>
          <div style={{ display: 'flex', gap: '0.5rem', marginBottom: '0.5rem' }}>
            {['none', 'percentage', 'fixed'].map(t => (
              <button key={t} onClick={() => { setDiscountType(t); setDiscountValue(''); }}
                style={{ flex: 1, padding: '6px', borderRadius: '6px', border: '1px solid', fontSize: '0.8125rem', fontWeight: '500', cursor: 'pointer', transition: 'all 0.12s', borderColor: discountType === t ? '#7EAFD0' : 'var(--border-color)', backgroundColor: discountType === t ? '#EFF6FF' : '#fff', color: discountType === t ? '#7EAFD0' : 'var(--text-muted)' }}>
                {t === 'none' ? 'None' : t === 'percentage' ? '% Off' : '₹ Fixed'}
              </button>
            ))}
          </div>
          {discountType !== 'none' && (
            <Input id="discount-val" type="number" min="0" max={discountType === 'percentage' ? 100 : undefined}
              value={discountValue} onChange={e => setDiscountValue(e.target.value)}
              placeholder={discountType === 'percentage' ? 'e.g. 10' : 'e.g. 100'}
              startIcon={discountType === 'percentage' ? <Percent size={14} /> : <IndianRupee size={14} />}
            />
          )}
        </div>

        {/* Order Summary */}
        <div style={{ backgroundColor: '#fff', borderRadius: 'var(--radius-lg)', border: '1px solid var(--border-color)', padding: '1rem', boxShadow: 'var(--shadow-sm)' }}>
          <div style={{ fontSize: '0.75rem', fontWeight: '700', textTransform: 'uppercase', letterSpacing: '0.05em', color: 'var(--text-muted)', marginBottom: '0.875rem' }}>Order Summary</div>
          {[
            { label: 'Subtotal', value: `₹${fmt(subtotal)}` },
            ...(discountAmount > 0 ? [{ label: `Discount (${discountType === 'percentage' ? dv + '%' : '₹' + fmt(dv)})`, value: `-₹${fmt(discountAmount)}`, color: '#10B981' }] : []),
            ...(discountAmount > 0 ? [{ label: 'Taxable Amount', value: `₹${fmt(taxableAmount)}`, muted: true }] : []),
            ...(taxSettings.taxEnabled ? [{ label: `${taxSettings.taxName} (${effectiveTaxRate}%)`, value: `₹${fmt(taxAmount)}` }] : []),
          ].map(({ label, value, color, muted }) => (
            <div key={label} style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '8px', fontSize: muted ? '0.8125rem' : '0.875rem', color: muted ? 'var(--text-muted)' : 'var(--text-main)' }}>
              <span>{label}</span>
              <span style={{ fontWeight: '500', color: color || (muted ? 'var(--text-muted)' : 'var(--text-main)') }}>{value}</span>
            </div>
          ))}
          <div style={{ borderTop: '2px solid var(--border-color)', paddingTop: '0.75rem', marginTop: '4px', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
            <span style={{ fontWeight: '700', fontSize: '1rem', color: 'var(--text-main)' }}>Grand Total</span>
            <span style={{ fontWeight: '800', fontSize: '1.375rem', color: '#7EAFD0' }}>₹{fmt(totalAmount)}</span>
          </div>
        </div>

        {/* Payment */}
        <div style={{ backgroundColor: '#fff', borderRadius: 'var(--radius-lg)', border: '1px solid var(--border-color)', padding: '1rem', boxShadow: 'var(--shadow-sm)' }}>
          <div style={{ fontSize: '0.75rem', fontWeight: '700', textTransform: 'uppercase', letterSpacing: '0.05em', color: 'var(--text-muted)', marginBottom: '0.875rem' }}>Payment</div>
          <div style={{ display: 'flex', gap: '0.5rem', marginBottom: '0.875rem' }}>
            {['CASH', 'UPI', 'CARD'].map(pm => (
              <button key={pm} onClick={() => { setPaymentMethod(pm); setCashReceived(''); }}
                style={{ flex: 1, padding: '8px 4px', borderRadius: '6px', border: '1px solid', fontSize: '0.8125rem', fontWeight: '600', cursor: 'pointer', transition: 'all 0.12s', borderColor: paymentMethod === pm ? '#7EAFD0' : 'var(--border-color)', backgroundColor: paymentMethod === pm ? '#7EAFD0' : '#fff', color: paymentMethod === pm ? '#fff' : 'var(--text-muted)' }}>
                {pm}
              </button>
            ))}
          </div>

          {paymentMethod === 'CASH' && (
            <div style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
              <Input id="cash-received" label="Cash Received (₹)" type="number" min={totalAmount} step="0.01"
                value={cashReceived} onChange={e => setCashReceived(e.target.value)}
                placeholder={`Min ₹${fmt(totalAmount)}`}
                error={insufficientCash ? `Need ₹${fmt(totalAmount - cashReceivedNum)} more` : null}
              />
              {cashReceivedNum >= totalAmount && totalAmount > 0 && (
                <div style={{ display: 'flex', justifyContent: 'space-between', padding: '8px 12px', backgroundColor: '#D1FAE5', borderRadius: '6px', border: '1px solid #A7F3D0' }}>
                  <span style={{ fontSize: '0.875rem', fontWeight: '500', color: '#065F46' }}>Change</span>
                  <span style={{ fontSize: '1rem', fontWeight: '700', color: '#065F46' }}>₹{fmt(changeAmount)}</span>
                </div>
              )}
            </div>
          )}

          {(paymentMethod === 'UPI' || paymentMethod === 'CARD') && (
            <div style={{ padding: '10px 12px', backgroundColor: 'var(--bg-page)', borderRadius: '6px', border: '1px solid var(--border-subtle)', fontSize: '0.875rem', color: 'var(--text-muted)' }}>
              {paymentMethod === 'UPI' ? 'UPI payment of' : 'Card payment of'} <strong style={{ color: 'var(--text-main)' }}>₹{fmt(totalAmount)}</strong> will be recorded.
            </div>
          )}
        </div>

        {/* Complete Sale Button */}
        <Button
          variant="primary"
          size="lg"
          isLoading={completing}
          disabled={cart.length === 0 || completing || (paymentMethod === 'CASH' && cashReceivedNum > 0 && cashReceivedNum < totalAmount)}
          onClick={handleCompleteSale}
          style={{ width: '100%', fontWeight: '700', fontSize: '1rem', padding: '14px' }}
        >
          <CheckCircle size={18} style={{ marginRight: '8px' }} />
          Complete Sale — ₹{fmt(totalAmount)}
        </Button>
      </div>
    </div>
  );
}

// ── Invoice View ──────────────────────────────────────────────────────────────
export function InvoiceView({ sale, store, onNewSale, onNavigate, printMode = false }) {
  const handlePrint = () => window.print();

  const formatDate = (iso) => {
    const d = new Date(iso);
    return d.toLocaleString('en-IN', { day: '2-digit', month: 'short', year: 'numeric', hour: '2-digit', minute: '2-digit' });
  };

  return (
    <div style={{ maxWidth: '680px', margin: '0 auto' }}>
      {!printMode && (
        <div style={{ display: 'flex', gap: '0.75rem', marginBottom: '1.5rem', flexWrap: 'wrap' }}>
          <div style={{ flex: 1 }}>
            <div style={{ fontSize: '0.75rem', color: 'var(--text-muted)', textTransform: 'uppercase', fontWeight: '600', letterSpacing: '0.05em' }}>Sale Complete</div>
            <div style={{ fontSize: '1.25rem', fontWeight: '700', color: 'var(--text-main)', marginTop: 2 }}>Invoice {sale.invoiceNumber}</div>
          </div>
          <div style={{ display: 'flex', gap: '0.5rem', alignItems: 'flex-start' }}>
            <Button variant="secondary" size="md" onClick={handlePrint}>
              <Printer size={14} style={{ marginRight: 6 }} /> Print
            </Button>
            {onNewSale && (
              <Button variant="primary" size="md" onClick={onNewSale}>
                New Sale
              </Button>
            )}
          </div>
        </div>
      )}

      {/* Invoice document */}
      <div id="invoice-print" style={{ backgroundColor: '#fff', border: '1px solid var(--border-color)', borderRadius: 'var(--radius-lg)', padding: '2rem', boxShadow: 'var(--shadow-sm)' }}>
        {/* Store header */}
        <div style={{ textAlign: 'center', borderBottom: '1px solid var(--border-color)', paddingBottom: '1.25rem', marginBottom: '1.25rem' }}>
          <div style={{ display: 'inline-flex', alignItems: 'center', justifyContent: 'center', width: 44, height: 44, borderRadius: '10px', backgroundColor: '#7EAFD0', color: '#fff', fontWeight: '800', fontSize: '1.25rem', marginBottom: '0.5rem' }}>W</div>
          <div style={{ fontSize: '1.375rem', fontWeight: '800', color: 'var(--text-main)', letterSpacing: '-0.01em' }}>{store?.name || 'Westsides'}</div>
          {store?.address && <div style={{ fontSize: '0.8125rem', color: 'var(--text-muted)', marginTop: 2 }}>{store.address}{store.city ? `, ${store.city}` : ''}</div>}
          {store?.phone && <div style={{ fontSize: '0.8125rem', color: 'var(--text-muted)' }}>{store.phone}</div>}
          {store?.gstNumber && <div style={{ fontSize: '0.8125rem', color: 'var(--text-muted)' }}>GSTIN: {store.gstNumber}</div>}
          {store?.receiptHeader && <div style={{ fontSize: '0.8125rem', color: 'var(--text-muted)', marginTop: 4, fontStyle: 'italic' }}>{store.receiptHeader}</div>}
        </div>

        {/* Invoice meta */}
        <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '1.25rem', flexWrap: 'wrap', gap: '0.5rem' }}>
          <div>
            <div style={{ fontSize: '0.75rem', color: 'var(--text-muted)', textTransform: 'uppercase', fontWeight: '600', marginBottom: 3 }}>Invoice</div>
            <div style={{ fontWeight: '700', fontSize: '1rem', color: 'var(--text-main)' }}>{sale.invoiceNumber}</div>
            <div style={{ fontSize: '0.8125rem', color: 'var(--text-muted)', marginTop: 2 }}>{formatDate(sale.createdAt)}</div>
          </div>
          <div style={{ textAlign: 'right' }}>
            <div style={{ fontSize: '0.75rem', color: 'var(--text-muted)', textTransform: 'uppercase', fontWeight: '600', marginBottom: 3 }}>Cashier</div>
            <div style={{ fontWeight: '500', color: 'var(--text-main)' }}>{sale.cashierName}</div>
          </div>
        </div>

        {/* Customer */}
        {sale.customerName && (
          <div style={{ marginBottom: '1.25rem', padding: '10px 14px', backgroundColor: 'var(--bg-page)', borderRadius: 'var(--radius-md)', border: '1px solid var(--border-subtle)' }}>
            <div style={{ fontSize: '0.75rem', color: 'var(--text-muted)', textTransform: 'uppercase', fontWeight: '600', marginBottom: 4 }}>Customer</div>
            <div style={{ fontWeight: '500', color: 'var(--text-main)' }}>{sale.customerName}</div>
            {sale.customerPhone && <div style={{ fontSize: '0.8125rem', color: 'var(--text-muted)' }}>{sale.customerPhone}</div>}
          </div>
        )}

        {/* Items */}
        <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: '0.875rem', marginBottom: '1.25rem' }}>
          <thead>
            <tr style={{ borderBottom: '2px solid var(--border-color)' }}>
              {['Item', 'Qty', 'Rate', 'Amount'].map(h => (
                <th key={h} style={{ padding: '6px 8px', textAlign: h === 'Item' ? 'left' : 'right', fontWeight: '600', color: 'var(--text-muted)', fontSize: '0.75rem', textTransform: 'uppercase', letterSpacing: '0.04em' }}>{h}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {(sale.items || []).map((item, idx) => (
              <tr key={idx} style={{ borderBottom: '1px solid var(--border-subtle)' }}>
                <td style={{ padding: '8px 8px' }}>
                  <div style={{ fontWeight: '500', color: 'var(--text-main)' }}>{item.productNameSnapshot}</div>
                  <div style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>
                    {[item.sizeSnapshot, item.colorSnapshot].filter(Boolean).join(' / ')}
                    {item.skuSnapshot ? ` • ${item.skuSnapshot}` : ''}
                  </div>
                </td>
                <td style={{ padding: '8px 8px', textAlign: 'right', color: 'var(--text-muted)' }}>{item.quantity}</td>
                <td style={{ padding: '8px 8px', textAlign: 'right', color: 'var(--text-main)' }}>₹{fmt(item.unitPrice)}</td>
                <td style={{ padding: '8px 8px', textAlign: 'right', fontWeight: '600', color: 'var(--text-main)' }}>₹{fmt(item.lineTotal)}</td>
              </tr>
            ))}
          </tbody>
        </table>

        {/* Totals */}
        <div style={{ borderTop: '1px solid var(--border-color)', paddingTop: '1rem', display: 'flex', flexDirection: 'column', gap: '6px', alignItems: 'flex-end' }}>
          {[
            { label: 'Subtotal', val: fmt(sale.subtotal) },
            ...(sale.discountAmount > 0 ? [{ label: `Discount`, val: `-₹${fmt(sale.discountAmount)}`, color: '#10B981' }] : []),
            ...(sale.taxAmount > 0 ? [{ label: `GST (${sale.taxRate}%)`, val: `₹${fmt(sale.taxAmount)}` }] : []),
          ].map(({ label, val, color }) => (
            <div key={label} style={{ display: 'flex', gap: '1.5rem', fontSize: '0.875rem' }}>
              <span style={{ color: 'var(--text-muted)' }}>{label}</span>
              <span style={{ fontWeight: '500', color: color || 'var(--text-main)', minWidth: 80, textAlign: 'right' }}>{val.startsWith('-') ? val : `₹${val}`}</span>
            </div>
          ))}
          <div style={{ display: 'flex', gap: '1.5rem', borderTop: '2px solid var(--border-color)', paddingTop: '8px', marginTop: '4px' }}>
            <span style={{ fontWeight: '700', fontSize: '1rem', color: 'var(--text-main)' }}>Grand Total</span>
            <span style={{ fontWeight: '800', fontSize: '1.125rem', color: '#7EAFD0', minWidth: 80, textAlign: 'right' }}>₹{fmt(sale.totalAmount)}</span>
          </div>
        </div>

        {/* Payment info */}
        <div style={{ marginTop: '1.25rem', padding: '10px 14px', backgroundColor: 'var(--bg-page)', borderRadius: 'var(--radius-md)', border: '1px solid var(--border-subtle)', display: 'flex', justifyContent: 'space-between', flexWrap: 'wrap', gap: '8px' }}>
          <div>
            <div style={{ fontSize: '0.75rem', color: 'var(--text-muted)', textTransform: 'uppercase', fontWeight: '600', marginBottom: 3 }}>Payment</div>
            <div style={{ fontWeight: '600', color: 'var(--text-main)' }}>{sale.paymentMethod}</div>
          </div>
          {sale.paymentMethod === 'CASH' && sale.changeAmount > 0 && (
            <div style={{ textAlign: 'right' }}>
              <div style={{ fontSize: '0.75rem', color: 'var(--text-muted)', textTransform: 'uppercase', fontWeight: '600', marginBottom: 3 }}>Change</div>
              <div style={{ fontWeight: '600', color: '#10B981' }}>₹{fmt(sale.changeAmount)}</div>
            </div>
          )}
        </div>

        {/* Footer */}
        {store?.receiptFooter && (
          <div style={{ textAlign: 'center', marginTop: '1.25rem', paddingTop: '1rem', borderTop: '1px dashed var(--border-color)', fontSize: '0.8125rem', color: 'var(--text-muted)', fontStyle: 'italic' }}>
            {store.receiptFooter}
          </div>
        )}
      </div>

      <style>{`
        @media print {
          body * { visibility: hidden !important; }
          #invoice-print, #invoice-print * { visibility: visible !important; }
          #invoice-print { position: fixed; top: 0; left: 0; right: 0; box-shadow: none !important; border: none !important; }
        }
      `}</style>
    </div>
  );
}
