const express = require('express');
const router = express.Router();
const StoreModel = require('../models/storeModel');
const authMiddleware = require('../middleware/auth');
const tenantIsolationMiddleware = require('../middleware/tenant');
const { requireRole } = require('../middleware/roles');
const { ROLES } = require('../constants/roles');

// Apply auth to all store routes
router.use(authMiddleware);

/**
 * GET /api/store or /api/store/current
 * Returns store details for the current tenant only
 */
router.get(['/', '/current'], tenantIsolationMiddleware, (req, res) => {
  try {
    const store = StoreModel.findById(req.storeId);
    if (!store) {
      return res.status(404).json({ success: false, error: 'Store not found.' });
    }

    return res.json({
      success: true,
      store
    });
  } catch (err) {
    console.error('Fetch store error:', err);
    return res.status(500).json({ success: false, error: 'Unable to retrieve store details.' });
  }
});

/**
 * POST /api/store/onboarding
 * Handles step updates and finalization of onboarding wizard
 */
router.post('/onboarding', tenantIsolationMiddleware, (req, res) => {
  try {
    const {
      step,
      completed,
      name,
      phone,
      address,
      city,
      state,
      country,
      currency,
      category,
      gstNumber,
      receiptHeader,
      receiptFooter
    } = req.body;

    const currentStore = StoreModel.findById(req.storeId);
    if (!currentStore) {
      return res.status(404).json({ success: false, error: 'Store not found.' });
    }

    const updates = {};
    if (step !== undefined) updates.onboardingStep = step;
    if (completed !== undefined) updates.onboardingCompleted = completed;
    if (name !== undefined) updates.name = name;
    if (phone !== undefined) updates.phone = phone;
    if (address !== undefined) updates.address = address;
    if (city !== undefined) updates.city = city;
    if (state !== undefined) updates.state = state;
    if (country !== undefined) updates.country = country;
    if (currency !== undefined) updates.currency = currency;
    if (category !== undefined) updates.category = category;
    if (gstNumber !== undefined) updates.gstNumber = gstNumber;
    if (receiptHeader !== undefined) updates.receiptHeader = receiptHeader;
    if (receiptFooter !== undefined) updates.receiptFooter = receiptFooter;

    const updated = StoreModel.update(req.storeId, updates);

    return res.json({
      success: true,
      message: completed ? 'Store onboarding completed successfully!' : `Step ${step} saved.`,
      store: updated
    });
  } catch (err) {
    console.error('Onboarding update error:', err);
    return res.status(500).json({ success: false, error: 'Failed to update onboarding progress.' });
  }
});

/**
 * PUT /api/store/update
 * Updates store details (restricted to OWNER or MANAGER)
 */
router.put('/update', tenantIsolationMiddleware, requireRole([ROLES.OWNER, ROLES.MANAGER]), (req, res) => {
  try {
    const { name, phone, address, city, state, country, gstNumber, currency, receiptHeader, receiptFooter } = req.body;

    const updated = StoreModel.update(req.storeId, {
      name,
      phone,
      address,
      city,
      state,
      country,
      gstNumber,
      currency,
      receiptHeader,
      receiptFooter
    });

    return res.json({
      success: true,
      message: 'Store settings updated successfully.',
      store: updated
    });
  } catch (err) {
    console.error('Update store error:', err);
    return res.status(500).json({ success: false, error: 'Failed to update store settings.' });
  }
});

/**
 * POST /api/store/test-isolation
 * Live verification test demonstrating multi-tenant security
 * Verifies that requests targeted at an unauthorized tenant ID are blocked
 */
router.post('/test-isolation', (req, res) => {
  const { targetStoreId } = req.body;

  if (!targetStoreId) {
    return res.status(400).json({
      success: false,
      error: 'Please supply a targetStoreId to test tenant security isolation.'
    });
  }

  // Security check: Compare requested target against authenticated tenant context
  if (targetStoreId !== req.storeId) {
    return res.status(403).json({
      success: false,
      isolationEnforced: true,
      code: 'TENANT_ISOLATION_VERIFIED',
      message: `Tenant Isolation Block: User associated with store "${req.storeId}" attempted to access foreign store "${targetStoreId}". Access strictly forbidden.`
    });
  }

  return res.json({
    success: true,
    isolationEnforced: true,
    message: 'Authorized tenant access permitted within boundary.',
    storeId: req.storeId
  });
});

module.exports = router;
