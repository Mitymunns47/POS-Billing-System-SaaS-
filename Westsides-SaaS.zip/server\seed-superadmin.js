/**
 * seed-superadmin.js
 * Creates the Westsides Platform SUPER_ADMIN account.
 * Run with: node server/seed-superadmin.js
 *
 * The Super Admin operates at the PLATFORM level (not store/tenant level).
 * The login flow for Super Admin uses a separate /admin route in the frontend.
 */

const crypto = require('crypto');
const bcrypt = require('bcryptjs');
const db = require('./db/database');
const UserModel = require('./models/userModel');
const PlatformAdminModel = require('./models/platformAdminModel');
const SubscriptionModel = require('./models/subscriptionModel');

function seedSuperAdmin() {
  console.log('\n╔══════════════════════════════════════════════════════════════╗');
  console.log('║  WESTSIDES SAAS — PLATFORM SUPER ADMIN INITIALIZATION       ║');
  console.log('╚══════════════════════════════════════════════════════════════╝\n');

  const superAdminEmail = 'superadmin@westsides.com';
  const superAdminPassword = 'Westsides@SuperAdmin2026!';
  const superAdminName = 'Westsides Platform Admin';
  const superAdminPhone = '+91 98200 11111';

  const salt = bcrypt.genSaltSync(12);
  const passwordHash = bcrypt.hashSync(superAdminPassword, salt);
  const now = new Date().toISOString();

  // 1. Create or update the user account
  let user = UserModel.findByEmail(superAdminEmail);
  if (user) {
    db.prepare('UPDATE users SET passwordHash = ?, name = ?, phone = ?, updatedAt = ? WHERE id = ?')
      .run(passwordHash, superAdminName, superAdminPhone, now, user.id);
    user = UserModel.findByEmail(superAdminEmail);
    console.log(`✓ Updated existing user: ${superAdminEmail} (ID: ${user.id})`);
  } else {
    const userId = 'usr_' + crypto.randomBytes(8).toString('hex');
    db.prepare('INSERT INTO users (id, name, email, phone, passwordHash, createdAt, updatedAt) VALUES (?, ?, ?, ?, ?, ?, ?)')
      .run(userId, superAdminName, superAdminEmail, superAdminPhone, passwordHash, now, now);
    user = UserModel.findById(userId);
    console.log(`✓ Created new user: ${superAdminEmail} (ID: ${user.id})`);
  }

  // 2. Register as Platform Admin (SUPER_ADMIN)
  const existing = PlatformAdminModel.findByUserId(user.id);
  if (!existing) {
    PlatformAdminModel.create({ userId: user.id, platformRole: 'SUPER_ADMIN' });
    console.log(`✓ Registered as SUPER_ADMIN in platform_admins`);
  } else {
    console.log(`✓ Already registered as SUPER_ADMIN`);
  }

  // 3. The Super Admin does NOT belong to a tenant store.
  //    But we need a session-compatible store for login flow.
  //    We create or reuse a "Platform Admin Store" that is ONLY used for session tracking.
  let platformStore = db.prepare("SELECT * FROM stores WHERE name = 'Westsides Platform' LIMIT 1").get();
  if (!platformStore) {
    const storeId = 'str_platform_' + crypto.randomBytes(4).toString('hex');
    db.prepare(`
      INSERT INTO stores (id, name, address, city, state, country, gstNumber, phone, currency, category, onboardingStep, onboardingCompleted, status, createdAt, updatedAt)
      VALUES (?, 'Westsides Platform', 'HQ', 'Mumbai', 'Maharashtra', 'India', '', '', 'INR', 'Platform', 4, 1, 'ACTIVE', ?, ?)
    `).run(storeId, now, now);
    platformStore = db.prepare("SELECT * FROM stores WHERE id = ?").get(storeId);
    console.log(`✓ Created Platform HQ store (ID: ${platformStore.id})`);
  } else {
    console.log(`✓ Found existing Platform HQ store (ID: ${platformStore.id})`);
  }

  // Link Super Admin user to Platform HQ store as OWNER (needed for session resolution)
  const existingLink = db.prepare('SELECT id FROM store_users WHERE userId = ? AND storeId = ?').get(user.id, platformStore.id);
  if (!existingLink) {
    const suId = 'su_' + crypto.randomBytes(8).toString('hex');
    db.prepare('INSERT INTO store_users (id, storeId, userId, role, status, createdAt) VALUES (?, ?, ?, ?, ?, ?)')
      .run(suId, platformStore.id, user.id, 'OWNER', 'ACTIVE', now);
    console.log(`✓ Linked Super Admin to Platform HQ store`);
  } else {
    console.log(`✓ Super Admin already linked to Platform HQ store`);
  }

  // 4. Create subscription for Platform HQ store (Enterprise plan)
  const sub = SubscriptionModel.getStoreSubscription(platformStore.id);
  if (!sub) {
    SubscriptionModel.createSubscription({
      storeId: platformStore.id,
      planId: 'plan_enterprise',
      status: 'ACTIVE',
      trialDays: 0
    });
    console.log(`✓ Assigned Enterprise subscription to Platform HQ`);
  }

  // 5. Verify password
  const verify = bcrypt.compareSync(superAdminPassword, passwordHash);
  if (!verify) throw new Error('Password verification failed! Seeding aborted.');

  console.log('\n╔══════════════════════════════════════════════════════════════╗');
  console.log('║                SUPER ADMIN CREDENTIALS                      ║');
  console.log('╠══════════════════════════════════════════════════════════════╣');
  console.log(`║  Admin Portal:  http://localhost:5000/admin                  ║`);
  console.log(`║  Email:         ${superAdminEmail.padEnd(42)}║`);
  console.log(`║  Password:      ${superAdminPassword.padEnd(42)}║`);
  console.log(`║  Role:          SUPER_ADMIN (Platform Level)                 ║`);
  console.log(`║  User ID:       ${user.id.padEnd(42)}║`);
  console.log('╚══════════════════════════════════════════════════════════════╝\n');

  console.log('⚠  IMPORTANT: Change this password in production!');
  console.log('⚠  The Super Admin has access to ALL tenant data.\n');
}

seedSuperAdmin();
