import React from 'react';

export function Badge({ children, variant = 'default', size = 'sm', className = '', style = {} }) {
  const variantStyles = {
    default: {
      backgroundColor: 'var(--primary-light)',
      color: '#4B7C9E',
      borderColor: '#D4E6F1'
    },
    primary: {
      backgroundColor: '#7EAFD0',
      color: '#FFFFFF',
      borderColor: '#7EAFD0'
    },
    success: {
      backgroundColor: 'var(--success-light)',
      color: '#065F46',
      borderColor: '#A7F3D0'
    },
    warning: {
      backgroundColor: 'var(--warning-light)',
      color: '#92400E',
      borderColor: '#FDE68A'
    },
    danger: {
      backgroundColor: 'var(--danger-light)',
      color: '#991B1B',
      borderColor: '#FECACA'
    },
    neutral: {
      backgroundColor: '#F1F5F9',
      color: '#475569',
      borderColor: '#E2E8F0'
    }
  };

  const sizeStyles = {
    sm: { padding: '2px 8px', fontSize: '0.75rem', fontWeight: '500' },
    md: { padding: '4px 10px', fontSize: '0.8125rem', fontWeight: '600' }
  };

  return (
    <span
      style={{
        display: 'inline-flex',
        alignItems: 'center',
        gap: '4px',
        borderRadius: '9999px',
        border: '1px solid',
        lineHeight: 1.25,
        ...sizeStyles[size],
        ...variantStyles[variant],
        ...style
      }}
      className={className}
    >
      {children}
    </span>
  );
}
