import React, { useState, useEffect, useCallback } from 'react';
import { api } from '../services/api';
import { useAuth } from '../context/AuthContext';
import { Button } from '../components/ui/Button';
import { Input } from '../components/ui/Input';
import { Alert } from '../components/ui/Alert';
import { Badge } from '../components/ui/Badge';
import { Modal } from '../components/ui/Modal';
import {
  Users,
  Search,
  UserPlus,
  Phone,
  Mail,
  MapPin,
  ShoppingBag,
  IndianRupee,
  Edit2,
  ChevronLeft,
  ChevronRight,
  RotateCcw,
  Archive,
  RefreshCw,
  Eye,
  Calendar,
  Filter,
  CheckCircle2,
  AlertTriangle
} from 'lucide-react';

const fmt = (n) => Number(n || 0).toFixed(2);
const PHONE_REGEX = /^[+]?[\d\s-]{7,15}$/;
const EMAIL_REGEX = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

export function CustomersPage({ onNavigate }) {
  const { store, hasPermission } = useAuth();

  const [activeTab, setActiveTab] = useState('ACTIVE'); // 'ACTIVE' or 'ARCHIVED'
  const [customers, setCustomers] = useState([]);
  const [pagination, setPagination] = useState({ page: 1, limit: 15, total: 0, pages: 1 });
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [successMsg, setSuccessMsg] = useState(null);

  // Filters & Sorting
  const [search, setSearch] = useState('');
  const [sortBy, setSortBy] = useState('name');
  const [sortDir, setSortDir] = useState('ASC');

  // Add / Edit Modal state
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingCustomer, setEditingCustomer] = useState(null);
  const [formData, setFormData] = useState({
    name: '',
    phone: '',
    email: '',
    dateOfBirth: '',
    gender: '',
    address: '',
    city: '',
    state: '',
    postalCode: '',
    notes: ''
  });
  const [formErrors, setFormErrors] = useState({});
  const [saving, setSaving] = useState(false);

  // Archive / Restore Confirmation Modal
  const [archiveTarget, setArchiveTarget] = useState(null);
  const [restoreTarget, setRestoreTarget] = useState(null);
  const [actionLoading, setActionLoading] = useState(false);

  // Load customers
  const loadCustomers = useCallback(async (page = 1) => {
    setLoading(true);
    setError(null);
    try {
      const res = await api.getCustomers({
        page,
        limit: pagination.limit,
        status: activeTab,
        search: search.trim() || undefined,
        sortBy,
        sortDir
      });
      if (res.success) {
        setCustomers(res.customers || []);
        setPagination({
          page: res.page || 1,
          limit: res.limit || 15,
          total: res.total || 0,
          pages: res.totalPages || 1
        });
      }
    } catch (err) {
      setError(err.message || 'Failed to load customers.');
    } finally {
      setLoading(false);
    }
  }, [activeTab, search, sortBy, sortDir, pagination.limit]);

  useEffect(() => {
    loadCustomers(1);
  }, [loadCustomers]);

  // Open modal for add
  const handleOpenAdd = () => {
    setEditingCustomer(null);
    setFormData({
      name: '',
      phone: '',
      email: '',
      dateOfBirth: '',
      gender: '',
      address: '',
      city: '',
      state: '',
      postalCode: '',
      notes: ''
    });
    setFormErrors({});
    setIsModalOpen(true);
  };

  // Open modal for edit
  const handleOpenEdit = (c) => {
    setEditingCustomer(c);
    setFormData({
      name: c.name || '',
      phone: c.phone || '',
      email: c.email || '',
      dateOfBirth: c.dateOfBirth || '',
      gender: c.gender || '',
      address: c.address || '',
      city: c.city || '',
      state: c.state || '',
      postalCode: c.postalCode || '',
      notes: c.notes || ''
    });
    setFormErrors({});
    setIsModalOpen(true);
  };

  // Validate form
  const validateForm = () => {
    const errs = {};
    if (!formData.name.trim()) errs.name = 'Full name is required.';

    if (formData.phone && !PHONE_REGEX.test(formData.phone.trim())) {
      errs.phone = 'Please enter a valid phone number (7-15 digits).';
    }

    if (formData.email && !EMAIL_REGEX.test(formData.email.trim())) {
      errs.email = 'Please enter a valid email address.';
    }

    setFormErrors(errs);
    return Object.keys(errs).length === 0;
  };

  // Handle submit
  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!validateForm()) return;

    setSaving(true);
    setFormErrors({});
    try {
      if (editingCustomer) {
        const res = await api.updateCustomer(editingCustomer.id, formData);
        if (res.success) {
          setIsModalOpen(false);
          setSuccessMsg(`Customer "${res.customer.name}" updated successfully.`);
          loadCustomers(pagination.page);
        }
      } else {
        const res = await api.createCustomer(formData);
        if (res.success) {
          setIsModalOpen(false);
          setSuccessMsg(`Customer "${res.customer.name}" created successfully.`);
          loadCustomers(1);
        }
      }
    } catch (err) {
      setFormErrors({ submit: err.message || 'Failed to save customer.' });
    } finally {
      setSaving(false);
    }
  };

  // Handle Archive
  const handleArchiveConfirm = async () => {
    if (!archiveTarget) return;
    setActionLoading(true);
    try {
      const res = await api.archiveCustomer(archiveTarget.id);
      if (res.success) {
        setArchiveTarget(null);
        setSuccessMsg(`Customer "${archiveTarget.name}" has been archived.`);
        loadCustomers(pagination.page);
      }
    } catch (err) {
      setError(err.message || 'Failed to archive customer.');
    } finally {
      setActionLoading(false);
    }
  };

  // Handle Restore
  const handleRestoreConfirm = async () => {
    if (!restoreTarget) return;
    setActionLoading(true);
    try {
      const res = await api.restoreCustomer(restoreTarget.id);
      if (res.success) {
        setRestoreTarget(null);
        setSuccessMsg(`Customer "${restoreTarget.name}" restored to active status.`);
        loadCustomers(pagination.page);
      }
    } catch (err) {
      setError(err.message || 'Failed to restore customer.');
    } finally {
      setActionLoading(false);
    }
  };

  return (
    <div style={{ maxWidth: '1400px', margin: '0 auto', display: 'flex', flexDirection: 'column', gap: '1.5rem' }}>
      {/* Top Header */}
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: '1rem' }}>
        <div>
          <h1 style={{ fontSize: '1.5rem', fontWeight: '700', color: 'var(--text-main)', margin: '0 0 4px 0', letterSpacing: '-0.02em' }}>
            Customer CRM
          </h1>
          <p style={{ margin: 0, color: 'var(--text-muted)', fontSize: '0.875rem' }}>
            Maintain shopper profiles, contact history, and lifetime store spending.
          </p>
        </div>

        <div style={{ display: 'flex', gap: '0.75rem' }}>
          <Button
            variant="outline"
            onClick={() => loadCustomers(pagination.page)}
            style={{ display: 'flex', alignItems: 'center', gap: '6px' }}
          >
            <RotateCcw size={15} />
            Refresh
          </Button>
          <Button
            variant="primary"
            onClick={handleOpenAdd}
            style={{ display: 'flex', alignItems: 'center', gap: '6px' }}
          >
            <UserPlus size={16} />
            Add Customer
          </Button>
        </div>
      </div>

      {successMsg && (
        <Alert variant="success" onClose={() => setSuccessMsg(null)}>
          {successMsg}
        </Alert>
      )}

      {error && (
        <Alert variant="danger" onClose={() => setError(null)}>
          {error}
        </Alert>
      )}

      {/* Tabs & Filter Bar */}
      <div style={{ backgroundColor: '#FFFFFF', borderRadius: 'var(--radius-lg)', border: '1px solid var(--border-color)', padding: '1rem 1.25rem', boxShadow: 'var(--shadow-sm)', display: 'flex', flexDirection: 'column', gap: '1rem' }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: '1rem' }}>
          {/* Tabs */}
          <div style={{ display: 'flex', backgroundColor: 'var(--bg-page)', borderRadius: 'var(--radius-md)', padding: '3px' }}>
            <button
              onClick={() => { setActiveTab('ACTIVE'); }}
              style={{
                border: 'none',
                padding: '6px 16px',
                borderRadius: 'var(--radius-sm)',
                fontSize: '0.8125rem',
                fontWeight: '600',
                cursor: 'pointer',
                backgroundColor: activeTab === 'ACTIVE' ? '#FFFFFF' : 'transparent',
                color: activeTab === 'ACTIVE' ? 'var(--text-main)' : 'var(--text-muted)',
                boxShadow: activeTab === 'ACTIVE' ? 'var(--shadow-sm)' : 'none',
                transition: 'all 0.15s ease'
              }}
            >
              Active Customers
            </button>
            <button
              onClick={() => { setActiveTab('ARCHIVED'); }}
              style={{
                border: 'none',
                padding: '6px 16px',
                borderRadius: 'var(--radius-sm)',
                fontSize: '0.8125rem',
                fontWeight: '600',
                cursor: 'pointer',
                backgroundColor: activeTab === 'ARCHIVED' ? '#FFFFFF' : 'transparent',
                color: activeTab === 'ARCHIVED' ? 'var(--text-main)' : 'var(--text-muted)',
                boxShadow: activeTab === 'ARCHIVED' ? 'var(--shadow-sm)' : 'none',
                transition: 'all 0.15s ease'
              }}
            >
              Archived Customers
            </button>
          </div>

          {/* Search & Sort Controls */}
          <div style={{ display: 'flex', flexWrap: 'wrap', gap: '0.75rem', alignItems: 'center' }}>
            <div style={{ position: 'relative', width: '280px' }}>
              <Search size={15} style={{ position: 'absolute', left: '10px', top: '50%', transform: 'translateY(-50%)', color: 'var(--text-muted)' }} />
              <input
                type="text"
                placeholder="Search name, phone, or email..."
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                style={{
                  width: '100%',
                  padding: '0.5rem 0.75rem 0.5rem 2rem',
                  border: '1px solid var(--border-color)',
                  borderRadius: 'var(--radius-md)',
                  fontSize: '0.8125rem',
                  color: 'var(--text-main)',
                  backgroundColor: 'var(--bg-page)',
                  outline: 'none'
                }}
              />
            </div>

            <select
              value={`${sortBy}-${sortDir}`}
              onChange={(e) => {
                const [sb, sd] = e.target.value.split('-');
                setSortBy(sb);
                setSortDir(sd);
              }}
              style={{
                padding: '0.5rem 0.75rem',
                border: '1px solid var(--border-color)',
                borderRadius: 'var(--radius-md)',
                fontSize: '0.8125rem',
                color: 'var(--text-main)',
                backgroundColor: 'var(--bg-page)',
                outline: 'none'
              }}
            >
              <option value="name-ASC">Sort: Name (A-Z)</option>
              <option value="name-DESC">Sort: Name (Z-A)</option>
              <option value="totalSpent-DESC">Sort: Highest Spender</option>
              <option value="totalPurchases-DESC">Sort: Most Orders</option>
              <option value="createdAt-DESC">Sort: Recently Added</option>
            </select>
          </div>
        </div>
      </div>

      {/* Customer Table */}
      <div style={{ backgroundColor: '#FFFFFF', borderRadius: 'var(--radius-lg)', border: '1px solid var(--border-color)', boxShadow: 'var(--shadow-sm)', overflow: 'hidden' }}>
        <div style={{ overflowX: 'auto' }}>
          <table style={{ width: '100%', borderCollapse: 'collapse', textAlign: 'left', fontSize: '0.875rem' }}>
            <thead>
              <tr style={{ backgroundColor: 'var(--bg-page)', borderBottom: '1px solid var(--border-color)' }}>
                <th style={{ padding: '0.875rem 1rem', fontWeight: '600', color: 'var(--text-muted)', fontSize: '0.75rem', textTransform: 'uppercase', letterSpacing: '0.04em' }}>Customer Name</th>
                <th style={{ padding: '0.875rem 1rem', fontWeight: '600', color: 'var(--text-muted)', fontSize: '0.75rem', textTransform: 'uppercase', letterSpacing: '0.04em' }}>Phone</th>
                <th style={{ padding: '0.875rem 1rem', fontWeight: '600', color: 'var(--text-muted)', fontSize: '0.75rem', textTransform: 'uppercase', letterSpacing: '0.04em' }}>Email</th>
                <th style={{ padding: '0.875rem 1rem', fontWeight: '600', color: 'var(--text-muted)', fontSize: '0.75rem', textTransform: 'uppercase', letterSpacing: '0.04em', textAlign: 'center' }}>Total Orders</th>
                <th style={{ padding: '0.875rem 1rem', fontWeight: '600', color: 'var(--text-muted)', fontSize: '0.75rem', textTransform: 'uppercase', letterSpacing: '0.04em', textAlign: 'right' }}>Total Spent</th>
                <th style={{ padding: '0.875rem 1rem', fontWeight: '600', color: 'var(--text-muted)', fontSize: '0.75rem', textTransform: 'uppercase', letterSpacing: '0.04em' }}>Status</th>
                <th style={{ padding: '0.875rem 1rem', fontWeight: '600', color: 'var(--text-muted)', fontSize: '0.75rem', textTransform: 'uppercase', letterSpacing: '0.04em', textAlign: 'right' }}>Actions</th>
              </tr>
            </thead>
            <tbody>
              {loading ? (
                <tr>
                  <td colSpan="7" style={{ padding: '3rem 1rem', textAlign: 'center', color: 'var(--text-muted)' }}>
                    <div style={{ display: 'inline-block', width: '20px', height: '20px', border: '2px solid #7EAFD0', borderTopColor: 'transparent', borderRadius: '50%', animation: 'spin 0.8s linear infinite', marginBottom: '8px' }} />
                    <div>Loading customers...</div>
                  </td>
                </tr>
              ) : customers.length === 0 ? (
                <tr>
                  <td colSpan="7" style={{ padding: '3.5rem 1rem', textAlign: 'center' }}>
                    <div style={{ width: '48px', height: '48px', borderRadius: '50%', backgroundColor: 'var(--bg-page)', display: 'inline-flex', alignItems: 'center', justifyContent: 'center', color: 'var(--text-muted)', marginBottom: '12px' }}>
                      <Users size={24} />
                    </div>
                    <div style={{ fontWeight: '600', color: 'var(--text-main)', marginBottom: '4px' }}>
                      {activeTab === 'ACTIVE' ? 'No active customers found' : 'No archived customers'}
                    </div>
                    <div style={{ color: 'var(--text-muted)', fontSize: '0.8125rem', marginBottom: '1rem' }}>
                      {search ? 'Try clearing your search query.' : 'Add your first customer profile or select customers during POS checkout.'}
                    </div>
                    {activeTab === 'ACTIVE' && (
                      <Button variant="primary" size="sm" onClick={handleOpenAdd}>
                        Add First Customer
                      </Button>
                    )}
                  </td>
                </tr>
              ) : (
                customers.map((c) => (
                  <tr key={c.id} style={{ borderBottom: '1px solid var(--border-subtle)', transition: 'background-color 0.15s ease' }}>
                    {/* Name */}
                    <td style={{ padding: '0.875rem 1rem', fontWeight: '600', color: '#172033' }}>
                      <div
                        onClick={() => onNavigate(`/customers/${c.id}`)}
                        style={{ display: 'flex', alignItems: 'center', gap: '10px', cursor: 'pointer' }}
                        title="Click to view Customer Profile"
                      >
                        <div style={{ width: '32px', height: '32px', borderRadius: '50%', backgroundColor: 'rgba(126, 175, 208, 0.15)', color: '#7EAFD0', display: 'flex', alignItems: 'center', justifyContent: 'center', fontWeight: '700', fontSize: '0.8125rem' }}>
                          {c.name.charAt(0).toUpperCase()}
                        </div>
                        <div>
                          <span style={{ color: '#172033', textDecoration: 'none' }} className="hover:text-primary">
                            {c.name}
                          </span>
                          {c.city && <div style={{ fontSize: '0.75rem', color: 'var(--text-muted)', fontWeight: '400' }}>{c.city}</div>}
                        </div>
                      </div>
                    </td>

                    {/* Phone */}
                    <td style={{ padding: '0.875rem 1rem', color: 'var(--text-muted)' }}>
                      {c.phone ? (
                        <div style={{ display: 'flex', alignItems: 'center', gap: '4px' }}>
                          <Phone size={13} style={{ color: 'var(--text-muted)' }} />
                          <span>{c.phone}</span>
                        </div>
                      ) : (
                        <span style={{ color: 'var(--border-color)', fontSize: '0.8125rem' }}>—</span>
                      )}
                    </td>

                    {/* Email */}
                    <td style={{ padding: '0.875rem 1rem', color: 'var(--text-muted)' }}>
                      {c.email ? (
                        <div style={{ display: 'flex', alignItems: 'center', gap: '4px' }}>
                          <Mail size={13} style={{ color: 'var(--text-muted)' }} />
                          <span>{c.email}</span>
                        </div>
                      ) : (
                        <span style={{ color: 'var(--border-color)', fontSize: '0.8125rem' }}>—</span>
                      )}
                    </td>

                    {/* Total Orders */}
                    <td style={{ padding: '0.875rem 1rem', textAlign: 'center', fontWeight: '600', color: 'var(--text-main)' }}>
                      {c.totalPurchases || 0}
                    </td>

                    {/* Total Spent */}
                    <td style={{ padding: '0.875rem 1rem', textAlign: 'right', fontWeight: '700', color: '#172033' }}>
                      ₹{fmt(c.totalSpent)}
                    </td>

                    {/* Status */}
                    <td style={{ padding: '0.875rem 1rem' }}>
                      {c.status === 'ARCHIVED' ? (
                        <Badge variant="neutral" size="sm">Archived</Badge>
                      ) : (
                        <Badge variant="success" size="sm">Active</Badge>
                      )}
                    </td>

                    {/* Actions */}
                    <td style={{ padding: '0.875rem 1rem', textAlign: 'right' }}>
                      <div style={{ display: 'inline-flex', gap: '6px' }}>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => onNavigate(`/customers/${c.id}`)}
                          title="View Profile & Purchase History"
                          style={{ padding: '4px 8px' }}
                        >
                          <Eye size={14} />
                        </Button>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => handleOpenEdit(c)}
                          title="Edit Customer"
                          style={{ padding: '4px 8px' }}
                        >
                          <Edit2 size={14} />
                        </Button>
                        {c.status === 'ARCHIVED' ? (
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => setRestoreTarget(c)}
                            title="Restore Customer"
                            style={{ padding: '4px 8px', color: '#10B981' }}
                          >
                            <RefreshCw size={14} />
                          </Button>
                        ) : (
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => setArchiveTarget(c)}
                            title="Archive Customer"
                            style={{ padding: '4px 8px', color: '#EF4444' }}
                          >
                            <Archive size={14} />
                          </Button>
                        )}
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>

        {/* Pagination Bar */}
        {pagination.pages > 1 && (
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '0.875rem 1.25rem', borderTop: '1px solid var(--border-color)', backgroundColor: 'var(--bg-page)', fontSize: '0.8125rem', color: 'var(--text-muted)' }}>
            <div>
              Showing {((pagination.page - 1) * pagination.limit) + 1} to {Math.min(pagination.page * pagination.limit, pagination.total)} of {pagination.total} customers
            </div>
            <div style={{ display: 'flex', gap: '6px' }}>
              <Button
                variant="outline"
                size="sm"
                disabled={pagination.page <= 1}
                onClick={() => loadCustomers(pagination.page - 1)}
              >
                <ChevronLeft size={14} /> Previous
              </Button>
              <div style={{ display: 'flex', alignItems: 'center', padding: '0 8px', fontWeight: '600', color: 'var(--text-main)' }}>
                {pagination.page} / {pagination.pages}
              </div>
              <Button
                variant="outline"
                size="sm"
                disabled={pagination.page >= pagination.pages}
                onClick={() => loadCustomers(pagination.page + 1)}
              >
                Next <ChevronRight size={14} />
              </Button>
            </div>
          </div>
        )}
      </div>

      {/* Add / Edit Customer Modal */}
      <Modal
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        title={editingCustomer ? 'Edit Customer Profile' : 'Add New Customer'}
        width="560px"
      >
        <form onSubmit={handleSubmit} style={{ display: 'flex', flexDirection: 'column', gap: '1rem' }}>
          {formErrors.submit && (
            <Alert variant="danger">
              {formErrors.submit}
            </Alert>
          )}

          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(220px, 1fr))', gap: '1rem' }}>
            <Input
              label="Full Name *"
              placeholder="e.g. Rahul Sharma"
              value={formData.name}
              onChange={(e) => setFormData({ ...formData, name: e.target.value })}
              error={formErrors.name}
              required
            />
            <Input
              label="Phone Number"
              placeholder="e.g. +91 98765 43210"
              value={formData.phone}
              onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
              error={formErrors.phone}
            />
          </div>

          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(220px, 1fr))', gap: '1rem' }}>
            <Input
              label="Email Address"
              type="email"
              placeholder="e.g. rahul@example.com"
              value={formData.email}
              onChange={(e) => setFormData({ ...formData, email: e.target.value })}
              error={formErrors.email}
            />
            <div>
              <label style={{ display: 'block', fontSize: '0.8125rem', fontWeight: '600', color: 'var(--text-main)', marginBottom: '4px' }}>
                Gender
              </label>
              <select
                value={formData.gender}
                onChange={(e) => setFormData({ ...formData, gender: e.target.value })}
                style={{
                  width: '100%',
                  padding: '0.625rem 0.875rem',
                  border: '1px solid var(--border-color)',
                  borderRadius: 'var(--radius-md)',
                  fontSize: '0.875rem',
                  color: 'var(--text-main)',
                  backgroundColor: 'var(--bg-page)',
                  outline: 'none'
                }}
              >
                <option value="">Select Gender (optional)</option>
                <option value="Male">Male</option>
                <option value="Female">Female</option>
                <option value="Other">Other</option>
              </select>
            </div>
          </div>

          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(220px, 1fr))', gap: '1rem' }}>
            <Input
              label="Date of Birth"
              type="date"
              value={formData.dateOfBirth}
              onChange={(e) => setFormData({ ...formData, dateOfBirth: e.target.value })}
            />
            <Input
              label="City"
              placeholder="e.g. Mumbai"
              value={formData.city}
              onChange={(e) => setFormData({ ...formData, city: e.target.value })}
            />
          </div>

          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(220px, 1fr))', gap: '1rem' }}>
            <Input
              label="State"
              placeholder="e.g. Maharashtra"
              value={formData.state}
              onChange={(e) => setFormData({ ...formData, state: e.target.value })}
            />
            <Input
              label="Postal Code"
              placeholder="e.g. 400050"
              value={formData.postalCode}
              onChange={(e) => setFormData({ ...formData, postalCode: e.target.value })}
            />
          </div>

          <div>
            <label style={{ display: 'block', fontSize: '0.8125rem', fontWeight: '600', color: 'var(--text-main)', marginBottom: '4px' }}>
              Street Address
            </label>
            <input
              type="text"
              placeholder="e.g. 14 Linking Road, Bandra West"
              value={formData.address}
              onChange={(e) => setFormData({ ...formData, address: e.target.value })}
              style={{
                width: '100%',
                padding: '0.625rem 0.875rem',
                border: '1px solid var(--border-color)',
                borderRadius: 'var(--radius-md)',
                fontSize: '0.875rem',
                color: 'var(--text-main)',
                backgroundColor: 'var(--bg-page)',
                outline: 'none'
              }}
            />
          </div>

          <div>
            <label style={{ display: 'block', fontSize: '0.8125rem', fontWeight: '600', color: 'var(--text-main)', marginBottom: '4px' }}>
              Notes / Apparel Preferences
            </label>
            <textarea
              rows="2"
              placeholder="e.g. Prefers slim-fit shirts and size M. VIP regular shopper."
              value={formData.notes}
              onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
              style={{
                width: '100%',
                padding: '0.625rem 0.875rem',
                border: '1px solid var(--border-color)',
                borderRadius: 'var(--radius-md)',
                fontSize: '0.875rem',
                color: 'var(--text-main)',
                backgroundColor: 'var(--bg-page)',
                resize: 'vertical',
                outline: 'none',
                fontFamily: 'inherit'
              }}
            />
          </div>

          <div style={{ display: 'flex', justifyContent: 'flex-end', gap: '0.75rem', marginTop: '0.5rem' }}>
            <Button
              type="button"
              variant="outline"
              onClick={() => setIsModalOpen(false)}
              disabled={saving}
            >
              Cancel
            </Button>
            <Button
              type="submit"
              variant="primary"
              loading={saving}
            >
              {editingCustomer ? 'Save Changes' : 'Create Customer'}
            </Button>
          </div>
        </form>
      </Modal>

      {/* Archive Confirmation Modal */}
      {archiveTarget && (
        <Modal
          isOpen={Boolean(archiveTarget)}
          onClose={() => setArchiveTarget(null)}
          title="Archive Customer Profile"
          width="440px"
        >
          <div style={{ display: 'flex', flexDirection: 'column', gap: '1rem' }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: '10px', color: '#EF4444' }}>
              <Archive size={22} />
              <span style={{ fontWeight: '700', fontSize: '1rem', color: 'var(--text-main)' }}>
                Archive {archiveTarget.name}?
              </span>
            </div>
            <p style={{ margin: 0, fontSize: '0.875rem', color: 'var(--text-muted)', lineHeight: '1.5' }}>
              Archiving hides this customer from the default list and POS search. <strong>Their historical sales and purchase records will remain completely intact</strong>. You can restore this customer at any time.
            </p>
            <div style={{ display: 'flex', justifyContent: 'flex-end', gap: '0.75rem', marginTop: '0.5rem' }}>
              <Button variant="outline" disabled={actionLoading} onClick={() => setArchiveTarget(null)}>
                Cancel
              </Button>
              <Button variant="danger" loading={actionLoading} onClick={handleArchiveConfirm}>
                Confirm Archive
              </Button>
            </div>
          </div>
        </Modal>
      )}

      {/* Restore Confirmation Modal */}
      {restoreTarget && (
        <Modal
          isOpen={Boolean(restoreTarget)}
          onClose={() => setRestoreTarget(null)}
          title="Restore Customer Profile"
          width="440px"
        >
          <div style={{ display: 'flex', flexDirection: 'column', gap: '1rem' }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: '10px', color: '#10B981' }}>
              <RefreshCw size={20} />
              <span style={{ fontWeight: '700', fontSize: '1rem', color: 'var(--text-main)' }}>
                Restore {restoreTarget.name}?
              </span>
            </div>
            <p style={{ margin: 0, fontSize: '0.875rem', color: 'var(--text-muted)', lineHeight: '1.5' }}>
              This will restore the customer to the active directory and re-enable them in the POS customer search.
            </p>
            <div style={{ display: 'flex', justifyContent: 'flex-end', gap: '0.75rem', marginTop: '0.5rem' }}>
              <Button variant="outline" disabled={actionLoading} onClick={() => setRestoreTarget(null)}>
                Cancel
              </Button>
              <Button variant="primary" loading={actionLoading} onClick={handleRestoreConfirm}>
                Restore Customer
              </Button>
            </div>
          </div>
        </Modal>
      )}
    </div>
  );
}
