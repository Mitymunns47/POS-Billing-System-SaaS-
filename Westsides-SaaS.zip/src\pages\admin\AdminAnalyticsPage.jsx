/**
 * AdminAnalyticsPage.jsx — Phase 7
 * Platform-wide analytics: store growth, revenue, plan distribution, top stores.
 */
import React, { useEffect, useState } from 'react';
import { api } from '../../services/api';

const COLORS = {
  card: '#1E293B', border: 'rgba(126,175,208,0.12)',
  text: '#F1F5F9', muted: '#64748B', accent: '#7EAFD0',
  success: '#10B981', warn: '#F59E0B', danger: '#EF4444'
};

const PLAN_COLORS = { free: '#64748B', basic: '#7EAFD0', pro: '#F59E0B', enterprise: '#10B981' };

function Section({ title, children }) {
  return (
    <div style={{ background: COLORS.card, border: `1px solid ${COLORS.border}`, borderRadius: '12px', padding: '1.25rem', marginBottom: '1.25rem' }}>
      <h3 style={{ color: COLORS.text, fontSize: '0.9375rem', fontWeight: '600', margin: '0 0 1rem' }}>{title}</h3>
      {children}
    </div>
  );
}

function BarChart({ data, xKey, yKey, color = COLORS.accent, yFormat = v => v }) {
  const max = Math.max(...data.map(d => d[yKey]), 1);
  return (
    <div style={{ display: 'flex', alignItems: 'flex-end', gap: '0.375rem', height: '120px', paddingTop: '1rem' }}>
      {data.map((d, i) => (
        <div key={i} style={{ flex: 1, display: 'flex', flexDirection: 'column', alignItems: 'center', gap: '0.25rem' }}>
          <div style={{ color: COLORS.muted, fontSize: '0.625rem' }}>{yFormat(d[yKey])}</div>
          <div style={{
            width: '100%', background: color, borderRadius: '4px 4px 0 0',
            height: `${((d[yKey] || 0) / max) * 80}px`, minHeight: '3px',
            opacity: 0.75, transition: 'height 0.3s'
          }} />
          <div style={{ color: COLORS.muted, fontSize: '0.625rem', textAlign: 'center' }}>
            {String(d[xKey]).slice(-5)}
          </div>
        </div>
      ))}
    </div>
  );
}

export function AdminAnalyticsPage() {
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    api.adminGetAnalytics()
      .then(res => { if (res.success) setData(res.analytics); else setError('Failed to load analytics.'); })
      .catch(err => setError(err.message))
      .finally(() => setLoading(false));
  }, []);

  if (loading) return <div style={{ color: COLORS.muted, padding: '3rem', textAlign: 'center' }}>Loading analytics...</div>;
  if (error) return <div style={{ color: COLORS.danger, padding: '2rem' }}>{error}</div>;
  if (!data) return null;

  const { storeGrowth, revenueByMonth, planDistribution, statusDistribution, topStores, churnThisMonth } = data;

  const fmtK = v => v >= 1000 ? `₹${(v / 1000).toFixed(1)}k` : `₹${v}`;

  return (
    <div style={{ padding: '1.75rem', fontFamily: "'Inter', 'Segoe UI', sans-serif" }}>
      <div style={{ marginBottom: '1.5rem' }}>
        <h1 style={{ color: COLORS.text, fontSize: '1.375rem', fontWeight: '700', margin: '0 0 0.25rem' }}>Platform Analytics</h1>
        <p style={{ color: COLORS.muted, fontSize: '0.875rem', margin: 0 }}>Growth trends, revenue, and tenant health overview</p>
      </div>

      {/* Summary stats */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(200px, 1fr))', gap: '1rem', marginBottom: '1.25rem' }}>
        <div style={{ background: COLORS.card, border: `1px solid ${COLORS.border}`, borderRadius: '12px', padding: '1.25rem' }}>
          <div style={{ color: COLORS.muted, fontSize: '0.8125rem', marginBottom: '0.5rem' }}>Churn This Month</div>
          <div style={{ color: churnThisMonth > 0 ? COLORS.danger : COLORS.success, fontSize: '1.75rem', fontWeight: '700' }}>{churnThisMonth}</div>
          <div style={{ color: COLORS.muted, fontSize: '0.75rem', marginTop: '0.25rem' }}>Cancelled subscriptions</div>
        </div>
        {statusDistribution.map(s => (
          <div key={s.status} style={{ background: COLORS.card, border: `1px solid ${COLORS.border}`, borderRadius: '12px', padding: '1.25rem' }}>
            <div style={{ color: COLORS.muted, fontSize: '0.8125rem', marginBottom: '0.5rem' }}>{s.status} Stores</div>
            <div style={{ color: s.status === 'ACTIVE' ? COLORS.success : s.status === 'SUSPENDED' ? COLORS.warn : COLORS.danger, fontSize: '1.75rem', fontWeight: '700' }}>{s.count}</div>
          </div>
        ))}
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '1.25rem' }}>
        {/* Store growth */}
        {storeGrowth.length > 0 && (
          <Section title="Store Registrations (Monthly)">
            <BarChart data={storeGrowth} xKey="month" yKey="count" color={COLORS.accent} />
          </Section>
        )}

        {/* Revenue */}
        {revenueByMonth.length > 0 && (
          <Section title="Subscription Revenue (Monthly)">
            <BarChart data={revenueByMonth} xKey="month" yKey="revenue" color={COLORS.success} yFormat={fmtK} />
          </Section>
        )}
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '1.25rem', marginBottom: '1.25rem' }}>
        {/* Plan distribution */}
        <Section title="Plan Distribution">
          {planDistribution.map(p => {
            const pct = planDistribution.reduce((s, x) => s + x.stores, 0);
            return (
              <div key={p.slug} style={{ marginBottom: '0.75rem' }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '0.8125rem', marginBottom: '0.25rem' }}>
                  <span style={{ color: COLORS.text, fontWeight: '500' }}>{p.name}</span>
                  <span style={{ color: COLORS.muted }}>{p.stores} stores</span>
                </div>
                <div style={{ height: '6px', background: '#263348', borderRadius: '3px', overflow: 'hidden' }}>
                  <div style={{ height: '100%', width: pct > 0 ? `${(p.stores / pct) * 100}%` : '0%', background: PLAN_COLORS[p.slug] || COLORS.accent, borderRadius: '3px', transition: 'width 0.3s' }} />
                </div>
              </div>
            );
          })}
        </Section>

        {/* Top stores */}
        <Section title="Top Stores by Revenue">
          {topStores.length === 0 ? (
            <p style={{ color: COLORS.muted, fontSize: '0.875rem' }}>No revenue data yet.</p>
          ) : topStores.slice(0, 8).map((s, i) => (
            <div key={s.id} style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '0.5rem 0', borderBottom: `1px solid ${COLORS.border}`, fontSize: '0.8125rem' }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: '0.625rem' }}>
                <span style={{ color: COLORS.muted, width: '20px', textAlign: 'right', flexShrink: 0 }}>#{i + 1}</span>
                <div>
                  <div style={{ color: COLORS.text, fontWeight: '500' }}>{s.name}</div>
                  <div style={{ color: COLORS.muted, fontSize: '0.6875rem' }}>{s.city} · {s.saleCount} sales</div>
                </div>
              </div>
              <span style={{ color: COLORS.success, fontWeight: '600' }}>
                {s.storeRevenue >= 1000 ? `₹${(s.storeRevenue / 1000).toFixed(1)}k` : `₹${Math.round(s.storeRevenue)}`}
              </span>
            </div>
          ))}
        </Section>
      </div>
    </div>
  );
}
