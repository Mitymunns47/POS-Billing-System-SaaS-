const express = require('express');
const router = express.Router();
const ExpenseModel = require('../models/expenseModel');
const ActivityLogModel = require('../models/activityLogModel');
const authMiddleware = require('../middleware/auth');
const { requirePermission } = require('../middleware/roles');
const { PERMISSIONS } = require('../constants/roles');

router.use(authMiddleware);

// GET /api/expenses — List paginated expenses
router.get('/', requirePermission(PERMISSIONS.EXPENSES_VIEW), (req, res) => {
  try {
    const { search, category, status, startDate, endDate, page = 1, limit = 20, sortBy, sortDir } = req.query;

    const result = ExpenseModel.findAll({
      storeId: req.storeId,
      search: search || '',
      category: category || '',
      status: status || 'ACTIVE',
      startDate: startDate || '',
      endDate: endDate || '',
      page: parseInt(page) || 1,
      limit: Math.min(parseInt(limit) || 20, 100),
      sortBy: sortBy || 'date',
      sortDir: sortDir || 'DESC'
    });

    res.json({
      success: true,
      categories: ExpenseModel.CATEGORIES,
      ...result
    });
  } catch (err) {
    console.error('List expenses error:', err);
    res.status(500).json({ success: false, error: 'Could not load expenses.' });
  }
});

// GET /api/expenses/summary — Expense analytics by category and over time
router.get('/summary', requirePermission(PERMISSIONS.EXPENSES_VIEW), (req, res) => {
  try {
    const { startDate, endDate } = req.query;
    const summary = ExpenseModel.getSummary({
      storeId: req.storeId,
      startDate: startDate || '',
      endDate: endDate || ''
    });

    res.json({ success: true, ...summary });
  } catch (err) {
    console.error('Expense summary error:', err);
    res.status(500).json({ success: false, error: 'Could not load expense summary.' });
  }
});

// POST /api/expenses — Create an expense
router.post('/', requirePermission(PERMISSIONS.EXPENSES_MANAGE), (req, res) => {
  try {
    const { title, category, amount, date, notes } = req.body;

    const expense = ExpenseModel.create({
      storeId: req.storeId,
      title,
      category,
      amount,
      date,
      notes,
      createdBy: req.auth.userName
    });

    // Activity Log
    ActivityLogModel.log({
      storeId: req.storeId,
      userId: req.auth.userId,
      userName: req.auth.userName,
      action: 'EXPENSE_CREATED',
      module: 'Expenses',
      description: `Added expense: ${expense.title} (₹${expense.amount}) in ${expense.category}`,
      recordId: expense.id
    });

    res.status(201).json({ success: true, message: 'Expense recorded successfully.', expense });
  } catch (err) {
    console.error('Create expense error:', err);
    res.status(400).json({ success: false, error: err.message || 'Could not record expense.' });
  }
});

// PUT /api/expenses/:id — Update expense
router.put('/:id', requirePermission(PERMISSIONS.EXPENSES_MANAGE), (req, res) => {
  try {
    const { title, category, amount, date, notes } = req.body;

    const expense = ExpenseModel.update(req.params.id, req.storeId, {
      title,
      category,
      amount,
      date,
      notes
    });

    ActivityLogModel.log({
      storeId: req.storeId,
      userId: req.auth.userId,
      userName: req.auth.userName,
      action: 'EXPENSE_UPDATED',
      module: 'Expenses',
      description: `Updated expense: ${expense.title} (₹${expense.amount})`,
      recordId: expense.id
    });

    res.json({ success: true, message: 'Expense updated successfully.', expense });
  } catch (err) {
    console.error('Update expense error:', err);
    res.status(400).json({ success: false, error: err.message || 'Could not update expense.' });
  }
});

// PATCH /api/expenses/:id/archive — Archive expense
router.patch('/:id/archive', requirePermission(PERMISSIONS.EXPENSES_MANAGE), (req, res) => {
  try {
    const expense = ExpenseModel.archive(req.params.id, req.storeId);

    ActivityLogModel.log({
      storeId: req.storeId,
      userId: req.auth.userId,
      userName: req.auth.userName,
      action: 'EXPENSE_ARCHIVED',
      module: 'Expenses',
      description: `Archived expense: ${expense.title}`,
      recordId: expense.id
    });

    res.json({ success: true, message: 'Expense archived.', expense });
  } catch (err) {
    console.error('Archive expense error:', err);
    res.status(400).json({ success: false, error: err.message || 'Could not archive expense.' });
  }
});

// PATCH /api/expenses/:id/restore — Restore archived expense
router.patch('/:id/restore', requirePermission(PERMISSIONS.EXPENSES_MANAGE), (req, res) => {
  try {
    const expense = ExpenseModel.restore(req.params.id, req.storeId);

    ActivityLogModel.log({
      storeId: req.storeId,
      userId: req.auth.userId,
      userName: req.auth.userName,
      action: 'EXPENSE_RESTORED',
      module: 'Expenses',
      description: `Restored expense: ${expense.title}`,
      recordId: expense.id
    });

    res.json({ success: true, message: 'Expense restored to active status.', expense });
  } catch (err) {
    console.error('Restore expense error:', err);
    res.status(400).json({ success: false, error: err.message || 'Could not restore expense.' });
  }
});

module.exports = router;
