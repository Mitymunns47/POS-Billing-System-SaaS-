import React, { useState, useEffect } from 'react';
import { api } from '../services/api';
import { useAuth } from '../context/AuthContext';
import { Card } from '../components/ui/Card';
import { Badge } from '../components/ui/Badge';
import { Button } from '../components/ui/Button';
import {
  RotateCcw,
  Search,
  CheckCircle2,
  AlertTriangle,
  FileText,
  Printer,
  Calendar,
  User,
  ArrowRight,
  Package,
  ShieldAlert,
  Clock,
  ExternalLink,
  X
} from 'lucide-react';

export function ReturnsPage({ initialTab = 'process', saleIdFromUrl = null, onNavigate }) {
  const { user } = useAuth();
  const [activeTab, setActiveTab] = useState(initialTab); // 'process' | 'history'

  // Tab 1: Process Return State
  const [searchSaleQuery, setSearchSaleQuery] = useState('');
  const [searchingSales, setSearchingSales] = useState(false);
  const [eligibleSales, setEligibleSales] = useState([]);
  const [selectedSaleId, setSelectedSaleId] = useState(saleIdFromUrl);
  const [saleDetails, setSaleDetails] = useState(null);
  const [loadingSaleDetails, setLoadingSaleDetails] = useState(false);

  // Return Form State
  const [selectedItems, setSelectedItems] = useState({}); // { [saleItemId]: { selected: boolean, quantity: number, condition: 'RESELLABLE' | 'DAMAGED' } }
  const [returnReason, setReturnReason] = useState('Wrong Size');
  const [returnNotes, setReturnNotes] = useState('');
  const [refundMethod, setRefundMethod] = useState('');
  const [submittingReturn, setSubmittingReturn] = useState(false);
  const [returnSuccessResult, setReturnSuccessResult] = useState(null);
  const [processError, setProcessError] = useState('');

  // Tab 2: Return History State
  const [historyList, setHistoryList] = useState([]);
  const [historyPagination, setHistoryPagination] = useState({ page: 1, limit: 15, total: 0 });
  const [historyLoading, setHistoryLoading] = useState(false);
  const [historySearch, setHistorySearch] = useState('');
  const [historyMethodFilter, setHistoryMethodFilter] = useState('');
  const [selectedReturnDetail, setSelectedReturnDetail] = useState(null);

  // Auto-search or load sale if saleId provided
  useEffect(() => {
    if (saleIdFromUrl) {
      setSelectedSaleId(saleIdFromUrl);
      loadSaleDetails(saleIdFromUrl);
    } else {
      searchSales();
    }
  }, [saleIdFromUrl]);

  useEffect(() => {
    if (activeTab === 'history') {
      loadReturnHistory();
    }
  }, [activeTab, historySearch, historyMethodFilter, historyPagination.page]);

  // Search eligible sales
  const searchSales = async (query = searchSaleQuery) => {
    setSearchingSales(true);
    try {
      const res = await api.getReturnableSales({ search: query, limit: 10 });
      if (res.success) {
        setEligibleSales(res.data.sales || []);
      }
    } catch (err) {
      console.error('Search sales error:', err);
    } finally {
      setSearchingSales(false);
    }
  };

  // Load specific sale for return processing
  const loadSaleDetails = async (id) => {
    setLoadingSaleDetails(true);
    setProcessError('');
    setReturnSuccessResult(null);
    try {
      const res = await api.getSaleReturnDetails(id);
      if (res.success) {
        setSaleDetails(res.data);
        setSelectedSaleId(id);
        setRefundMethod(res.data.sale.paymentMethod || 'CASH');

        // Pre-populate items selectable map
        const initialMap = {};
        res.data.items.forEach(it => {
          if (it.availableQty > 0) {
            initialMap[it.id] = {
              selected: false,
              quantity: 1,
              condition: 'RESELLABLE'
            };
          }
        });
        setSelectedItems(initialMap);
      }
    } catch (err) {
      setProcessError(err.message || 'Could not load sale transaction details.');
    } finally {
      setLoadingSaleDetails(false);
    }
  };

  // Load return history
  const loadReturnHistory = async () => {
    setHistoryLoading(true);
    try {
      const res = await api.getReturns({
        search: historySearch,
        refundMethod: historyMethodFilter,
        page: historyPagination.page,
        limit: historyPagination.limit
      });
      if (res.success) {
        setHistoryList(res.data.returns || []);
        setHistoryPagination(res.data.pagination || { page: 1, limit: 15, total: 0 });
      }
    } catch (err) {
      console.error('Load return history error:', err);
    } finally {
      setHistoryLoading(false);
    }
  };

  // Toggle item selection
  const handleToggleItem = (itemId) => {
    setSelectedItems(prev => ({
      ...prev,
      [itemId]: {
        ...prev[itemId],
        selected: !prev[itemId]?.selected
      }
    }));
  };

  // Update quantity
  const handleQuantityChange = (itemId, val, maxQty) => {
    const qty = Math.max(1, Math.min(maxQty, parseInt(val, 10) || 1));
    setSelectedItems(prev => ({
      ...prev,
      [itemId]: {
        ...prev[itemId],
        quantity: qty
      }
    }));
  };

  // Update condition
  const handleConditionChange = (itemId, condition) => {
    setSelectedItems(prev => ({
      ...prev,
      [itemId]: {
        ...prev[itemId],
        condition
      }
    }));
  };

  // Calculate estimated live refund
  const calculateEstimatedRefund = () => {
    if (!saleDetails) return 0;
    let total = 0;
    const sale = saleDetails.sale;

    saleDetails.items.forEach(si => {
      const selection = selectedItems[si.id];
      if (selection && selection.selected) {
        const itemGross = si.unitPrice * selection.quantity;
        let lineDiscount = 0;
        if (sale.subtotal > 0 && sale.discountAmount > 0) {
          lineDiscount = ((itemGross / sale.subtotal) * sale.discountAmount);
        }
        const lineTaxable = Math.max(0, itemGross - lineDiscount);
        let lineTax = 0;
        if (sale.taxRate > 0) {
          lineTax = lineTaxable * (sale.taxRate / 100);
        }
        total += (lineTaxable + lineTax);
      }
    });

    return Math.round(total * 100) / 100;
  };

  // Submit return
  const handleSubmitReturn = async (e) => {
    e.preventDefault();
    setProcessError('');

    const itemsToReturn = [];
    Object.entries(selectedItems).forEach(([saleItemId, data]) => {
      if (data.selected) {
        itemsToReturn.push({
          saleItemId,
          quantity: data.quantity,
          condition: data.condition
        });
      }
    });

    if (itemsToReturn.length === 0) {
      setProcessError('Please check at least one garment item to return.');
      return;
    }

    setSubmittingReturn(true);
    try {
      const res = await api.createReturn({
        saleId: selectedSaleId,
        items: itemsToReturn,
        reason: returnReason,
        notes: returnNotes,
        refundMethod
      });

      if (res.success) {
        setReturnSuccessResult(res.data);
        // Refresh sale details
        loadSaleDetails(selectedSaleId);
      }
    } catch (err) {
      setProcessError(err.message || 'Failed to complete return transaction.');
    } finally {
      setSubmittingReturn(false);
    }
  };

  const estimatedRefund = calculateEstimatedRefund();
  const selectedCount = Object.values(selectedItems).filter(i => i.selected).length;

  return (
    <div style={{ padding: '1.5rem', maxWidth: '1360px', margin: '0 auto' }}>
      {/* Header */}
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: '1.5rem', flexWrap: 'wrap', gap: '1rem' }}>
        <div>
          <h1 style={{ fontSize: '1.625rem', fontWeight: '700', color: 'var(--text-main)', margin: '0 0 0.25rem 0', letterSpacing: '-0.02em', display: 'flex', alignItems: 'center', gap: '0.625rem' }}>
            <RotateCcw size={26} color="#7EAFD0" />
            Sales Returns & Customer Refunds
          </h1>
          <p style={{ margin: 0, fontSize: '0.875rem', color: 'var(--text-muted)' }}>
            Process garment returns, restore sellable stock or record damaged goods, and issue verified refunds.
          </p>
        </div>

        {/* Tab Switcher */}
        <div style={{ display: 'flex', backgroundColor: '#FFFFFF', border: '1px solid var(--border-color)', borderRadius: 'var(--radius-md)', padding: '3px' }}>
          <button
            onClick={() => { setActiveTab('process'); setReturnSuccessResult(null); }}
            style={{
              padding: '6px 16px',
              fontSize: '0.8125rem',
              fontWeight: '600',
              borderRadius: 'var(--radius-sm)',
              border: 'none',
              cursor: 'pointer',
              backgroundColor: activeTab === 'process' ? '#7EAFD0' : 'transparent',
              color: activeTab === 'process' ? '#FFFFFF' : 'var(--text-main)',
              transition: 'all 0.15s ease'
            }}
          >
            Process Return
          </button>
          <button
            onClick={() => setActiveTab('history')}
            style={{
              padding: '6px 16px',
              fontSize: '0.8125rem',
              fontWeight: '600',
              borderRadius: 'var(--radius-sm)',
              border: 'none',
              cursor: 'pointer',
              backgroundColor: activeTab === 'history' ? '#7EAFD0' : 'transparent',
              color: activeTab === 'history' ? '#FFFFFF' : 'var(--text-main)',
              transition: 'all 0.15s ease'
            }}
          >
            Return History
          </button>
        </div>
      </div>

      {/* ── TAB 1: PROCESS RETURN ────────────────────────────────────────── */}
      {activeTab === 'process' && (
        <div>
          {/* Step 1: Sale Search & Selection */}
          {!selectedSaleId || returnSuccessResult ? (
            <Card style={{ marginBottom: '1.5rem', padding: '1.25rem' }}>
              <div style={{ marginBottom: '1rem' }}>
                <h3 style={{ fontSize: '1rem', fontWeight: '600', color: 'var(--text-main)', margin: '0 0 0.375rem 0' }}>
                  1. Find Original Sale Transaction
                </h3>
                <p style={{ fontSize: '0.8125rem', color: 'var(--text-muted)', margin: 0 }}>
                  Search by Invoice Number (e.g. WS-000001), Customer Name, Customer Phone, or Garment SKU.
                </p>
              </div>

              {/* Search Box */}
              <div style={{ display: 'flex', gap: '0.75rem', marginBottom: '1.25rem', flexWrap: 'wrap' }}>
                <div style={{ position: 'relative', flex: 1, minWidth: '260px' }}>
                  <Search size={16} color="var(--text-muted)" style={{ position: 'absolute', left: '12px', top: '50%', transform: 'translateY(-50%)' }} />
                  <input
                    type="text"
                    placeholder="Search invoice #, customer name, phone, SKU..."
                    value={searchSaleQuery}
                    onChange={(e) => setSearchSaleQuery(e.target.value)}
                    onKeyDown={(e) => e.key === 'Enter' && searchSales(searchSaleQuery)}
                    style={{
                      width: '100%',
                      padding: '8px 12px 8px 36px',
                      borderRadius: 'var(--radius-md)',
                      border: '1px solid var(--border-color)',
                      fontSize: '0.875rem'
                    }}
                  />
                </div>
                <Button variant="primary" onClick={() => searchSales(searchSaleQuery)} disabled={searchingSales}>
                  {searchingSales ? 'Searching...' : 'Search Invoices'}
                </Button>
              </div>

              {/* Eligible Sales Table */}
              <div style={{ overflowX: 'auto', border: '1px solid var(--border-color)', borderRadius: 'var(--radius-md)' }}>
                <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: '0.875rem' }}>
                  <thead>
                    <tr style={{ backgroundColor: 'var(--bg-page)', borderBottom: '1px solid var(--border-color)', textAlign: 'left' }}>
                      <th style={{ padding: '10px 14px', fontWeight: '600', color: 'var(--text-muted)' }}>Invoice #</th>
                      <th style={{ padding: '10px 14px', fontWeight: '600', color: 'var(--text-muted)' }}>Date & Time</th>
                      <th style={{ padding: '10px 14px', fontWeight: '600', color: 'var(--text-muted)' }}>Customer</th>
                      <th style={{ padding: '10px 14px', fontWeight: '600', color: 'var(--text-muted)' }}>Cashier</th>
                      <th style={{ padding: '10px 14px', fontWeight: '600', color: 'var(--text-muted)' }}>Payment</th>
                      <th style={{ padding: '10px 14px', fontWeight: '600', color: 'var(--text-muted)', textAlign: 'right' }}>Total (₹)</th>
                      <th style={{ padding: '10px 14px', fontWeight: '600', color: 'var(--text-muted)' }}>Return Status</th>
                      <th style={{ padding: '10px 14px', fontWeight: '600', color: 'var(--text-muted)', textAlign: 'right' }}>Action</th>
                    </tr>
                  </thead>
                  <tbody>
                    {searchingSales ? (
                      <tr>
                        <td colSpan="8" style={{ padding: '2rem', textAlign: 'center', color: 'var(--text-muted)' }}>
                          Searching sales catalog...
                        </td>
                      </tr>
                    ) : eligibleSales.length === 0 ? (
                      <tr>
                        <td colSpan="8" style={{ padding: '2.5rem', textAlign: 'center', color: 'var(--text-muted)' }}>
                          No matching completed sales found. Enter an invoice number or customer phone.
                        </td>
                      </tr>
                    ) : (
                      eligibleSales.map(sale => (
                        <tr key={sale.id} style={{ borderBottom: '1px solid var(--border-subtle)' }}>
                          <td style={{ padding: '10px 14px', fontWeight: '600', color: 'var(--text-main)' }}>
                            {sale.invoiceNumber}
                          </td>
                          <td style={{ padding: '10px 14px', color: 'var(--text-muted)', fontSize: '0.8125rem' }}>
                            {sale.createdAt ? sale.createdAt.replace('T', ' ').substring(0, 16) : ''}
                          </td>
                          <td style={{ padding: '10px 14px' }}>
                            <div style={{ fontWeight: '500', color: 'var(--text-main)' }}>{sale.customerName || 'Walk-in Customer'}</div>
                            {sale.customerPhone && <div style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>{sale.customerPhone}</div>}
                          </td>
                          <td style={{ padding: '10px 14px', color: 'var(--text-main)' }}>{sale.cashierName}</td>
                          <td style={{ padding: '10px 14px' }}>
                            <Badge variant="outline" size="sm">{sale.paymentMethod}</Badge>
                          </td>
                          <td style={{ padding: '10px 14px', textAlign: 'right', fontWeight: '600', color: 'var(--text-main)' }}>
                            ₹{sale.totalAmount.toFixed(2)}
                          </td>
                          <td style={{ padding: '10px 14px' }}>
                            {sale.isFullyReturned ? (
                              <Badge variant="danger" size="sm">Fully Returned</Badge>
                            ) : sale.returnedQuantity > 0 ? (
                              <Badge variant="warning" size="sm">Partially Returned ({sale.returnedQuantity}/{sale.totalQuantity})</Badge>
                            ) : (
                              <Badge variant="success" size="sm">Returnable ({sale.totalQuantity} items)</Badge>
                            )}
                          </td>
                          <td style={{ padding: '10px 14px', textAlign: 'right' }}>
                            <Button
                              variant="outline"
                              size="sm"
                              disabled={sale.isFullyReturned}
                              onClick={() => loadSaleDetails(sale.id)}
                            >
                              Select Sale
                            </Button>
                          </td>
                        </tr>
                      ))
                    )}
                  </tbody>
                </table>
              </div>
            </Card>
          ) : null}

          {/* Success Banner if return processed */}
          {returnSuccessResult && (
            <Card style={{ marginBottom: '1.5rem', border: '1px solid #99D1B7', backgroundColor: '#F0FDF4', padding: '1.5rem' }}>
              <div style={{ display: 'flex', alignItems: 'flex-start', gap: '1rem', justifyContent: 'space-between', flexWrap: 'wrap' }}>
                <div style={{ display: 'flex', gap: '0.875rem' }}>
                  <CheckCircle2 size={24} color="#15803D" style={{ flexShrink: 0, marginTop: '2px' }} />
                  <div>
                    <h3 style={{ fontSize: '1.0625rem', fontWeight: '700', color: '#166534', margin: '0 0 0.25rem 0' }}>
                      Return Processed Successfully!
                    </h3>
                    <p style={{ margin: 0, fontSize: '0.875rem', color: '#15803D' }}>
                      Refund of <strong>₹{returnSuccessResult.totalRefundAmount.toFixed(2)}</strong> issued via <strong>{returnSuccessResult.refundMethod}</strong> for Invoice <strong>{returnSuccessResult.invoiceNumber}</strong>.
                    </p>
                    <div style={{ marginTop: '0.5rem', fontSize: '0.8125rem', color: '#166534' }}>
                      Resellable items were returned to inventory. Customer lifetime metrics and store reports have been updated.
                    </div>
                  </div>
                </div>

                <div style={{ display: 'flex', gap: '0.5rem' }}>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => window.print()}
                    style={{ display: 'flex', alignItems: 'center', gap: '6px' }}
                  >
                    <Printer size={14} /> Print Return Receipt
                  </Button>
                  <Button
                    variant="primary"
                    size="sm"
                    onClick={() => { setSelectedSaleId(null); setReturnSuccessResult(null); }}
                  >
                    Process Another Return
                  </Button>
                </div>
              </div>
            </Card>
          )}

          {/* Step 2: Sale Items & Return Configuration */}
          {selectedSaleId && saleDetails && !returnSuccessResult && (
            <div>
              {/* Back / Clear Selection */}
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '1rem' }}>
                <button
                  onClick={() => { setSelectedSaleId(null); setSaleDetails(null); }}
                  style={{
                    background: 'none',
                    border: 'none',
                    color: '#7EAFD0',
                    fontWeight: '600',
                    fontSize: '0.875rem',
                    cursor: 'pointer',
                    display: 'flex',
                    alignItems: 'center',
                    gap: '4px'
                  }}
                >
                  ← Choose Different Sale
                </button>

                <div style={{ fontSize: '0.8125rem', color: 'var(--text-muted)' }}>
                  Invoice: <strong style={{ color: 'var(--text-main)' }}>{saleDetails.sale.invoiceNumber}</strong> • Date: {saleDetails.sale.createdAt?.substring(0, 10)}
                </div>
              </div>

              {processError && (
                <div style={{ padding: '0.75rem 1rem', backgroundColor: '#FEF2F2', border: '1px solid #FCA5A5', borderRadius: 'var(--radius-md)', color: '#991B1B', marginBottom: '1.25rem', fontSize: '0.875rem', display: 'flex', alignItems: 'center', gap: '8px' }}>
                  <AlertTriangle size={16} /> {processError}
                </div>
              )}

              <form onSubmit={handleSubmitReturn}>
                <div style={{ display: 'grid', gridTemplateColumns: 'minmax(0, 2fr) minmax(0, 1fr)', gap: '1.5rem', alignItems: 'start' }}>
                  {/* Left Column: Selectable Items */}
                  <Card style={{ padding: '1.25rem' }}>
                    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '1rem', borderBottom: '1px solid var(--border-color)', paddingBottom: '0.75rem' }}>
                      <h3 style={{ fontSize: '1rem', fontWeight: '600', color: 'var(--text-main)', margin: 0 }}>
                        Select Items to Return
                      </h3>
                      <span style={{ fontSize: '0.8125rem', color: 'var(--text-muted)' }}>
                        {selectedCount} item{selectedCount === 1 ? '' : 's'} selected
                      </span>
                    </div>

                    <div style={{ display: 'flex', flexDirection: 'column', gap: '0.875rem' }}>
                      {saleDetails.items.map(item => {
                        const isSelected = selectedItems[item.id]?.selected;
                        const isAvailable = item.availableQty > 0;
                        const currentQty = selectedItems[item.id]?.quantity || 1;
                        const currentCondition = selectedItems[item.id]?.condition || 'RESELLABLE';

                        return (
                          <div
                            key={item.id}
                            style={{
                              border: isSelected ? '1px solid #7EAFD0' : '1px solid var(--border-color)',
                              borderRadius: 'var(--radius-md)',
                              padding: '1rem',
                              backgroundColor: !isAvailable ? '#F8FAFC' : isSelected ? '#F0F9FF' : '#FFFFFF',
                              opacity: isAvailable ? 1 : 0.6,
                              transition: 'all 0.15s ease'
                            }}
                          >
                            <div style={{ display: 'flex', alignItems: 'flex-start', gap: '0.875rem' }}>
                              <input
                                type="checkbox"
                                disabled={!isAvailable}
                                checked={isSelected}
                                onChange={() => handleToggleItem(item.id)}
                                style={{ marginTop: '4px', cursor: isAvailable ? 'pointer' : 'not-allowed', width: '16px', height: '16px' }}
                              />

                              <div style={{ flex: 1 }}>
                                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: '0.25rem' }}>
                                  <div style={{ fontWeight: '600', color: 'var(--text-main)', fontSize: '0.9375rem' }}>
                                    {item.productNameSnapshot}
                                  </div>
                                  <div style={{ fontWeight: '700', color: 'var(--text-main)', fontSize: '0.9375rem' }}>
                                    ₹{item.unitPrice.toFixed(2)}
                                  </div>
                                </div>

                                <div style={{ fontSize: '0.8125rem', color: 'var(--text-muted)', marginBottom: '0.625rem' }}>
                                  {[item.sizeSnapshot, item.colorSnapshot].filter(Boolean).join(' • ') || 'Default'} • SKU: {item.skuSnapshot || 'N/A'}
                                </div>

                                <div style={{ display: 'flex', alignItems: 'center', gap: '1rem', fontSize: '0.75rem', color: 'var(--text-muted)', flexWrap: 'wrap' }}>
                                  <span>Purchased: <strong>{item.quantity}</strong></span>
                                  <span>Already Returned: <strong>{item.alreadyReturned}</strong></span>
                                  <span style={{ color: isAvailable ? '#15803D' : '#991B1B' }}>
                                    Available for Return: <strong>{item.availableQty}</strong>
                                  </span>
                                </div>

                                {/* Controls when selected */}
                                {isSelected && (
                                  <div style={{ marginTop: '0.875rem', paddingTop: '0.75rem', borderTop: '1px dashed #CBD5E1', display: 'flex', gap: '1rem', alignItems: 'center', flexWrap: 'wrap' }}>
                                    <div style={{ display: 'flex', alignItems: 'center', gap: '6px' }}>
                                      <label style={{ fontSize: '0.75rem', fontWeight: '600', color: 'var(--text-main)' }}>Return Qty:</label>
                                      <input
                                        type="number"
                                        min="1"
                                        max={item.availableQty}
                                        value={currentQty}
                                        onChange={(e) => handleQuantityChange(item.id, e.target.value, item.availableQty)}
                                        style={{
                                          width: '60px',
                                          padding: '4px 6px',
                                          borderRadius: 'var(--radius-sm)',
                                          border: '1px solid var(--border-color)',
                                          fontSize: '0.8125rem',
                                          textAlign: 'center'
                                        }}
                                      />
                                      <span style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>/ {item.availableQty}</span>
                                    </div>

                                    <div style={{ display: 'flex', alignItems: 'center', gap: '6px' }}>
                                      <label style={{ fontSize: '0.75rem', fontWeight: '600', color: 'var(--text-main)' }}>Condition:</label>
                                      <select
                                        value={currentCondition}
                                        onChange={(e) => handleConditionChange(item.id, e.target.value)}
                                        style={{
                                          padding: '4px 8px',
                                          borderRadius: 'var(--radius-sm)',
                                          border: '1px solid var(--border-color)',
                                          fontSize: '0.8125rem',
                                          backgroundColor: '#FFFFFF'
                                        }}
                                      >
                                        <option value="RESELLABLE">Resellable (Add to stock)</option>
                                        <option value="DAMAGED">Damaged / Defect (Inventory Loss)</option>
                                      </select>
                                    </div>
                                  </div>
                                )}
                              </div>
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  </Card>

                  {/* Right Column: Return Parameters & Confirmation */}
                  <Card style={{ padding: '1.25rem' }}>
                    <h3 style={{ fontSize: '1rem', fontWeight: '600', color: 'var(--text-main)', margin: '0 0 1rem 0', borderBottom: '1px solid var(--border-color)', paddingBottom: '0.75rem' }}>
                      Return Details
                    </h3>

                    <div style={{ display: 'flex', flexDirection: 'column', gap: '1rem' }}>
                      {/* Reason */}
                      <div>
                        <label style={{ display: 'block', fontSize: '0.8125rem', fontWeight: '600', color: 'var(--text-main)', marginBottom: '4px' }}>
                          Reason for Return *
                        </label>
                        <select
                          value={returnReason}
                          onChange={(e) => setReturnReason(e.target.value)}
                          style={{
                            width: '100%',
                            padding: '8px 10px',
                            borderRadius: 'var(--radius-md)',
                            border: '1px solid var(--border-color)',
                            fontSize: '0.875rem',
                            backgroundColor: '#FFFFFF'
                          }}
                        >
                          <option value="Customer Changed Mind">Customer Changed Mind</option>
                          <option value="Wrong Size">Wrong Size</option>
                          <option value="Wrong Product">Wrong Product</option>
                          <option value="Damaged Product">Damaged Product</option>
                          <option value="Defective Product">Defective Product</option>
                          <option value="Other">Other</option>
                        </select>
                      </div>

                      {/* Refund Method */}
                      <div>
                        <label style={{ display: 'block', fontSize: '0.8125rem', fontWeight: '600', color: 'var(--text-main)', marginBottom: '4px' }}>
                          Refund Tender Method *
                        </label>
                        <select
                          value={refundMethod}
                          onChange={(e) => setRefundMethod(e.target.value)}
                          style={{
                            width: '100%',
                            padding: '8px 10px',
                            borderRadius: 'var(--radius-md)',
                            border: '1px solid var(--border-color)',
                            fontSize: '0.875rem',
                            backgroundColor: '#FFFFFF'
                          }}
                        >
                          <option value="CASH">Cash</option>
                          <option value="UPI">UPI</option>
                          <option value="CARD">Card</option>
                          <option value={saleDetails.sale.paymentMethod}>Original Method ({saleDetails.sale.paymentMethod})</option>
                        </select>
                      </div>

                      {/* Notes */}
                      <div>
                        <label style={{ display: 'block', fontSize: '0.8125rem', fontWeight: '600', color: 'var(--text-main)', marginBottom: '4px' }}>
                          Staff Notes (Optional)
                        </label>
                        <textarea
                          rows="2"
                          placeholder="e.g. Garment tags intact, verified receipt..."
                          value={returnNotes}
                          onChange={(e) => setReturnNotes(e.target.value)}
                          style={{
                            width: '100%',
                            padding: '8px 10px',
                            borderRadius: 'var(--radius-md)',
                            border: '1px solid var(--border-color)',
                            fontSize: '0.8125rem',
                            fontFamily: 'inherit'
                          }}
                        />
                      </div>

                      {/* Calculation Summary Box */}
                      <div style={{ backgroundColor: 'var(--bg-page)', borderRadius: 'var(--radius-md)', padding: '1rem', border: '1px solid var(--border-color)' }}>
                        <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '0.8125rem', color: 'var(--text-muted)', marginBottom: '6px' }}>
                          <span>Original Sale Total:</span>
                          <span style={{ fontWeight: '500', color: 'var(--text-main)' }}>₹{saleDetails.sale.totalAmount.toFixed(2)}</span>
                        </div>
                        <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '0.8125rem', color: 'var(--text-muted)', marginBottom: '6px' }}>
                          <span>Selected Items to Return:</span>
                          <span style={{ fontWeight: '500', color: 'var(--text-main)' }}>{selectedCount} item{selectedCount === 1 ? '' : 's'}</span>
                        </div>
                        <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '1rem', fontWeight: '700', color: 'var(--text-main)', paddingTop: '8px', borderTop: '1px solid var(--border-subtle)' }}>
                          <span>Total Refund Amount:</span>
                          <span style={{ color: '#166534' }}>₹{estimatedRefund.toFixed(2)}</span>
                        </div>
                      </div>

                      <Button
                        variant="primary"
                        type="submit"
                        disabled={submittingReturn || selectedCount === 0 || estimatedRefund <= 0}
                        style={{ width: '100%', padding: '10px', fontWeight: '600' }}
                      >
                        {submittingReturn ? 'Processing Return...' : `Confirm & Issue Refund (₹${estimatedRefund.toFixed(2)})`}
                      </Button>
                    </div>
                  </Card>
                </div>
              </form>
            </div>
          )}
        </div>
      )}

      {/* ── TAB 2: RETURN HISTORY ────────────────────────────────────────── */}
      {activeTab === 'history' && (
        <Card style={{ padding: '1.25rem' }}>
          {/* Filter Bar */}
          <div style={{ display: 'flex', gap: '0.75rem', marginBottom: '1.25rem', flexWrap: 'wrap', alignItems: 'center', justifyContent: 'space-between' }}>
            <div style={{ display: 'flex', gap: '0.75rem', flex: 1, minWidth: '300px' }}>
              <div style={{ position: 'relative', flex: 1 }}>
                <Search size={16} color="var(--text-muted)" style={{ position: 'absolute', left: '12px', top: '50%', transform: 'translateY(-50%)' }} />
                <input
                  type="text"
                  placeholder="Filter by invoice #, customer, reason..."
                  value={historySearch}
                  onChange={(e) => setHistorySearch(e.target.value)}
                  style={{
                    width: '100%',
                    padding: '8px 12px 8px 36px',
                    borderRadius: 'var(--radius-md)',
                    border: '1px solid var(--border-color)',
                    fontSize: '0.875rem'
                  }}
                />
              </div>

              <select
                value={historyMethodFilter}
                onChange={(e) => setHistoryMethodFilter(e.target.value)}
                style={{
                  padding: '8px 12px',
                  borderRadius: 'var(--radius-md)',
                  border: '1px solid var(--border-color)',
                  fontSize: '0.875rem',
                  backgroundColor: '#FFFFFF'
                }}
              >
                <option value="">All Refund Methods</option>
                <option value="CASH">Cash</option>
                <option value="UPI">UPI</option>
                <option value="CARD">Card</option>
              </select>
            </div>

            <div style={{ fontSize: '0.8125rem', color: 'var(--text-muted)' }}>
              Showing {historyList.length} of {historyPagination.total} returns
            </div>
          </div>

          {/* Table */}
          <div style={{ overflowX: 'auto', border: '1px solid var(--border-color)', borderRadius: 'var(--radius-md)' }}>
            <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: '0.875rem' }}>
              <thead>
                <tr style={{ backgroundColor: 'var(--bg-page)', borderBottom: '1px solid var(--border-color)', textAlign: 'left' }}>
                  <th style={{ padding: '10px 14px', fontWeight: '600', color: 'var(--text-muted)' }}>Return ID</th>
                  <th style={{ padding: '10px 14px', fontWeight: '600', color: 'var(--text-muted)' }}>Original Invoice</th>
                  <th style={{ padding: '10px 14px', fontWeight: '600', color: 'var(--text-muted)' }}>Customer</th>
                  <th style={{ padding: '10px 14px', fontWeight: '600', color: 'var(--text-muted)' }}>Items</th>
                  <th style={{ padding: '10px 14px', fontWeight: '600', color: 'var(--text-muted)' }}>Reason</th>
                  <th style={{ padding: '10px 14px', fontWeight: '600', color: 'var(--text-muted)', textAlign: 'right' }}>Refund (₹)</th>
                  <th style={{ padding: '10px 14px', fontWeight: '600', color: 'var(--text-muted)' }}>Method</th>
                  <th style={{ padding: '10px 14px', fontWeight: '600', color: 'var(--text-muted)' }}>Staff</th>
                  <th style={{ padding: '10px 14px', fontWeight: '600', color: 'var(--text-muted)' }}>Date</th>
                  <th style={{ padding: '10px 14px', fontWeight: '600', color: 'var(--text-muted)', textAlign: 'right' }}>Actions</th>
                </tr>
              </thead>
              <tbody>
                {historyLoading ? (
                  <tr>
                    <td colSpan="10" style={{ padding: '2.5rem', textAlign: 'center', color: 'var(--text-muted)' }}>
                      Loading return history...
                    </td>
                  </tr>
                ) : historyList.length === 0 ? (
                  <tr>
                    <td colSpan="10" style={{ padding: '2.5rem', textAlign: 'center', color: 'var(--text-muted)' }}>
                      No returns recorded yet.
                    </td>
                  </tr>
                ) : (
                  historyList.map(ret => (
                    <tr key={ret.id} style={{ borderBottom: '1px solid var(--border-subtle)' }}>
                      <td style={{ padding: '10px 14px', fontFamily: 'monospace', fontSize: '0.8125rem', color: 'var(--text-muted)' }}>
                        {ret.id.substring(0, 12)}...
                      </td>
                      <td style={{ padding: '10px 14px', fontWeight: '600', color: 'var(--text-main)' }}>
                        {ret.invoiceNumber}
                      </td>
                      <td style={{ padding: '10px 14px' }}>
                        <div style={{ fontWeight: '500', color: 'var(--text-main)' }}>{ret.customerName || 'Walk-in'}</div>
                        {ret.customerPhone && <div style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>{ret.customerPhone}</div>}
                      </td>
                      <td style={{ padding: '10px 14px' }}>
                        <Badge variant="outline" size="sm">
                          {ret.totalItemsReturned} item{ret.totalItemsReturned === 1 ? '' : 's'}
                        </Badge>
                      </td>
                      <td style={{ padding: '10px 14px', color: 'var(--text-main)' }}>
                        {ret.reason}
                      </td>
                      <td style={{ padding: '10px 14px', textAlign: 'right', fontWeight: '700', color: '#166534' }}>
                        ₹{ret.totalRefundAmount.toFixed(2)}
                      </td>
                      <td style={{ padding: '10px 14px' }}>
                        <Badge variant="secondary" size="sm">{ret.refundMethod}</Badge>
                      </td>
                      <td style={{ padding: '10px 14px', color: 'var(--text-muted)', fontSize: '0.8125rem' }}>
                        {ret.staffName}
                      </td>
                      <td style={{ padding: '10px 14px', color: 'var(--text-muted)', fontSize: '0.8125rem' }}>
                        {ret.createdAt ? ret.createdAt.replace('T', ' ').substring(0, 16) : ''}
                      </td>
                      <td style={{ padding: '10px 14px', textAlign: 'right' }}>
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={async () => {
                            const res = await api.getReturn(ret.id);
                            if (res.success) setSelectedReturnDetail(res.data);
                          }}
                        >
                          Details
                        </Button>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </Card>
      )}

      {/* Return Detail Modal */}
      {selectedReturnDetail && (
        <div style={{ position: 'fixed', inset: 0, backgroundColor: 'rgba(23, 32, 51, 0.5)', zIndex: 60, display: 'flex', alignItems: 'center', justifyContent: 'center', padding: '1rem' }}>
          <div style={{ backgroundColor: '#FFFFFF', borderRadius: 'var(--radius-lg)', width: '100%', maxWidth: '640px', maxHeight: '90vh', overflowY: 'auto', boxShadow: 'var(--shadow-xl)', padding: '1.5rem' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: '1.25rem', borderBottom: '1px solid var(--border-color)', paddingBottom: '0.75rem' }}>
              <div>
                <h3 style={{ fontSize: '1.125rem', fontWeight: '700', color: 'var(--text-main)', margin: '0 0 0.25rem 0' }}>
                  Return Details: {selectedReturnDetail.invoiceNumber}
                </h3>
                <span style={{ fontSize: '0.8125rem', color: 'var(--text-muted)' }}>
                  Processed on {selectedReturnDetail.createdAt?.replace('T', ' ').substring(0, 19)} by {selectedReturnDetail.staffName}
                </span>
              </div>
              <button
                onClick={() => setSelectedReturnDetail(null)}
                style={{ background: 'none', border: 'none', cursor: 'pointer', padding: '4px', color: 'var(--text-muted)' }}
              >
                <X size={20} />
              </button>
            </div>

            {/* Key stats row */}
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: '0.75rem', marginBottom: '1.25rem', backgroundColor: 'var(--bg-page)', padding: '0.875rem', borderRadius: 'var(--radius-md)' }}>
              <div>
                <div style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>Total Refund</div>
                <div style={{ fontSize: '1.125rem', fontWeight: '700', color: '#166534' }}>₹{selectedReturnDetail.totalRefundAmount.toFixed(2)}</div>
              </div>
              <div>
                <div style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>Refund Tender</div>
                <div style={{ fontSize: '0.9375rem', fontWeight: '600', color: 'var(--text-main)' }}>{selectedReturnDetail.refundMethod}</div>
              </div>
              <div>
                <div style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>Reason</div>
                <div style={{ fontSize: '0.9375rem', fontWeight: '600', color: 'var(--text-main)' }}>{selectedReturnDetail.reason}</div>
              </div>
            </div>

            {/* Returned Items Table */}
            <h4 style={{ fontSize: '0.875rem', fontWeight: '600', color: 'var(--text-main)', marginBottom: '0.5rem' }}>Returned Garments</h4>
            <div style={{ border: '1px solid var(--border-color)', borderRadius: 'var(--radius-md)', overflowX: 'auto', marginBottom: '1.25rem' }}>
              <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: '0.8125rem' }}>
                <thead>
                  <tr style={{ backgroundColor: 'var(--bg-page)', borderBottom: '1px solid var(--border-color)', textAlign: 'left' }}>
                    <th style={{ padding: '8px 10px', color: 'var(--text-muted)' }}>Garment</th>
                    <th style={{ padding: '8px 10px', color: 'var(--text-muted)' }}>Condition</th>
                    <th style={{ padding: '8px 10px', color: 'var(--text-muted)', textAlign: 'center' }}>Qty</th>
                    <th style={{ padding: '8px 10px', color: 'var(--text-muted)', textAlign: 'right' }}>Refund (₹)</th>
                  </tr>
                </thead>
                <tbody>
                  {selectedReturnDetail.items?.map(it => (
                    <tr key={it.id} style={{ borderBottom: '1px solid var(--border-subtle)' }}>
                      <td style={{ padding: '8px 10px' }}>
                        <div style={{ fontWeight: '600', color: 'var(--text-main)' }}>{it.productNameSnapshot}</div>
                        <div style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>{[it.sizeSnapshot, it.colorSnapshot].filter(Boolean).join(' / ')}</div>
                      </td>
                      <td style={{ padding: '8px 10px' }}>
                        <Badge variant={it.condition === 'RESELLABLE' ? 'success' : 'danger'} size="sm">
                          {it.condition}
                        </Badge>
                      </td>
                      <td style={{ padding: '8px 10px', textAlign: 'center', fontWeight: '600' }}>
                        {it.quantity}
                      </td>
                      <td style={{ padding: '8px 10px', textAlign: 'right', fontWeight: '600', color: '#166534' }}>
                        ₹{it.refundAmount.toFixed(2)}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            {selectedReturnDetail.notes && (
              <div style={{ marginBottom: '1.25rem', fontSize: '0.8125rem' }}>
                <span style={{ fontWeight: '600', color: 'var(--text-main)' }}>Staff Notes: </span>
                <span style={{ color: 'var(--text-muted)' }}>{selectedReturnDetail.notes}</span>
              </div>
            )}

            <div style={{ display: 'flex', justifyContent: 'flex-end', gap: '0.5rem' }}>
              <Button variant="outline" size="sm" onClick={() => window.print()}>
                <Printer size={14} style={{ marginRight: '4px' }} /> Print Slip
              </Button>
              <Button variant="primary" size="sm" onClick={() => setSelectedReturnDetail(null)}>
                Close
              </Button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
