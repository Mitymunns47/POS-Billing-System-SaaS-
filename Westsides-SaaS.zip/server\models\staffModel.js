const crypto = require('crypto');
const bcrypt = require('bcryptjs');
const db = require('../db/database');
const { ROLES } = require('../constants/roles');
const UserModel = require('./userModel');
const StoreUserModel = require('./storeUserModel');

const StaffModel = {
  /**
   * Create a new staff account linked to the current store
   */
  createStaff: ({ storeId, name, email, phone, role, password, actorRole }) => {
    // 1. Role hierarchy validation: Managers cannot create Owners
    if (role === ROLES.OWNER && actorRole !== ROLES.OWNER) {
      throw new Error('Only the store Owner can assign the OWNER role.');
    }
    if (![ROLES.OWNER, ROLES.MANAGER, ROLES.CASHIER, ROLES.STAFF].includes(role)) {
      throw new Error(`Invalid role: ${role}`);
    }

    const cleanEmail = email.trim().toLowerCase();
    const cleanName = name.trim();
    const cleanPhone = phone ? phone.trim() : null;

    if (!cleanName) throw new Error('Staff name is required.');
    if (!cleanEmail) throw new Error('Staff email is required.');
    if (!password || password.length < 6) throw new Error('Password must be at least 6 characters.');

    // Phase 8: Enforce subscription plan maxUsers limit
    try {
      const sub = db.prepare(`
        SELECT sp.maxUsers
        FROM store_subscriptions ss
        JOIN subscription_plans sp ON ss.planId = sp.id
        WHERE ss.storeId = ? AND ss.status IN ('ACTIVE', 'TRIALING')
      `).get(storeId);

      if (sub && sub.maxUsers) {
        const currentUsers = db.prepare('SELECT COUNT(*) as cnt FROM store_users WHERE storeId = ? AND status = "ACTIVE"').get(storeId).cnt;
        if (currentUsers >= sub.maxUsers) {
          throw new Error(`User limit reached for your subscription plan (maximum: ${sub.maxUsers}). Please upgrade your plan.`);
        }
      }
    } catch (err) {
      if (err.message && err.message.includes('User limit reached')) throw err;
    }

    const now = new Date().toISOString();

    // 2. Check if user already exists
    let user = UserModel.findByEmail(cleanEmail);
    if (user) {
      // Check if user is already linked to this store
      const existingMapping = db.prepare(`
        SELECT * FROM store_users WHERE storeId = ? AND userId = ?
      `).get(storeId, user.id);

      if (existingMapping) {
        throw new Error(`A staff member with email "${cleanEmail}" is already registered in this store.`);
      }

      // Link existing user to this store
      const suId = 'su_' + crypto.randomBytes(8).toString('hex');
      db.prepare(`
        INSERT INTO store_users (id, storeId, userId, role, status, createdAt, updatedAt)
        VALUES (?, ?, ?, ?, 'ACTIVE', ?, ?)
      `).run(suId, storeId, user.id, role, now, now);

      return StaffModel.findById(user.id, storeId);
    }

    // 3. Create new user account with hashed password
    const salt = bcrypt.genSaltSync(10);
    const passwordHash = bcrypt.hashSync(password, salt);
    const userId = 'usr_' + crypto.randomBytes(8).toString('hex');

    db.prepare(`
      INSERT INTO users (id, name, email, phone, passwordHash, createdAt, updatedAt)
      VALUES (?, ?, ?, ?, ?, ?, ?)
    `).run(userId, cleanName, cleanEmail, cleanPhone, passwordHash, now, now);

    // 4. Link to store_users
    const suId = 'su_' + crypto.randomBytes(8).toString('hex');
    db.prepare(`
      INSERT INTO store_users (id, storeId, userId, role, status, createdAt, updatedAt)
      VALUES (?, ?, ?, ?, 'ACTIVE', ?, ?)
    `).run(suId, storeId, userId, role, now, now);

    return StaffModel.findById(userId, storeId);
  },

  /**
   * Find staff member by userId within store context
   */
  findById: (userId, storeId) => {
    const row = db.prepare(`
      SELECT
        u.id, u.id AS userId, u.name, u.email, u.phone, u.createdAt as userCreatedAt,
        su.id as storeUserId, su.role, su.status, su.createdAt as joinedAt,
        su.updatedAt as statusUpdatedAt, su.lastLoginAt
      FROM store_users su
      JOIN users u ON su.userId = u.id
      WHERE su.storeId = ? AND su.userId = ?
    `).get(storeId, userId);

    if (!row) return null;

    // Fetch sales stats
    const stats = db.prepare(`
      SELECT
        COUNT(*) AS totalSales,
        COALESCE(SUM(totalAmount), 0) AS totalRevenue,
        MAX(createdAt) AS lastSaleDate
      FROM sales
      WHERE storeId = ? AND cashierId = ? AND status = 'COMPLETED'
    `).get(storeId, userId);

    return {
      ...row,
      isActive: row.status === 'ACTIVE',
      isOwner: row.role === ROLES.OWNER,
      salesCount: Number(stats?.totalSales) || 0,
      totalRevenue: Number(stats?.totalRevenue) || 0,
      lastSaleDate: stats?.lastSaleDate || null
    };
  },

  /**
   * List staff members for a store with live sales metrics
   */
  findAll: ({ storeId, search = '', role = '', status = '', page = 1, limit = 20 }) => {
    const offset = (page - 1) * limit;
    const conditions = ['su.storeId = ?'];
    const params = [storeId];

    if (role) {
      conditions.push('su.role = ?');
      params.push(role);
    }
    if (status) {
      conditions.push('su.status = ?');
      params.push(status);
    }
    if (search && search.trim()) {
      conditions.push('(u.name LIKE ? OR u.email LIKE ? OR u.phone LIKE ?)');
      const q = `%${search.trim()}%`;
      params.push(q, q, q);
    }

    const where = conditions.join(' AND ');

    const total = db.prepare(`
      SELECT COUNT(*) AS cnt
      FROM store_users su
      JOIN users u ON su.userId = u.id
      WHERE ${where}
    `).get(...params).cnt;

    const rows = db.prepare(`
      SELECT
        u.id, u.id AS userId, u.name, u.email, u.phone,
        su.id as storeUserId, su.role, su.status, su.createdAt as joinedAt, su.lastLoginAt,
        (SELECT COUNT(*) FROM sales WHERE storeId = su.storeId AND cashierId = u.id AND status = 'COMPLETED') AS salesCount,
        (SELECT COALESCE(SUM(totalAmount), 0) FROM sales WHERE storeId = su.storeId AND cashierId = u.id AND status = 'COMPLETED') AS totalRevenue,
        (SELECT MAX(createdAt) FROM sales WHERE storeId = su.storeId AND cashierId = u.id AND status = 'COMPLETED') AS lastSaleDate
      FROM store_users su
      JOIN users u ON su.userId = u.id
      WHERE ${where}
      ORDER BY
        CASE su.role
          WHEN 'OWNER' THEN 1
          WHEN 'MANAGER' THEN 2
          WHEN 'CASHIER' THEN 3
          ELSE 4
        END ASC,
        u.name ASC
      LIMIT ? OFFSET ?
    `).all(...params, limit, offset);

    return {
      staff: rows.map(r => ({
        ...r,
        isActive: r.status === 'ACTIVE',
        isOwner: r.role === ROLES.OWNER,
        salesCount: Number(r.salesCount) || 0,
        totalRevenue: Number(r.totalRevenue) || 0
      })),
      total,
      page: Number(page),
      limit: Number(limit),
      totalPages: Math.ceil(total / limit)
    };
  },

  /**
   * Update staff contact information
   */
  updateProfile: (userId, storeId, { name, phone }) => {
    const existing = StaffModel.findById(userId, storeId);
    if (!existing) return null;

    const now = new Date().toISOString();

    db.prepare(`
      UPDATE users SET
        name = COALESCE(?, name),
        phone = COALESCE(?, phone),
        updatedAt = ?
      WHERE id = ?
    `).run(name ? name.trim() : null, phone ? phone.trim() : null, now, userId);

    return StaffModel.findById(userId, storeId);
  },

  /**
   * Change staff role with authority checks
   */
  updateRole: (userId, storeId, newRole, actorRole) => {
    const target = StaffModel.findById(userId, storeId);
    if (!target) throw new Error('Staff member not found.');

    // Owner protection: No one can demote the Owner
    if (target.role === ROLES.OWNER) {
      throw new Error('The store Owner role cannot be changed.');
    }

    // Managers cannot promote someone to Owner or Manager
    if (actorRole !== ROLES.OWNER && (newRole === ROLES.OWNER || newRole === ROLES.MANAGER)) {
      throw new Error('Only the store Owner can assign Owner or Manager roles.');
    }

    if (![ROLES.OWNER, ROLES.MANAGER, ROLES.CASHIER, ROLES.STAFF].includes(newRole)) {
      throw new Error(`Invalid role: ${newRole}`);
    }

    const now = new Date().toISOString();
    db.prepare(`
      UPDATE store_users SET role = ?, updatedAt = ?
      WHERE storeId = ? AND userId = ?
    `).run(newRole, now, storeId, userId);

    return StaffModel.findById(userId, storeId);
  },

  /**
   * Activate or deactivate staff member
   */
  setStatus: (userId, storeId, status, actorRole) => {
    const target = StaffModel.findById(userId, storeId);
    if (!target) throw new Error('Staff member not found.');

    // Owner protection: Owner can NEVER be deactivated
    if (target.role === ROLES.OWNER) {
      throw new Error('The store Owner account cannot be deactivated.');
    }

    if (target.role === ROLES.MANAGER && actorRole !== ROLES.OWNER) {
      throw new Error('Only the store Owner can deactivate a Manager.');
    }

    if (!['ACTIVE', 'INACTIVE'].includes(status)) {
      throw new Error('Status must be ACTIVE or INACTIVE.');
    }

    const now = new Date().toISOString();
    db.prepare(`
      UPDATE store_users SET status = ?, updatedAt = ?
      WHERE storeId = ? AND userId = ?
    `).run(status, now, storeId, userId);

    return StaffModel.findById(userId, storeId);
  },

  /**
   * Reset staff password
   */
  resetPassword: (userId, storeId, newPassword, actorRole) => {
    const target = StaffModel.findById(userId, storeId);
    if (!target) throw new Error('Staff member not found.');

    if (target.role === ROLES.OWNER && actorRole !== ROLES.OWNER) {
      throw new Error('Only the store Owner can reset the Owner account password.');
    }

    if (!newPassword || newPassword.length < 6) {
      throw new Error('New password must be at least 6 characters long.');
    }

    const salt = bcrypt.genSaltSync(10);
    const passwordHash = bcrypt.hashSync(newPassword, salt);
    const now = new Date().toISOString();

    db.prepare(`
      UPDATE users SET passwordHash = ?, updatedAt = ?
      WHERE id = ?
    `).run(passwordHash, now, userId);

    return true;
  },

  /**
   * Update last login timestamp
   */
  updateLastLogin: (userId, storeId) => {
    const now = new Date().toISOString();
    db.prepare(`
      UPDATE store_users SET lastLoginAt = ?
      WHERE storeId = ? AND userId = ?
    `).run(now, storeId, userId);
  },

  /**
   * Remove a staff member from the store
   */
  deleteStaff: (userId, storeId) => {
    const existing = db.prepare('SELECT * FROM store_users WHERE storeId = ? AND userId = ?').get(storeId, userId);
    if (!existing) throw new Error('Staff member not found in this store.');
    if (existing.role === ROLES.OWNER) throw new Error('The store Owner cannot be removed.');

    db.prepare('DELETE FROM store_users WHERE storeId = ? AND userId = ?').run(storeId, userId);
    db.prepare('DELETE FROM user_permissions WHERE storeId = ? AND userId = ?').run(storeId, userId);
    db.prepare('DELETE FROM sessions WHERE storeId = ? AND userId = ?').run(storeId, userId);
    return true;
  }
};

module.exports = StaffModel;
