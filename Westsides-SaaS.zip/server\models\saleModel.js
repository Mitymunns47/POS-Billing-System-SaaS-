const crypto = require('crypto');
const db = require('../db/database');
const SettingsModel = require('./settingsModel');
const NotificationModel = require('./notificationModel');

// ── Invoice counter ───────────────────────────────────────────────────────────
// Generates sequential, collision-safe invoice numbers per store.
// Uses a SQLite UPDATE + SELECT within a transaction for atomicity.
function getNextInvoiceNumber(storeId) {
  // Sync prefix from store_settings if configured
  const settings = SettingsModel.getSettings(storeId);
  const prefix = settings.invoicePrefix || 'WS';

  // Ensure counter row exists
  db.prepare(`
    INSERT INTO invoice_counters (storeId, lastNumber, prefix)
    VALUES (?, 0, ?)
    ON CONFLICT(storeId) DO UPDATE SET prefix = excluded.prefix
  `).run(storeId, prefix);

  // Atomically increment
  db.prepare('UPDATE invoice_counters SET lastNumber = lastNumber + 1 WHERE storeId = ?').run(storeId);
  const row = db.prepare('SELECT lastNumber, prefix FROM invoice_counters WHERE storeId = ?').get(storeId);
  const num = String(row.lastNumber).padStart(6, '0');
  return `${row.prefix}-${num}`;
}

// ── Tax settings ──────────────────────────────────────────────────────────────
function getStoreTaxSettings(storeId) {
  let row = db.prepare('SELECT * FROM store_tax_settings WHERE storeId = ?').get(storeId);
  if (!row) {
    // Create default (tax disabled) for this store
    const now = new Date().toISOString();
    db.prepare(`
      INSERT OR IGNORE INTO store_tax_settings (storeId, taxEnabled, taxName, taxRate, taxInclusive, updatedAt)
      VALUES (?, 0, 'GST', 18.0, 0, ?)
    `).run(storeId, now);
    row = db.prepare('SELECT * FROM store_tax_settings WHERE storeId = ?').get(storeId);
  }
  return { ...row, taxEnabled: Boolean(row.taxEnabled), taxInclusive: Boolean(row.taxInclusive) };
}

function updateStoreTaxSettings(storeId, { taxEnabled, taxName, taxRate, taxInclusive }) {
  const now = new Date().toISOString();
  db.prepare(`
    INSERT OR REPLACE INTO store_tax_settings (storeId, taxEnabled, taxName, taxRate, taxInclusive, updatedAt)
    VALUES (?, ?, ?, ?, ?, ?)
  `).run(storeId, taxEnabled ? 1 : 0, taxName || 'GST', Number(taxRate) || 0, taxInclusive ? 1 : 0, now);
  return getStoreTaxSettings(storeId);
}

// ── Sale Model ────────────────────────────────────────────────────────────────
const SaleModel = {
  /**
   * Create a sale atomically:
   * - Validates store settings rules (customer requirement, discount caps, stock limits)
   * - Validates all stock is still available
   * - Deducts stock from variants
   * - Creates inventory_transactions for each line item
   * - Inserts sale + sale_items records
   * - Updates customer stats if applicable
   * - Triggers low-stock alerts
   * All inside a single SQLite transaction for atomicity.
   */
  create: ({ storeId, customerId, cashierId, cashierName, items, discountType, discountValue, taxRate, paymentMethod, paymentAmount, note }) => {
    // 0. Enforce Store Operational Rules
    const settings = SettingsModel.getSettings(storeId);

    if (settings.requireCustomerForSale && !customerId) {
      throw new Error('Customer selection is mandatory for completing checkout per store policy.');
    }

    const discVal = Number(discountValue) || 0;
    if (discVal > 0) {
      if (!settings.allowDiscounts) {
        throw new Error('Discounts are currently disabled per store operational controls.');
      }
      if (discountType === 'percentage' && discVal > settings.maxDiscountPercent) {
        throw new Error(`Discount rate of ${discVal}% exceeds maximum allowed limit of ${settings.maxDiscountPercent}%.`);
      }
    }

    db.exec('BEGIN');
    try {
      // 1. Re-validate each item's stock (concurrency protection)
      const validatedItems = [];
      for (const item of items) {
        const variant = db.prepare(
          'SELECT pv.*, p.name AS productName, p.sellingPrice AS productPrice FROM product_variants pv JOIN products p ON pv.productId = p.id WHERE pv.id = ? AND pv.storeId = ? AND pv.active = 1 AND p.archived = 0'
        ).get(item.variantId, storeId);

        if (!variant) throw new Error(`Product variant not found or has been archived.`);

        if (!settings.allowNegativeInventory && variant.stock < item.quantity) {
          throw new Error(`Insufficient stock for "${variant.productName}" (${[variant.size, variant.color].filter(Boolean).join('/')}) — available: ${variant.stock}, requested: ${item.quantity}`);
        }

        const effectivePrice = item.unitPrice; // Price locked at time of POS
        validatedItems.push({ ...item, variant, effectivePrice });
      }

      // 2. Calculate totals server-side (never trust frontend totals)
      let subtotal = 0;
      for (const item of validatedItems) {
        subtotal += item.effectivePrice * item.quantity;
      }
      subtotal = Math.round(subtotal * 100) / 100;

      // Discount
      let discountAmount = 0;
      if (discountType === 'percentage' && discVal > 0) {
        discountAmount = Math.round((subtotal * discVal / 100) * 100) / 100;
      } else if (discountType === 'fixed' && discVal > 0) {
        discountAmount = Math.min(discVal, subtotal);
      }
      discountAmount = Math.round(discountAmount * 100) / 100;

      const taxableAmount = Math.round((subtotal - discountAmount) * 100) / 100;

      // Tax
      const effectiveTaxRate = Number(taxRate) || 0;
      const taxAmount = Math.round((taxableAmount * effectiveTaxRate / 100) * 100) / 100;

      const totalAmount = Math.round((taxableAmount + taxAmount) * 100) / 100;

      // Validate payment
      const effectivePaymentAmount = paymentAmount !== undefined && paymentAmount !== null ? Number(paymentAmount) : totalAmount;
      const paidAmount = Math.round(effectivePaymentAmount * 100) / 100;
      if (paidAmount < totalAmount - 0.01) { // 0.01 tolerance for floating point
        throw new Error(`Insufficient payment. Total is ₹${totalAmount.toFixed(2)}, received ₹${paidAmount.toFixed(2)}.`);
      }
      const changeAmount = Math.round(Math.max(0, paidAmount - totalAmount) * 100) / 100;

      // 3. Generate invoice number atomically using configured prefix
      const invoiceNumber = getNextInvoiceNumber(storeId);
      const saleId = 'sal_' + crypto.randomBytes(8).toString('hex');
      const now = new Date().toISOString();

      // 4. Insert sale record
      db.prepare(`
        INSERT INTO sales (id, storeId, invoiceNumber, customerId, cashierId, cashierName, subtotal, discountType, discountValue, discountAmount, taxRate, taxAmount, totalAmount, paymentMethod, paymentAmount, changeAmount, status, note, createdAt, updatedAt)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'COMPLETED', ?, ?, ?)
      `).run(
        saleId, storeId, invoiceNumber,
        customerId || null, cashierId || null, cashierName || 'Cashier',
        subtotal, discountType || 'none', discVal, discountAmount,
        effectiveTaxRate, taxAmount, totalAmount,
        paymentMethod || 'CASH', paidAmount, changeAmount,
        note || null, now, now
      );

      // 5. Insert sale items + deduct stock + create inventory transactions
      for (const item of validatedItems) {
        const { variant, effectivePrice } = item;
        const lineTotal = Math.round(effectivePrice * item.quantity * 100) / 100;
        const itemId = 'sit_' + crypto.randomBytes(8).toString('hex');

        db.prepare(`
          INSERT INTO sale_items (id, saleId, storeId, productId, variantId, productNameSnapshot, skuSnapshot, sizeSnapshot, colorSnapshot, barcodeSnapshot, unitPrice, quantity, discountAmount, taxAmount, lineTotal)
          VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 0, 0, ?)
        `).run(
          itemId, saleId, storeId,
          variant.productId, variant.id,
          variant.productName,
          variant.sku || null,
          variant.size || null,
          variant.color || null,
          variant.barcode || null,
          effectivePrice, item.quantity, lineTotal
        );

        // Deduct stock
        const prevStock = variant.stock;
        const newStock = prevStock - item.quantity;
        db.prepare('UPDATE product_variants SET stock = ?, updatedAt = ? WHERE id = ?').run(newStock, now, variant.id);

        // Create inventory transaction for this sale
        const txId = 'itx_' + crypto.randomBytes(8).toString('hex');
        db.prepare(`
          INSERT INTO inventory_transactions (id, storeId, productId, variantId, action, quantity, previousQuantity, newQuantity, reason, performedBy, note, createdAt)
          VALUES (?, ?, ?, ?, 'REMOVE_STOCK', ?, ?, ?, 'SALE', ?, ?, ?)
        `).run(txId, storeId, variant.productId, variant.id, item.quantity, prevStock, newStock, cashierName || 'Cashier', `Sale: ${invoiceNumber}`, now);
      }

      // 6. Update customer stats
      if (customerId) {
        db.prepare(`
          UPDATE customers SET totalPurchases = totalPurchases + 1, totalSpent = totalSpent + ?, updatedAt = ? WHERE id = ? AND storeId = ?
        `).run(totalAmount, now, customerId, storeId);
      }

      db.exec('COMMIT');

      // Post-commit triggers: Notifications & stock monitors
      try {
        if (settings.lowStockAlerts || settings.outOfStockAlerts) {
          NotificationModel.checkLowStockAlerts(storeId);
        }
        NotificationModel.create({
          storeId,
          targetRole: 'ALL',
          type: 'SALE_COMPLETED',
          title: `Sale Completed: ${invoiceNumber}`,
          message: `Invoice ${invoiceNumber} completed for ₹${totalAmount.toFixed(2)} (${paymentMethod}) by ${cashierName}.`,
          recordId: saleId,
          recordType: 'sale'
        });
      } catch (notifErr) {
        console.error('Non-critical notification trigger error:', notifErr);
      }

      return SaleModel.findById(saleId, storeId);
    } catch (err) {
      db.exec('ROLLBACK');
      throw err;
    }
  },

  findById: (id, storeId) => {
    const sale = db.prepare(`
      SELECT s.*, c.name AS customerName, c.phone AS customerPhone
      FROM sales s
      LEFT JOIN customers c ON s.customerId = c.id
      WHERE s.id = ? AND s.storeId = ?
    `).get(id, storeId);
    if (!sale) return null;

    const items = db.prepare('SELECT * FROM sale_items WHERE saleId = ? ORDER BY rowid ASC').all(id);
    return { ...sale, items };
  },

  findByInvoice: (invoiceNumber, storeId) => {
    const sale = db.prepare('SELECT id FROM sales WHERE invoiceNumber = ? AND storeId = ?').get(invoiceNumber, storeId);
    if (!sale) return null;
    return SaleModel.findById(sale.id, storeId);
  },

  findAll: ({ storeId, cashierId, search, paymentMethod, status, startDate, endDate, page = 1, limit = 20 }) => {
    const offset = (page - 1) * limit;
    const conditions = ['s.storeId = ?'];
    const params = [storeId];

    if (cashierId) { conditions.push('s.cashierId = ?'); params.push(cashierId); }
    if (paymentMethod) { conditions.push('s.paymentMethod = ?'); params.push(paymentMethod); }
    if (status) { conditions.push('s.status = ?'); params.push(status); }
    if (startDate) { conditions.push("s.createdAt >= ?"); params.push(startDate); }
    if (endDate) { conditions.push("s.createdAt <= ?"); params.push(endDate + 'T23:59:59.999Z'); }
    if (search) {
      conditions.push('(s.invoiceNumber LIKE ? OR c.name LIKE ? OR c.phone LIKE ?)');
      const q = `%${search}%`;
      params.push(q, q, q);
    }

    const where = conditions.join(' AND ');
    const total = db.prepare(`
      SELECT COUNT(*) AS cnt FROM sales s LEFT JOIN customers c ON s.customerId = c.id WHERE ${where}
    `).get(...params).cnt;

    const rows = db.prepare(`
      SELECT s.*, c.name AS customerName, c.phone AS customerPhone,
        (SELECT COUNT(*) FROM sale_items WHERE saleId = s.id) AS itemCount
      FROM sales s
      LEFT JOIN customers c ON s.customerId = c.id
      WHERE ${where}
      ORDER BY s.createdAt DESC
      LIMIT ? OFFSET ?
    `).all(...params, limit, offset);

    return { sales: rows, total, page: Number(page), limit: Number(limit), totalPages: Math.ceil(total / limit) };
  },

  cancel: (id, storeId, cancelledBy) => {
    const sale = SaleModel.findById(id, storeId);
    if (!sale) return null;
    if (sale.status === 'CANCELLED') throw new Error('Sale is already cancelled.');

    db.exec('BEGIN');
    try {
      const now = new Date().toISOString();
      db.prepare("UPDATE sales SET status = 'CANCELLED', updatedAt = ? WHERE id = ? AND storeId = ?").run(now, id, storeId);

      // Reverse inventory for each item
      for (const item of sale.items) {
        const variant = db.prepare('SELECT stock FROM product_variants WHERE id = ?').get(item.variantId);
        if (variant) {
          const prevStock = variant.stock;
          const newStock = prevStock + item.quantity;
          db.prepare('UPDATE product_variants SET stock = ?, updatedAt = ? WHERE id = ?').run(newStock, now, item.variantId);

          const txId = 'itx_' + crypto.randomBytes(8).toString('hex');
          db.prepare(`
            INSERT INTO inventory_transactions (id, storeId, productId, variantId, action, quantity, previousQuantity, newQuantity, reason, performedBy, note, createdAt)
            VALUES (?, ?, ?, ?, 'ADD_STOCK', ?, ?, ?, 'SALE_CANCELLED', ?, ?, ?)
          `).run(txId, storeId, item.productId, item.variantId, item.quantity, prevStock, newStock, cancelledBy, `Cancellation: ${sale.invoiceNumber}`, now);
        }
      }

      db.exec('COMMIT');
      return SaleModel.findById(id, storeId);
    } catch (err) {
      db.exec('ROLLBACK');
      throw err;
    }
  },

  getTodayStats: (storeId) => {
    const todayStart = new Date();
    todayStart.setHours(0, 0, 0, 0);
    const todayEnd = new Date();
    todayEnd.setHours(23, 59, 59, 999);

    const row = db.prepare(`
      SELECT
        COUNT(*) AS totalSales,
        COALESCE(SUM(totalAmount), 0) AS totalRevenue,
        COALESCE(SUM(CASE WHEN paymentMethod = 'CASH' THEN totalAmount ELSE 0 END), 0) AS cashRevenue,
        COALESCE(SUM(CASE WHEN paymentMethod = 'UPI' THEN totalAmount ELSE 0 END), 0) AS upiRevenue,
        COALESCE(SUM(CASE WHEN paymentMethod = 'CARD' THEN totalAmount ELSE 0 END), 0) AS cardRevenue
      FROM sales
      WHERE storeId = ? AND status = 'COMPLETED' AND createdAt >= ? AND createdAt <= ?
    `).get(storeId, todayStart.toISOString(), todayEnd.toISOString());

    const salesCount = Number(row?.totalSales) || 0;
    const revenue = Number(row?.totalRevenue) || 0;
    const avg = salesCount > 0 ? Math.round((revenue / salesCount) * 100) / 100 : 0;

    return {
      salesCount,
      revenue,
      totalSales: salesCount,
      totalRevenue: revenue,
      averageOrderValue: avg,
      byPaymentMethod: {
        CASH: Number(row?.cashRevenue) || 0,
        UPI: Number(row?.upiRevenue) || 0,
        CARD: Number(row?.cardRevenue) || 0
      }
    };
  },

  // POS product search — searches by name, SKU, barcode within the store
  searchProducts: (storeId, query, limit = 15) => {
    if (!query || !query.trim()) return [];
    const q = `%${query.trim()}%`;
    const rows = db.prepare(`
      SELECT
        p.id AS productId, p.name AS productName, p.sku AS productSku, p.sellingPrice,
        p.barcode AS productBarcode, p.minimumStock,
        pv.id AS variantId, pv.size, pv.color, pv.sku AS variantSku,
        pv.barcode AS variantBarcode, pv.stock, pv.price AS variantPrice,
        c.name AS categoryName, b.name AS brandName
      FROM product_variants pv
      JOIN products p ON pv.productId = p.id
      LEFT JOIN categories c ON p.categoryId = c.id
      LEFT JOIN brands b ON p.brandId = b.id
      WHERE p.storeId = ? AND p.archived = 0 AND p.active = 1 AND pv.active = 1
        AND (p.name LIKE ? OR p.sku LIKE ? OR p.barcode LIKE ? OR pv.sku LIKE ? OR pv.barcode LIKE ?)
      ORDER BY p.name ASC, pv.size ASC
      LIMIT ?
    `).all(storeId, q, q, q, q, q, limit);

    return rows.map(r => ({
      ...r,
      effectivePrice: r.variantPrice !== null ? r.variantPrice : r.sellingPrice,
      stockStatus: r.stock === 0 ? 'OUT_OF_STOCK' : 'IN_STOCK'
    }));
  },

  // Barcode lookup — exact match on product or variant barcode
  lookupBarcode: (storeId, barcode) => {
    if (!barcode || !barcode.trim()) return null;
    const bc = barcode.trim();

    // First try variant barcode
    const variantRow = db.prepare(`
      SELECT
        p.id AS productId, p.name AS productName, p.sku AS productSku, p.sellingPrice,
        p.barcode AS productBarcode,
        pv.id AS variantId, pv.size, pv.color, pv.sku AS variantSku,
        pv.barcode AS variantBarcode, pv.stock, pv.price AS variantPrice,
        c.name AS categoryName, b.name AS brandName
      FROM product_variants pv
      JOIN products p ON pv.productId = p.id
      LEFT JOIN categories c ON p.categoryId = c.id
      LEFT JOIN brands b ON p.brandId = b.id
      WHERE p.storeId = ? AND p.archived = 0 AND p.active = 1 AND pv.active = 1 AND pv.barcode = ?
      LIMIT 1
    `).get(storeId, bc);

    if (variantRow) {
      return { ...variantRow, effectivePrice: variantRow.variantPrice !== null ? variantRow.variantPrice : variantRow.sellingPrice };
    }

    // Then try product barcode
    const productRow = db.prepare(`
      SELECT
        p.id AS productId, p.name AS productName, p.sku AS productSku, p.sellingPrice,
        p.barcode AS productBarcode,
        pv.id AS variantId, pv.size, pv.color, pv.sku AS variantSku,
        pv.barcode AS variantBarcode, pv.stock, pv.price AS variantPrice,
        c.name AS categoryName, b.name AS brandName
      FROM products p
      JOIN product_variants pv ON pv.productId = p.id AND pv.active = 1
      LEFT JOIN categories c ON p.categoryId = c.id
      LEFT JOIN brands b ON p.brandId = b.id
      WHERE p.storeId = ? AND p.archived = 0 AND p.active = 1 AND p.barcode = ?
      ORDER BY pv.stock DESC
      LIMIT 1
    `).get(storeId, bc);

    if (productRow) {
      return { ...productRow, effectivePrice: productRow.variantPrice !== null ? productRow.variantPrice : productRow.sellingPrice };
    }

    return null;
  }
};

module.exports = { SaleModel, getStoreTaxSettings, updateStoreTaxSettings };
