const crypto = require('crypto');
const db = require('../db/database');
const NotificationModel = require('./notificationModel');

const EXPENSE_CATEGORIES = [
  'Rent',
  'Utilities',
  'Salaries',
  'Marketing',
  'Maintenance',
  'Supplies',
  'Transport',
  'Other'
];

const ExpenseModel = {
  CATEGORIES: EXPENSE_CATEGORIES,

  create: ({ storeId, title, category, amount, date, expenseDate, paymentMethod = 'CASH', notes = '', createdBy }) => {
    if (!title || !title.trim()) throw new Error('Expense title is required.');
    if (!category || !category.trim()) throw new Error('Expense category is required.');
    const numAmount = Number(amount);
    if (isNaN(numAmount) || numAmount <= 0) throw new Error('Expense amount must be a positive number.');
    const effectiveDate = date || expenseDate || new Date().toISOString().split('T')[0];

    const id = `exp_${crypto.randomBytes(8).toString('hex')}`;
    const now = new Date().toISOString();

    db.prepare(`
      INSERT INTO expenses (id, storeId, title, category, amount, date, paymentMethod, notes, createdBy, status, createdAt, updatedAt)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 'ACTIVE', ?, ?)
    `).run(id, storeId, title.trim(), category.trim(), numAmount, effectiveDate, paymentMethod || 'CASH', notes ? notes.trim() : '', createdBy || 'Staff', now, now);

    try {
      NotificationModel.create({
        storeId,
        targetRole: 'OWNER',
        type: 'EXPENSE_CREATED',
        title: `Expense Recorded: ${title.trim()}`,
        message: `₹${numAmount.toFixed(2)} recorded for ${category.trim()} by ${createdBy || 'Staff'}.`,
        recordId: id,
        recordType: 'expense'
      });
    } catch {
      // Non-critical
    }

    return ExpenseModel.findById(id, storeId);
  },

  update: (id, storeId, { title, category, amount, date, paymentMethod, notes }) => {
    const existing = ExpenseModel.findById(id, storeId);
    if (!existing) throw new Error('Expense not found.');

    const updates = [];
    const params = [];

    if (title !== undefined) {
      if (!title || !title.trim()) throw new Error('Expense title cannot be empty.');
      updates.push('title = ?');
      params.push(title.trim());
    }
    if (category !== undefined) {
      if (!category || !category.trim()) throw new Error('Expense category cannot be empty.');
      updates.push('category = ?');
      params.push(category.trim());
    }
    if (amount !== undefined) {
      const num = Number(amount);
      if (isNaN(num) || num <= 0) throw new Error('Expense amount must be a positive number.');
      updates.push('amount = ?');
      params.push(num);
    }
    if (date !== undefined) {
      if (!date) throw new Error('Expense date is required.');
      updates.push('date = ?');
      params.push(date);
    }
    if (paymentMethod !== undefined) {
      updates.push('paymentMethod = ?');
      params.push(paymentMethod || 'CASH');
    }
    if (notes !== undefined) {
      updates.push('notes = ?');
      params.push(notes ? notes.trim() : '');
    }

    if (updates.length === 0) return existing;

    const now = new Date().toISOString();
    updates.push('updatedAt = ?');
    params.push(now);

    params.push(storeId, id);

    db.prepare(`
      UPDATE expenses SET ${updates.join(', ')}
      WHERE storeId = ? AND id = ?
    `).run(...params);

    return ExpenseModel.findById(id, storeId);
  },

  archive: (id, storeId) => {
    const existing = ExpenseModel.findById(id, storeId);
    if (!existing) throw new Error('Expense not found.');

    const now = new Date().toISOString();
    db.prepare(`
      UPDATE expenses SET status = 'ARCHIVED', updatedAt = ?
      WHERE storeId = ? AND id = ?
    `).run(now, storeId, id);

    return ExpenseModel.findById(id, storeId);
  },

  restore: (id, storeId) => {
    const existing = ExpenseModel.findById(id, storeId);
    if (!existing) throw new Error('Expense not found.');

    const now = new Date().toISOString();
    db.prepare(`
      UPDATE expenses SET status = 'ACTIVE', updatedAt = ?
      WHERE storeId = ? AND id = ?
    `).run(now, storeId, id);

    return ExpenseModel.findById(id, storeId);
  },

  findById: (id, storeId) => {
    return db.prepare(`
      SELECT * FROM expenses WHERE storeId = ? AND id = ?
    `).get(storeId, id) || null;
  },

  findAll: ({ storeId, search = '', category = '', status = 'ACTIVE', startDate = '', endDate = '', page = 1, limit = 20, sortBy = 'date', sortDir = 'DESC' }) => {
    const offset = (page - 1) * limit;
    const conditions = ['storeId = ?'];
    const params = [storeId];

    if (status && status !== 'ALL') {
      conditions.push('status = ?');
      params.push(status);
    }

    if (category) {
      conditions.push('category = ?');
      params.push(category);
    }

    if (startDate) {
      conditions.push('date >= ?');
      params.push(startDate);
    }

    if (endDate) {
      conditions.push('date <= ?');
      params.push(endDate);
    }

    if (search && search.trim()) {
      conditions.push('(title LIKE ? OR notes LIKE ? OR createdBy LIKE ?)');
      const q = `%${search.trim()}%`;
      params.push(q, q, q);
    }

    const where = conditions.join(' AND ');

    const validSortCols = {
      date: 'date',
      amount: 'amount',
      title: 'title',
      category: 'category',
      createdAt: 'createdAt'
    };
    const sortCol = validSortCols[sortBy] || 'date';
    const direction = sortDir.toUpperCase() === 'ASC' ? 'ASC' : 'DESC';

    const countRow = db.prepare(`
      SELECT COUNT(*) AS total, COALESCE(SUM(amount), 0) AS totalAmount
      FROM expenses
      WHERE ${where}
    `).get(...params);

    const total = Number(countRow?.total) || 0;
    const totalAmount = Number(countRow?.totalAmount) || 0;

    const expenses = db.prepare(`
      SELECT * FROM expenses
      WHERE ${where}
      ORDER BY ${sortCol} ${direction}, createdAt DESC
      LIMIT ? OFFSET ?
    `).all(...params, limit, offset);

    return {
      expenses,
      totalAmount,
      pagination: {
        total,
        page: Number(page),
        limit: Number(limit),
        totalPages: Math.ceil(total / limit)
      }
    };
  },

  getSummary: ({ storeId, startDate = '', endDate = '' }) => {
    const conditions = ['storeId = ?', "status = 'ACTIVE'"];
    const params = [storeId];

    if (startDate) {
      conditions.push('date >= ?');
      params.push(startDate);
    }
    if (endDate) {
      conditions.push('date <= ?');
      params.push(endDate);
    }

    const where = conditions.join(' AND ');

    const totalRow = db.prepare(`
      SELECT COUNT(*) AS totalCount, COALESCE(SUM(amount), 0) AS totalAmount
      FROM expenses
      WHERE ${where}
    `).get(...params);

    const totalAmount = Number(totalRow?.totalAmount) || 0;
    const totalCount = Number(totalRow?.totalCount) || 0;

    // By category
    const categoryRows = db.prepare(`
      SELECT category, COUNT(*) as count, COALESCE(SUM(amount), 0) as amount
      FROM expenses
      WHERE ${where}
      GROUP BY category
      ORDER BY amount DESC
    `).all(...params);

    const byCategory = categoryRows.map(r => ({
      category: r.category,
      count: Number(r.count),
      amount: Number(r.amount),
      percentage: totalAmount > 0 ? Number(((r.amount / totalAmount) * 100).toFixed(1)) : 0
    }));

    // Over time (grouped by date)
    const overTimeRows = db.prepare(`
      SELECT date, COUNT(*) as count, COALESCE(SUM(amount), 0) as amount
      FROM expenses
      WHERE ${where}
      GROUP BY date
      ORDER BY date ASC
    `).all(...params);

    const overTime = overTimeRows.map(r => ({
      date: r.date,
      count: Number(r.count),
      amount: Number(r.amount)
    }));

    return {
      totalAmount,
      totalCount,
      byCategory,
      overTime
    };
  }
};

module.exports = ExpenseModel;
