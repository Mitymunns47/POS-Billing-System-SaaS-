const express = require('express');
const router = express.Router();
const ProductModel = require('../models/productModel');
const VariantModel = require('../models/variantModel');
const InventoryTxModel = require('../models/inventoryTxModel');
const authMiddleware = require('../middleware/auth');
const { requirePermission } = require('../middleware/roles');
const { PERMISSIONS } = require('../constants/roles');

router.use(authMiddleware);

// GET /api/inventory/stats
router.get('/stats', requirePermission(PERMISSIONS.INVENTORY_VIEW), (req, res) => {
  try {
    const stats = ProductModel.getStats(req.storeId);
    res.json({ success: true, stats });
  } catch (err) {
    res.status(500).json({ success: false, error: 'Could not load inventory stats.' });
  }
});

// GET /api/inventory — product-level inventory with variant stock
router.get('/', requirePermission(PERMISSIONS.INVENTORY_VIEW), (req, res) => {
  try {
    const { search, status, page = 1, limit = 20 } = req.query;
    const result = ProductModel.findAll({
      storeId: req.storeId,
      search: search || '',
      page: parseInt(page) || 1,
      limit: Math.min(parseInt(limit) || 20, 100),
      status: status || '',
      sortBy: 'updatedAt',
      sortDir: 'DESC'
    });
    res.json({ success: true, ...result });
  } catch (err) {
    res.status(500).json({ success: false, error: 'Could not load inventory.' });
  }
});

// POST /api/inventory/adjust — adjust stock for a specific variant
router.post('/adjust', requirePermission(PERMISSIONS.INVENTORY_ADJUST), (req, res) => {
  try {
    const { productId, variantId, action, quantity, reason, note } = req.body;

    if (!productId) return res.status(400).json({ success: false, error: 'Product ID is required.' });
    if (!variantId) return res.status(400).json({ success: false, error: 'Variant ID is required.' });
    if (!action || !InventoryTxModel.VALID_ACTIONS.includes(action)) {
      return res.status(400).json({ success: false, error: `Action must be one of: ${InventoryTxModel.VALID_ACTIONS.join(', ')}` });
    }
    const qty = parseInt(quantity);
    if (isNaN(qty) || qty <= 0) return res.status(400).json({ success: false, error: 'Quantity must be a positive integer.' });

    // Verify product belongs to this store
    const product = ProductModel.findById(productId, req.storeId);
    if (!product) return res.status(404).json({ success: false, error: 'Product not found.' });

    const variant = VariantModel.findById(variantId, req.storeId);
    if (!variant) return res.status(404).json({ success: false, error: 'Variant not found.' });

    const prev = variant.stock;
    let newStock;

    switch (action) {
      case 'ADD_STOCK':
      case 'TRANSFER_IN':
        newStock = prev + qty;
        break;
      case 'REMOVE_STOCK':
      case 'TRANSFER_OUT':
        newStock = Math.max(0, prev - qty);
        break;
      case 'ADJUST_STOCK':
        newStock = qty; // Direct set
        break;
      default:
        newStock = prev + qty;
    }

    VariantModel.update(variantId, req.storeId, { stock: newStock });

    const tx = InventoryTxModel.record({
      storeId: req.storeId,
      productId,
      variantId,
      action,
      quantity: qty,
      previousQuantity: prev,
      newQuantity: newStock,
      reason: reason || '',
      performedBy: req.auth.userName,
      note: note || null
    });

    res.json({
      success: true,
      message: `Stock ${action.toLowerCase().replace('_', ' ')} recorded.`,
      transaction: tx,
      previousStock: prev,
      newStock
    });
  } catch (err) {
    console.error('Inventory adjust error:', err);
    res.status(500).json({ success: false, error: 'Could not process stock adjustment.' });
  }
});

// GET /api/inventory/history — paginated transaction log
router.get('/history', requirePermission(PERMISSIONS.INVENTORY_HISTORY), (req, res) => {
  try {
    const { productId, variantId, action, startDate, endDate, performedBy, page = 1, limit = 30 } = req.query;
    const result = InventoryTxModel.findAll({
      storeId: req.storeId,
      productId: productId || null,
      variantId: variantId || null,
      action: action || null,
      startDate: startDate || null,
      endDate: endDate || null,
      performedBy: performedBy || null,
      page: parseInt(page) || 1,
      limit: Math.min(parseInt(limit) || 30, 100)
    });
    res.json({ success: true, ...result });
  } catch (err) {
    res.status(500).json({ success: false, error: 'Could not load inventory history.' });
  }
});

module.exports = router;
