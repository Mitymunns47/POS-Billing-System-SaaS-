/**
 * AdminApp.jsx — Phase 7
 * Root component for the Westsides Platform Administration Portal.
 * Mounts at /admin and all /admin/* routes.
 * Completely separate from the store-level DashboardLayout.
 */
import React, { useState, useEffect } from 'react';
import { AdminAuthProvider, useAdminAuth } from '../context/AdminAuthContext';
import { AdminLayout } from '../components/admin/AdminLayout';
import { AdminLoginPage } from './admin/AdminLoginPage';
import { AdminDashboardPage } from './admin/AdminDashboardPage';
import { AdminStoresPage } from './admin/AdminStoresPage';
import { AdminStoreDetailPage } from './admin/AdminStoreDetailPage';
import { AdminPlansPage } from './admin/AdminPlansPage';
import { AdminInvoicesPage } from './admin/AdminInvoicesPage';
import { AdminAnalyticsPage } from './admin/AdminAnalyticsPage';
import { AdminAuditPage } from './admin/AdminAuditPage';
import { AdminSettingsPage } from './admin/AdminSettingsPage';

function AdminRouter() {
  const { isAdminAuthenticated, isAdminLoading } = useAdminAuth();
  const [currentPath, setCurrentPath] = useState(() => window.location.pathname);

  const navigate = (path) => {
    window.history.pushState({}, '', path);
    setCurrentPath(path);
  };

  useEffect(() => {
    const handlePop = () => setCurrentPath(window.location.pathname);
    window.addEventListener('popstate', handlePop);
    return () => window.removeEventListener('popstate', handlePop);
  }, []);

  useEffect(() => {
    if (isAdminLoading) return;
    if (!isAdminAuthenticated && currentPath !== '/admin' && currentPath !== '/admin/') {
      navigate('/admin');
    }
    if (isAdminAuthenticated && (currentPath === '/admin' || currentPath === '/admin/')) {
      navigate('/admin/dashboard');
    }
  }, [isAdminAuthenticated, isAdminLoading, currentPath]);

  if (isAdminLoading) {
    return (
      <div style={{
        minHeight: '100vh', background: '#0F172A',
        display: 'flex', alignItems: 'center', justifyContent: 'center',
        fontFamily: "'Inter', 'Segoe UI', sans-serif"
      }}>
        <div style={{ textAlign: 'center' }}>
          <div style={{ width: '40px', height: '40px', borderRadius: '10px', background: 'linear-gradient(135deg, #7EAFD0, #5B91B8)', display: 'flex', alignItems: 'center', justifyContent: 'center', margin: '0 auto 1rem', color: '#fff', fontWeight: '700', fontSize: '1.25rem' }}>W</div>
          <div style={{ color: '#64748B', fontSize: '0.875rem' }}>Verifying platform access...</div>
        </div>
      </div>
    );
  }

  if (!isAdminAuthenticated) {
    return <AdminLoginPage onNavigate={navigate} />;
  }

  const inLayout = (page) => (
    <AdminLayout currentPath={currentPath} onNavigate={navigate}>
      {page}
    </AdminLayout>
  );

  // Dynamic store detail route: /admin/stores/:id
  if (currentPath.startsWith('/admin/stores/')) {
    const storeId = currentPath.split('/')[3];
    if (storeId) return inLayout(<AdminStoreDetailPage storeId={storeId} onNavigate={navigate} />);
  }

  switch (currentPath) {
    case '/admin/dashboard':
      return inLayout(<AdminDashboardPage onNavigate={navigate} />);
    case '/admin/stores':
      return inLayout(<AdminStoresPage onNavigate={navigate} />);
    case '/admin/plans':
      return inLayout(<AdminPlansPage onNavigate={navigate} />);
    case '/admin/invoices':
      return inLayout(<AdminInvoicesPage onNavigate={navigate} />);
    case '/admin/analytics':
      return inLayout(<AdminAnalyticsPage onNavigate={navigate} />);
    case '/admin/audit':
      return inLayout(<AdminAuditPage onNavigate={navigate} />);
    case '/admin/settings':
      return inLayout(<AdminSettingsPage onNavigate={navigate} />);
    case '/admin':
    case '/admin/':
    default:
      return <AdminLoginPage onNavigate={navigate} />;
  }
}

export function AdminApp() {
  return (
    <AdminAuthProvider>
      <AdminRouter />
    </AdminAuthProvider>
  );
}
