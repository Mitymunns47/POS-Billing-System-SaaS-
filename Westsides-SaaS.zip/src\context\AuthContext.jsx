import React, { createContext, useContext, useState, useEffect, useCallback } from 'react';
import { api } from '../services/api';

const AuthContext = createContext(null);

export function AuthProvider({ children }) {
  const [user, setUser] = useState(null);
  const [store, setStore] = useState(null);
  const [role, setRole] = useState(null);
  const [permissions, setPermissions] = useState([]);
  const [isLoading, setIsLoading] = useState(true);

  // Check existing session on boot
  const checkAuth = useCallback(async () => {
    setIsLoading(true);
    try {
      const data = await api.getMe();
      if (data.success) {
        setUser(data.user);
        setStore(data.store);
        setRole(data.role);
        setPermissions(data.permissions || []);
      } else {
        setUser(null);
        setStore(null);
        setRole(null);
        setPermissions([]);
      }
    } catch (err) {
      setUser(null);
      setStore(null);
      setRole(null);
      setPermissions([]);
    } finally {
      setIsLoading(false);
    }
  }, []);

  useEffect(() => {
    checkAuth();
  }, [checkAuth]);

  const login = async (credentials) => {
    const data = await api.login(credentials);
    if (data.success) {
      setUser(data.user);
      setStore(data.store);
      setRole(data.role);
      setPermissions(data.permissions || []);
    }
    return data;
  };

  const signup = async (formData) => {
    const data = await api.signup(formData);
    if (data.success) {
      setUser(data.user);
      setStore(data.store);
      setRole(data.role);
      setPermissions(data.permissions || []);
    }
    return data;
  };

  const logout = async () => {
    try {
      await api.logout();
    } finally {
      setUser(null);
      setStore(null);
      setRole(null);
      setPermissions([]);
    }
  };

  const updateStoreState = (storeData) => {
    setStore((prev) => ({
      ...prev,
      ...storeData
    }));
  };

  const updateUserState = (userData) => {
    setUser((prev) => ({
      ...prev,
      ...userData
    }));
  };

  const value = {
    user,
    store,
    role,
    permissions,
    isAuthenticated: Boolean(user && store),
    isLoading,
    login,
    signup,
    logout,
    checkAuth,
    updateStoreState,
    updateUserState
  };

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
}
