const crypto = require('crypto');
const db = require('../db/database');

const VALID_ACTIONS = ['ADD_STOCK', 'REMOVE_STOCK', 'ADJUST_STOCK', 'TRANSFER_OUT', 'TRANSFER_IN', 'INITIAL_STOCK'];

const InventoryTxModel = {
  record: ({ storeId, productId, variantId, action, quantity, previousQuantity, newQuantity, reason, performedBy, note }) => {
    if (!VALID_ACTIONS.includes(action)) throw new Error(`Invalid inventory action: ${action}`);
    const id = 'itx_' + crypto.randomBytes(8).toString('hex');
    const now = new Date().toISOString();
    db.prepare(`
      INSERT INTO inventory_transactions
        (id, storeId, productId, variantId, action, quantity, previousQuantity, newQuantity, reason, performedBy, note, createdAt)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `).run(
      id, storeId, productId,
      variantId || null,
      action,
      Number(quantity),
      Number(previousQuantity),
      Number(newQuantity),
      reason || '',
      performedBy,
      note || null,
      now
    );
    return InventoryTxModel.findById(id, storeId);
  },

  findById: (id, storeId) => {
    return db.prepare('SELECT * FROM inventory_transactions WHERE id = ? AND storeId = ?').get(id, storeId) || null;
  },

  findAll: ({ storeId, productId, variantId, action, startDate, endDate, performedBy, page = 1, limit = 30 }) => {
    const offset = (page - 1) * limit;
    const conditions = ['t.storeId = ?'];
    const params = [storeId];

    if (productId) { conditions.push('t.productId = ?'); params.push(productId); }
    if (variantId) { conditions.push('t.variantId = ?'); params.push(variantId); }
    if (action) { conditions.push('t.action = ?'); params.push(action); }
    if (startDate) { conditions.push("t.createdAt >= ?"); params.push(startDate); }
    if (endDate) { conditions.push("t.createdAt <= ?"); params.push(endDate + 'T23:59:59.999Z'); }
    if (performedBy) { conditions.push('t.performedBy LIKE ?'); params.push(`%${performedBy}%`); }

    const where = conditions.join(' AND ');

    const total = db.prepare(`SELECT COUNT(*) AS cnt FROM inventory_transactions t WHERE ${where}`).get(...params).cnt;

    const rows = db.prepare(`
      SELECT t.*,
        p.name AS productName, p.sku AS productSku,
        pv.size AS variantSize, pv.color AS variantColor, pv.sku AS variantSku
      FROM inventory_transactions t
      JOIN products p ON t.productId = p.id
      LEFT JOIN product_variants pv ON t.variantId = pv.id
      WHERE ${where}
      ORDER BY t.createdAt DESC
      LIMIT ? OFFSET ?
    `).all(...params, limit, offset);

    return {
      transactions: rows,
      total,
      page: Number(page),
      limit: Number(limit),
      totalPages: Math.ceil(total / limit)
    };
  },

  VALID_ACTIONS
};

module.exports = InventoryTxModel;
