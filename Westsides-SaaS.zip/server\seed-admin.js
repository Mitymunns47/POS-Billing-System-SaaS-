const crypto = require('crypto');
const bcrypt = require('bcryptjs');
const db = require('./db/database');
const UserModel = require('./models/userModel');
const StoreModel = require('./models/storeModel');
const StoreUserModel = require('./models/storeUserModel');
const { ROLES } = require('./constants/roles');

function seedAdminAccount() {
  console.log('--- Initializing Westsides Unique Admin Account ---');

  const adminEmail = 'admin@westsides.com';
  const adminPassword = 'WestSides#Admin2026!'; // Strong unique password
  const adminName = 'Westsides Administrator';
  const adminPhone = '+91 98200 99999';

  // 1. Find or create the primary Westsides store
  let storeStmt = db.prepare("SELECT * FROM stores WHERE name = 'Westsides' LIMIT 1");
  let store = storeStmt.get();

  if (!store) {
    store = StoreModel.create({
      name: 'Westsides',
      address: 'Flagship Store, Linking Road, Bandra West',
      city: 'Mumbai',
      state: 'Maharashtra',
      country: 'India',
      gstNumber: '27AAACW8888Z1Z5',
      phone: '+91 22 2600 8888',
      currency: 'INR',
      category: 'Apparel & Fashion'
    });

    // Mark onboarding as completed for this primary store
    StoreModel.update(store.id, {
      onboardingCompleted: 1,
      onboardingStep: 4,
      receiptHeader: 'Westsides - Contemporary Apparel & Fashion',
      receiptFooter: 'Thank you for shopping with Westsides! Exchange within 14 days.'
    });
    console.log(`✓ Created primary store: "${store.name}" (ID: ${store.id})`);
  } else {
    // Ensure onboarding is marked complete
    StoreModel.update(store.id, {
      onboardingCompleted: 1,
      onboardingStep: 4
    });
    console.log(`✓ Found primary store: "${store.name}" (ID: ${store.id})`);
  }

  // 2. Check if admin user already exists
  let user = UserModel.findByEmail(adminEmail);
  const salt = bcrypt.genSaltSync(10);
  const passwordHash = bcrypt.hashSync(adminPassword, salt);
  const now = new Date().toISOString();

  if (user) {
    // Update existing admin password and credentials
    const updateStmt = db.prepare(`
      UPDATE users 
      SET passwordHash = ?, name = ?, phone = ?, updatedAt = ?
      WHERE id = ?
    `);
    updateStmt.run(passwordHash, adminName, adminPhone, now, user.id);
    console.log(`✓ Updated existing admin account: ${adminEmail}`);
  } else {
    // Create new admin user
    const userId = 'usr_' + crypto.randomBytes(8).toString('hex');
    const insertStmt = db.prepare(`
      INSERT INTO users (id, name, email, phone, passwordHash, createdAt, updatedAt)
      VALUES (?, ?, ?, ?, ?, ?, ?)
    `);
    insertStmt.run(userId, adminName, adminEmail, adminPhone, passwordHash, now, now);
    user = UserModel.findById(userId);
    console.log(`✓ Created unique admin user: ${adminEmail} (ID: ${user.id})`);
  }

  // 3. Ensure store_user link with OWNER role
  const existingMapping = StoreUserModel.findByUserAndStore(user.id, store.id);
  if (!existingMapping) {
    StoreUserModel.create({
      storeId: store.id,
      userId: user.id,
      role: ROLES.OWNER
    });
    console.log(`✓ Assigned OWNER role to ${adminEmail} for store "${store.name}"`);
  } else {
    console.log(`✓ Verified OWNER role for ${adminEmail} in store "${store.name}"`);
  }

  // 4. Verify password verification
  const verify = UserModel.verifyPassword(adminPassword, passwordHash);
  if (!verify) {
    throw new Error('Password hash verification failed!');
  }

  console.log('\n======================================================');
  console.log(' WESTSIDES SAAS ADMIN CREDENTIALS');
  console.log('======================================================');
  console.log(`Portal URL:  http://localhost:5000/login`);
  console.log(`Store Name:  ${store.name}`);
  console.log(`Tenant ID:   ${store.id}`);
  console.log(`Email/User:  ${adminEmail}`);
  console.log(`Password:    ${adminPassword}`);
  console.log(`Role:        ${ROLES.OWNER}`);
  console.log('======================================================\n');
}

seedAdminAccount();
