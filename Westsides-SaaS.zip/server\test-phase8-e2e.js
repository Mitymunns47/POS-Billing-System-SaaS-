/**
 * ==============================================================================
 * Phase 8 Comprehensive End-to-End & Security Acceptance Test Suite
 * ==============================================================================
 * Validates Workflows A through G, Multi-Tenant Security, Idempotency,
 * Subscription Enforcements, Decimal Calculations, and Mobile API Foundation.
 */

const http = require('http');

const BASE_URL = 'http://localhost:5000';
const API_URL = `${BASE_URL}/api/v1`;

let passedCount = 0;
let totalCount = 0;

function assert(condition, message) {
  totalCount++;
  if (!condition) {
    console.error(`❌ [FAIL] ${message}`);
    throw new Error(`Assertion failed: ${message}`);
  }
  passedCount++;
  console.log(`  ✓ ${message}`);
}

async function apiRequest(path, options = {}) {
  const url = path.startsWith('http') ? path : `${API_URL}${path}`;
  const headers = { 'Content-Type': 'application/json', ...(options.headers || {}) };
  const res = await fetch(url, { ...options, headers });
  let data = null;
  try {
    data = await res.json();
  } catch (err) {
    // If not JSON
  }
  return { status: res.status, headers: res.headers, data };
}

async function runTestSuite() {
  console.log('\n=================================================================');
  console.log('🚀 RUNNING PHASE 8 COMPREHENSIVE END-TO-END TEST SUITE');
  console.log('=================================================================\n');

  const ts = Date.now();

  // ── HEALTH & MOBILE API FOUNDATION ─────────────────────────────────────────
  console.log('--- 1. Testing Health & Mobile API Parity ---');
  const healthRes = await apiRequest('/health');
  assert(healthRes.status === 200, 'GET /api/v1/health returns 200 OK');
  assert(healthRes.data.status === 'healthy', 'System status is healthy');
  assert(healthRes.data.database.status === 'healthy', 'Database connectivity probe is healthy');
  assert(healthRes.data.mobileApi.version === 'v1', 'Mobile API v1 foundation is active');

  // ── WORKFLOW A: SIGNUP → CREATE STORE → ONBOARDING ──────────────────────────
  console.log('\n--- 2. Workflow A: Store Owner Signup & Onboarding ---');
  const ownerEmail = `phase8_owner_${ts}@westsides.com`;
  const ownerPassword = 'Password@2026!';
  const storeName = `Phase8 Boutique ${ts}`;

  const signupRes = await apiRequest('/auth/signup', {
    method: 'POST',
    body: JSON.stringify({
      ownerName: 'Priya Sharma',
      email: ownerEmail,
      phone: '9820011122',
      password: ownerPassword,
      confirmPassword: ownerPassword,
      storeName: storeName,
      city: 'Mumbai',
      state: 'Maharashtra',
      country: 'India'
    })
  });

  assert(signupRes.status === 200 || signupRes.status === 201, 'Signup succeeds');
  assert(signupRes.data.success === true, 'Signup response indicates success');
  assert(Boolean(signupRes.data.token), 'Signup returns auth session token');

  const storeAToken = signupRes.data.token;
  const storeAId = signupRes.data.store.id;
  const authHeadersA = { 'Authorization': `Bearer ${storeAToken}` };

  // Verify store profile & auto-assigned trial/subscription
  const storeProfileRes = await apiRequest('/store', { headers: authHeadersA });
  assert(storeProfileRes.status === 200, 'GET /api/v1/store retrieves store details');
  assert(storeProfileRes.data.store.name === storeName, 'Store name matches signup');

  // Complete onboarding
  const onboardRes = await apiRequest('/store/onboarding', {
    method: 'POST',
    headers: authHeadersA,
    body: JSON.stringify({
      category: 'Women Ethnic Wear',
      gstNumber: '27AABCU9603R1ZM',
      receiptHeader: 'Welcome to Westsides Phase 8',
      receiptFooter: 'Thank you for shopping with us!'
    })
  });
  assert(onboardRes.status === 200, 'POST /store/onboarding completed');

  // ── WORKFLOW B: PRODUCT → VARIANT → STOCK → CUSTOMER → POS SALE ────────────
  console.log('\n--- 3. Workflow B: Catalog, Product, Inventory, Customer & POS Sale ---');

  // Create Product
  const prodRes = await apiRequest('/products', {
    method: 'POST',
    headers: authHeadersA,
    body: JSON.stringify({
      name: 'Chanderi Silk Kurti',
      sku: `KUR-${ts}`,
      costPrice: 500,
      mrp: 1299,
      sellingPrice: 999,
      minimumStock: 2,
      barcode: `8901234${ts.toString().slice(-6)}`
    })
  });
  assert(prodRes.status === 200 || prodRes.status === 201, 'Product created');
  const productId = prodRes.data.product.id;

  // Create Variant with Stock
  const variantRes = await apiRequest(`/products/${productId}/variants`, {
    method: 'POST',
    headers: authHeadersA,
    body: JSON.stringify({
      size: 'M',
      color: 'Teal Blue',
      stock: 10,
      sku: `KUR-${ts}-M`,
      barcode: `8901234${ts.toString().slice(-5)}M`
    })
  });
  assert(variantRes.status === 200 || variantRes.status === 201, 'Product variant created with initial stock');
  const variantId = variantRes.data.variant.id;

  // Create Customer
  const custRes = await apiRequest('/customers', {
    method: 'POST',
    headers: authHeadersA,
    body: JSON.stringify({
      name: 'Ananya Roy',
      phone: `9988${ts.toString().slice(-6)}`,
      email: `ananya_${ts}@gmail.com`,
      city: 'Mumbai'
    })
  });
  assert(custRes.status === 200 || custRes.status === 201, 'Customer created');
  const customerId = custRes.data.customer.id;

  // POS Sale: 2 units of variant at 999, with 10% discount and 5% GST
  const salePayload = {
    customerId: customerId,
    items: [{ variantId, quantity: 2, unitPrice: 999 }],
    discountType: 'percentage',
    discountValue: 10,
    taxRate: 5,
    paymentMethod: 'CASH',
    paymentAmount: 2000,
    note: 'Phase 8 Acceptance Test Sale'
  };

  const saleRes = await apiRequest('/pos/sales', {
    method: 'POST',
    headers: authHeadersA,
    body: JSON.stringify(salePayload)
  });

  assert(saleRes.status === 201, 'POS sale completed with HTTP 201');
  assert(saleRes.data.success === true, 'Sale marked success');
  const sale = saleRes.data.sale;
  assert(sale.subtotal === 1998, `Subtotal calculated: ${sale.subtotal} (expected 1998)`);
  assert(sale.discountAmount === 199.8, `Discount calculated: ${sale.discountAmount} (expected 199.80)`);
  assert(sale.taxAmount === 89.91, `Tax calculated: ${sale.taxAmount} (expected 89.91)`);
  assert(sale.totalAmount === 1888.11, `Total amount calculated: ${sale.totalAmount} (expected 1888.11)`);
  assert(Boolean(sale.invoiceNumber), `Collison-free invoice number generated: ${sale.invoiceNumber}`);

  // Check inventory deduction
  const prodCheckRes = await apiRequest(`/products/${productId}`, { headers: authHeadersA });
  const updatedVariant = prodCheckRes.data.product.variants.find(v => v.id === variantId);
  assert(updatedVariant && updatedVariant.stock === 8, `Stock reduced atomically from 10 to 8 (actual: ${updatedVariant?.stock})`);

  // Check customer stats updated
  const custDetailRes = await apiRequest(`/customers/${customerId}`, { headers: authHeadersA });
  assert(custDetailRes.data.customer.totalPurchases >= 1, 'Customer totalPurchases count incremented');
  assert(custDetailRes.data.customer.totalSpent >= 1888, 'Customer totalSpent balance updated');

  // ── WORKFLOW C: RETURN & REFUND RESTORATION ────────────────────────────────
  console.log('\n--- 4. Workflow C: Return, Pro-Rated Refund & Stock Restoration ---');
  const returnPayload = {
    saleId: sale.id,
    reason: 'Size did not fit customer',
    notes: 'Exchanged for store credit',
    refundMethod: 'CASH',
    items: [{
      saleItemId: sale.items[0].id,
      quantity: 1,
      condition: 'RESELLABLE'
    }]
  };

  const returnRes = await apiRequest('/returns', {
    method: 'POST',
    headers: authHeadersA,
    body: JSON.stringify(returnPayload)
  });
  const refundAmount = returnRes.data.data?.totalRefundAmount || returnRes.data.refundAmount;
  assert(refundAmount === 944.06, `Pro-rated refund: ₹${refundAmount} (expected ~944.06)`);

  // Verify stock restored
  const prodAfterReturn = await apiRequest(`/products/${productId}`, { headers: authHeadersA });
  const restoredVariant = prodAfterReturn.data.product.variants.find(v => v.id === variantId);
  assert(restoredVariant && restoredVariant.stock === 9, `Stock restored atomically from 8 to 9 (actual: ${restoredVariant?.stock})`);

  // ── WORKFLOW D: STAFF MANAGEMENT & ROLE PERMISSION ENFORCEMENT ────────────
  console.log('\n--- 5. Workflow D: Staff Creation & Cashier Role Permissions ---');
  const cashierEmail = `cashier_${ts}@westsides.com`;
  const cashierPassword = 'Cashier@Password2026!';

  const staffRes = await apiRequest('/staff', {
    method: 'POST',
    headers: authHeadersA,
    body: JSON.stringify({
      name: 'Rohan Verma',
      email: cashierEmail,
      phone: '9820033344',
      role: 'CASHIER',
      password: cashierPassword
    })
  });
  assert(staffRes.status === 201, 'Cashier account created by Owner');

  // Login as Cashier
  const cashierLoginRes = await apiRequest('/auth/login', {
    method: 'POST',
    body: JSON.stringify({ email: cashierEmail, password: cashierPassword })
  });
  assert(cashierLoginRes.status === 200, 'Cashier authenticated');
  const cashierToken = cashierLoginRes.data.token;
  const authHeadersCashier = { 'Authorization': `Bearer ${cashierToken}` };

  // Cashier should be able to view POS
  const cashierPosRes = await apiRequest('/pos/search?q=kurti', { headers: authHeadersCashier });
  assert(cashierPosRes.status === 200, 'Cashier permitted to search POS products');

  // Cashier should NOT be able to modify store settings (must return 403 Forbidden)
  const cashierSettingsRes = await apiRequest('/settings', {
    method: 'PUT',
    headers: authHeadersCashier,
    body: JSON.stringify({ allowDiscounts: false })
  });
  assert(cashierSettingsRes.status === 403, 'Cashier forbidden from modifying store operational settings (403)');

  // ── WORKFLOW E: EXPENSE MANAGEMENT ─────────────────────────────────────────
  console.log('\n--- 6. Workflow E: Expense Recording & Reporting ---');
  const expenseRes = await apiRequest('/expenses', {
    method: 'POST',
    headers: authHeadersA,
    body: JSON.stringify({
      title: 'Store Hanger & Display Supplies',
      category: 'Supplies',
      amount: 450,
      paymentMethod: 'CASH',
      notes: 'Purchased locally'
    })
  });
  assert(expenseRes.status === 201, 'Expense recorded');

  const expListRes = await apiRequest('/expenses', { headers: authHeadersA });
  assert(expListRes.status === 200, 'Expenses list retrieved');
  assert(expListRes.data.expenses.some(e => e.title.includes('Store Hanger')), 'Expense present in store ledger');

  // ── WORKFLOW F: MULTI-TENANT ISOLATION (CRITICAL SECURITY) ────────────────
  console.log('\n--- 7. Workflow F: Multi-Tenant Data Isolation Audit ---');
  // Create Store B
  const storeBEmail = `ownerB_${ts}@westsides.com`;
  const signupBRes = await apiRequest('/auth/signup', {
    method: 'POST',
    body: JSON.stringify({
      ownerName: 'Owner B',
      email: storeBEmail,
      phone: '9820055566',
      password: 'Password@StoreB2026!',
      confirmPassword: 'Password@StoreB2026!',
      storeName: `Store B ${ts}`,
      city: 'Bengaluru'
    })
  });
  const storeBToken = signupBRes.data.token;
  const authHeadersB = { 'Authorization': `Bearer ${storeBToken}` };

  // Attempt 1: Store B attempts to query Store A customer by ID
  const crossCustRes = await apiRequest(`/customers/${customerId}`, { headers: authHeadersB });
  assert(crossCustRes.status === 404 || crossCustRes.status === 403, 'Store B CANNOT read Store A customer (404/403 isolated)');

  // Attempt 2: Store B attempts to query Store A sale by ID
  const crossSaleRes = await apiRequest(`/pos/sales/${sale.id}`, { headers: authHeadersB });
  assert(crossSaleRes.status === 404 || crossSaleRes.status === 403, 'Store B CANNOT read Store A sale (404/403 isolated)');

  // Attempt 3: Store B attempts to query Store A product by ID
  const crossProdRes = await apiRequest(`/products/${productId}`, { headers: authHeadersB });
  assert(crossProdRes.status === 404 || crossProdRes.status === 403, 'Store B CANNOT read Store A product (404/403 isolated)');

  // ── WORKFLOW G: SUPER ADMIN PLATFORM SECURITY & LIFECYCLE ─────────────────
  console.log('\n--- 8. Workflow G: Super Admin Security & Store Suspension ---');
  // Attempt unauthorized access to admin dashboard with Store Owner token (must be 403)
  const fakeAdminRes = await apiRequest('/admin/dashboard', { headers: authHeadersA });
  assert(fakeAdminRes.status === 403, 'Store Owner REJECTED from /api/v1/admin/dashboard (403 Forbidden)');

  // Login as Super Admin
  const superAdminLoginRes = await apiRequest('/auth/admin-login', {
    method: 'POST',
    body: JSON.stringify({ email: 'superadmin@westsides.com', password: 'Westsides@SuperAdmin2026!' })
  });
  assert(superAdminLoginRes.status === 200, 'Super Admin authenticated');
  const adminToken = superAdminLoginRes.data.token;
  const adminHeaders = { 'Authorization': `Bearer ${adminToken}` };

  // View platform dashboard
  const adminDashRes = await apiRequest('/admin/dashboard', { headers: adminHeaders });
  assert(adminDashRes.status === 200, 'Super Admin retrieves platform dashboard');

  // Suspend Store A
  const suspendRes = await apiRequest(`/admin/stores/${storeAId}/suspend`, {
    method: 'POST',
    headers: adminHeaders,
    body: JSON.stringify({ reason: 'Compliance audit test' })
  });
  assert(suspendRes.status === 200, 'Super Admin suspends Store A');

  // Verify Store A user is BLOCKED from making requests with STORE_SUSPENDED
  const blockedMeRes = await apiRequest('/auth/me', { headers: authHeadersA });
  assert(blockedMeRes.status === 403, 'Suspended Store A user BLOCKED with HTTP 403');
  assert(blockedMeRes.data.code === 'STORE_SUSPENDED', 'Error code is STORE_SUSPENDED');

  // Reactivate Store A
  const reactivateRes = await apiRequest(`/admin/stores/${storeAId}/reactivate`, {
    method: 'POST',
    headers: adminHeaders
  });
  assert(reactivateRes.status === 200, 'Super Admin reactivates Store A');

  // Verify Store A user can access again
  const unblockedMeRes = await apiRequest('/auth/me', { headers: authHeadersA });
  assert(unblockedMeRes.status === 200, 'Reactivated Store A user permitted access again');

  // ── IDEMPOTENCY / DUPLICATE PROTECTION AUDIT ──────────────────────────────
  console.log('\n--- 9. Idempotency & Duplicate Submission Audit ---');
  const idempotencyKey = `idemp_${ts}_${Math.random()}`;

  // Complete a sale with Idempotency-Key
  const idempSalePayload = {
    idempotencyKey: idempotencyKey,
    items: [{ variantId, quantity: 1, unitPrice: 999 }],
    paymentMethod: 'CASH',
    paymentAmount: 999
  };

  const idempRes1 = await apiRequest('/pos/sales', {
    method: 'POST',
    headers: { ...authHeadersA, 'Idempotency-Key': idempotencyKey },
    body: JSON.stringify(idempSalePayload)
  });
  assert(idempRes1.status === 201, 'First sale with idempotency key succeeds');
  const firstSaleId = idempRes1.data.sale.id;

  // Immediate retry with identical Idempotency-Key
  const idempRes2 = await apiRequest('/pos/sales', {
    method: 'POST',
    headers: { ...authHeadersA, 'Idempotency-Key': idempotencyKey },
    body: JSON.stringify(idempSalePayload)
  });
  assert(idempRes2.status === 201, 'Second request with same idempotency key succeeds');
  assert(idempRes2.data.sale.id === firstSaleId, 'Returned cached sale ID without creating duplicate');
  assert(idempRes2.headers.get('x-idempotent-replay') === 'true', 'Header X-Idempotent-Replay confirmed');

  // Check stock decreased by only 1 (from 9 to 8, NOT to 7)
  const idempProdRes = await apiRequest(`/products/${productId}`, { headers: authHeadersA });
  const idempVariant = idempProdRes.data.product.variants.find(v => v.id === variantId);
  assert(idempVariant && idempVariant.stock === 8, `Stock deducted exactly once (stock: ${idempVariant?.stock}, expected 8)`);

  console.log('\n=================================================================');
  console.log(`🎉 ALL ${passedCount}/${totalCount} PHASE 8 END-TO-END ACCEPTANCE TESTS PASSED!`);
  console.log('=================================================================\n');
}

runTestSuite().catch(err => {
  console.error('\n❌ Test Suite Aborted with Error:', err);
  process.exit(1);
});
