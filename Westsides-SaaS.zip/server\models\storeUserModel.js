const crypto = require('crypto');
const db = require('../db/database');
const { ROLES } = require('../constants/roles');

const StoreUserModel = {
  create: ({ storeId, userId, role = ROLES.OWNER }) => {
    const id = 'su_' + crypto.randomBytes(8).toString('hex');
    const now = new Date().toISOString();

    const stmt = db.prepare(`
      INSERT INTO store_users (id, storeId, userId, role, createdAt)
      VALUES (?, ?, ?, ?, ?)
    `);

    stmt.run(id, storeId, userId, role, now);
    return StoreUserModel.findById(id);
  },

  findById: (id) => {
    const stmt = db.prepare('SELECT * FROM store_users WHERE id = ?');
    return stmt.get(id) || null;
  },

  findByUserAndStore: (userId, storeId) => {
    const stmt = db.prepare(`
      SELECT su.*, s.name as storeName, s.onboardingCompleted, s.onboardingStep
      FROM store_users su
      JOIN stores s ON su.storeId = s.id
      WHERE su.userId = ? AND su.storeId = ?
    `);
    return stmt.get(userId, storeId) || null;
  },

  getStoresForUser: (userId) => {
    const stmt = db.prepare(`
      SELECT s.*, su.role, su.status as staffStatus, su.createdAt as joinedAt
      FROM store_users su
      JOIN stores s ON su.storeId = s.id
      WHERE su.userId = ?
      ORDER BY su.createdAt ASC
    `);
    return stmt.all(userId).map(store => ({
      ...store,
      onboardingCompleted: Boolean(store.onboardingCompleted)
    }));
  },

  getUsersForStore: (storeId) => {
    const stmt = db.prepare(`
      SELECT u.id, u.name, u.email, u.phone, su.role, su.status as staffStatus, su.createdAt as joinedAt, su.lastLoginAt
      FROM store_users su
      JOIN users u ON su.userId = u.id
      WHERE su.storeId = ?
      ORDER BY su.createdAt ASC
    `);
    return stmt.all(storeId);
  }
};

module.exports = StoreUserModel;
