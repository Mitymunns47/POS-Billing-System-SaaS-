const crypto = require('crypto');
const db = require('../db/database');

const CategoryModel = {
  create: ({ storeId, name, description = '' }) => {
    const id = 'cat_' + crypto.randomBytes(8).toString('hex');
    const now = new Date().toISOString();
    db.prepare(`
      INSERT INTO categories (id, storeId, name, description, active, createdAt, updatedAt)
      VALUES (?, ?, ?, ?, 1, ?, ?)
    `).run(id, storeId, name.trim(), description.trim(), now, now);
    return CategoryModel.findById(id, storeId);
  },

  findById: (id, storeId) => {
    const row = db.prepare('SELECT * FROM categories WHERE id = ? AND storeId = ?').get(id, storeId);
    return row ? { ...row, active: Boolean(row.active) } : null;
  },

  findAll: (storeId, includeInactive = false) => {
    const sql = includeInactive
      ? 'SELECT * FROM categories WHERE storeId = ? ORDER BY name ASC'
      : 'SELECT * FROM categories WHERE storeId = ? AND active = 1 ORDER BY name ASC';
    return db.prepare(sql).all(storeId).map(r => ({ ...r, active: Boolean(r.active) }));
  },

  update: (id, storeId, { name, description, active }) => {
    const now = new Date().toISOString();
    const current = CategoryModel.findById(id, storeId);
    if (!current) return null;
    db.prepare(`
      UPDATE categories
      SET name = COALESCE(?, name),
          description = COALESCE(?, description),
          active = COALESCE(?, active),
          updatedAt = ?
      WHERE id = ? AND storeId = ?
    `).run(
      name !== undefined ? name.trim() : null,
      description !== undefined ? description.trim() : null,
      active !== undefined ? (active ? 1 : 0) : null,
      now, id, storeId
    );
    return CategoryModel.findById(id, storeId);
  },

  delete: (id, storeId) => {
    // Soft delete — set active = 0
    const now = new Date().toISOString();
    const info = db.prepare(
      'UPDATE categories SET active = 0, updatedAt = ? WHERE id = ? AND storeId = ?'
    ).run(now, id, storeId);
    return info.changes > 0;
  },

  checkDuplicate: (storeId, name, excludeId = null) => {
    const sql = excludeId
      ? 'SELECT id FROM categories WHERE storeId = ? AND name = ? AND id != ? COLLATE NOCASE'
      : 'SELECT id FROM categories WHERE storeId = ? AND name = ? COLLATE NOCASE';
    const params = excludeId ? [storeId, name.trim(), excludeId] : [storeId, name.trim()];
    return !!db.prepare(sql).get(...params);
  }
};

module.exports = CategoryModel;
