const crypto = require('crypto');
const db = require('../db/database');

const PlatformAuditModel = {
  log: ({ adminId, adminEmail, action, targetType = null, targetId = null, targetName = null, description, metadata = null, ipAddress = null }) => {
    const id = 'pal_' + crypto.randomBytes(8).toString('hex');
    const now = new Date().toISOString();
    const metaStr = metadata ? JSON.stringify(metadata) : null;
    db.prepare(`
      INSERT INTO platform_audit_logs
      (id, adminId, adminEmail, action, targetType, targetId, targetName, description, metadata, ipAddress, createdAt)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `).run(id, adminId, adminEmail, action, targetType, targetId, targetName, description, metaStr, ipAddress, now);
    return { id };
  },

  list: ({ limit = 100, offset = 0, action = null, targetType = null } = {}) => {
    let where = '';
    const params = [];
    const conditions = [];
    if (action) { conditions.push('action = ?'); params.push(action); }
    if (targetType) { conditions.push('targetType = ?'); params.push(targetType); }
    if (conditions.length) where = 'WHERE ' + conditions.join(' AND ');
    params.push(limit, offset);
    return db.prepare(`
      SELECT * FROM platform_audit_logs
      ${where}
      ORDER BY createdAt DESC LIMIT ? OFFSET ?
    `).all(...params);
  },

  countTotal: () => {
    return db.prepare('SELECT COUNT(*) as cnt FROM platform_audit_logs').get().cnt;
  }
};

module.exports = PlatformAuditModel;
