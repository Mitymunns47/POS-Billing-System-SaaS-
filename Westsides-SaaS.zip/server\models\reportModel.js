const db = require('../db/database');

/**
 * Helper to compute date range ISO strings for SQLite queries
 */
function resolveDateRange(range = 'last30days', customStart = '', customEnd = '') {
  const now = new Date();
  let start = new Date();
  let end = new Date();
  let prevStart = new Date();
  let prevEnd = new Date();

  // Reset end to end of today
  end.setHours(23, 59, 59, 999);

  switch (range) {
    case 'today': {
      start.setHours(0, 0, 0, 0);
      // Previous period: yesterday
      prevStart.setDate(prevStart.getDate() - 1);
      prevStart.setHours(0, 0, 0, 0);
      prevEnd.setDate(prevEnd.getDate() - 1);
      prevEnd.setHours(23, 59, 59, 999);
      break;
    }
    case 'yesterday': {
      start.setDate(start.getDate() - 1);
      start.setHours(0, 0, 0, 0);
      end.setDate(end.getDate() - 1);
      end.setHours(23, 59, 59, 999);
      // Previous period: 2 days ago
      prevStart.setDate(prevStart.getDate() - 2);
      prevStart.setHours(0, 0, 0, 0);
      prevEnd.setDate(prevEnd.getDate() - 2);
      prevEnd.setHours(23, 59, 59, 999);
      break;
    }
    case 'last7days': {
      start.setDate(start.getDate() - 6);
      start.setHours(0, 0, 0, 0);
      // Previous 7 days
      prevStart.setDate(prevStart.getDate() - 13);
      prevStart.setHours(0, 0, 0, 0);
      prevEnd.setDate(prevEnd.getDate() - 7);
      prevEnd.setHours(23, 59, 59, 999);
      break;
    }
    case 'last30days': {
      start.setDate(start.getDate() - 29);
      start.setHours(0, 0, 0, 0);
      // Previous 30 days
      prevStart.setDate(prevStart.getDate() - 59);
      prevStart.setHours(0, 0, 0, 0);
      prevEnd.setDate(prevEnd.getDate() - 30);
      prevEnd.setHours(23, 59, 59, 999);
      break;
    }
    case 'thismonth': {
      start = new Date(now.getFullYear(), now.getMonth(), 1, 0, 0, 0, 0);
      // Previous month
      prevStart = new Date(now.getFullYear(), now.getMonth() - 1, 1, 0, 0, 0, 0);
      prevEnd = new Date(now.getFullYear(), now.getMonth(), 0, 23, 59, 59, 999);
      break;
    }
    case 'lastmonth': {
      start = new Date(now.getFullYear(), now.getMonth() - 1, 1, 0, 0, 0, 0);
      end = new Date(now.getFullYear(), now.getMonth(), 0, 23, 59, 59, 999);
      // 2 months ago
      prevStart = new Date(now.getFullYear(), now.getMonth() - 2, 1, 0, 0, 0, 0);
      prevEnd = new Date(now.getFullYear(), now.getMonth() - 1, 0, 23, 59, 59, 999);
      break;
    }
    case 'thisyear': {
      start = new Date(now.getFullYear(), 0, 1, 0, 0, 0, 0);
      // Last year
      prevStart = new Date(now.getFullYear() - 1, 0, 1, 0, 0, 0, 0);
      prevEnd = new Date(now.getFullYear() - 1, 11, 31, 23, 59, 59, 999);
      break;
    }
    case 'all': {
      start = new Date('2020-01-01T00:00:00.000Z');
      end = new Date('2099-12-31T23:59:59.999Z');
      prevStart = new Date('2020-01-01T00:00:00.000Z');
      prevEnd = new Date('2020-01-01T00:00:00.000Z');
      break;
    }
    case 'custom': {
      if (customStart) {
        start = new Date(customStart);
        start.setHours(0, 0, 0, 0);
      } else {
        start.setDate(start.getDate() - 29);
        start.setHours(0, 0, 0, 0);
      }
      if (customEnd) {
        end = new Date(customEnd);
        end.setHours(23, 59, 59, 999);
      }
      const diffMs = end.getTime() - start.getTime();
      prevEnd = new Date(start.getTime() - 1);
      prevStart = new Date(prevEnd.getTime() - diffMs);
      break;
    }
    default:
      start.setDate(start.getDate() - 29);
      start.setHours(0, 0, 0, 0);
  }

  return {
    startStr: start.toISOString(),
    endStr: end.toISOString(),
    prevStartStr: prevStart.toISOString(),
    prevEndStr: prevEnd.toISOString(),
    startDateLabel: start.toISOString().split('T')[0],
    endDateLabel: end.toISOString().split('T')[0]
  };
}

const ReportModel = {
  resolveDateRange,

  /**
   * 1. MAIN DASHBOARD BUSINESS INTELLIGENCE OVERVIEW
   */
  getDashboardOverview: (storeId, { range = 'today', startDate = '', endDate = '' } = {}) => {
    const dates = resolveDateRange(range, startDate, endDate);

    // Today's specific metrics
    const todayDates = resolveDateRange('today');
    const todayRow = db.prepare(`
      SELECT
        COUNT(*) as count,
        COALESCE(SUM(totalAmount), 0) as revenue
      FROM sales
      WHERE storeId = ? AND status = 'COMPLETED' AND createdAt >= ? AND createdAt <= ?
    `).get(storeId, todayDates.startStr, todayDates.endStr);

    const yesterdayRow = db.prepare(`
      SELECT
        COUNT(*) as count,
        COALESCE(SUM(totalAmount), 0) as revenue
      FROM sales
      WHERE storeId = ? AND status = 'COMPLETED' AND createdAt >= ? AND createdAt <= ?
    `).get(storeId, todayDates.prevStartStr, todayDates.prevEndStr);

    // Selected period metrics
    const currentPeriodRow = db.prepare(`
      SELECT
        COUNT(*) as count,
        COALESCE(SUM(totalAmount), 0) as revenue,
        COALESCE(SUM(discountAmount), 0) as discount,
        COALESCE(SUM(taxAmount), 0) as tax
      FROM sales
      WHERE storeId = ? AND status = 'COMPLETED' AND createdAt >= ? AND createdAt <= ?
    `).get(storeId, dates.startStr, dates.endStr);

    const prevPeriodRow = db.prepare(`
      SELECT
        COUNT(*) as count,
        COALESCE(SUM(totalAmount), 0) as revenue
      FROM sales
      WHERE storeId = ? AND status = 'COMPLETED' AND createdAt >= ? AND createdAt <= ?
    `).get(storeId, dates.prevStartStr, dates.prevEndStr);

    // Lifetime store revenue
    const lifetimeRow = db.prepare(`
      SELECT
        COUNT(*) as totalOrders,
        COALESCE(SUM(totalAmount), 0) as totalRevenue
      FROM sales
      WHERE storeId = ? AND status = 'COMPLETED'
    `).get(storeId);

    // Catalog & stock indicators
    const productStats = db.prepare(`
      SELECT
        COUNT(DISTINCT p.id) as totalProducts,
        COALESCE(SUM(pv.stock), 0) as totalStockUnits
      FROM products p
      LEFT JOIN product_variants pv ON p.id = pv.productId AND pv.active = 1
      WHERE p.storeId = ? AND p.archived = 0 AND p.active = 1
    `).get(storeId);

    const lowStockCount = db.prepare(`
      SELECT COUNT(*) as count
      FROM product_variants pv
      JOIN products p ON pv.productId = p.id
      WHERE pv.storeId = ? AND pv.active = 1 AND p.archived = 0 AND p.active = 1
        AND pv.stock <= pv.minimumStock AND pv.stock > 0
    `).get(storeId).count;

    const outOfStockCount = db.prepare(`
      SELECT COUNT(*) as count
      FROM product_variants pv
      JOIN products p ON pv.productId = p.id
      WHERE pv.storeId = ? AND pv.active = 1 AND p.archived = 0 AND p.active = 1
        AND pv.stock = 0
    `).get(storeId).count;

    // Customer count
    const customerCount = db.prepare(`
      SELECT COUNT(*) as count FROM customers WHERE storeId = ? AND status = 'ACTIVE'
    `).get(storeId).count;

    // Active staff count
    const staffCount = db.prepare(`
      SELECT COUNT(*) as count FROM store_users WHERE storeId = ? AND status = 'ACTIVE'
    `).get(storeId).count;

    // Payment methods breakdown for selected period
    const paymentRows = db.prepare(`
      SELECT
        paymentMethod,
        COUNT(*) as count,
        COALESCE(SUM(totalAmount), 0) as amount
      FROM sales
      WHERE storeId = ? AND status = 'COMPLETED' AND createdAt >= ? AND createdAt <= ?
      GROUP BY paymentMethod
    `).all(storeId, dates.startStr, dates.endStr);

    // Returns in period
    const periodReturnsRow = db.prepare(`
      SELECT COUNT(*) as returnCount, COALESCE(SUM(totalRefundAmount), 0) as totalRefunds
      FROM returns
      WHERE storeId = ? AND status != 'CANCELLED' AND createdAt >= ? AND createdAt <= ?
    `).get(storeId, dates.startStr, dates.endStr);
    const periodRefunds = Number(periodReturnsRow?.totalRefunds) || 0;
    const periodReturnCount = Number(periodReturnsRow?.returnCount) || 0;

    const periodRevenue = Number(currentPeriodRow?.revenue) || 0;
    const payments = ['CASH', 'UPI', 'CARD'].map(pm => {
      const found = paymentRows.find(r => r.paymentMethod === pm);
      const amount = found ? Number(found.amount) : 0;
      const count = found ? Number(found.count) : 0;
      const percentage = periodRevenue > 0 ? Number(((amount / periodRevenue) * 100).toFixed(1)) : 0;
      return { method: pm, amount, count, percentage };
    });

    // Top selling products in selected period
    const topProducts = db.prepare(`
      SELECT
        si.productNameSnapshot as productName,
        si.skuSnapshot as sku,
        SUM(si.quantity) as unitsSold,
        COALESCE(SUM(si.lineTotal), 0) as revenue
      FROM sale_items si
      JOIN sales s ON si.saleId = s.id
      WHERE s.storeId = ? AND s.status = 'COMPLETED' AND s.createdAt >= ? AND s.createdAt <= ?
      GROUP BY si.productId, si.productNameSnapshot
      ORDER BY unitsSold DESC, revenue DESC
      LIMIT 5
    `).all(storeId, dates.startStr, dates.endStr).map(r => ({
      ...r,
      unitsSold: Number(r.unitsSold),
      revenue: Number(r.revenue)
    }));

    // Recent 5 sales
    const recentSales = db.prepare(`
      SELECT
        s.id, s.invoiceNumber, c.name as customerName, s.customerId, s.cashierName,
        s.totalAmount, s.paymentMethod, s.status, s.createdAt
      FROM sales s
      LEFT JOIN customers c ON s.customerId = c.id
      WHERE s.storeId = ?
      ORDER BY s.createdAt DESC
      LIMIT 5
    `).all(storeId).map(s => ({
      ...s,
      totalAmount: Number(s.totalAmount)
    }));

    // Recent 5 activity logs
    const recentActivity = db.prepare(`
      SELECT id, userName, action, module, description, createdAt
      FROM activity_logs
      WHERE storeId = ?
      ORDER BY createdAt DESC
      LIMIT 5
    `).all(storeId);

    // Sales timeline chart for selected period
    const timeline = ReportModel.getSalesTimeline(storeId, dates.startStr, dates.endStr);

    // Calculate comparisons safely
    const todayRev = Number(todayRow?.revenue) || 0;
    const yestRev = Number(yesterdayRow?.revenue) || 0;
    const todayOrders = Number(todayRow?.count) || 0;
    const yestOrders = Number(yesterdayRow?.count) || 0;

    let revenueChangePercent = null;
    if (yestRev > 0) {
      revenueChangePercent = Number((((todayRev - yestRev) / yestRev) * 100).toFixed(1));
    } else if (todayRev > 0) {
      revenueChangePercent = 100;
    }

    let orderChangePercent = null;
    if (yestOrders > 0) {
      orderChangePercent = Number((((todayOrders - yestOrders) / yestOrders) * 100).toFixed(1));
    } else if (todayOrders > 0) {
      orderChangePercent = 100;
    }

    return {
      range,
      startDate: dates.startDateLabel,
      endDate: dates.endDateLabel,
      kpis: {
        todaySales: todayRev,
        todayOrders: todayOrders,
        yesterdaySales: yestRev,
        yesterdayOrders: yestOrders,
        todayVsYesterdayRevPercent: revenueChangePercent,
        todayVsYesterdayOrderPercent: orderChangePercent,
        periodRevenue: periodRevenue,
        periodRefunds: periodRefunds,
        periodReturnCount: periodReturnCount,
        periodNetRevenue: Math.max(0, periodRevenue - periodRefunds),
        periodOrders: Number(currentPeriodRow?.count) || 0,
        periodAverageOrderValue: Number(currentPeriodRow?.count) > 0 ? Number((periodRevenue / Number(currentPeriodRow.count)).toFixed(2)) : 0,
        lifetimeRevenue: Number(lifetimeRow?.totalRevenue) || 0,
        lifetimeOrders: Number(lifetimeRow?.totalOrders) || 0,
        totalCustomers: customerCount,
        activeStaff: staffCount,
        totalProducts: Number(productStats?.totalProducts) || 0,
        totalStockUnits: Number(productStats?.totalStockUnits) || 0,
        lowStockCount,
        outOfStockCount
      },
      timeline,
      payments,
      topProducts,
      recentSales,
      recentActivity
    };
  },

  /**
   * Helper: timeline points for charts
   */
  getSalesTimeline: (storeId, startStr, endStr) => {
    const rows = db.prepare(`
      SELECT
        substr(createdAt, 1, 10) as date,
        COUNT(*) as orders,
        COALESCE(SUM(totalAmount), 0) as revenue
      FROM sales
      WHERE storeId = ? AND status = 'COMPLETED' AND createdAt >= ? AND createdAt <= ?
      GROUP BY substr(createdAt, 1, 10)
      ORDER BY date ASC
    `).all(storeId, startStr, endStr);

    return rows.map(r => ({
      date: r.date,
      label: r.date.split('-').slice(1).join('/'), // MM/DD
      orders: Number(r.orders),
      revenue: Number(r.revenue)
    }));
  },

  /**
   * 2. DETAILED SALES REPORT (/reports/sales)
   */
  getSalesReport: (storeId, { range = 'last30days', startDate = '', endDate = '', groupBy = 'day' } = {}) => {
    const dates = resolveDateRange(range, startDate, endDate);

    // Main aggregates
    const summaryRow = db.prepare(`
      SELECT
        COUNT(*) as orderCount,
        COALESCE(SUM(subtotal), 0) as grossSales,
        COALESCE(SUM(discountAmount), 0) as totalDiscounts,
        COALESCE(SUM(taxAmount), 0) as totalTax,
        COALESCE(SUM(totalAmount), 0) as netSales
      FROM sales
      WHERE storeId = ? AND status = 'COMPLETED' AND createdAt >= ? AND createdAt <= ?
    `).get(storeId, dates.startStr, dates.endStr);

    const itemsRow = db.prepare(`
      SELECT COALESCE(SUM(si.quantity), 0) as itemsSold
      FROM sale_items si
      JOIN sales s ON si.saleId = s.id
      WHERE s.storeId = ? AND s.status = 'COMPLETED' AND s.createdAt >= ? AND s.createdAt <= ?
    `).get(storeId, dates.startStr, dates.endStr);

    // Returns in period
    const returnsRow = db.prepare(`
      SELECT COUNT(*) as returnCount, COALESCE(SUM(totalRefundAmount), 0) as totalRefunds
      FROM returns
      WHERE storeId = ? AND status != 'CANCELLED' AND createdAt >= ? AND createdAt <= ?
    `).get(storeId, dates.startStr, dates.endStr);
    const totalRefunds = Number(returnsRow?.totalRefunds) || 0;
    const returnCount = Number(returnsRow?.returnCount) || 0;

    const orderCount = Number(summaryRow?.orderCount) || 0;
    const grossSales = Number(summaryRow?.grossSales) || 0;
    const totalDiscounts = Number(summaryRow?.totalDiscounts) || 0;
    const totalTax = Number(summaryRow?.totalTax) || 0;
    const netSales = Math.max(0, Math.round(((grossSales - totalDiscounts - totalRefunds) + totalTax) * 100) / 100);
    const itemsSold = Number(itemsRow?.itemsSold) || 0;
    const averageOrderValue = orderCount > 0 ? Number((netSales / orderCount).toFixed(2)) : 0;

    // Timeline grouping by day
    const timeline = ReportModel.getSalesTimeline(storeId, dates.startStr, dates.endStr);

    // Payment distribution
    const paymentRows = db.prepare(`
      SELECT
        paymentMethod,
        COUNT(*) as count,
        COALESCE(SUM(totalAmount), 0) as amount
      FROM sales
      WHERE storeId = ? AND status = 'COMPLETED' AND createdAt >= ? AND createdAt <= ?
      GROUP BY paymentMethod
    `).all(storeId, dates.startStr, dates.endStr);

    const payments = ['CASH', 'UPI', 'CARD'].map(pm => {
      const found = paymentRows.find(r => r.paymentMethod === pm);
      const amount = found ? Number(found.amount) : 0;
      const count = found ? Number(found.count) : 0;
      const percentage = netSales > 0 ? Number(((amount / netSales) * 100).toFixed(1)) : 0;
      return { method: pm, amount, count, percentage };
    });

    // Recent / Detailed sales in range for table export
    const sales = db.prepare(`
      SELECT
        s.id, s.invoiceNumber, c.name as customerName, s.cashierName, s.subtotal,
        s.discountAmount, s.taxAmount, s.totalAmount, s.paymentMethod, s.status, s.createdAt
      FROM sales s
      LEFT JOIN customers c ON s.customerId = c.id
      WHERE s.storeId = ? AND s.status = 'COMPLETED' AND s.createdAt >= ? AND s.createdAt <= ?
      ORDER BY s.createdAt DESC
      LIMIT 100
    `).all(storeId, dates.startStr, dates.endStr).map(s => ({
      ...s,
      subtotal: Number(s.subtotal),
      discountAmount: Number(s.discountAmount),
      taxAmount: Number(s.taxAmount),
      totalAmount: Number(s.totalAmount)
    }));

    return {
      range,
      startDate: dates.startDateLabel,
      endDate: dates.endDateLabel,
      summary: {
        grossSales,
        discounts: totalDiscounts,
        refunds: totalRefunds,
        returnCount,
        tax: totalTax,
        netSales,
        orderCount,
        averageOrderValue,
        itemsSold
      },
      timeline,
      payments,
      sales
    };
  },

  /**
   * 3. TOP-SELLING PRODUCTS & CATEGORY PERFORMANCE (/reports/products)
   */
  getProductReport: (storeId, { range = 'last30days', startDate = '', endDate = '', categoryId = '', sortBy = 'revenue', sortDir = 'DESC' } = {}) => {
    const dates = resolveDateRange(range, startDate, endDate);

    const conditions = ['s.storeId = ?', "s.status = 'COMPLETED'", 's.createdAt >= ?', 's.createdAt <= ?'];
    const params = [storeId, dates.startStr, dates.endStr];

    if (categoryId) {
      conditions.push('p.categoryId = ?');
      params.push(categoryId);
    }

    const where = conditions.join(' AND ');

    const orderCol = sortBy === 'units' ? 'unitsSold' : 'revenue';
    const direction = sortDir.toUpperCase() === 'ASC' ? 'ASC' : 'DESC';

    const products = db.prepare(`
      SELECT
        si.productId,
        si.productNameSnapshot as productName,
        si.skuSnapshot as sku,
        c.name as categoryName,
        b.name as brandName,
        SUM(si.quantity) as unitsSold,
        COALESCE(SUM(si.lineTotal), 0) as revenue
      FROM sale_items si
      JOIN sales s ON si.saleId = s.id
      LEFT JOIN products p ON si.productId = p.id
      LEFT JOIN categories c ON p.categoryId = c.id
      LEFT JOIN brands b ON p.brandId = b.id
      WHERE ${where}
      GROUP BY si.productId, si.productNameSnapshot, si.skuSnapshot
      ORDER BY ${orderCol} ${direction}
      LIMIT 50
    `).all(...params).map(r => {
      const units = Number(r.unitsSold) || 0;
      const rev = Number(r.revenue) || 0;
      return {
        ...r,
        unitsSold: units,
        revenue: rev,
        avgSellingPrice: units > 0 ? Number((rev / units).toFixed(2)) : 0
      };
    });

    // Total sales in this period for percentage calculation
    const totalRevRow = db.prepare(`
      SELECT COALESCE(SUM(lineTotal), 0) as total
      FROM sale_items si
      JOIN sales s ON si.saleId = s.id
      WHERE s.storeId = ? AND s.status = 'COMPLETED' AND s.createdAt >= ? AND s.createdAt <= ?
    `).get(storeId, dates.startStr, dates.endStr);
    const totalPeriodSales = Number(totalRevRow?.total) || 0;

    // Category performance
    const categoryRows = db.prepare(`
      SELECT
        COALESCE(c.name, 'Uncategorized') as categoryName,
        SUM(si.quantity) as unitsSold,
        COALESCE(SUM(si.lineTotal), 0) as revenue
      FROM sale_items si
      JOIN sales s ON si.saleId = s.id
      LEFT JOIN products p ON si.productId = p.id
      LEFT JOIN categories c ON p.categoryId = c.id
      WHERE s.storeId = ? AND s.status = 'COMPLETED' AND s.createdAt >= ? AND s.createdAt <= ?
      GROUP BY COALESCE(c.name, 'Uncategorized')
      ORDER BY revenue DESC
    `).all(storeId, dates.startStr, dates.endStr);

    const categories = categoryRows.map(c => {
      const rev = Number(c.revenue) || 0;
      return {
        categoryName: c.categoryName,
        unitsSold: Number(c.unitsSold) || 0,
        revenue: rev,
        percentage: totalPeriodSales > 0 ? Number(((rev / totalPeriodSales) * 100).toFixed(1)) : 0
      };
    });

    return {
      range,
      startDate: dates.startDateLabel,
      endDate: dates.endDateLabel,
      totalPeriodSales,
      products,
      categories
    };
  },

  /**
   * 4. INVENTORY ANALYTICS & VALUATIONS (/reports/inventory)
   */
  getInventoryReport: (storeId, { statusFilter = 'ALL', page = 1, limit = 50 } = {}) => {
    // Total products count
    const totalProducts = db.prepare(`
      SELECT COUNT(*) as count FROM products WHERE storeId = ? AND archived = 0 AND active = 1
    `).get(storeId).count;

    // Total stock units
    const totalStock = db.prepare(`
      SELECT COALESCE(SUM(pv.stock), 0) as count
      FROM product_variants pv
      JOIN products p ON pv.productId = p.id
      WHERE pv.storeId = ? AND pv.active = 1 AND p.archived = 0 AND p.active = 1
    `).get(storeId).count;

    // Inventory cost valuation: SUM(pv.stock * p.costPrice)
    const costValuationRow = db.prepare(`
      SELECT COALESCE(SUM(pv.stock * COALESCE(p.costPrice, 0)), 0) as costValue
      FROM product_variants pv
      JOIN products p ON pv.productId = p.id
      WHERE pv.storeId = ? AND pv.active = 1 AND p.archived = 0 AND p.active = 1
    `).get(storeId);

    // Potential retail valuation: SUM(pv.stock * COALESCE(pv.price, p.sellingPrice, 0))
    const retailValuationRow = db.prepare(`
      SELECT COALESCE(SUM(pv.stock * COALESCE(pv.price, p.sellingPrice, 0)), 0) as retailValue
      FROM product_variants pv
      JOIN products p ON pv.productId = p.id
      WHERE pv.storeId = ? AND pv.active = 1 AND p.archived = 0 AND p.active = 1
    `).get(storeId);

    // Counts for stock statuses
    const lowStockCount = db.prepare(`
      SELECT COUNT(*) as count
      FROM product_variants pv
      JOIN products p ON pv.productId = p.id
      WHERE pv.storeId = ? AND pv.active = 1 AND p.archived = 0 AND p.active = 1
        AND pv.stock <= pv.minimumStock AND pv.stock > 0
    `).get(storeId).count;

    const outOfStockCount = db.prepare(`
      SELECT COUNT(*) as count
      FROM product_variants pv
      JOIN products p ON pv.productId = p.id
      WHERE pv.storeId = ? AND pv.active = 1 AND p.archived = 0 AND p.active = 1
        AND pv.stock = 0
    `).get(storeId).count;

    // Low stock / out-of-stock items listing
    const stockConditions = [
      'pv.storeId = ?',
      'pv.active = 1',
      'p.archived = 0',
      'p.active = 1'
    ];
    if (statusFilter === 'LOW_STOCK') {
      stockConditions.push('pv.stock <= pv.minimumStock AND pv.stock > 0');
    } else if (statusFilter === 'OUT_OF_STOCK') {
      stockConditions.push('pv.stock = 0');
    } else if (statusFilter === 'ALL_ALERTS') {
      stockConditions.push('pv.stock <= pv.minimumStock');
    }

    const lowStockItems = db.prepare(`
      SELECT
        p.id as productId,
        p.name as productName,
        pv.id as variantId,
        COALESCE(pv.sku, p.sku) as sku,
        pv.size,
        pv.color,
        pv.stock as currentStock,
        pv.minimumStock,
        COALESCE(p.costPrice, 0) as costPrice,
        COALESCE(pv.price, p.sellingPrice, 0) as sellingPrice,
        CASE
          WHEN pv.stock = 0 THEN 'OUT OF STOCK'
          WHEN pv.stock <= pv.minimumStock THEN 'LOW STOCK'
          ELSE 'NORMAL'
        END as status
      FROM product_variants pv
      JOIN products p ON pv.productId = p.id
      WHERE ${stockConditions.join(' AND ')}
      ORDER BY
        CASE WHEN pv.stock = 0 THEN 1 WHEN pv.stock <= pv.minimumStock THEN 2 ELSE 3 END,
        pv.stock ASC
      LIMIT ?
    `).all(storeId, limit).map(r => ({
      ...r,
      currentStock: Number(r.currentStock),
      minimumStock: Number(r.minimumStock),
      costPrice: Number(r.costPrice),
      sellingPrice: Number(r.sellingPrice)
    }));

    // Recent inventory audit movements
    const movements = db.prepare(`
      SELECT
        it.id, it.action, it.quantity, it.previousQuantity, it.newQuantity,
        it.reason, it.performedBy, it.note, it.createdAt,
        p.name as productName,
        pv.size, pv.color
      FROM inventory_transactions it
      LEFT JOIN products p ON it.productId = p.id
      LEFT JOIN product_variants pv ON it.variantId = pv.id
      WHERE it.storeId = ?
      ORDER BY it.createdAt DESC
      LIMIT 20
    `).all(storeId);

    return {
      summary: {
        totalProducts,
        totalStockUnits: Number(totalStock),
        lowStockProducts: lowStockCount,
        outOfStockProducts: outOfStockCount,
        inventoryCostValue: Number(costValuationRow?.costValue) || 0,
        potentialRetailValue: Number(retailValuationRow?.retailValue) || 0
      },
      lowStockItems,
      movements
    };
  },

  /**
   * 5. CUSTOMER ANALYTICS & TOP CUSTOMERS (/reports/customers)
   */
  getCustomerReport: (storeId, { range = 'last30days', startDate = '', endDate = '' } = {}) => {
    const dates = resolveDateRange(range, startDate, endDate);

    // Total registered customers
    const totalCustomers = db.prepare(`
      SELECT COUNT(*) as count FROM customers WHERE storeId = ? AND status = 'ACTIVE'
    `).get(storeId).count;

    // New customers in period
    const newCustomers = db.prepare(`
      SELECT COUNT(*) as count
      FROM customers
      WHERE storeId = ? AND status = 'ACTIVE' AND createdAt >= ? AND createdAt <= ?
    `).get(storeId, dates.startStr, dates.endStr).count;

    // Customers who completed a purchase in period
    const activePurchasers = db.prepare(`
      SELECT COUNT(DISTINCT customerId) as count
      FROM sales
      WHERE storeId = ? AND status = 'COMPLETED' AND customerId IS NOT NULL
        AND createdAt >= ? AND createdAt <= ?
    `).get(storeId, dates.startStr, dates.endStr).count;

    // Returning customers (customers with > 1 total completed sales)
    const returningCustomers = db.prepare(`
      SELECT COUNT(*) as count FROM (
        SELECT customerId
        FROM sales
        WHERE storeId = ? AND status = 'COMPLETED' AND customerId IS NOT NULL
        GROUP BY customerId
        HAVING COUNT(*) > 1
      )
    `).get(storeId).count;

    // Total spent across period
    const spendRow = db.prepare(`
      SELECT COALESCE(SUM(totalAmount), 0) as totalSpent
      FROM sales
      WHERE storeId = ? AND status = 'COMPLETED' AND createdAt >= ? AND createdAt <= ?
    `).get(storeId, dates.startStr, dates.endStr);

    const periodSpend = Number(spendRow?.totalSpent) || 0;
    const avgCustomerSpend = activePurchasers > 0 ? Number((periodSpend / activePurchasers).toFixed(2)) : 0;

    // Top customers in period
    const topCustomers = db.prepare(`
      SELECT
        c.id as customerId,
        c.name as customerName,
        c.phone as customerPhone,
        c.email as customerEmail,
        COUNT(s.id) as orders,
        COALESCE(SUM(s.totalAmount), 0) as totalSpent,
        MAX(s.createdAt) as lastPurchaseDate
      FROM customers c
      JOIN sales s ON c.id = s.customerId
      WHERE s.storeId = ? AND s.status = 'COMPLETED' AND s.createdAt >= ? AND s.createdAt <= ?
      GROUP BY c.id, c.name, c.phone, c.email
      ORDER BY totalSpent DESC, orders DESC
      LIMIT 50
    `).all(storeId, dates.startStr, dates.endStr).map(r => ({
      ...r,
      orders: Number(r.orders),
      totalSpent: Number(r.totalSpent)
    }));

    return {
      range,
      startDate: dates.startDateLabel,
      endDate: dates.endDateLabel,
      metrics: {
        totalCustomers,
        newCustomers,
        returningCustomers,
        customersWithPurchases: activePurchasers,
        averageCustomerSpend: avgCustomerSpend
      },
      topCustomers
    };
  },

  /**
   * 6. STAFF PERFORMANCE REPORT (/reports/staff)
   */
  getStaffReport: (storeId, { range = 'last30days', startDate = '', endDate = '' } = {}) => {
    const dates = resolveDateRange(range, startDate, endDate);

    // Objective sales performance per cashier
    const rows = db.prepare(`
      SELECT
        su.userId,
        u.name as staffName,
        u.email as staffEmail,
        su.role as staffRole,
        su.status as staffStatus,
        COUNT(s.id) as ordersCompleted,
        COALESCE(SUM(s.totalAmount), 0) as salesAmount,
        MAX(s.createdAt) as lastSaleDate
      FROM store_users su
      JOIN users u ON su.userId = u.id
      LEFT JOIN sales s ON su.userId = s.cashierId AND s.status = 'COMPLETED'
        AND s.createdAt >= ? AND s.createdAt <= ?
      WHERE su.storeId = ?
      GROUP BY su.userId, u.name, u.email, su.role, su.status
      ORDER BY salesAmount DESC, ordersCompleted DESC
    `).all(dates.startStr, dates.endStr, storeId);

    // Items sold per staff
    const staffPerformance = rows.map(r => {
      const orders = Number(r.ordersCompleted) || 0;
      const sales = Number(r.salesAmount) || 0;

      const itemsSold = db.prepare(`
        SELECT COALESCE(SUM(si.quantity), 0) as items
        FROM sale_items si
        JOIN sales s ON si.saleId = s.id
        WHERE s.storeId = ? AND s.cashierId = ? AND s.status = 'COMPLETED'
          AND s.createdAt >= ? AND s.createdAt <= ?
      `).get(storeId, r.userId, dates.startStr, dates.endStr).items;

      return {
        userId: r.userId,
        staffName: r.staffName,
        staffEmail: r.staffEmail,
        staffRole: r.staffRole,
        staffStatus: r.staffStatus,
        ordersCompleted: orders,
        itemsSold: Number(itemsSold) || 0,
        salesAmount: sales,
        averageOrderValue: orders > 0 ? Number((sales / orders).toFixed(2)) : 0,
        lastSaleDate: r.lastSaleDate || null
      };
    });

    return {
      range,
      startDate: dates.startDateLabel,
      endDate: dates.endDateLabel,
      staff: staffPerformance
    };
  },

  /**
   * 7. FINANCIAL SUMMARY & MARGINS (/reports/finance)
   */
  getFinanceReport: (storeId, { range, period, startDate = '', endDate = '' } = {}) => {
    const effectiveRange = range || period || 'last30days';
    const dates = resolveDateRange(effectiveRange, startDate, endDate);

    // Sales financial breakdown
    const salesSummary = db.prepare(`
      SELECT
        COUNT(*) as orderCount,
        COALESCE(SUM(subtotal), 0) as grossSales,
        COALESCE(SUM(discountAmount), 0) as totalDiscounts,
        COALESCE(SUM(taxAmount), 0) as totalTax,
        COALESCE(SUM(totalAmount), 0) as netSales
      FROM sales
      WHERE storeId = ? AND status = 'COMPLETED' AND createdAt >= ? AND createdAt <= ?
    `).get(storeId, dates.startStr, dates.endStr);

    const grossSales = Number(salesSummary?.grossSales) || 0;
    const discounts = Number(salesSummary?.totalDiscounts) || 0;
    const taxCollected = Number(salesSummary?.totalTax) || 0;
    const orderCount = Number(salesSummary?.orderCount) || 0;

    // Returns in period
    const returnsSummary = db.prepare(`
      SELECT
        COUNT(*) as returnCount,
        COALESCE(SUM(totalRefundAmount), 0) as totalRefunds
      FROM returns
      WHERE storeId = ? AND status != 'CANCELLED' AND createdAt >= ? AND createdAt <= ?
    `).get(storeId, dates.startStr, dates.endStr);
    const refunds = Number(returnsSummary?.totalRefunds) || 0;
    const returnCount = Number(returnsSummary?.returnCount) || 0;

    const netSales = Math.max(0, Math.round(((grossSales - discounts - refunds) + taxCollected) * 100) / 100);

    // Estimated COGS: SUM(quantity * p.costPrice) where p.costPrice > 0
    const cogsRow = db.prepare(`
      SELECT
        COALESCE(SUM(si.quantity * COALESCE(p.costPrice, 0)), 0) as cogs,
        COUNT(CASE WHEN p.costPrice IS NULL OR p.costPrice = 0 THEN 1 END) as missingCostCount
      FROM sale_items si
      JOIN sales s ON si.saleId = s.id
      LEFT JOIN products p ON si.productId = p.id
      WHERE s.storeId = ? AND s.status = 'COMPLETED' AND s.createdAt >= ? AND s.createdAt <= ?
    `).get(storeId, dates.startStr, dates.endStr);

    const grossEstimatedCOGS = Number(cogsRow?.cogs) || 0;
    const missingCostItems = Number(cogsRow?.missingCostCount) || 0;

    // Deduct COGS of returned items that were restored into sellable inventory (RESELLABLE)
    const returnedCogsRow = db.prepare(`
      SELECT COALESCE(SUM(ri.quantity * COALESCE(p.costPrice, 0)), 0) as returnedCogs
      FROM return_items ri
      JOIN returns r ON ri.returnId = r.id
      LEFT JOIN products p ON ri.productId = p.id
      WHERE r.storeId = ? AND r.status != 'CANCELLED' AND ri.condition = 'RESELLABLE'
        AND r.createdAt >= ? AND r.createdAt <= ?
    `).get(storeId, dates.startStr, dates.endStr);
    const returnedCOGS = Number(returnedCogsRow?.returnedCogs) || 0;
    const estimatedCOGS = Math.max(0, grossEstimatedCOGS - returnedCOGS);

    // Net product sales (excluding taxes) = grossSales - discounts - refunds
    const netProductSales = Math.max(0, Math.round((grossSales - discounts - refunds) * 100) / 100);
    const estimatedGrossProfit = Math.max(0, Math.round((netProductSales - estimatedCOGS) * 100) / 100);
    const grossMarginPercent = netProductSales > 0 ? Number(((estimatedGrossProfit / netProductSales) * 100).toFixed(1)) : 0;

    // Operating expenses from expenses table
    const expenseRow = db.prepare(`
      SELECT COALESCE(SUM(amount), 0) as totalExpenses
      FROM expenses
      WHERE storeId = ? AND status = 'ACTIVE' AND date >= ? AND date <= ?
    `).get(storeId, dates.startDateLabel, dates.endDateLabel);

    const operatingExpenses = Number(expenseRow?.totalExpenses) || 0;
    const estimatedOperatingResult = Number((estimatedGrossProfit - operatingExpenses).toFixed(2));

    const metrics = {
      grossSales,
      discounts,
      refunds,
      returnCount,
      taxCollected,
      netSales,
      netProductSales,
      orderCount,
      estimatedCOGS,
      estimatedGrossProfit,
      grossMarginPercent,
      missingCostItems,
      hasIncompleteCostData: missingCostItems > 0,
      operatingExpenses,
      expenses: operatingExpenses,
      estimatedOperatingResult
    };

    return {
      range,
      startDate: dates.startDateLabel,
      endDate: dates.endDateLabel,
      ...metrics,
      metrics
    };
  }
};

module.exports = ReportModel;
