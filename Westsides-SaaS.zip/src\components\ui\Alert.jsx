import React from 'react';
import { AlertCircle, CheckCircle, Info, XCircle } from 'lucide-react';

export function Alert({ children, variant = 'info', title, className = '', style = {}, onDismiss }) {
  const configs = {
    info: {
      bg: 'var(--info-light)',
      border: '#BFDBFE',
      text: '#1E40AF',
      Icon: Info
    },
    success: {
      bg: 'var(--success-light)',
      border: '#A7F3D0',
      text: '#065F46',
      Icon: CheckCircle
    },
    warning: {
      bg: 'var(--warning-light)',
      border: '#FDE68A',
      text: '#92400E',
      Icon: AlertCircle
    },
    danger: {
      bg: 'var(--danger-light)',
      border: '#FECACA',
      text: '#991B1B',
      Icon: XCircle
    }
  };

  const config = configs[variant] || configs.info;
  const IconComponent = config.Icon;

  return (
    <div
      style={{
        backgroundColor: config.bg,
        border: `1px solid ${config.border}`,
        color: config.text,
        borderRadius: 'var(--radius-md)',
        padding: '0.875rem 1rem',
        display: 'flex',
        alignItems: 'flex-start',
        gap: '0.75rem',
        fontSize: '0.875rem',
        ...style
      }}
      className={className}
      role="alert"
    >
      <IconComponent size={18} style={{ flexShrink: 0, marginTop: '2px' }} />
      <div style={{ flex: 1 }}>
        {title && <div style={{ fontWeight: '600', marginBottom: '2px' }}>{title}</div>}
        <div>{children}</div>
      </div>
      {onDismiss && (
        <button
          onClick={onDismiss}
          style={{
            background: 'none',
            border: 'none',
            color: 'inherit',
            cursor: 'pointer',
            padding: '2px',
            lineHeight: 1
          }}
          aria-label="Dismiss"
        >
          ×
        </button>
      )}
    </div>
  );
}
