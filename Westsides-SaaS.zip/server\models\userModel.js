const crypto = require('crypto');
const bcrypt = require('bcryptjs');
const db = require('../db/database');

const UserModel = {
  create: ({ name, email, phone, password }) => {
    const id = 'usr_' + crypto.randomBytes(8).toString('hex');
    const salt = bcrypt.genSaltSync(10);
    const passwordHash = bcrypt.hashSync(password, salt);
    const now = new Date().toISOString();

    const stmt = db.prepare(`
      INSERT INTO users (id, name, email, phone, passwordHash, createdAt, updatedAt)
      VALUES (?, ?, ?, ?, ?, ?, ?)
    `);

    stmt.run(id, name.trim(), email.trim().toLowerCase(), phone ? phone.trim() : null, passwordHash, now, now);

    return UserModel.findById(id);
  },

  findById: (id) => {
    const stmt = db.prepare('SELECT id, name, email, phone, createdAt, updatedAt FROM users WHERE id = ?');
    return stmt.get(id) || null;
  },

  findByEmail: (email) => {
    const normalized = email.trim().toLowerCase();
    const stmt = db.prepare('SELECT * FROM users WHERE email = ?');
    return stmt.get(normalized) || null;
  },

  verifyPassword: (password, passwordHash) => {
    return bcrypt.compareSync(password, passwordHash);
  },

  updateProfile: (id, { name, phone }) => {
    const now = new Date().toISOString();
    const stmt = db.prepare(`
      UPDATE users SET name = COALESCE(?, name), phone = COALESCE(?, phone), updatedAt = ?
      WHERE id = ?
    `);
    stmt.run(name || null, phone || null, now, id);
    return UserModel.findById(id);
  }
};

module.exports = UserModel;
